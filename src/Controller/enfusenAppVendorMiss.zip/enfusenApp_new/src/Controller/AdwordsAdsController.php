<?php

namespace App\Controller;

ini_set('max_execution_time', 500);
require_once(ROOT . DS . 'vendor' . DS . "adwords" . DS . "vendor" . DS . "autoload.php");

use Google\AdsApi\AdWords\AdWordsServices;
use Google\AdsApi\AdWords\AdWordsSession;
use Google\AdsApi\AdWords\AdWordsSessionBuilder;
use Google\AdsApi\AdWords\v201702\cm\AdGroupAdService;
use Google\AdsApi\AdWords\v201702\cm\AdGroupAdStatus;
use Google\AdsApi\AdWords\v201702\cm\AdType;
use Google\AdsApi\AdWords\v201702\cm\OrderBy;
use Google\AdsApi\AdWords\v201702\cm\Paging;
use Google\AdsApi\AdWords\v201702\cm\Predicate;
use Google\AdsApi\AdWords\v201702\cm\PredicateOperator;
use Google\AdsApi\AdWords\v201702\cm\Selector;
use Google\AdsApi\AdWords\v201702\cm\SortOrder;
use Google\AdsApi\Common\OAuth2TokenBuilder;
use Cake\Core\App;

App::className('Controller', 'AdwordsCampaignController'); // calling Adwords Campaign controller 
App::className('Controller', 'AdwordsDataController');  // calling Adwords Data Controller 

Class AdwordsAdsController extends AppController {

    private $adgroupModel; // variable for store adgroup model 

    /* Function for initialize first  */

    public function initialize() {
        parent::initialize();
        ob_start();

        $this->adgroupModel = $this->loadModel("AdwordsAdgroup");
    }

    /**
     * Date :- 12-june-17
     * Function disc :-  Function for get all ads according   
     * @RudrainnovativePvtLtd 
     */
    public function index($location_id) {

        $obj = new AdwordsDataController; // adwords data controller object 
        $campObj = new AdwordsCampaignController; // adwords campaign controller object 
        // $location_id = 1; // only for testing purpose 

        $subAccountArray = $campObj->getSubaccounts($location_id); // calling function for get subaccounts data 

        if (!empty($subAccountArray)) {
            foreach ($subAccountArray as $val):

                /* Calling adwords services object with session set */
                $adWordsServices = new AdWordsServices();
                $credentials = $obj->credentialBuilder($location_id); // generating credentials 
                $session = $obj->sessionBuilder($credentials, $val['subAccountId']); // creating session

                $campaignArray = $obj->getCampaignId($val['subAccountId']); // calling function for get all campaignids 
                if (!empty($campaignArray)) {

                    /* Loop for get campaign ids for get adgroups related to campaigns */
                    foreach ($campaignArray as $campId):
                        $adgroupData = $this->getAdgroups($campId); // calling function for get adgroup ids a/c to campid

                        foreach ($adgroupData as $value):

                            $adGroupId = $value['adgroup_id'];

                            $adGroupAdService = $adWordsServices->get($session, AdGroupAdService::class);

                            // Create a selector to select all ads for the specified ad group.
                            $selector = new Selector();
                            $selector->setFields(['Id', 'Headline']);
                            $selector->setOrdering([new OrderBy('Headline', SortOrder::ASCENDING)]);
                            // By default disabled ads aren't returned by the selector. To return them
                            // include the DISABLED status in a predicate.
                            $selector->setPredicates([
                                new Predicate('AdGroupId', PredicateOperator::IN, [$adGroupId]),
                                new Predicate('AdType', PredicateOperator::IN, [AdType::TEXT_AD]),
                                new Predicate('Status', PredicateOperator::IN, [AdGroupAdStatus::DISABLED, AdGroupAdStatus::ENABLED,
                                    AdGroupAdStatus::PAUSED])
                            ]);

                            $page = $adGroupAdService->get($selector);

                            if ($page->getEntries() !== null) {

                                $totalNumEntries = $page->getTotalNumEntries();
                                $adsData = []; // blank array for save data into database 

                                foreach ($page->getEntries() as $key => $adGroupAd):

                                    $adsData[$key]["ads_id"] = $adGroupAd->getAd()->getId();
                                    $adsData[$key]["headline"] = $adGroupAd->getAd()->getHeadline();
                                    $adsData[$key]["description1"] = $adGroupAd->getAd()->getDescription1();
                                    $adsData[$key]["description2"] = $adGroupAd->getAd()->getDescription2();
                                    $adsData[$key]["url"] = $adGroupAd->getAd()->getUrl();
                                    $adsData[$key]["displayUrl"] = $adGroupAd->getAd()->getDisplayUrl();
                                    $adsData[$key]["type"] = $adGroupAd->getAd()->getType();
                                    $adsData[$key]["status"] = $adGroupAd->getStatus();
                                    $adsData[$key]["approvalStatus"] = $adGroupAd->getApprovalStatus();
                                    $adsData[$key]["adGroupId"] = $adGroupAd->getAdGroupId();

                                endforeach;
                            }

                            /* database insertion code a/c conditions */
                            if (!empty($adsData)) {

                                foreach ($adsData as $data):

                                    $check = $this->check_db($data["ads_id"]); // calling function for check database 

                                    if ($check == 1) {
                                        $update = []; // empty array for update database with ads data 
                                        $update["location_id"] = $location_id;
                                        $update["parent_adgroup_id"] = $data["adGroupId"];
                                        $update["ads_heading"] = $data["headline"];
                                        $update["description1"] = $data["description1"];
                                        $update["description2"] = $data["description2"];
                                        $update["ads_id"] = $data["ads_id"];
                                        $update["ads_url"] = $data["url"];
                                        $update["ads_display_url"] = $data["displayUrl"];
                                        $update["ads_type"] = $data["type"];
                                        $update["ads_status"] = $data["status"];
                                        $update["ads_approval_status"] = $data["approvalStatus"];
                                        $update["updated_at"] = date('Y-m-d h:i:s');

                                        $query = $this->AdwordsAds->query();
                                        $query->update()->set($update)->where(["location_id" => $location_id, "ads_id" => $data["ads_id"]])->execute();
                                    } else {
                                        $insert = $this->AdwordsAds->newEntity();
                                        $insert->location_id = $location_id;
                                        $insert->parent_adgroup_id = $data["adGroupId"];
                                        $insert->ads_heading = $data["headline"];
                                        $insert->description1 = $data["description1"];
                                        $insert->description2 = $data["description2"];
                                        $insert->ads_id = $data["ads_id"];
                                        $insert->ads_url = $data["url"];
                                        $insert->ads_display_url = $data["displayUrl"];
                                        $insert->ads_type = $data["type"];
                                        $insert->ads_status = $data["status"];
                                        $insert->ads_approval_status = $data["approvalStatus"];
                                        $this->AdwordsAds->save($insert);
                                    }

                                endforeach;
                            }

                        endforeach;

                    endforeach;
                }

            endforeach;
        }
    }

    /**
     * Date :- 12-june-17
     * Function disc :-  function for get all adgroups according to location id  
     * @RudrainnovativePvtLtd 
     */
    private function getAdgroups($campaignId) {

        $returnArray = array(); // blank array to store return data 
        $adgroupData = $this->adgroupModel->find('all')->where(['parent_compaign_id' => $campaignId])->toArray();
        if (!empty($adgroupData)) {
            foreach ($adgroupData as $key => $value):
                $returnArray[$key]['adgroup_id'] = $value->adgroup_id;
            endforeach;
        }

        return $returnArray; // return all adgroup id's 
    }

    /**
     * Date :- 12-june-17
     * Function disc :-  Function for check data is in database or not according to location id  
     * @RudrainnovativePvtLtd 
     */
    private function check_db($ads_id) {

        $dbData = $this->AdwordsAds->find('all')->where(['ads_id' => $ads_id])->all();
        if (iterator_count($dbData)) {
            return 1;
        } else {
            return 0;
        }
    }

}
