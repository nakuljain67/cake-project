<?php

namespace App\Controller;

require_once(ROOT . DS . 'vendor' . DS . "adwords" . DS . "vendor" . DS . "autoload.php");

use Google\AdsApi\AdWords\AdWordsServices;
use Google\AdsApi\AdWords\v201702\cm\CampaignService;
use Google\AdsApi\AdWords\v201702\cm\Selector;
use Cake\Core\App; // use core app controller namespace 

App::className('Controller', 'AdwordsDataController');  // calling AdwordsDataController 

Class AdwordsCampaignController extends AppController {

    /**
     * Date :- 22-may-17 
     * Updated :- 24-may-17 
     * Function disc :- function for get all campaigns and store it into database 
     * @RudrainnovativePvtLtd 
     */
    public function index($location_id) {
        ob_start(); //buffer start 
//        $location_id = 1; // post comes user id 
        $subData = $this->getSubaccounts($location_id);
        $obj = new AdwordsDataController;
        $credential = $obj->credentialBuilder($location_id);

        foreach ($subData as $val):

            $subId = $val['Id']; // setting id form subuser table 
            $subClientId = $val['subAccountId']; // sub user table account id
            $subClientName = $val['subAccountName']; // sub user talbe account name 
            $session = $obj->sessionBuilder($credential, $subClientId);

            $adWordsServices = new AdWordsServices();

            $campaignService = $adWordsServices->get($session, CampaignService::class);

            $selector = new Selector();
            $selector->setFields(['Id', 'Name', 'BudgetId', 'StartDate', 'BudgetName', 'AdServingOptimizationStatus', 'BaseCampaignId', 'Amount', 'CampaignStatus', 'CampaignTrialType', 'ServingStatus', 'EndDate', 'DeliveryMethod', 'EnhancedCpcEnabled', 'EnhancedCpvEnabled', 'IsBudgetExplicitlyShared', 'LabelIds', 'Labels', 'UrlCustomParameters', 'SelectiveOptimization', 'Eligible', 'RejectionReasons', 'BiddingStrategyName', 'BiddingStrategyId', 'BidType', 'AccountDescriptiveName', 'Settings', 'AdvertisingChannelType', 'AdvertisingChannelSubType', 'BudgetStatus', 'BudgetReferenceCount', 'TrackingUrlTemplate']);

            $campaignData = []; // empty array to store adwords campaign data 
            $totalNumEntries = 0;
            $page = $campaignService->get($selector);

            if ($page->getTotalNumEntries() > 0) {
                foreach ($page->getEntries() as $key => $account) {
                    $budget = $account->getBudget();
                    $budgetAmount = $budget->getAmount();
                    $campaignData[$key]["campaignId"] = $account->getId();
                    $campaignData[$key]["campaignName"] = $account->getName();
                    $campaignData[$key]["CampaignStatus"] = $account->getStatus();
                    $campaignData[$key]["CampaignBudgetId"] = $budget->getBudgetId();
                    $campaignData[$key]["CampaignBudgetName"] = $budget->getName();
                    $campaignData[$key]["CampaignBudgetAmount"] = ($budgetAmount->getMicroAmount() > 0) ? $budgetAmount->getMicroAmount() / 1000000 : $budgetAmount->getMicroAmount();
                }
            }

            $total = count($campaignData); // Count total campaign data array to insert data into database 

            if ($total > 0) {
                for ($i = 0; $i < $total; $i++) {
                    
                    $dataCheck = $this->check_db($campaignData[$i]['campaignId'], $location_id); // calling function for check value is in database or not 
                    if($dataCheck == 1)
                    {
                        $update = []; // array for store update data into database 
                        $update["location_id"] = $location_id;
                        $update["sub_client_id"] = $subClientId;
                        $update["campaign_id"] = $campaignData[$i]['campaignId'];
                        $update["campaign_name"] = $campaignData[$i]['campaignName'];
                        $update["campaign_status"] = $campaignData[$i]['CampaignStatus'];
                        $update["campaign_budget_name"] = $campaignData[$i]['CampaignBudgetName'];
                        $update["campaign_budget_id"] = $campaignData[$i]['CampaignBudgetId'];
                        $update["campaign_budget_amount"] = $campaignData[$i]['CampaignBudgetAmount'];
                        $update["updated_at"] = date("Y-m-d h:i:s");
                        
                        $query = $this->AdwordsCampaign->query();
                        $query->update()
                            ->set($update)
                            ->where(['location_id' => $location_id, 'campaign_id' => $campaignData[$i]['campaignId']])
                            ->execute();
                    }
                    else
                    {
                        $campaign = $this->AdwordsCampaign->newEntity();
                        $campaign->location_id = $location_id;
                        $campaign->sub_client_id = $subClientId;
                        $campaign->campaign_id = $campaignData[$i]['campaignId'];
                        $campaign->campaign_name = $campaignData[$i]['campaignName'];
                        $campaign->campaign_status = $campaignData[$i]['CampaignStatus'];
                        $campaign->campaign_budget_name = $campaignData[$i]['CampaignBudgetName'];
                        $campaign->campaign_budget_id = $campaignData[$i]['CampaignBudgetId'];
                        $campaign->campaign_budget_amount = $campaignData[$i]['CampaignBudgetAmount'];
                        $this->AdwordsCampaign->save($campaign); // save campaign data into database
                    }
                }
            }

        endforeach;
        
    }

    /**
     * Date :- 22-may-17 
     * Function disc :- function for fetch subaccount's from database according to user id  
     * @RudrainnovativePvtLtd 
     */
    public function getSubaccounts($location_id = null) {
        $subAccountData = []; // array for store sub account data 
        $subAccountModel = $this->loadModel('AdwordsSubaccount'); // load AdwordsSubaccount model 
        $data = $subAccountModel->find('all')->where(['location_id' => $location_id])->all();

        if (!empty($data)) {
            foreach ($data as $key => $val) {
                $subAccountData[$key]['Id'] = $val->id;
                $subAccountData[$key]['subAccountId'] = $val->sub_cust_client_id;
                $subAccountData[$key]['subAccountName'] = $val->sub_cust_name;
            }
        }

        return $subAccountData; // return subAccount data from database 
    }
    
    /**
     * Date :- 08-june-17
     * Function disc :- Function for check value is in database or not  
     * @RudrainnovativePvtLtd 
     */
    
    private function check_db($id, $location_id) {
        $dbData = $this->AdwordsCampaign->find('all')->where(["location_id" => $location_id, 'campaign_id' => $id])->all();
        if (iterator_count($dbData)) {
            return 1;
        } else {
            return 0;
        }
    }

    /**
     * Date :- 24-may-17 
     * Function disc :- function for get campaign data from database and display it into table   
     * @RudrainnovativePvtLtd 
     */
    public function displayCampaign($subAccountId = null) {
        $campaignData = [];
        $campaignData = $this->AdwordsCampaign->find('all')->where(['sub_client_id' => $subAccountId])->all();

        if (!empty($campaignData)) {
            $this->set('campaigns', $campaignData); // set campaigns to display in view 
        }
    }

}
