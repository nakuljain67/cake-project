<?php

namespace App\Controller;

ini_set('max_execution_time', 500); // set maximum execution time 

require_once(ROOT . DS . 'vendor' . DS . "adwords" . DS . "vendor" . DS . "autoload.php");

use Google\AdsApi\AdWords\Reporting\v201702\ReportDownloader;
use Google\AdsApi\AdWords\Reporting\v201702\DownloadFormat;
use Cake\Core\App; // use core app controller namespace 

App::className('Controller', 'AdwordsDataController');  // calling AdwordsDataController 

Class AdwordsCampaignReportController extends AppController {

    /**
     * Date :- 24-may-17 
     * Function disc :- function for fetch subaccount's from database according to user id  
     * @RudrainnovativePvtLtd 
     */
    private function getSubaccounts($location_id = null) {
        $subAccountData = []; // array for store sub account data 
        $subAccountModel = $this->loadModel('AdwordsSubaccount'); // load AdwordsSubaccount model 
        $data = $subAccountModel->find('all')->where(['location_id' => $location_id])->all();

        if (!empty($data)) {
            foreach ($data as $key => $val) {
                $subAccountData[$key]['Id'] = $val->id;
                $subAccountData[$key]['subAccountId'] = $val->sub_cust_client_id;
                $subAccountData[$key]['subAccountName'] = $val->sub_cust_name;
            }
        }

        return $subAccountData; // return subAccount data from database 
    }

    /**
     * Date :- 24-may-17 
     * Function disc :- Function for get all campaigns according to subaccount id 
     * @RudrainnovativePvtLtd 
     */
    private function getCampaigns($subAccountId = null) {

        // $subAccountId = 7828610025;
        $campaignIds = []; // array to store campaign ids comes from database 
        $campaignModel = $this->loadModel('AdwordsCampaign');
        $campaignData = $campaignModel->find('all')->where(['sub_client_id' => $subAccountId])->all();

        /* Loop for store campaign ids into array comes from database a/c sub account id */
        if (iterator_count($campaignData)) {
            foreach ($campaignData as $val) {
                $campaignIds[] = $val->campaign_id;
            }
        }

        return $campaignIds;
    }

    /**
     * Date :- 24-may-17 
     * Updated :- 12-june-17
     * Function disc :- Function for Parse csv data 
     * @RudrainnovativePvtLtd 
     */
    public function parseCsv($csvData = null) {
        $dataArray = []; //array for store data performance data into array  
        $parsedArray = [];
        $lines = explode(PHP_EOL, $csvData);

        $total = count($lines);
        if ($total > 4) {

            for ($i = 2; $i < $total - 2; $i++) {
                $parsedArray[] = explode(",", $lines[$i]);
            }

            if (!empty($parsedArray)) {

                $count = count($parsedArray);
                for ($a = 0; $a < $count; $a++) {
                    $dataArray[$a]["campaign_id"] = $parsedArray[$a][0];
                    $dataArray[$a]["camp_name"] = $parsedArray[$a][1];
                    $dataArray[$a]["impr"] = $parsedArray[$a][2];
                    $dataArray[$a]["clicks"] = $parsedArray[$a][3];
                    $dataArray[$a]["cost"] = $parsedArray[$a][4] / 1000000;
                    $dataArray[$a]["ctr"] = $parsedArray[$a][5];
                    $dataArray[$a]["converssion"] = $parsedArray[$a][7];
                    $dataArray[$a]["costperconv"] = $parsedArray[$a][8] / 1000000;
                    $dataArray[$a]["conv_rate"] = $parsedArray[$a][9];
                    $dataArray[$a]["view_through_conv"] = $parsedArray[$a][10];
                    $dataArray[$a]["avg_cpc"] = $parsedArray[$a][11] / 1000000;
                    $dataArray[$a]["avg_position"] = $parsedArray[$a][12];
                }
            }

            return $dataArray;
        }
    }

    /**
     * Date :- 12-june-17 
     * Function disc :- Function for get campaign reporting a/c to sub-account id 
     * @RudrainnovativePvtLtd 
     */
    public function getCampaignReporting($location_id) {
        $obj = new AdwordsDataController;
//        $location_id = 1; // only for testing purpose 

        $subAccountArray = $this->getSubaccounts($location_id); // calling function for get subaccounts 

        if (!empty($subAccountArray)) {
            foreach ($subAccountArray as $val):

                $credential = $obj->credentialBuilder($location_id);
                $session = $obj->reportSession($credential, $val["subAccountId"]);
                
                $reportQuery = 'SELECT CampaignId,CampaignName,Impressions,Clicks,Cost,Ctr,
                                AverageCost,Conversions,CostPerConversion,ConversionRate,ViewThroughConversions,AverageCpc,AveragePosition
                                FROM CAMPAIGN_PERFORMANCE_REPORT DURING YESTERDAY';

                // Download report as a string.
                $reportDownloader = new ReportDownloader($session);
                $reportDownloadResult = $reportDownloader->downloadReportWithAwql($reportQuery, 'CSV');
                $csvData = $reportDownloadResult->getAsString(); // generate report as string 

                $parsedData = $this->parseCsv($csvData); // calling function to parse 
                $model = $this->loadModel('AdwordsCampaignReporting');

                if (!empty($parsedData)) {

                    foreach ($parsedData as $value):

                        $insert = $model->newEntity();
                        $insert->location_id = $location_id;
                        $insert->campaign_id = $value["campaign_id"];
                        $insert->campaign_name = $value["camp_name"];
                        $insert->clicks = $value["clicks"];
                        $insert->impression = $value["impr"];
                        $insert->ctr = $value["ctr"];
                        $insert->avg_cpc = $value["avg_cpc"];
                        $insert->cost = $value["cost"];
                        $insert->avg_pos = $value["avg_position"];
                        $insert->converssion = $value["converssion"];
                        $insert->view_through_conv = $value["view_through_conv"];
                        $insert->cost_per_conv = $value["costperconv"];
                        $insert->conv_rate = $value["conv_rate"];
                        $model->save($insert);

                    endforeach;
                }
            endforeach;
        }
    }
    
    /**
     * Date :- 12-june-17 
     * Function disc :- Function for get Historical campaign reporting 
     * @RudrainnovativePvtLtd 
     */
    public function getHistoricalCampaignReporting($location_id) {
        $obj = new AdwordsDataController;
//        $location_id = 1; // only for testing purposes 

        $subAccountArray = $this->getSubaccounts($location_id); // calling function for get subaccounts 

        if (!empty($subAccountArray)) {
            foreach ($subAccountArray as $val):

                $credential = $obj->credentialBuilder($location_id);
                $session = $obj->reportSession($credential, $val["subAccountId"]);

                $reportQuery = 'SELECT CampaignId,CampaignName,Impressions,Clicks,Cost,Ctr,
                                AverageCost,Conversions,CostPerConversion,ConversionRate,ViewThroughConversions,AverageCpc,AveragePosition
                                FROM CAMPAIGN_PERFORMANCE_REPORT DURING THIS_MONTH';

                // Download report as a string.
                $reportDownloader = new ReportDownloader($session);
                $reportDownloadResult = $reportDownloader->downloadReportWithAwql($reportQuery, 'CSV');
                $csvData = $reportDownloadResult->getAsString(); // generate report as string 

                $parsedData = $this->parseCsv($csvData); // calling function to parse 
                $model = $this->loadModel('AdwordsCampaignReporting');
                
                pr($parsedData);
                
                die('here');

                if (!empty($parsedData)) {

                    foreach ($parsedData as $value):

                        $insert = $model->newEntity();
                        $insert->location_id = $location_id;
                        $insert->campaign_id = $value["campaign_id"];
                        $insert->campaign_name = $value["camp_name"];
                        $insert->clicks = $value["clicks"];
                        $insert->impression = $value["impr"];
                        $insert->ctr = $value["ctr"];
                        $insert->avg_cpc = $value["avg_cpc"];
                        $insert->cost = $value["cost"];
                        $insert->avg_pos = $value["avg_position"];
                        $insert->converssion = $value["converssion"];
                        $insert->view_through_conv = $value["view_through_conv"];
                        $insert->cost_per_conv = $value["costperconv"];
                        $insert->conv_rate = $value["conv_rate"];
                        $model->save($insert);

                    endforeach;
                }
            endforeach;
        }
    }
    
    /**
     * Date :- 13-june-17 
     * Function disc :- Function for Display campaign reporting 
     * @RudrainnovativePvtLtd 
     */
    
    public function displayCampReporting($location_id=1)
    {
        $array = []; // blank array to return data into page
        $model = $this->loadModel('AdwordsCampaignReporting');
        $campData = $model->find('all')->where(['location_id' => $location_id])->toArray();
        
        if(!empty($campData)) {
            foreach($campData as $key => $val):
                $array[$key]["campaign_id"] = $val->campaign_id;
                $array[$key]["campaign_name"] = $val->campaign_name;
                $array[$key]["clicks"] = $val->clicks;
                $array[$key]["impression"] = $val->impression;
                $array[$key]["ctr"] = $val->ctr;
                $array[$key]["avg_cpc"] = $val->avg_cpc;
                $array[$key]["cost"] = $val->cost;
                $array[$key]["avg_pos"] = $val->avg_pos;
                $array[$key]["converssion"] = $val->converssion;
                $array[$key]["view_through_conv"] = $val->view_through_conv;
                $array[$key]["cost_per_conv"] = $val->cost_per_conv;
                $array[$key]["conv_rate"] = $val->conv_rate;
                $array[$key]["created_at"] = $val->created_at;
            endforeach;
        }
        
        if(!empty($array)) {
            $this->set("campReport", $array);
        }
    }

}
