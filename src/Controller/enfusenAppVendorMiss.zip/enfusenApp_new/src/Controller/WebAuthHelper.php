<?php
namespace App\Controller;

require_once(ROOT . DS . 'vendor' . DS ."bingAds" . DS . "vendor" . DS . "autoload.php");


final class WebAuthHelper {

    const DeveloperToken = '1204HV1U40148962';
    const ApiEnvironment = ApiEnvironment::Production;
    const UserName = 'rogercbryan@gmail.com';
    const Password = 'No!More!Vodka!4u!';
    const ClientId = '1f10204d-6236-42a9-8362-63e15bf1f7fb'; 
    const ClientSecret = 'V9qomr8EZmMJfg33ksNCm9y'; 
    const RedirectUri = "https://login.live.com/oauth20_authorize.srf?client_id=1f10204d-6236-42a9-8362-63e15bf1f7fb&scope=bingads.manage&response_type=code&redirect_uri=http://localhost/cakeApi/bingads/WebAuthentication/OAuth2Callback.php&grant_type=authorization_code&state=45415";
}

?>