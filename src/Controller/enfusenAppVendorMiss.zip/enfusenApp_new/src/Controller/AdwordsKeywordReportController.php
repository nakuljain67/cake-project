<?php

namespace App\Controller;

ini_set('max_execution_time', 500); // set maximum execution time 

require_once(ROOT . DS . 'vendor' . DS . "adwords" . DS . "vendor" . DS . "autoload.php");

use Google\AdsApi\AdWords\Reporting\v201702\ReportDownloader;
use Google\AdsApi\AdWords\Reporting\v201702\DownloadFormat;
use Cake\Core\App; // use core app controller namespace 

App::className('Controller', 'AdwordsDataController');  // calling AdwordsDataController 

Class AdwordsKeywordReportController extends AppController {

    public function initialise() {
        parent::initialise();
        ob_start();
    }

    /**
     * Date :- 13-june-17 
     * Function disc :- function for pull keywords performance reporting 
     * @RudrainnovativePvtLtd 
     */
    public function index($location_id) {

        $obj = new AdwordsDataController;
        $credential = $obj->credentialBuilder($location_id);
        $subData = $this->getSubaccounts($location_id);

        if (!empty($subData)) {
            foreach ($subData as $val):
               $session = $obj->reportSession($credential, $val["subAccountId"]);

                $reportQuery = 'SELECT CampaignId,AdGroupId,Criteria,Id,Labels,Impressions,Clicks,Cost,Ctr,Status
	                            ,AveragePosition,Conversions,CostPerConversion,ConversionRate,ViewThroughConversions,AllConversions,SearchImpressionShare,QualityScore,CpcBid,AverageCpc
	                            FROM KEYWORDS_PERFORMANCE_REPORT DURING YESTERDAY';

                // Download report as a string.
                $reportDownloader = new ReportDownloader($session);
                $reportDownloadResult = $reportDownloader->downloadReportWithAwql($reportQuery, 'CSV');
                $csvData = $reportDownloadResult->getAsString(); // generate report as string
                $parsedData = $this->parseCsv($csvData); // calling function to parse 

                $table = $this->loadModel("AdwordsKeywordReporting");

                if (!empty($parsedData)) {
                    foreach ($parsedData as $data):
                        $insert = $table->newEntity();
                        $insert->location_id = $location_id;
                        $insert->campaign_id = $data["campaign_id"];
                        $insert->adgroup_id = $data["adgroup_id"];
                        $insert->keyword_id = $data["keyword_id"];
                        $insert->keyword_text = $data["keyword_name"];
                        $insert->labels = $data["labels"];
                        $insert->impressions = $data["impressions"];
                        $insert->clicks = $data["clicks"];
                        $insert->cost = $data["cost"];
                        $insert->ctr = $data["ctr"];
                        $insert->state = $data["keyword_state"];
                        $insert->avg_pos = $data["avg_pos"];
                        $insert->conversions = $data["conversions"];
                        $insert->costperconv = $data["costperconv"];
                        $insert->conv_rate = $data["conv_rate"];
                        $insert->view_through_conv = $data["view_through_conv"];
                        $insert->all_conv = $data["all_conv"];
                        $insert->search_impr_share = $data["search_impr_share"];
                        $insert->quality_score = $data["quality_score"];
                        $insert->max_cpc = $data["max_cpc"];
                        $insert->avg_cpc = $data["avg_cpc"];
                        $table->save($insert);
                    endforeach;
                }

            endforeach;
        }
    }

    /**
     * Date :- 13-june-17 
     * Function disc :- function for fetch subaccount's from database according to user id  
     * @RudrainnovativePvtLtd 
     */
    private function getSubaccounts($location_id = null) {
        $subAccountData = []; // array for store sub account data 
        $subAccountModel = $this->loadModel('AdwordsSubaccount'); // load AdwordsSubaccount model 
        $data = $subAccountModel->find('all')->where(['location_id' => $location_id, 'can_manage_client != ' => 1])->all();

        if (!empty($data)) {
            foreach ($data as $key => $val) {
                $subAccountData[$key]['Id'] = $val->id;
                $subAccountData[$key]['subAccountId'] = $val->sub_cust_client_id;
                $subAccountData[$key]['subAccountName'] = $val->sub_cust_name;
            }
        }

        return $subAccountData; // return subAccount data from database 
    }

    /**
     * Date :- 13-june-17 
     * Function disc :- Function for Parse csv data 
     * @RudrainnovativePvtLtd 
     */
    public function parseCsv($csvData = null) {
        $dataArray = []; //array for store data performance data into array  
        $parsedArray = [];
        $lines = explode(PHP_EOL, $csvData);

        $total = count($lines);
        if ($total > 4) {

            for ($i = 2; $i < $total - 2; $i++) {
                $parsedArray[] = explode(",", $lines[$i]);
            }

            if (!empty($parsedArray)) {

                $count = count($parsedArray);
                for ($a = 0; $a < $count; $a++) {
                    $dataArray[$a]["campaign_id"] = $parsedArray[$a][0];
                    $dataArray[$a]["adgroup_id"] = $parsedArray[$a][1];
                    $dataArray[$a]["keyword_name"] = $parsedArray[$a][2];
                    $dataArray[$a]["keyword_id"] = $parsedArray[$a][3];
                    $dataArray[$a]["labels"] = $parsedArray[$a][4];
                    $dataArray[$a]["impressions"] = $parsedArray[$a][5];
                    $dataArray[$a]["clicks"] = $parsedArray[$a][6];
                    $dataArray[$a]["cost"] = $parsedArray[$a][7] / 1000000;
                    $dataArray[$a]["ctr"] = $parsedArray[$a][8];
                    $dataArray[$a]["keyword_state"] = $parsedArray[$a][9];
                    $dataArray[$a]["avg_pos"] = $parsedArray[$a][10];
                    $dataArray[$a]["conversions"] = $parsedArray[$a][11];
                    $dataArray[$a]["costperconv"] = $parsedArray[$a][12] / 1000000;
                    $dataArray[$a]["conv_rate"] = $parsedArray[$a][13];
                    $dataArray[$a]["view_through_conv"] = $parsedArray[$a][14];
                    $dataArray[$a]["all_conv"] = $parsedArray[$a][15];
                    $dataArray[$a]["search_impr_share"] = $parsedArray[$a][16];
                    $dataArray[$a]["quality_score"] = $parsedArray[$a][17];
                    $dataArray[$a]["max_cpc"] = is_numeric($parsedArray[$a][18]) ? $parsedArray[$a][18] / 1000000 : $this->parse_max_cpc($parsedArray[$a][18]);
                    $dataArray[$a]["avg_cpc"] = $parsedArray[$a][19] / 1000000;
                }
            }

            return $dataArray;
        }
    }

    /**
     * Date :- 13-june-17 
     * Function disc :- Function for parse max cpc 
     * @RudrainnovativePvtLtd 
     */
    private function parse_max_cpc($num) {
        $parse_num = explode(":", $num);
        if (!empty($parse_num)) {
            $max_cpc = $parse_num[0] . ": " . $parse_num[1] / 1000000;
            return $max_cpc;
        } else {
            return null;
        }
    }
    
    /**
     * Date :- 13-june-17 
     * Function disc :- Function for display keyword reporting data list 
     * @RudrainnovativePvtLtd 
     */
    
    public function displayKeywordsReport($location_id = 1)
    {
        $array = []; // blank array for return and send data into view page 
        $table = $this->loadModel("AdwordsKeywordReporting");
        $keywordData = $table->find('all')->where(["location_id" => $location_id])->toArray();
        
        if(!empty($keywordData)) {
            foreach($keywordData as $key => $val):
                $array[$key]["keyword_id"] = $val->keyword_id;
                $array[$key]["keyword_text"] = $val->keyword_text;
                $array[$key]["labels"] = $val->labels;
                $array[$key]["impressions"] = $val->impressions;
                $array[$key]["clicks"] = $val->clicks;
                $array[$key]["cost"] = $val->cost;
                $array[$key]["ctr"] = $val->ctr;
                $array[$key]["state"] = $val->state;
                $array[$key]["avg_pos"] = $val->avg_pos;
                $array[$key]["conversions"] = $val->conversions;
                $array[$key]["conv_rate"] = $val->conv_rate;
                $array[$key]["view_through_conv"] = $val->view_through_conv;
                $array[$key]["all_conv"] = $val->all_conv;
                $array[$key]["search_impr_share"] = $val->search_impr_share;
                $array[$key]["max_cpc"] = $val->max_cpc;
                $array[$key]["avg_cpc"] = $val->avg_cpc;
                $array[$key]["created_at"] = $val->created_at;
            endforeach;
        }
        
        if(!empty($array)) {
            $this->set("keywordData", $array);
        }
    }
    

}
