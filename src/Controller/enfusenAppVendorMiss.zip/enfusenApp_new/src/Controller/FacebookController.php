<?php

namespace App\Controller;

require_once(ROOT . DS . 'vendor' . DS . "facebook1" . DS . "vendor" . DS . "autoload.php");
require_once(ROOT . DS . 'vendor' . DS . "facebook" . DS . "vendor" . DS . "autoload.php");

use Cake\ORM\TableRegistry;
use App\Controller\AppController;
use FacebookAds\Api;
use FacebookAds\Object\User;
use FacebookAds\Object\AdAccount;
use FacebookAds\Object\AdAccountUser;
use FacebookAds\Object\Fields\AdAccountFields;
use FacebookAds\Object\Campaign;
use FacebookAds\Object\Ad;
use FacebookAds\Object\AdSet;
use FacebookAds\Object\Fields\AdCampaignFields;
use FacebookAds\Object\Fields\AdSetFields;
use FacebookAds\Object\Fields\CampaignFields;
use FacebookAds\Object\Fields\AdFields;
use FacebookAds\Object\Fields\AdsInsightsFields;

Class FacebookController extends AppController {

    public function index() {
       
        $users1 = TableRegistry::get('api_locations');
        $data = $users1->find('all')->where(['smart_location_id != ""'])->toArray();
        $this->set("data", $data);
        if (isset($_GET['code']) && isset($_GET['state'])) {
            if (!empty($_GET['code']) && !empty($_GET['state'])) {
                $users_table = $this->loadModel('ApiOptions');
                $matchcount = $users_table->find()->where(['option_key' => 'facebook'])->first();
                $data = json_decode($matchcount->option_value);
                $clientId = $data->clientId;
                $secret = $data->secret;
                $redirect = $data->redirect;
                $provider = new \League\OAuth2\Client\Provider\Facebook([
                    'clientId' => $clientId,
                    'clientSecret' => $secret,
                    'redirectUri' => $redirect,
                    'graphApiVersion' => 'v2.9',
                    'scopes' => 'ads_read,ads_management'
                ]);
                $token = $provider->getAccessToken('authorization_code', [
                    'code' => $_GET['code']
                ]);
                $today = date('d-m-Y');
                $expires_in = date('d-m-Y', strtotime($today . ' + 30 days'));
                $new = [];
                $new['token'] = $token;
                $new['expires_in'] = $expires_in;
                $users_table1 = TableRegistry::get('api_locations');
                $query = $users_table1->query();
                $query->update()->set(['fb_token' => json_encode($new)])->where(['fb_token' => 'test'])->execute();
                $user = $provider->getResourceOwner($token);
                $id = $user->getId();
                $firstName = $user->getFirstName();
                $lastName = $user->getLastName();
                $gender = $user->getGender();
                $facebook = $this->Facebook->newEntity();
                $matchcount = $this->Facebook->find()->where(['fb_id' => $id])->count();
                if ($matchcount == 0) {
                    $facebook->fb_id = !empty($id) ? $id : "";
                    $facebook->first_name = !empty($firstName) ? $firstName : "";
                    $facebook->last_name = !empty($lastName) ? $lastName : "";
                    $facebook->gender = !empty($gender) ? $gender : "";

                    if ($this->Facebook->save($facebook)) {
                        $this->Flash->success(__('successfully connected with Facebook .'));
                        return $this->redirect(['action' => 'index']);
                    }
                } else {
                    $this->Flash->success(__('successfully connected with Facebook .'));
                    return $this->redirect(['action' => 'index']);
                }
            } elseif (empty($_GET['state']) || ($_GET['state'] !== $_SESSION['oauth2state'])) {
                unset($_SESSION['oauth2state']);
                echo 'Invalid state.';
                exit;
            }
        }
        /* Code for get data from database */
        $fbData = $this->Facebook->find('all')->toArray();
        if (!empty($fbData)) {
            $this->set("facebook", $fbData);  // set facebook data into a variable 
        }
    }
    
    
    /**
     * Update :- 22-June-17 
     * Function disc :- Function for connect with Facebook 
     * @RudrainnovativePvtLtd 
     */
    public function connect() {
        if (!empty($_POST['location_id'])) {
            $location_id = $_POST['location_id'];
            $users_table1 = TableRegistry::get('api_locations');
            $query = $users_table1->query();
            $query->update()->set(['fb_token' => 'test'])->where(['smart_location_id' => $location_id])->execute();
            $users_table = $this->loadModel('ApiOptions');
            $matchcount = $users_table->find()->where(['option_key' => 'facebook'])->first();
            $data = json_decode($matchcount->option_value);
            $clientId = $data->clientId;
            $secret = $data->secret;
            $redirect = isset($_POST["redirect_uri"]) ? $_POST["redirect_uri"] : $data->redirect ;
            
            $provider = new \League\OAuth2\Client\Provider\Facebook([
                'clientId' => $clientId,
                'clientSecret' => $secret,
                'redirectUri' => $redirect,
                'graphApiVersion' => 'v2.9',
            ]);
            $authUrl = $provider->getAuthorizationUrl([
                'scope' => ['email', 'user_friends'],
            ]);
            $_SESSION['oauth2state'] = $provider->getState();
            
            header("Location:".$authUrl);
            exit;
        } else {
            $this->Flash->error(__('Please Select Location Id.'));
            return $this->redirect(['action' => 'index']);
        }
    }

    var $paginate = array(
        'limit' => 25,
    );

    public function getCampaign() {
        $users = TableRegistry::get('facebook_campaigns');
        $query = $this->paginate($users->find());
        // pr($query);die;
        $this->set('campaigns', $query);
    }

    public function getAd() {
        $users = TableRegistry::get('facebook_ads');
        $query = $this->paginate($users->find());
        // pr($query);die;
        $this->set('campaigns', $query);
    }

    public function getAdSet() {
        $users = TableRegistry::get('facebook_ad_sets');
        $query = $this->paginate($users->find());
        // pr($query);die;
        $this->set('campaigns', $query);
    }

}
