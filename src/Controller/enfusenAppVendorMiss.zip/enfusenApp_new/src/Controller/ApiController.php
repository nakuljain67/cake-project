<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;

/* for facebook only */
require_once(ROOT . DS . 'vendor' . DS . "facebook1" . DS . "vendor" . DS . "autoload.php");
require_once(ROOT . DS . 'vendor' . DS . "facebook" . DS . "vendor" . DS . "autoload.php");

use FacebookAds\Api;
use FacebookAds\Object\User;
use FacebookAds\Object\AdAccount;
use FacebookAds\Object\AdAccountUser;
use FacebookAds\Object\Fields\AdAccountFields;

/* -- BING ADS -- */
require_once(ROOT . DS . 'vendor' . DS . "bingAds" . DS . "vendor" . DS . "autoload.php");
use Microsoft\BingAds\Auth\AuthorizationData;
use Microsoft\BingAds\Auth\OAuthTokenRequestException;
use Microsoft\BingAds\Auth\OAuthWebAuthCodeGrant;
use Microsoft\BingAds\Samples\WebAuthHelper;

/* END */

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[] paginate($object = null, array $settings = [])
 */
class ApiController extends AppController {

    private $conn;
   

    public function initialize() {
        session_start();
        $this->autoRender = false;
        header('Access-Control-Allow-Origin: *');
        $this->viewBuilder()->layout(false);
        $this->viewBuilder()->templatePath('.');
        $this->viewBuilder()->template('my_blank_view');
        $allow = array("192.168.1.69", "35.163.234.186");
        $disallow_method = array();
        //$disallow_method = array("get");               
//        if(!in_array($_SERVER['SERVER_ADDR'], $allow) || in_array(strtolower($this->request->method()), $disallow_method)) {
//            $this->throwerror("HTTP/1.1 503 Service Unavailable");
//        }

        $this->loadModel('Apilocations');
        $this->conn = ConnectionManager::get('default');
    }

    public function index() {
        $this->json(0, "Invalid Request");
    }

    public function disconnectconn() {
        $location_id = $this->check_validrequest();
        $dataexists = $this->Apilocations->findBySmart_location_id($location_id);
        $row = $dataexists->first();
        if (!empty($row)) {
            ;
            $data = $this->request->getData();
            $type = isset($data['type']) ? trim(htmlspecialchars($data['type'])) : '';
            if ($type != '') {
                $txt = "";
                $apilocation = $this->Apilocations;
                $loc = $apilocation->newEntity();
                $loc->smart_location_id = $location_id;
                if ($type == "google_analytic") {
                    $loc->google_token = "";
                    $loc->analytics_child = "";
                    $txt = "Google Analytic";
                } else if ($type == "google_adwords") {
                    $loc->adword_token = "";
                    $loc->adword_custid = "";
                    $txt = "Google Adwords";
                } else if ($type == "google_search") {
                    $loc->google_search_token = "";
                    $txt = "Google Search Console";
                }

                $id = $row->id;
                $loc->id = $id;
                if ($apilocation->save($loc)) {
                    $this->json(1, $txt . " disconnected successfully");
                }
            }
        }
        $this->json(0, "Invalid Request");
    }
    
    /* @updated :- 23-june-17 */
    public function getallconnections() {
        $return = [];
        $location_id = $this->check_validrequest();
        $dataexists = $this->Apilocations->findBySmart_location_id($location_id);
        $row = $dataexists->first();
        if (!empty($row)) {
            
        $google_token = !empty($row->google_token) ? json_decode($row->google_token) : "";
        $analytics_child = !empty($row->analytics_child) ? json_decode($row->analytics_child) : "";
        $adword_token = !empty($row->adword_token) ? json_decode($row->adword_token) : "";
        $google_search_token = !empty($row->google_search_token) ? json_decode($row->google_search_token) : "";
        $bing_token = !empty($row->bing_token) ? json_decode($row->bing_token) : "";
        $fb_token = !empty($row->fb_token) ? json_decode($row->fb_token) : "";
        $adroll_info = !empty($row->adroll_info) ? json_decode($row->adroll_info) : "";
        $calltracking_info = !empty($row->calltracking_info) ? json_decode($row->calltracking_info) : "";
        $callrail_info = !empty($row->callrail_info) ? json_decode($row->callrail_info) : "";
        $twilio_info = !empty($row->twilio_info) ? json_decode($row->twilio_info) : "";
        
        $return["google_token"] = $google_token;
        $return["analytics_child"] = $analytics_child;
        $return["adword_token"] = $adword_token;
        $return["google_search_token"] = $google_search_token;
        $return["bing_token"] = $bing_token;
        $return["fb_token"] = $fb_token;
        $return["adroll_info"] = $adroll_info;
        $return["calltracking_info"] = $calltracking_info;
        $return["callrail_info"] = $callrail_info;
        $return["twilio_info"] = $twilio_info;
            
         
            $this->json(1, "Connections detail", $return);
        }
        $this->json(0, "No data found");
    }

    public function getgatoken() {

        $location_id = $this->check_validrequest();
        $dataexists = $this->Apilocations->findBySmart_location_id($location_id)->select(['Apilocations.google_token', 'Apilocations.analytics_child']);
        $row = $dataexists->first();

        if (!empty($row)) {
            $google_token = trim($row->google_token);
            if ($google_token != '')
                $this->json(1, "Google token found", $row);
        }
        $this->json(0, "No connected with google yet");
    }

    public function savegaaccount() {
        $location_id = $this->check_validrequest();
        $req_data = $this->request->getData();
        $account = isset($req_data['account']) && trim($req_data['account']) != '' ? $req_data['account'] : '';
        $property = isset($req_data['property']) && trim($req_data['property']) != '' ? $req_data['property'] : '';
        $profile = isset($req_data['profile']) && trim($req_data['profile']) != '' ? $req_data['profile'] : '';

        $arvalidation = array();
        if ($account == "") {
            $arvalidation['account'] = "Please provide account id";
        }
        if ($property == "") {
            $arvalidation['property'] = "Please provide property id";
        }
        if ($profile == "") {
            $arvalidation['account'] = "Please provide profile id";
        }
        if (!empty($arvalidation)) {
            $this->json(0, "Empty fields found", $arvalidation);
        }

        $accountdata = json_encode($req_data);
        $apilocation = $this->Apilocations;
        $loc = $apilocation->newEntity();
        $loc->analytics_child = $accountdata;

        $dataexists = $this->Apilocations->findBySmart_location_id($location_id);
        $row = $dataexists->first();
        if (!empty($row)) {
            $id = $row->id;
            $loc->id = $id;
            if ($apilocation->save($loc)) {
                $this->json(1, "Google analytics child accounts saved successfully");
            }
            $this->json(0, "Google analytics child accounts not saved");
        }
        $this->json(0, "You need to connect with Google analytics for this step");
    }

    public function savegatoken() {

        $location_id = $this->check_validrequest();
        $data = $this->request->getData();
        $apilocation = $this->Apilocations;
        $loc = $apilocation->newEntity();
        $loc->smart_location_id = $location_id;
        $loc->google_token = $data["token"];
        $loc->created = date("Y-m-d H:i:s");
        $dataexists = $this->Apilocations->findBySmart_location_id($location_id);
        $row = $dataexists->first();
        if (empty($row)) {
            if ($apilocation->save($loc)) {
                $this->json(1, "Google analytic token saved successfully");
            }
        } else {
            $id = $row->id;
            $loc->id = $id;
            if ($apilocation->save($loc)) {
                $this->json(1, "Google analytic token saved successfully");
            }
        }
        $this->json(0, "Error to save data. Please try again");
    }

    public function savegadwtoken() {

        $location_id = $this->check_validrequest();
        $data = $this->request->getData();
        $apilocation = $this->Apilocations;
        $loc = $apilocation->newEntity();
        $loc->smart_location_id = $location_id;
        $loc->adword_token = $data["token"];
        $loc->created = date("Y-m-d H:i:s");
        $dataexists = $this->Apilocations->findBySmart_location_id($location_id);
        $row = $dataexists->first();
        if (empty($row)) {
            if ($apilocation->save($loc)) {
                $this->json(1, "Google adwords token saved successfully");
            }
        } else {
            $id = $row->id;
            $loc->id = $id;
            if ($apilocation->save($loc)) {
                $this->json(1, "Google adwords token saved successfully");
            }
        }
        $this->json(0, "Error to save adwords token. Please try again");
    }

    public function savegconsoletoken() {

        $location_id = $this->check_validrequest();
        $data = $this->request->getData();
        $apilocation = $this->Apilocations;
        $loc = $apilocation->newEntity();
        $loc->smart_location_id = $location_id;
        $loc->google_search_token = $data["token"];
        $loc->created = date("Y-m-d H:i:s");
        $dataexists = $this->Apilocations->findBySmart_location_id($location_id);
        $row = $dataexists->first();
        if (empty($row)) {
            if ($apilocation->save($loc)) {
                $this->json(1, "Google search console token saved successfully");
            }
        } else {
            $id = $row->id;
            $loc->id = $id;
            if ($apilocation->save($loc)) {
                $this->json(1, "Google search console token saved successfully");
            }
        }
        $this->json(0, "Error to save google search console. Please try again");
    }

    /* Nakul code - 16-june-17  facebook CTM Call rail */

    public function facebookcampaign() {
        $location_id = $this->check_validrequest();
        $data = $this->request->getData();
        isset($data['limit']) ? $limit = $data['limit'] : $limit = '20';
        isset($data['offset']) ? $off = $data['offset'] : $off = '1';
        $row = $this->loadModel('FacebookCampaigns');
        $new = $row->find()->where(["location_id" => $location_id])->limit($limit)->page($off)
                ->toArray();
        $this->json(1, "Facebook Campaign Details", $new);
    }

    public function facebookad() {
        $location_id = $this->check_validrequest();
        $data = $this->request->getData();
        isset($data['limit']) ? $limit = $data['limit'] : $limit = '20';
        isset($data['offset']) ? $off = $data['offset'] : $off = '1';
        $users_table = TableRegistry::get('facebook_ads');
        $new = $users_table->find('all')->where(["location_id" => $location_id])->limit($limit)->page($off)->toArray();
        $this->json(1, "Facebook Ads Detail", $new);
    }

    public function facebookadset() {
        $location_id = $this->check_validrequest();
        $data = $this->request->getData();
        isset($data['limit']) ? $limit = $data['limit'] : $limit = '20';
        isset($data['offset']) ? $off = $data['offset'] : $off = '1';
        $users_table = TableRegistry::get('facebook_ad_sets');
        $new = $users_table->find('all')->where(["location_id" => $location_id])->limit($limit)->page($off)->toArray();
        $this->json(1, "Facebook Ad Sets Detail", $new);
    }

    public function calltrackingdetail() {
        $location_id = $this->check_validrequest();
        $data = $this->request->getData();
        $end_date = date('Y-m-d', strtotime("-1 days"));
        isset($data['start_date']) ? $start_date = $data['start_date'] : $start_date = date('Y-m-d', strtotime("-30 days"));
        isset($data['limit']) ? $limit = $data['limit'] : $limit = '20';
        isset($data['offset']) ? $off = $data['offset'] : $off = '1';
        $this->loadModel('CallDetail');
        $result = [];
        $result['data'] = $this->CallDetail->find('all')
                        ->where(function ($exp, $q) use($start_date, $end_date) {
                            return $exp->between('called_at', $start_date, $end_date);
                        })->where(["location_id" => $location_id])->limit($limit)->page($off)->toArray();

        $result['total_calls'] = $this->CallDetail->find()->where(function ($exp, $q) use($start_date, $end_date) {
                    return $exp->between('called_at', $start_date, $end_date);
                })->where(["location_id" => $location_id])->count();

        $result['missed_call'] = $this->CallDetail->find()->where(function ($exp, $q) use($start_date, $end_date) {
                    return $exp->between('called_at', $start_date, $end_date);
                })->where(["location_id" => $location_id])->where(['call_status' => 'no answer'])->count();
        $result['answer_call'] = $result['total_calls'] - $result['missed_call'];

        $result['direct_source_call'] = $this->CallDetail->find()->where(function ($exp, $q) use($start_date, $end_date) {
                    return $exp->between('called_at', $start_date, $end_date);
                })->where(["location_id" => $location_id])->where(['source' => 'Direct'])->count();
        $result['google_organic_source_call'] = $this->CallDetail->find()->where(function ($exp, $q) use($start_date, $end_date) {
                    return $exp->between('called_at', $start_date, $end_date);
                })->where(["location_id" => $location_id])->where(['source' => 'Google Organic'])->count();

        $result['bing_organic_source_call'] = $this->CallDetail->find()->where(function ($exp, $q) use($start_date, $end_date) {
                    return $exp->between('called_at', $start_date, $end_date);
                })->where(["location_id" => $location_id])->where(['source' => 'Bing Organic'])->count();
        $this->json(1, "CallTrackingMetrics Call Detail", $result);
    }

    public function twiliodetail() {
        $location_id = $this->check_validrequest();
        $data = $this->request->getData();
        isset($data['limit']) ? $limit = $data['limit'] : $limit = '20';
        isset($data['offset']) ? $off = $data['offset'] : $off = '1';
        $users_table = $this->loadModel('Twilio');
        $new = $users_table->find('all')->where(["location_id" => $location_id])->limit($limit)->page($off)->toArray();
        $this->json(1, "Twilio Call Detail", $new);
    }

    public function callraildetail() {
        $location_id = $this->check_validrequest();
        $data = $this->request->getData();
        $end_date = date('Y-m-d H:i:s', strtotime("-1 days"));
        isset($data['start_date']) ? $start_date = $data['start_date'] : $start_date = date('Y-m-d H:i:s', strtotime("-14 days"));
        isset($data['limit']) ? $limit = $data['limit'] : $limit = '20';
        isset($data['offset']) ? $off = $data['offset'] : $off = '1';
        $users_table = $this->loadModel('CallRail');
        // $new =  $users_table->find('all')->where(["location_id" =>  $location_id])->limit($limit)->page($off)->toArray();
        $result = [];
        $result['data'] = $this->CallRail->find('all')
                        ->where(function ($exp, $q) use($start_date, $end_date) {
                            return $exp->between('start_time', $start_date, $end_date);
                        })->where(["location_id" => $location_id])->limit($limit)->page($off)->toArray();
        $result['total_calls'] = $this->CallRail->find()->where(function ($exp, $q) use($start_date, $end_date) {
                    return $exp->between('start_time', $start_date, $end_date);
                })->where(["location_id" => $location_id])->count();

        $result['missed_call'] = $this->CallRail->find()->where(function ($exp, $q) use($start_date, $end_date) {
                    return $exp->between('start_time', $start_date, $end_date);
                })->where(["location_id" => $location_id])->where(['is_answered' => '0'])->count();
        $result['answer_call'] = $result['total_calls'] - $result['missed_call'];
        $this->json(1, "CallRail Call Detail", $result);
    }

    public function addrollcampaigndata() {
        $location_id = $this->check_validrequest();
        $data = $this->request->getData();
        isset($data['limit']) ? $limit = $data['limit'] : $limit = '20';
        isset($data['offset']) ? $off = $data['offset'] : $off = '1';
        $users_table = $this->loadModel('AdrollCampaign');
        $new = $users_table->find('all')->where(["location_id" => $location_id])->limit($limit)->page($off)->toArray();
        $this->json(1, "Adroll Campaign Data", $new);
    }

    public function addrollcampaignreport() {
        $location_id = $this->check_validrequest();
        $data = $this->request->getData();
        isset($data['limit']) ? $limit = $data['limit'] : $limit = '20';
        isset($data['offset']) ? $off = $data['offset'] : $off = '1';
        $users_table = $this->loadModel('AdrollCampaignReporting');
        $new = $users_table->find('all')->where(["location_id" => $location_id])->limit($limit)->page($off)->toArray();
        $this->json(1, "Adroll Campaign Report", $new);
    }

    public function addrollads() {
        $location_id = $this->check_validrequest();
        $data = $this->request->getData();
        isset($data['limit']) ? $limit = $data['limit'] : $limit = '20';
        isset($data['offset']) ? $off = $data['offset'] : $off = '1';
        $users_table = $this->loadModel('AdrollCampAds');
        $new = $users_table->find('all')->where(["location_id" => $location_id])->limit($limit)->page($off)->toArray();
        $this->json(1, "Adroll Camapign Ads Data", $new);
    }

    /**
     * Date :- 20-june-17 
     * Function disc :- Function for add new location into database  
     * parameter :- location_id (Header)
     * @RudrainnovativePvtLtd
     */
    public function addLocation() {
        $location_id = $this->check_validrequest();
        if (!empty($location_id) && is_numeric($location_id)) {
            $check = $this->check_location($location_id); // calling function for check location is in database or not 
            if ($check == 0 && $check != 1) {
                $insert = $this->Apilocations->newEntity();
                $insert->smart_location_id = $location_id;
                $insert->created = date("Y-m-d h:i:s");
                $insert->status = 1;
                if ($this->Apilocations->save($insert)) {
                    $this->json("1", "New Location Added into database");
                } else {
                    $this->json("0", "DB Insertion Error");
                }
            } else {
                $this->json("0", "Location Already in Use");
            }
        } else {
            $this->json("0", "Location Error , Invalid Location id");
        }
    }

    /**
     * Date :- 20-june-17 
     * Function disc :- Function for check location in database   
     * @RudrainnovativePvtLtd
     */
    private function check_location($location_id) {
        $check = $this->Apilocations->find("all")->where(["smart_location_id" => $location_id])->all();
        if (iterator_count($check)) {
            return 1; // if data exits in database  
        } else {
            return 0; // if data not exits in database  
        }
    }

    /**
     * Date :- 20-june-17 
     * Function disc :- function for delete location from database according to location id 
     * Parameter :- location_id (header)
     * @RudrainnovativePvtLtd
     */
    public function deleteLocation() {
        $location_id = $this->check_validrequest(); // getting location id 
        $check = $this->check_location($location_id); // function call for check location id is in database or not 
        if ($check === 1) {
            $locationData = $this->Apilocations->find("all", array("conditions" => array("smart_location_id" => $location_id)))->toArray();
            if (!empty($locationData)) {
                $id = $locationData[0]->id;
                $entity = $this->Apilocations->get($id);
                $result = $this->Apilocations->delete($entity);
                $this->deleteDynamicTables($data['location_id']);
                if ($result == 1) {
                    $this->json("1", "Location deleted sucessfully from database");
                } else {
                    $this->json("0", "Location not deleted, Database Error occured");
                }
            }
        } else {
            $this->json("0", "Unknown Location Id");
        }
    }
    
    private function deleteDynamicTables($location_id){
        try{
            $con = new ConnectionManager;
            $cn = $con->get('default');
            // delete GA main analytics table
            $mainanalytcs = "api_main_analytics_".$location_id;
            $sql = "DROP TABLE ".$mainanalytcs;
            $cn->execute($sql);            
            
        } catch (\Exception $ex) {

        } catch (\Exception $ex) {

        }
    }
    
    /**
     * Date :- 20-june-17 
     * Function disc :- Function for save adRoll credentials into database 
     * Parameter :- location_id(header), api_key, email, password
     * @RudrainnovativePvtLtd
     */
    public function saveAdrollCredentials() {
       
        /* Getting different variable data */
        $location_id = $this->check_validrequest(); // getting location id 
        $apiKey = isset($_POST["api_key"]) ? $_POST["api_key"] : ""; // getting api key
        $email = isset($_POST["email"]) ? $_POST["email"] : ""; // getting email
        $pass = isset($_POST["password"]) ? $_POST["password"] : ""; // getting password 
        
        /* Checking validation for adroll credentials */
        if (!empty($apiKey) && !empty($email) && !empty($pass)) {
            $check = $this->check_location($location_id);
            if ($check === 1) {
                $adrollCredentials = ["apikey" => $apiKey, "email" => $email, "password" => $pass];
                $query = $this->Apilocations->query();
                if ($query->update()->set(["adroll_info" => json_encode($adrollCredentials)])->where(["smart_location_id" => $location_id])->execute()) {
                    $this->json("1", "Successfully Connected with AdRoll API");
                } else {
                    $this->json("0", "Adroll Credentails insertion failled");
                }
            } else {
                $this->json("0", "Unknown Location Id");
            }
        } else {
            $this->json("0", "Provide all input fields");
        }
    }

    /**
     * Date :- 20-june-17 
     * Function disc :- Function for save Twilio credentials into database 
     * Parameter :- location_id(header), api_key, api_secret 
     * @RudrainnovativePvtLtd
     */
    public function saveTwilioCredentials() {

        $location_id = $this->check_validrequest(); // getting location id 
        $api_key = isset($_POST["api_key"]) ? $_POST["api_key"] : ""; // getting Api key by post method
        $api_secret = isset($_POST["api_secret"]) ? $_POST["api_secret"] : ""; // getting Api secret by post method 

        /* Checking validation for twilio credentials */
        if (!empty($api_key) && !empty($api_secret)) {
            $check = $this->check_location($location_id); // checking id is in database or not 
            if ($check == 1) {
                $credentails = ["apikey" => $api_key, "apisecret" => $api_secret];
                $query = $this->Apilocations->query();
                if ($query->update()->set(["twilio_info" => json_encode($credentails)])->where(["smart_location_id" => $location_id])->execute()) {
                    $this->json("1", "Successfully Connected with Twilio API");
                } else {
                    $this->json("0", "Twilio Credentails insertion failled");
                }
            } else {
                $this->json("0", "Unknown Location Id");
            }
        } else {
            $this->json("0", "Provide all input fields");
        }
    }
    
    /**
     * Date :- 20-june-17 
     * Function disc :- Function for save Call Rail credentials into database 
     * Parameter :- location_id(header), api_key
     * @RudrainnovativePvtLtd
     */
    
    public function saveCallrailCredentials() {
        
        $location_id = $this->check_validrequest(); // getting location id 
        $api_key = isset($_POST["api_key"]) ? $_POST["api_key"] : ""; // getting api key by post method 
        
        /* validation for api key */
        if(!empty($api_key)) {
            $check = $this->check_location($location_id); // checking id is in database or not 
            if($check == 1) {
                $credentials = ["apikey" => $api_key];
                $query = $this->Apilocations->query();
                if($query->update()->set(["callrail_info" => json_encode($credentials)])->where(["smart_location_id" => $location_id])->execute()) {
                    $this->json("1", "Successfully Connected with Call Rail API");
                } else {
                    $this->json("0", "Callrail Credentails insertion failled");
                }
            } else {
                $this->json("0", "Unknown Location Id");
            }
        } else {
            $this->json("0", "Provide all input fields");
        }
    }
    
    /**
     * Date :- 20-june-17 
     * Function disc :- Function for save Call Tracking Metrics credentials into database 
     * Parameter :- location_id(header), api_key, api_secret
     * @RudrainnovativePvtLtd
     */
    
    public function saveCalltrackingmetricsCredentials() {
        $location_id = $this->check_validrequest(); // getting location id 
        $apikey = isset($_POST["api_key"]) ? $_POST["api_key"] : "";
        $apisecret = isset($_POST["api_secret"]) ? $_POST["api_secret"] : "";
        
        /* CTM check input validation */
        if(!empty($apikey) && !empty($apisecret)) {
            $check = $this->check_location($location_id); // check location is in database or not 
            if($check == 1) {
                $credentials = ["apikey" => $apikey, "apisecret" => $apisecret];
                $query = $this->Apilocations->query();
                if($query->update()->set(["calltracking_info" => json_encode($credentials)])->where(["smart_location_id" => $location_id])->execute()) {
                    $this->json("1", "Successfully Connected with Call Tracking Metrics API");
                } else {
                    $this->json("0", "CallTrackingMetrics Credentails insertion failled");
                }
            } else {
                $this->json("0", "Unknown Location Id");
            }
        } else {
            $this->json("0", "Provide all input fields");
        }
    }
    
    /**
     * Date :- 21-june-17 
     * Function disc :- Function for delete credentials according to condition 
     * Parameter :- location_id(header), field
     * @RudrainnovativePvtLtd
     */
    
    public function deleteCredentials()
    {
        $location_id = $this->check_validrequest(); // getting location id
        $field = isset($_POST["field"]) ? $_POST["field"] : ""; // getting fields by post method 
        if(!empty($field)) {
            $check = $this->check_location($location_id); // calling function for check location is in database or not 
            if($check == 1) {
                $updateData = [$field => ""];
                $query = $this->Apilocations->query(); // calling model 
                if($query->update()->set([$updateData])->where(["smart_location_id" => $location_id])->execute()) {
                    $this->json("1", "Disconnected successfully");
                } else {
                    $this->json("0", "DB Error occured");
                }
            } else {
                $this->json("0", "Unknown Location Id");
            }
            
        } else {
            $this->json("0", "Provide all input fields");
        }
    }
    
    /**
     * Date :- 22-june-17 
     * Function disc :- Function for save Facebook credentials into database  
     * Parameter :- location_id(header), credential (json credentials)
     * @RudrainnovativePvtLtd
     */
    
    public function saveFacebookCredentials() {
        $location_id = $this->check_validrequest(); // getting location id
        $credentials = isset($_POST["credential"]) ? $_POST["credential"] : "";
        if(!empty($credentials)) {
            $check = $this->check_location($location_id); // calling function for check location is in database or not 
            if($check == 1) {
                $query = $this->Apilocations->query();
                if($query->update()->set(["fb_token" => $credentials])->where(["smart_location_id" => $location_id])->execute()) {
                     $this->json("1", "Facebook Credentials sucessfully Updated into database");
                } else {
                     $this->json("0", "DB Error occured");
                }
                
            } else {
                $this->json("0", "Unknown Location Id");
            }
        } else {
            $this->json("0", "Provide all input fields");
        }
    }
    
    
    /**
     * Date :- 22-june-17 
     * Function disc :- function for get `google_search_token` credentials according to location id  
     * Parameter :- location_id(header)
     * @RudrainnovativePvtLtd
     */
    
    public function getToken() {
        $location_id = $this->check_validrequest(); // getting location id
        $field = isset($_POST["field"]) ? $_POST["field"] : "";
        
        if(!empty($field)) {
            $check = $this->check_location($location_id); // check location id from db 
            if($check == 1) {
                $credentials = $this->Apilocations->find()->select([$field])->where(["smart_location_id" => $location_id])->toArray();
                if(!empty($credentials)) {
                    $data = json_decode($credentials[0]->google_search_token);
                    $this->json("1", $field, $data);
                } 
            } else {
                 $this->json("0", "Unknown Location Id");
            }
        } else {
            $this->json("0", "Provide all input fields");
        }
    }
    
    /* Function for update status in api locations table */
    public function updateLocation() {
        $location_id = $this->check_validrequest(); // getting location id
        $status = isset($_POST["status"]) ? $_POST["status"] : 1;
        
         if($status != "") {
             $check = $this->check_location($location_id); // check location id from db 
             if($check == 1) {
                $query = $this->Apilocations->query();
                if($query->update()->set(["status" => $status])->where(["smart_location_id" => $location_id])->execute()) {
                     $this->json("1", "Status Updated successfully");
                } else {
                     $this->json("0", "DB Error occured");
                }
             } else {
                 $this->json("0", "Unknown Location Id");
             }
        } else {
             $this->json("0", "Provide all input fields");
        }
        
        
    }
    
    /**
     * Date :- 24-june-17 
     * Function disc :- function for save bing ads credentials into database 
     * Parameter :- location_id(header), Credentials 
     * @RudrainnovativePvtLtd
     */
    
    public function saveBingCredentials() {
        $location_id = $this->check_validrequest(); // getting location id
        $credentials = isset($_POST["credential"]) ? $_POST["credential"] : "";
        
        if(!empty($credentials)) {
            $check = $this->check_location($location_id); // calling function for check location is in database or not 
            if($check == 1) {
                $query = $this->Apilocations->query();
                if($query->update()->set(["bing_token" => $credentials])->where(["smart_location_id" => $location_id])->execute()) {
                     $this->json("1", "Bing Credentials sucessfully Updated into database");
                } else {
                     $this->json("0", "DB Error occured");
                }
                
            } else {
                $this->json("0", "Unknown Location Id");
            }
        } else {
            $this->json("0", "Provide all input fields");
        }
    }
    
    
    
}





