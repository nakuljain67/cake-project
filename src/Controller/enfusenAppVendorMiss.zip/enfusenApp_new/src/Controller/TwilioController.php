<?php

namespace App\Controller;

require_once(ROOT . DS . 'vendor' . DS . "twilio" . DS . "vendor" . DS . "autoload.php"); // Including lib file

use App\Controller\AppController;
use Twilio\Rest\Client;

Class TwilioController extends AppController {
    
        
    public function initialize() {
       ob_start();
       ini_set('memory_limit', '-1');
    }
     
    

    /**
     * Date :- 13-may-17 
     * Function disc :- Display index file with twilio data from database 
     * @RudrainnovativePvtLtd 
     */
    public function index() {
        $twilioLog = $this->Twilio->find('all')->all(); // get all data from twilio database 
        $twilioArr = []; // blank array to store data 

        /* get call log data from data base and set it into blank array */
        if (iterator_count($twilioLog)) {
            foreach ($twilioLog as $key => $val):

                $twilioArr[$key]["direction"] = $val->direction;
                $twilioArr[$key]["call_from"] = $val->call_from;
                $twilioArr[$key]["call_to"] = $val->call_to;
                $twilioArr[$key]["status"] = $val->status;
                $twilioArr[$key]["duration"] = $val->duration;
                $twilioArr[$key]["call_start_time"] = $val->call_start_time;
                $twilioArr[$key]["call_end_time"] = $val->call_end_time;

            endforeach;
        }
        $this->set("twiliolog", $twilioArr);
    }

    /**
     * Date :- 13-may-17 
     * Function disc :- Function for connect with twilio api to get incomming call details 
     * @RudrainnovativePvtLtd 
     */
    public function connect() {
        try {
            $location_id = 1; // only for testing Post request 
            $output = [];
            if (isset($_POST['callmatrix'])) {
                if (!empty($_POST['callmatrix']['apikey']) && !empty($_POST['callmatrix']['apisecret'])) {
                    $AccountSid = $_POST['callmatrix']['apikey'];
                    $AuthToken = $_POST['callmatrix']['apisecret'];

                    $client = new Client($AccountSid, $AuthToken);
                    $i = 0;
                    foreach ($client->account->calls->read("50") as $call) {
                        $startTime = $call->startTime->format("Y-m-d H:i:s");
                        $endTime = $call->endTime->format("Y-m-d H:i:s");
                        $output[$i]['callfrom'] = $call->from;
                        $output[$i]['callto'] = $call->to;
                        $output[$i]['starttime'] = $startTime;
                        $output[$i]['endtime'] = $startTime;
                        $output[$i]['callduration'] = $call->duration;
                        $output[$i]['calldirection'] = $call->direction;
                        $output[$i]['apiversion'] = $call->apiVersion;
                        $output[$i]['status'] = $call->status;
                        $output[$i]['phonenumbersid'] = $call->phoneNumberSid;
                        $output[$i]['price'] = $call->price;
                        $output[$i]['priceunit'] = $call->priceUnit;
                        $i++;
                    }


                    /* insert incomming call details into database */

                    if (!empty($output)) {
                        foreach ($output as $val):
                            try {
                                $insert = $this->Twilio->newEntity();
                                $insert->location_id = $location_id;
                                $insert->direction = $val['calldirection'];
                                $insert->call_from = $val['callfrom'];
                                $insert->call_to = $val['callto'];
                                $insert->status = $val['status'];
                                $insert->duration = $val['callduration'];
                                $insert->call_start_time = $val['starttime'];
                                $insert->call_end_time = $val['endtime'];
                                $insert->api_version = $val['apiversion'];
                                $insert->phonenumbersid = $val['phonenumbersid'];
                                $insert->price = $val['price'];
                                $insert->price_unit = $val['priceunit'];

                                $this->Twilio->save($insert);
                            } catch (Exception $e) {
                                echo "Error :-" . $e->getMessage();
                            }

                        endforeach;
                    }

                    $this->Flash->success(__('All Incoming call data inserted into dashboard.'));
                    return $this->redirect(['action' => 'index']);
                } else {
                    $this->Flash->error(__('Please fill fields correctally.'));
                    return $this->redirect(['action' => 'index']);
                }
            }
        } catch (Exception $e) {
            echo "Error :-" . $e->getMessage();
        }
    }

    /**
     * Date :- 29-may-17 
     * Function disc :- Function for get today call log from twilio api 
     * @RudrainnovativePvtLtd 
     */
    public function todayLog($location_id, $apiKey, $apisecret) {
        ob_start();
        try {
            $location_id = 1; // only for testing Post request 
            $output = [];
            $apiKey = "AC3e486c4443c0e0b24e8427014b7acacb";
            $apisecret = "3c1a51246f8a564359d7ea63e3779549";
            $date = date('Y-m-d', strtotime("-1 days"));

            if (!empty($apiKey) && !empty($apisecret)) {
                $AccountSid = $apiKey;
                $AuthToken = $apisecret;

                $client = new Client($AccountSid, $AuthToken);
                
                $i = 0;
                foreach ($client->account->calls->read(["startTime" => $date]) as $call) {
                    $startTime = $call->startTime->format("Y-m-d H:i:s");
                    $endTime = $call->endTime->format("Y-m-d H:i:s");
                    $output[$i]['callfrom'] = $call->from;
                    $output[$i]['callto'] = $call->to;
                    $output[$i]['starttime'] = $startTime;
                    $output[$i]['endtime'] = $startTime;
                    $output[$i]['callduration'] = $call->duration;
                    $output[$i]['calldirection'] = $call->direction;
                    $output[$i]['apiversion'] = $call->apiVersion;
                    $output[$i]['status'] = $call->status;
                    $output[$i]['phonenumbersid'] = $call->phoneNumberSid;
                    $output[$i]['price'] = $call->price;
                    $output[$i]['priceunit'] = $call->priceUnit;
                    $i++;
                }
                
               /* insert incomming call details into database */

                if (!empty($output)) {
                    foreach ($output as $val):
                        try {
                            $insert = $this->Twilio->newEntity();
                            $insert->location_id = $location_id;
                            $insert->direction = $val['calldirection'];
                            $insert->call_from = $val['callfrom'];
                            $insert->call_to = $val['callto'];
                            $insert->status = $val['status'];
                            $insert->duration = $val['callduration'];
                            $insert->call_start_time = $val['starttime'];
                            $insert->call_end_time = $val['endtime'];
                            $insert->api_version = $val['apiversion'];
                            $insert->phonenumbersid = $val['phonenumbersid'];
                            $insert->price = $val['price'];
                            $insert->price_unit = $val['priceunit'];

                            $this->Twilio->save($insert);
                        } catch (Exception $e) {
                            echo "Error :-" . $e->getMessage();
                        }

                    endforeach;
                }
            } 
        } catch (Exception $e) {
            echo "Error :-" . $e->getMessage();
        }
    }
    
}
