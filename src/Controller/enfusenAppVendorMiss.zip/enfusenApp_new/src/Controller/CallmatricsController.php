<?php 

namespace App\controller;


require_once(ROOT . DS . 'vendor' . DS ."callmetrics" . DS . "lib" . DS . "ctm.php");

use AuthToken;
use Number;
use Cake\ORM\TableRegistry;
use App\Controller\AppController;

Class CallmatricsController extends AppController {

	/** 
	  * Date :- may-17 
	  * Function disc :- display index page with callmetrics data get from database  
	  * @RudrainnovativePvtLtd 
	  */
	
	public function index() 
	{
		$all = $this->Callmatrics->find("all")->toArray();
		$return = [];
		if(!empty($all))
		{
			$return['token'] = $all[0]->token;
			$return['account_id'] = $all[0]->account_id;
			$return['apikey'] = $all[0]->apikey;
			$return['apisecret'] = $all[0]->apisecret;
			$return['mobile_data'] = $all[0]->mobile_data;
			$this->set("userdata", $return);    
		}
		
	}

	
	/** 
	  * Date :- may-17 
	  * Function disc :- Function for connect with callTrackingMetrics API  
	  * @RudrainnovativePvtLtd 
	  */

	public function connect()
	{
		try {
			
			/* Condition for validate api key data field */
			if($_POST['callmatrix']['apikey'] != '' && $_POST['callmatrix']['apisecret'])
			{
				$apiKey = trim($_POST['callmatrix']['apikey']); 
				$apiSecret = trim($_POST['callmatrix']['apisecret']);
				$auth_token = AuthToken::authorize($apiKey,$apiSecret);
				if ($auth_token) {
                    $new=[];
                    $new["apikey"]= $apiKey ;
                    $new["apiSecret"]= $apiSecret ;
                    //pr($new); die;
                    $users_table = TableRegistry::get('api_locations');
	                $insert1 = $users_table->newEntity();
	                $insert1->calltracking_info = json_encode($new);
                    $users_table->save($insert1);

                    $mobile = [];
					$number  = Number::list_numbers($auth_token);
					$insert = $this->Callmatrics->newEntity();
					if(count($number->items) != 0)
					{
						$i = 0;
						foreach($number->items as $data)
						{
							$mobile[$i]["id"] = $data->id;
							$mobile[$i]["number"] = $data->number;
							$i++;
						}
					}
					
					$insert->mobile_data = json_encode($mobile);
					$insert->token = $auth_token->token;
					$insert->account_id = $auth_token->account_id;
					$insert->apikey = $apiKey;
					$insert->apisecret = $apiSecret;

				  /* Check data save into database or not */				  
				  if($this->Callmatrics->save($insert)) {

						$this->Flash->success(__('CallMetrics connected successfull'));
						return $this->redirect(['action' => 'index']);

					} else {

						$this->Flash->error(__('Some Error occured.'));
						return $this->redirect(['action' => 'index']);
					}

				} else {

				  $this->Flash->error(__('Invalid Credentials.'));
				  return $this->redirect(['action' => 'index']);
				}
			}
			else 
			{
				$this->Flash->error(__('All Form fields are required.'));
				return $this->redirect(['action' => 'index']);
			}



			} catch(Exception $e) {
				echo 'Message: ' .$e->errorMessage();
			}

	}

var $paginate = array(
'limit' => 25,
);

public function callDetails(){
         $users = TableRegistry::get('calldetails');
         $query = $this->paginate($users->find());
        // pr($query);die;
         $this->set('users',$query);
         $total = $users->find()->count();
         //pr($total); die;
         $missed=$users->find()->where(['call_status' => 'no answer'])->count();
         $answered= $total - $missed;
         $this->set('total',$total);
         $this->set('missed',$missed);
         $this->set('answered',$answered);
         $direct =$users->find()->where(['source' => 'Direct'])->count();
         $google =$users->find()->where(['source' => 'Google Organic'])->count();
         $bing = $users->find()->where(['source' => 'Bing Organic'])->count();
           $this->set('direct',$direct);
           $this->set('google',$google);
           $this->set('bing',$bing);
        // pr($answered); die;
       }
}
