<?php

namespace App\Controller;

Use App\Controller\AppController;
use Cake\I18n\Time;
Use stdClass;

Class CallRailController extends AppController {
    /* CallRail API Help URL :- http://legacy-apidocs.callrail.com/objects/calls/ */

    /**
     * Date :- 18-may-17 
     * Function disc :- display index page with callrail connected data get from database  
     * @RudrainnovativePvtLtd 
     */
    public function index() {
        $callLog = []; // array for store call log information 

        /* Fetch callrail data from database */
        $callrailData = $this->CallRail->find("all")->all();
        if (iterator_count($callrailData)) {
            foreach ($callrailData as $key => $val):

                $callLog[$key]["company_name"] = $val->company_name;
                $callLog[$key]["start_time"] = $val->start_time;
                $callLog[$key]["customer_name"] = $val->customer_name;
                $callLog[$key]["customer_phone_number"] = $val->customer_phone_number;
                $callLog[$key]["customer_city"] = $val->customer_city;
                $callLog[$key]["duration"] = $val->duration;
                $callLog[$key]["keywords"] = $val->keywords;
                $callLog[$key]["direction"] = $val->direction;

            endforeach;

            /* set data into variable to display it in view */
            $this->set("callrail", $callLog);
        }
    }

    /**
     * Date :- 18-may-17 
     * Function disc :- function for conenct with callrail api 
     * Help Url :- http://legacy-apidocs.callrail.com/examples/php/
     * @RudrainnovativePvtLtd 
     */
    public function connect() {
        if (!isset($_POST["callrail"]["apikey"]) && empty($_POST["callrail"]["apikey"])) {
            /* Connection code with callrail api */
            try {

                $api_key = CALL_RAIL_APIKEY;   // getting callrail api key from user 
                $api_url = CALL_RAIL_APIURL;

                $ch = curl_init($api_url);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                // authenticate token send in header to verify api key 
                curl_setopt($ch, CURLOPT_HTTPHEADER, array("Authorization: Token token=\"{$api_key}\""));
                $json_data = curl_exec($ch);
                $parsed_data = json_decode($json_data);
                curl_close($ch);

                echo "<pre>";
                print_r($parsed_data);
                die('here');

                // Condition if wrong callrail api key 
                if (isset($parsed_data->error)) {
                    $this->Flash->error(__("API key error .."));
                    return $this->redirect(["action" => "index"]);
                } else {
                    /* Insert callrail api response data into database */
                    $callrail = $this->CallRail->newEntity();
                    $callrail->callrail_id = $parsed_data->accounts[0]->id;
                    $callrail->name = $parsed_data->accounts[0]->name;

                    /* Condition check data insert into database or not */
                    if ($this->CallRail->save($callrail)) {
                        $this->Flash->success(__("Successfully connected with CallRail API."));
                        return $this->redirect(["action" => "index"]);
                    } else {
                        $this->Flash->error(__("Connection Error...!!!"));
                        return $this->redirect(["action" => "index"]);
                    }
                }
            } catch (Exception $e) {
                echo "Error" . $e->getMessage();
            }
        } else {
            $this->Flash->error(__("Api key shouldn't be blank..!!"));
            return $this->redirect(["action" => "index"]);
        }
    }

    /**
     * Date :- 25-may-17 
     * Update :- 29-may-17
     * Updated :- 17-07-17   
     * Function disc :- function for get all callrail call logs 
     * Help Url :- http://apidocs.callrail.com/#listing-all-calls
     * @RudrainnovativePvtLtd 
     */
    public function callLog($location_id, $api_key, $accountId) {
        ob_start();
        try {
            $api_key = 'ed4c96b7a91985d340c656a25903840e';   // getting callrail api key from user 
            $accountId = '327429711';
            $location_id = 1; // only for testinfg purposes 	
            $check = 0;
            $total_page = $this->getPage($api_key, $accountId);

            for ($i = 1; $i < $total_page; $i++) {
                $logData = []; // empty array to store call log data 
                $api_url = "https://api.callrail.com/v2/a/" . $accountId . "/calls.json?fields=company_name,device_type,tracker_id,keywords,formatted_business_phone_number,source_name,utm_campaign,company_name,utm_source,utm_medium&page=" . $i;


                $ch = curl_init($api_url);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                // authenticate token send in header to verify api key 
                curl_setopt($ch, CURLOPT_HTTPHEADER, array("Authorization: Token token=\"{$api_key}\""));
                $json_data = curl_exec($ch);
                $parsed_data = json_decode($json_data);
                curl_close($ch);


                //pr($parsed_data); die('here'); 

                /* Storing call log into a array to save into database */
                if (($parsed_data->total_records > 0)) {
                    foreach ($parsed_data->calls as $key => $val):

                        $logData[$key]['answered'] = $val->answered;
                        $logData[$key]['business_phone_number'] = $val->business_phone_number;
                        $logData[$key]['customer_city'] = $val->customer_city;
                        $logData[$key]['customer_country'] = $val->customer_country;
                        $logData[$key]['customer_name'] = $val->customer_name;
                        $logData[$key]['customer_phone_number'] = $val->customer_phone_number;
                        $logData[$key]['customer_state'] = $val->customer_state;
                        $logData[$key]['customer_zip'] = $val->customer_zip;
                        $logData[$key]['direction'] = $val->direction;
                        $logData[$key]['duration'] = $val->duration;
                        $logData[$key]['id'] = $val->id;
                        $logData[$key]['recording'] = $val->recording;
                        $logData[$key]['recording_duration'] = $val->recording_duration;
                        $logData[$key]['start_time'] = $val->start_time;
                        $logData[$key]['tracking_phone_number'] = $val->tracking_phone_number;
                        $logData[$key]['voicemail'] = $val->voicemail;
                        $logData[$key]['company_name'] = $val->company_name;
                        $logData[$key]['device_type'] = $val->device_type;
                        $logData[$key]['tracker_id'] = $val->tracker_id;
                        $logData[$key]['keywords'] = $val->keywords;
                        $logData[$key]['formatted_business_phone_number'] = $val->formatted_business_phone_number;
                        $logData[$key]['source_name'] = $val->source_name;
                        $logData[$key]['utm_campaign'] = $val->utm_campaign;
                        $logData[$key]['utm_source'] = $val->utm_source;
                        $logData[$key]['utm_medium'] = $val->utm_medium;
                    endforeach;
                }

                /* Insert into database if not empty */
                if (!empty($logData)) {
                    /* Insert value a/c to log Loop data */
                    foreach ($logData as $data):

                        $setArray = []; // empty array to store update data 

                        $dbCheck = $this->checkDb($data['id']);
                        if ($dbCheck == 0) {
                            $callrail = $this->CallRail->newEntity();
                            $callrail->location_id = $location_id;
                            $callrail->call_id = $data['id'];
                            $callrail->is_answered = $data['answered'];
                            $callrail->business_phone_number = $data['business_phone_number'];
                            $callrail->customer_city = $data['customer_city'];
                            $callrail->customer_country = $data['customer_country'];
                            $callrail->customer_name = $data['customer_name'];
                            $callrail->customer_phone_number = $data['customer_phone_number'];
                            $callrail->customer_state = $data['customer_state'];
                            $callrail->customer_zip = $data['customer_zip'];
                            $callrail->direction = $data['direction'];
                            $callrail->duration = $data['duration'];
                            $callrail->recording = $data['recording'];
                            $callrail->recording_duration = $data['recording_duration'];
                            $callrail->start_time = $data['start_time'];
                            $callrail->tracking_phone_number = $data['tracking_phone_number'];
                            $callrail->voicemail = $data['voicemail'];
                            $callrail->company_name = $data['company_name'];
                            $callrail->device_type = $data['device_type'];
                            $callrail->tracker_id = $data['tracker_id'];
                            $callrail->keywords = $data['keywords'];
                            $callrail->formatted_business_phone_number = $data['formatted_business_phone_number'];
                            $callrail->source_name = $data['source_name'];
                            $callrail->utm_campaign = $data['utm_campaign'];
                            $callrail->utm_source = $data['utm_source'];
                            $callrail->utm_medium = $data['utm_medium'];
                            $callrail->page_no = $i;

                            if ($this->CallRail->save($callrail)) {
                                $check ++;
                            }
                        } else {
                            $setArray['location_id'] = $location_id;
                            $setArray['call_id'] = $data['id'];
                            $setArray['is_answered'] = $data['answered'];
                            $setArray['business_phone_number'] = $data['business_phone_number'];
                            $setArray['customer_city'] = $data['customer_city'];
                            $setArray['customer_country'] = $data['customer_country'];
                            $setArray['customer_name'] = $data['customer_name'];
                            $setArray['customer_phone_number'] = $data['customer_phone_number'];
                            $setArray['customer_state'] = $data['customer_state'];
                            $setArray['customer_zip'] = $data['customer_zip'];
                            $setArray['direction'] = $data['direction'];
                            $setArray['duration'] = $data['duration'];
                            $setArray['recording'] = $data['recording'];
                            $setArray['recording_duration'] = $data['recording_duration'];
                            $setArray['start_time'] = $data['start_time'];
                            $setArray['tracking_phone_number'] = $data['tracking_phone_number'];
                            $setArray['voicemail'] = $data['voicemail'];
                            $setArray['company_name'] = $data['company_name'];
                            $setArray['device_type'] = $data['device_type'];
                            $setArray['tracker_id'] = $data['tracker_id'];
                            $setArray['keywords'] = $data['keywords'];
                            $setArray['formatted_business_phone_number'] = $data['formatted_business_phone_number'];
                            $setArray['source_name'] = $data['source_name'];
                            $setArray['utm_campaign'] = $data['utm_campaign'];
                            $setArray['utm_source'] = $data['utm_source'];
                            $setArray['utm_medium'] = $data['utm_medium'];
                            $setArray['updated_at'] = date('Y-m-d h:i:s');

                            /* Update db using values */
                            $query = $this->CallRail->query();
                            $query->update()
                                    ->set($setArray)
                                    ->where(['call_id' => $data['id']])
                                    ->execute();
                            $check ++;
                        }

                    endforeach;
                }
            }
            /*
              if($check > 0 && $check != 0)
              {
              $this->Flash->success(__('Call Log Updated successfully into database .'));
              return $this->redirect(['action' => 'index']);
              }
              else
              {
              $this->Flash->error(__('Call log updation failled.'));
              return $this->redirect(['action' => 'index']);
              }
             * 
             */
        } catch (Exception $e) {
            echo "Error :-" . $e->getMessage();
        }
    }

    /**
     * Date :- 29-may-17 
     * Function disc :- Function for get page number 
     * @RudrainnovativePvtLtd 
     */
    private function getPage($apiKey = null, $accountId = null) {
        try {

            $api_url = "https://api.callrail.com/v2/a/" . $accountId . "/calls.json?fields=company_name,device_type,tracker_id,keywords,formatted_business_phone_number&page=1";


            $ch = curl_init($api_url);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            // authenticate token send in header to verify api key 
            curl_setopt($ch, CURLOPT_HTTPHEADER, array("Authorization: Token token=\"{$apiKey}\""));
            $json_data = curl_exec($ch);
            curl_close($ch);

            $parsed_data = json_decode($json_data); // parse json output 

            if (!empty($parsed_data)) {
                $page = $parsed_data->total_pages;
            }

            return $page;
        } catch (Exception $e) {
            echo "Error :-" . $e->getMessage();
        }
    }

    /**
     * Date :- 29-may-17 
     * Function disc :- Function for check database a/c to call id 
     * @RudrainnovativePvtLtd 
     */
    private function checkDb($callId = null) {
        try {
            $callrailData = $this->CallRail->find('all')->where(['call_id' => $callId])->all();

            if (iterator_count($callrailData)) {
                return 1;
            } else {
                return 0;
            }
        } catch (Exception $e) {
            echo "Error :- " . $e->getMessage();
        }
    }

    /**
     * Date :- 29-may-17 
     * Updated :- 17-07-17  
     * Function disc :- get today call log 
     * @RudrainnovativePvtLtd 
     */
    public function getTodaylog($location_id, $api_key, $accountId) {
        ob_start();
        try {
            // $api_key = 'ed4c96b7a91985d340c656a25903840e'; 		// getting callrail api key from user 
            // $accountId = '327429711';
            // $location_id = 1; // only for testinfg purposes 	
            $check = 0;
            $total_page = $this->getPage($api_key, $accountId);

            for ($i = 1; $i < $total_page; $i++) {
                $logData = []; // empty array to store call log data 
                $api_url = "https://api.callrail.com/v2/a/" . $accountId . "/calls.json?fields=company_name,device_type,tracker_id,keywords,formatted_business_phone_number,source_name,utm_campaign&page=" . $i . "&date_range=today";


                $ch = curl_init($api_url);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

                // authenticate token send in header to verify api key 
                curl_setopt($ch, CURLOPT_HTTPHEADER, array("Authorization: Token token=\"{$api_key}\""));
                $json_data = curl_exec($ch);
                $parsed_data = json_decode($json_data);
                curl_close($ch);

                //pr($parsed_data); die("here");


                /* Storing call log into a array to save into database */
                if (($parsed_data->total_records > 0)) {
                    foreach ($parsed_data->calls as $key => $val):

                        $logData[$key]['answered'] = $val->answered;
                        $logData[$key]['business_phone_number'] = $val->business_phone_number;
                        $logData[$key]['customer_city'] = $val->customer_city;
                        $logData[$key]['customer_country'] = $val->customer_country;
                        $logData[$key]['customer_name'] = $val->customer_name;
                        $logData[$key]['customer_phone_number'] = $val->customer_phone_number;
                        $logData[$key]['customer_state'] = $val->customer_state;
                        $logData[$key]['customer_zip'] = $val->customer_zip;
                        $logData[$key]['direction'] = $val->direction;
                        $logData[$key]['duration'] = $val->duration;
                        $logData[$key]['id'] = $val->id;
                        $logData[$key]['recording'] = $val->recording;
                        $logData[$key]['recording_duration'] = $val->recording_duration;
                        $logData[$key]['start_time'] = $val->start_time;
                        $logData[$key]['tracking_phone_number'] = $val->tracking_phone_number;
                        $logData[$key]['voicemail'] = $val->voicemail;
                        $logData[$key]['company_name'] = $val->company_name;
                        $logData[$key]['device_type'] = $val->device_type;
                        $logData[$key]['tracker_id'] = $val->tracker_id;
                        $logData[$key]['keywords'] = $val->keywords;
                        $logData[$key]['formatted_business_phone_number'] = $val->formatted_business_phone_number;
                        $logData[$key]['source_name'] = $val->source_name;
                        $logData[$key]['utm_campaign'] = $val->utm_campaign;
                        $logData[$key]['utm_source'] = $val->utm_source;
                        $logData[$key]['utm_medium'] = $val->utm_medium;
                    endforeach;
                }
                else {
                    $this->Flash->error(__('No call Logs for Today.'));
                    return $this->redirect(['action' => 'index']);
                }

                /* Insert into database if not empty */
                if (!empty($logData)) {
                    /* Insert value a/c to log Loop data */
                    foreach ($logData as $data):

                        $setArray = []; // empty array to store update data 

                        $dbCheck = $this->checkDb($data['id']);
                        if ($dbCheck == 0) {
                            $callrail = $this->CallRail->newEntity();
                            $callrail->location_id = $location_id;
                            $callrail->call_id = $data['id'];
                            $callrail->is_answered = $data['answered'];
                            $callrail->business_phone_number = $data['business_phone_number'];
                            $callrail->customer_city = $data['customer_city'];
                            $callrail->customer_country = $data['customer_country'];
                            $callrail->customer_name = $data['customer_name'];
                            $callrail->customer_phone_number = $data['customer_phone_number'];
                            $callrail->customer_state = $data['customer_state'];
                            $callrail->customer_zip = $data['customer_zip'];
                            $callrail->direction = $data['direction'];
                            $callrail->duration = $data['duration'];
                            $callrail->recording = $data['recording'];
                            $callrail->recording_duration = $data['recording_duration'];
                            $callrail->start_time = $data['start_time'];
                            $callrail->tracking_phone_number = $data['tracking_phone_number'];
                            $callrail->voicemail = $data['voicemail'];
                            $callrail->company_name = $data['company_name'];
                            $callrail->device_type = $data['device_type'];
                            $callrail->tracker_id = $data['tracker_id'];
                            $callrail->keywords = $data['keywords'];
                            $callrail->formatted_business_phone_number = $data['formatted_business_phone_number'];
                            $callrail->source_name = $data['source_name'];
                            $callrail->utm_campaign = $data['utm_campaign'];
                            $callrail->utm_source = $data['utm_source'];
                            $callrail->utm_medium = $data['utm_medium'];
                            $callrail->page_no = $i;

                            if ($this->CallRail->save($callrail)) {
                                $check ++;
                            }
                        } else {
                            $setArray['location_id'] = $location_id;
                            $setArray['call_id'] = $data['id'];
                            $setArray['is_answered'] = $data['answered'];
                            $setArray['business_phone_number'] = $data['business_phone_number'];
                            $setArray['customer_city'] = $data['customer_city'];
                            $setArray['customer_country'] = $data['customer_country'];
                            $setArray['customer_name'] = $data['customer_name'];
                            $setArray['customer_phone_number'] = $data['customer_phone_number'];
                            $setArray['customer_state'] = $data['customer_state'];
                            $setArray['customer_zip'] = $data['customer_zip'];
                            $setArray['direction'] = $data['direction'];
                            $setArray['duration'] = $data['duration'];
                            $setArray['recording'] = $data['recording'];
                            $setArray['recording_duration'] = $data['recording_duration'];
                            $setArray['start_time'] = $data['start_time'];
                            $setArray['tracking_phone_number'] = $data['tracking_phone_number'];
                            $setArray['voicemail'] = $data['voicemail'];
                            $setArray['company_name'] = $data['company_name'];
                            $setArray['device_type'] = $data['device_type'];
                            $setArray['tracker_id'] = $data['tracker_id'];
                            $setArray['keywords'] = $data['keywords'];
                            $setArray['formatted_business_phone_number'] = $data['formatted_business_phone_number'];
                            $setArray['source_name'] = $data['source_name'];
                            $setArray['utm_campaign'] = $data['utm_campaign'];
                            $setArray['utm_source'] = $data['utm_source'];
                            $setArray['utm_medium'] = $data['utm_medium'];
                            $setArray['updated_at'] = date('Y-m-d h:i:s');

                            /* Update db using values */
                            $query = $this->CallRail->query();
                            $query->update()
                                    ->set($setArray)
                                    ->where(['call_id' => $data['id']])
                                    ->execute();
                            $check ++;
                        }

                    endforeach;
                }
            }
        } catch (Exception $e) {
            echo "Error :-" . $e->getMessage();
        }
    }

}

