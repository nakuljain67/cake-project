<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Sems Controller
 *
 * @property \App\Model\Table\SemsTable $Sems
 *
 * @method \App\Model\Entity\Sem[] paginate($object = null, array $settings = [])
 */
class SemsController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Sems']
        ];
        $sems = $this->paginate($this->Sems);

        $this->set(compact('sems'));
        $this->set('_serialize', ['sems']);
    }

    /**
     * View method
     *
     * @param string|null $id Sem id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $sem = $this->Sems->get($id, [
            'contain' => ['Sems']
        ]);

        $this->set('sem', $sem);
        $this->set('_serialize', ['sem']);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $sem = $this->Sems->newEntity();
        if ($this->request->is('post')) {
            $sem = $this->Sems->patchEntity($sem, $this->request->getData());
            if ($this->Sems->save($sem)) {
                $this->Flash->success(__('The sem has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The sem could not be saved. Please, try again.'));
        }
        $sems = $this->Sems->Sems->find('list', ['limit' => 200]);
        $this->set(compact('sem', 'sems'));
        $this->set('_serialize', ['sem']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Sem id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $sem = $this->Sems->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $sem = $this->Sems->patchEntity($sem, $this->request->getData());
            if ($this->Sems->save($sem)) {
                $this->Flash->success(__('The sem has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The sem could not be saved. Please, try again.'));
        }
        $sems = $this->Sems->Sems->find('list', ['limit' => 200]);
        $this->set(compact('sem', 'sems'));
        $this->set('_serialize', ['sem']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Sem id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $sem = $this->Sems->get($id);
        if ($this->Sems->delete($sem)) {
            $this->Flash->success(__('The sem has been deleted.'));
        } else {
            $this->Flash->error(__('The sem could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
