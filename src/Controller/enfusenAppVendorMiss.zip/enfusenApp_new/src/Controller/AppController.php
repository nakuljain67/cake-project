<?php

/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link      http://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   http://www.opensource.org/licenses/mit-license.php MIT License
 */

namespace App\Controller;

use Cake\Controller\Controller;
use Cake\Event\Event;

require_once(ROOT . DS . 'vendor' . DS . "gaconnect" . DS . "vendor" . DS . "autoload.php");

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @link http://book.cakephp.org/3.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {

    /**
     * Initialization hook method.
     *
     * Use this method to add common initialization code like loading components.
     *
     * e.g. `$this->loadComponent('Security');`
     *
     * @return void
     */
    public function initialize() {
        parent::initialize();

        $this->loadComponent('RequestHandler');
        $this->loadComponent('Flash');

        /*
         * Enable the following components for recommended CakePHP security settings.
         * see http://book.cakephp.org/3.0/en/controllers/components/security.html
         */
        //$this->loadComponent('Security');
        //$this->loadComponent('Csrf');

        /* aman@rudrainnovatives.com date:- 08-may-2017 */
        $array_api_controllers = array("api");
        if (!in_array(strtolower($this->request->params['controller']), $array_api_controllers)) {
            $this->loadComponent('Auth', [
                'authenticate' => [
                    'Form' => [
                        'fields' => [
                            'username' => 'email',
                            'password' => 'password'
                        ]
                    ]
                ],
                'loginAction' => [
                    'controller' => 'Users',
                    'action' => 'login'
                ],
                'unauthorizedRedirect' => $this->referer() // If unauthorized, return them to page they were just on
            ]);

            // Allow the display action so our pages controller
            // continues to work.
            $this->Auth->allow(['display']);
        }
    }

    /**
     * Before render callback.
     *
     * @param \Cake\Event\Event $event The beforeRender event.
     * @return \Cake\Network\Response|null|void
     */
    public function beforeRender(Event $event) {
        if (!array_key_exists('_serialize', $this->viewVars) &&
                in_array($this->response->type(), ['application/json', 'application/xml'])
        ) {
            $this->set('_serialize', true);
        }
    }

    public function json($code, $message, $data = array()) {
        $arr = array(
            'sts' => $code,
            'msg' => $message,
            'arr' => $data
        );
        header("Content-Type:application/json; charset=UTF-8");
        echo json_encode($arr);
        exit();
    }

    protected function throwerror($msg) {
        echo $msg;
        exit();
    }

    /* protected function check_validrequest() {
      $allheaders = getallheaders();
      $location_id = 0;
      if (!empty($allheaders)) {
      $location_id = $allheaders['location_id'];
      } else {
      $this->json(0, "Invalid Header");
      }
      return $location_id;
      } */

    protected function check_validrequest() {
        $allheaders = getallheaders();
        $location_id = isset($allheaders['location_id']) && intval($allheaders['location_id']) > 0 ? intval($allheaders['location_id']) : 0;
        if ($location_id > 0) {
            return $location_id;
        }
        $this->json(0, "Invalid Header");
    }
    
    
     /* PLACESCOUT PARAMETERS */

    public function placesscout_api_info() {
        $pc_api['username'] = "rbryan";
        $pc_api['password'] = "TG7RN5XvKaJvt9UiAKYpAy8";
        $pc_api['main_api_url'] = "https://apihost1.placesscout.com/";
        return $pc_api;
    }

    public function googleclient() {
        $client = new \Google_Client();
        $client->setAccessType('offline');
        $client->setClientId(GA_CLIENTID);
        $client->setClientSecret(GA_CLIENT_SECRET);
        $client->setApprovalPrompt('force');
        $client->setScopes(GA_SCOPES);
        return $client;
    }

    public function ToFloat($Num) {
        return !empty($Num) ? floatval($Num) : 0.0;
    }

    public function FormatFloat($Num, $NDecimals = 2) {
        return number_format($Num, $NDecimals);
    }

    public function PerSentFormat($Num, $NDecimals = 2, $DivBy = 100.0) {
        return number_format(ToFloat($Num) / $DivBy, $NDecimals) . '%';
    }

    public function SecondsToMinSec($Seconds) {
        return strval(intval($Seconds / 60)) . ':' . strval($Seconds % 60);
    }

    public function FormatMoney($Num, $NDecimals = 2) {
        return ($Num >= 0 ? '' : '-') . '$' . number_format(abs($Num), $NDecimals);
    }

    public function MoneyFromMicros($Amount) {
        return $Amount / MICROS_CONV;
    }

    public function MoneyToMicros($Amount) {
        return $Amount * MICROS_CONV;
    }
    
   /* ------------------ Added :- 28-june-17 ---------------------------- */ 
    public function pc_get($username, $password, $main_api_url, $curl_url, $additional = array()) {
        $FinalURL = $main_api_url . $curl_url;
        $location_id = isset($additional['location_id'])?intval($additional['location_id']):0;
        if($location_id > 0){
            $headers =  array("location_id: " . $location_id);
        } else {
            $headers =  array();
        }
        
        $contentType = isset($additional['contentType'])?trim($additional['contentType']):"";
        if($contentType != ''){
            array_push($headers, $contentType);
        }
        $ch = curl_init($FinalURL);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        if ($username != "" && $password != "") {
            curl_setopt($ch, CURLOPT_USERPWD, $username . ":" . $password);
        }
        return $result_on = curl_exec($ch);
    }

    
    /* post request via cURL */

    public function pc_post($username, $password, $main_api_url, $curl_url, $data_string, $additional = array()) {
        try {
           
            $FinalURL = $main_api_url . $curl_url;
            $ch = curl_init($FinalURL);
            $location_id = isset($additional['location_id'])?intval($additional['location_id']):0;
            if($location_id > 0){
                $headers =  array("Content-Length: " . strlen($data_string), "location_id: " . $location_id);
            }else {
                $headers =  array("Content-Length: " . strlen($data_string));
            }
            
            $contentType = isset($additional['contentType'])?trim($additional['contentType']):"";
            if($contentType != ''){
                array_push($headers, $contentType);
            }
                        
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
            if ($username != "" && $password != "") {
                curl_setopt($ch, CURLOPT_USERPWD, $username . ":" . $password);
            }
            $Val = curl_exec($ch);
            return $Val;
        } catch (Exception $ex) {
            
        }
    }
}
