<?php

namespace App\Controller;

require_once(ROOT . DS . 'vendor' . DS . "adwords" . DS . "vendor" . DS . "autoload.php");

use Google\Auth\OAuth2;
use Google\AdsApi\AdWords\AdWordsServices;
use Google\AdsApi\AdWords\AdWordsSessionBuilder;
use Google\AdsApi\Common\OAuth2TokenBuilder;
use Google\AdsApi\AdWords\v201702\mcm\CustomerService;
use App\Controller\AppController;

Class AdwordsController extends AppController {
    
    private $clientId; //variable for store client id from database 
    private $secret; // variable for store client secret from database 
    private $redirect; // variable for store redirect url for Adwords 
    private static $configIniFilePath = __DIR__ . "/../../adsapi_php.ini";  // include adsapi_php.ini path 

    public function initialize() {
        parent::initialize();
        $this->getCredentials(); // call function for auto set credentials 
    }

    /**
     * Date :- may-17 
     * Updated :- 22-may-17
     * Function disc :- display index page with adwords data get from database  
     * @RudrainnovativePvtLtd 
     */
    public function index() {
        $table = $this->loadModel('ApiLocations');
        $all = $table->find("all", array("condition" => array("status" => 1, "adword_token <>" => "")))->toArray();
        $return = [];
        if (!empty($all)) {
            foreach($all as $key => $val):
                $return[$key]["location_id"] = $val->smart_location_id;
            endforeach;
            $this->set("locations", $return); // send data into another page view 
        }
    }
    
   /**
     * Date :- may-17 
     * Updated :- 22-may-17
     * Function disc :- Function for connect with google adwords  
     * @RudrainnovativePvtLtd 
     */
    public function connect() {
        
        /* setting location */
        if(isset($_POST['location']) && !empty($_POST['location'])){
           $_SESSION["Client.location"] = $_POST['location'];
        }
        // else {
        //     $this->Flash->error(__('Select a location first to connect with Google Adwords.'));
        //     return $this->redirect(['action' => 'index']);
        // }
        
        $oauth2 = new OAuth2([
            'authorizationUri' => ADWORDS_AUTHORIZATION_URI,
            'tokenCredentialUri' => ADWORDS_TOKEN_CREDENTIAL_URI,
            'redirectUri' => $this->redirect,
            'clientId' => $this->clientId,
            'clientSecret' => $this->secret,
            'scope' => ADWORDS_SCOPE
        ]);

        if (!isset($_GET['code'])) {

            $oauth2->setState(sha1(openssl_random_pseudo_bytes(1024)));
            $_SESSION['oauth2state'] = $oauth2->getState();

            $config = [
                // Set to 'offline' if you require offline access.
                'access_type' => 'offline'
            ];
            header('Location: ' . $oauth2->buildFullAuthorizationUri($config));
            exit;
        }
        // Check given state against previously stored one to mitigate CSRF attack.
        elseif (empty($_GET['state']) || ($_GET['state'] !== $_SESSION['oauth2state'])) {
            unset($_SESSION['oauth2state']);
            exit('Invalid state.');
        } else {
            $oauth2->setCode($_GET['code']);
            $authToken = $oauth2->fetchAuthToken();

            // Store the refresh token for your user in your local storage if you
            // requested offline access.
            $refreshToken = $authToken['refresh_token'];
        }

        $session = (new AdWordsSessionBuilder())
                ->fromFile(self::$configIniFilePath)
                ->withOAuth2Credential($oauth2)
                ->build();

        /* Creating object of Adwords services */
        $adWordsServices = new AdWordsServices();

        /* Adwords Customer services */
        $customerService = $adWordsServices->get($session, CustomerService::class);
        $customers = $customerService->getCustomers();
        $customerId = $customers[0]->getCustomerId();  // Getting main customer client id 

        $apiOptions = $this->loadModel("ApiLocations");

        /* Condition check for store none empty data into data base */
        if (!empty($authToken)) {
            
            $location = $_SESSION['Client.location'];
            
           /* Set a new entry Update it into database */

            $update = []; // blank array for update data into database into api locations table
            $update['adword_token'] = json_encode($authToken);
            $update['adword_custid'] = $customerId;

            $query = $apiOptions->query();
            if ($query->update()->set($update)->where(["smart_location_id" => $location])->execute()) {
                unset($_SESSION['Client.location']); // unset location from session 
                $this->Flash->success(__("Successfully connected with google adwords."));
                return $this->redirect(["action" => "index"]);
            } else {
                unset($_SESSION['Client.location']); // unset location from session
                $this->Flash->error(__("You are not connected with Adwords. Please Try again..!!"));
                return $this->redirect(['action' => "index"]);
            }
        }
    }

    /**
     * Date :-14-june-17
     * Function disc :- Function for get credentials for adwords from database   
     * @RudrainnovativePvtLtd 
     */
    private function getCredentials() {
        $model = $this->loadModel("ApiOptions");
        $dbCredentials = $model->find('all', array("conditions" => array("option_key" => "adword")))->toArray();

        if (!empty($dbCredentials)) {
            $credentials = $dbCredentials[0]->option_value;
            $credentialValue = json_decode($credentials);

            if (!empty($credentialValue)) {
                /* Setting client credentials from database */
                $this->clientId = $credentialValue->clientId;
                $this->secret = $credentialValue->secret;
                $this->redirect = $credentialValue->redirect;
            }
        }
    }
    
   

}
