<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;

Class AdwordApiController extends AppController {

    private $limit;
    private $location_id;
    private $default;

    /**
     * Date :- 19-june-17 
     * Function disc :- Function for initialize  
     * @RudrainnovativePvtLtd 
     */
    public function initialize() {

        header('Access-Control-Allow-Origin: *');
        $allow = array("192.168.1.69", "35.163.234.186");
        $this->autoRender = false;
        $this->location_id = $this->check_validrequest();
        $this->limit = 50;
        $this->default = ConnectionManager::get('default');
    }

    /**
     * Date :- 19-june-17 
     * Function disc :- Function for get subAccounts according to location id 
     * Parameter :- Location_id*, offset  
     * @RudrainnovativePvtLtd 
     */
    public function getSubaccounts() {

        $table = TableRegistry::get('adwords_subaccount_data');
        $offset = isset($_POST["offset"]) ? $_POST["offset"] : 0;
        $limit = isset($_POST["limit"]) ? $_POST["limit"] : $this->limit ;
        $dbdata = $table->find('all')->where(["location_id" => $this->location_id, "can_manage_client <>" => 1])->limit($limit)->offset($offset)->all();

        if (iterator_count($dbdata)) {
            $this->json(1, 'Adwords Sub-Account List', $dbdata);
        } else {
            $this->json(0, 'No Sub-Accounts found');
        }
    }

    /**
     * Date :- 19-june-17 
     * Function disc :- Function for get campaigns 
     * Parameter :- Location_id*, offset , start_date, end_date, sub-account id  
     * @RudrainnovativePvtLtd 
     */
    public function getCampaigns() {

        $subAccount = isset($_POST["subaccountId"]) ? $_POST["subaccountId"] : "";
        $offset = isset($_POST["offset"]) ? $_POST["offset"] : 0;
        $start_date = isset($_POST["start_date"]) ? $_POST["start_date"] : "";
        $end_date = isset($_POST["end_date"]) ? $_POST["end_date"] : "";
        $limit = isset($_POST["limit"]) ? $_POST["limit"] : $this->limit ;

        /* different conditions to get data from database */
        if (!empty($subAccount) && empty($start_date) && empty($end_date)) {
            $query = $this->default->execute("SELECT * , acr.created_at AS reporting_date FROM `adwords_campaign_list` acl CROSS JOIN `adwords_campaign_reporting` acr ON acr.campaign_id = acl.campaign_id WHERE acl.location_id = $this->location_id AND acl.sub_client_id = $subAccount LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && empty($subAccount)) {
            $query = $this->default->execute("SELECT * , acr.created_at AS reporting_date FROM `adwords_campaign_list` acl CROSS JOIN `adwords_campaign_reporting` acr ON acr.campaign_id = acl.campaign_id WHERE acl.location_id = $this->location_id AND acr.created_at <= '" . $start_date . "' AND acr.created_at >= '" . $end_date . "' LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && !empty($subAccount)) {
            $query = $this->default->execute("SELECT * , acr.created_at AS reporting_date FROM `adwords_campaign_list` acl CROSS JOIN `adwords_campaign_reporting` acr ON acr.campaign_id = acl.campaign_id WHERE acl.location_id = $this->location_id AND acr.created_at <= '" . $start_date . "' AND acr.created_at >= '" . $end_date . "' AND acl.sub_client_id = $subAccount LIMIT $limit OFFSET $offset ");
        } else {
            $query = $this->default->execute("SELECT *, acr.created_at as reporting_date FROM `adwords_campaign_list` acl CROSS JOIN `adwords_campaign_reporting` acr ON acr.campaign_id = acl.campaign_id WHERE acl.location_id = $this->location_id LIMIT $limit OFFSET $offset ;");
        }

        $data = $query->fetchAll("assoc");

        if (!empty($data)) {
            $this->json(1, 'Adwords Campaign List', $data);
        } else {
            $this->json(0, "No campaign Found");
        }
    }

    /**
     * Date :- 19-june-17 
     * Function disc :- Function for get Ad-Groups
     * Parameter :- Location_id*, offset , start_date, end_date, campaignId  
     * @RudrainnovativePvtLtd 
     */
    public function getAdgroups() {

        $campaignId = isset($_POST["campaignId"]) ? $_POST["campaignId"] : "";
        $offset = isset($_POST["offset"]) ? $_POST["offset"] : 0;
        $start_date = isset($_POST["start_date"]) ? $_POST["start_date"] : "";
        $end_date = isset($_POST["end_date"]) ? $_POST["end_date"] : "";
        $limit = isset($_POST["limit"]) ? $_POST["limit"] : $this->limit ;

        /* different conditions to get data from database */
        if (!empty($campaignId) && empty($start_date) && empty($end_date)) {
            $query = $this->default->execute("SELECT * , aar.created_at AS reporting_date FROM `adwords_adgroup_list` aal CROSS JOIN `adwords_adgroup_reporting` aar ON aar.adgroup_id = aal.adgroup_id WHERE aal.location_id = $this->location_id AND aal.parent_compaign_id = $campaignId LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && empty($campaignId)) {
            $query = $this->default->execute("SELECT * , aar.created_at AS reporting_date FROM `adwords_adgroup_list` aal CROSS JOIN `adwords_adgroup_reporting` aar ON aar.adgroup_id = aal.adgroup_id WHERE aal.location_id = $this->location_id AND aar.created_at <= '" . $start_date . "' AND aar.created_at >= '" . $end_date . "' LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && !empty($campaignId)) {
            $query = $this->default->execute("SELECT * , aar.created_at AS reporting_date FROM `adwords_adgroup_list` aal CROSS JOIN `adwords_adgroup_reporting` aar ON aar.adgroup_id = aal.adgroup_id WHERE aal.location_id = $this->location_id AND aar.created_at <= '" . $start_date . "' AND aar.created_at >= '" . $end_date . "' AND aal.parent_compaign_id = $campaignId LIMIT $limit OFFSET $offset ");
        } else {
            $query = $this->default->execute("SELECT *, aar.created_at as reporting_date FROM `adwords_adgroup_list` aal CROSS JOIN `adwords_adgroup_reporting` aar ON aar.adgroup_id = aal.adgroup_id WHERE aal.location_id = $this->location_id LIMIT $limit OFFSET $offset ;");
        }

        $data = $query->fetchAll("assoc");

        if (!empty($data)) {
            $this->json(1, 'Adwords Adgroups List', $data);
        } else {
            $this->json(0, "No Adgroups Found");
        }
    }

    /**
     * Date :- 19-june-17 
     * Function disc :- Function for get Keywords
     * Parameter :- Location_id*, offset , start_date, end_date, AdgroupId  
     * @RudrainnovativePvtLtd 
     */
    public function getKeywords() {

        $adgroupId = isset($_POST["adgroupId"]) ? $_POST["adgroupId"] : "";
        $offset = isset($_POST["offset"]) ? $_POST["offset"] : 0;
        $start_date = isset($_POST["start_date"]) ? $_POST["start_date"] : "";
        $end_date = isset($_POST["end_date"]) ? $_POST["end_date"] : "";
        $limit = isset($_POST["limit"]) ? $_POST["limit"] : $this->limit ;

        /* different conditions to get data from database */
        if (!empty($adgroupId) && empty($start_date) && empty($end_date)) {
            $query = $this->default->execute("SELECT * , akr.created_at AS reporting_date FROM `adwords_keyword_list` akl CROSS JOIN `adwords_keyword_reporting` akr ON akr.keyword_id = akl.keyword_id WHERE akl.location_id = $this->location_id AND akl.parent_adgroup_id = $adgroupId LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && empty($adgroupId)) {
            $query = $this->default->execute("SELECT * , akr.created_at AS reporting_date FROM `adwords_keyword_list` akl CROSS JOIN `adwords_keyword_reporting` akr ON akr.keyword_id = akl.keyword_id WHERE akl.location_id = $this->location_id AND akr.created_at <= '" . $start_date . "' AND akr.created_at >= '" . $end_date . "' LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && !empty($adgroupId)) {
            $query = $this->default->execute("SELECT * , akr.created_at AS reporting_date FROM `adwords_keyword_list` akl CROSS JOIN `adwords_keyword_reporting` akr ON akr.keyword_id = akl.keyword_id WHERE akl.location_id = $this->location_id AND akr.created_at <= '" . $start_date . "' AND akr.created_at >= '" . $end_date . "' AND akl.parent_adgroup_id = $adgroupId LIMIT $limit OFFSET $offset ");
        } else {
            $query = $this->default->execute("SELECT *, akr.created_at as reporting_date FROM `adwords_keyword_list` akl CROSS JOIN `adwords_keyword_reporting` akr ON akr.keyword_id = akl.keyword_id WHERE akl.location_id = $this->location_id LIMIT $limit OFFSET $offset ;");
        }

        $data = $query->fetchAll("assoc");

        if (!empty($data)) {
            $this->json(1, 'Adwords Keywords List', $data);
        } else {
            $this->json(0, "No Keywords Found");
        }
    }

    /**
     * Date :- 19-june-17 
     * Function disc :- Function for get Ads
     * Parameter :- Location_id*, offset , start_date, end_date, AdgroupId  
     * @RudrainnovativePvtLtd 
     */
    public function getAds() {

        $adgroupId = isset($_POST["adgroupId"]) ? $_POST["adgroupId"] : "";
        $offset = isset($_POST["offset"]) ? $_POST["offset"] : 0;
        $start_date = isset($_POST["start_date"]) ? $_POST["start_date"] : "";
        $end_date = isset($_POST["end_date"]) ? $_POST["end_date"] : "";
        $limit = isset($_POST["limit"]) ? $_POST["limit"] : $this->limit ;

        /* different conditions to get data from database */
        if (!empty($adgroupId) && empty($start_date) && empty($end_date)) {
            $query = $this->default->execute("SELECT * , aar.created_at AS reporting_date FROM `adwords_ads_list` aal CROSS JOIN `adwords_ads_reporting` aar ON aar.ads_id = aal.ads_id WHERE aal.location_id = $this->location_id AND aal.parent_adgroup_id = $adgroupId LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && empty($adgroupId)) {
            $query = $this->default->execute("SELECT * , aar.created_at AS reporting_date FROM `adwords_ads_list` aal CROSS JOIN `adwords_ads_reporting` aar ON aar.ads_id = aal.ads_id WHERE aal.location_id = $this->location_id AND aar.created_at <= '" . $start_date . "' AND aar.created_at >= '" . $end_date . "' LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && !empty($adgroupId)) {
            $query = $this->default->execute("SELECT * , aar.created_at AS reporting_date FROM `adwords_ads_list` aal CROSS JOIN `adwords_ads_reporting` aar ON aar.ads_id = aal.ads_id WHERE aal.location_id = $this->location_id AND aar.created_at <= '" . $start_date . "' AND aar.created_at >= '" . $end_date . "' AND aal.parent_adgroup_id = $adgroupId LIMIT $limit OFFSET $offset ");
        } else {
            $query = $this->default->execute("SELECT *, aar.created_at as reporting_date FROM `adwords_ads_list` aal CROSS JOIN `adwords_ads_reporting` aar ON aar.ads_id = aal.ads_id WHERE aal.location_id = $this->location_id LIMIT $limit OFFSET $offset ;");
        }

        $data = $query->fetchAll("assoc");

        if (!empty($data)) {
            $this->json(1, 'Adwords Ads List', $data);
        } else {
            $this->json(0, "No Ads Found");
        }
    }

}
