<?php

namespace App\Controller;

ini_set('max_execution_time', 500);

require_once(ROOT . DS . 'vendor' . DS . "adwords" . DS . "vendor" . DS . "autoload.php");

use Google\AdsApi\AdWords\AdWordsServices;
use Google\AdsApi\AdWords\v201702\cm\AdGroupService;
use Google\AdsApi\AdWords\v201702\cm\SortOrder;
use Google\AdsApi\AdWords\v201702\cm\OrderBy;
use Google\AdsApi\AdWords\v201702\cm\Selector;
use Google\AdsApi\AdWords\v201702\cm\Predicate;
use Google\AdsApi\AdWords\v201702\cm\PredicateOperator;
use Cake\Core\App; // use core app controller namespace 

App::className('Controller', 'AdwordsCampaignController');
App::className('Controller', 'AdwordsDataController');  // calling AdwordsDataController 

Class AdwordsAdgroupController extends AppController {

    /**
     * Date :- 24-may-17 
     * Function disc :-  
     * @RudrainnovativePvtLtd 
     */
    public function index( $location_id ) {
        //$subClientId = 7828610025; // only for testing {data comes in post for api}
        //$location_id = 1; // only for testing purposes

        ob_start();

        $obj = new AdwordsDataController;
        $campObj = new AdwordsCampaignController;
        $subAccountArray = $campObj->getSubaccounts($location_id);
        if (!empty($subAccountArray)) {
            foreach ($subAccountArray as $val):

                $subId = $val['Id']; // setting id form subuser table 
                $subClientId = $val['subAccountId']; // sub user table account id
                $subClientName = $val['subAccountName']; // sub user talbe account name

                $campIds = $obj->getCampaignId($subClientId); // calling function for get all campaign id related to this account	

                if (!empty($campIds)) {
                    try {
                        foreach ($campIds as $campaignId):

                            $adGroupData = []; // array to store adGroup data 
                            $adWordsServices = new AdWordsServices();
                            $credentials = $obj->credentialBuilder($location_id); // generating credentials 
                            $session = $obj->sessionBuilder($credentials, $subClientId); // creating session

                            $adGroupService = $adWordsServices->get($session, adGroupService::class);

                            // Create a selector to select all ad groups for the specified campaign.
                            $selector = new Selector();
                            $selector->setFields(['Id', 'Name', 'CampaignId', 'Status']);
                            $selector->setOrdering([new OrderBy('Name', SortOrder::ASCENDING)]);
                            $selector->setPredicates(
                                    [new Predicate('CampaignId', PredicateOperator::IN, [$campaignId])]);

                            $page = $adGroupService->get($selector);

                            if (!empty($page)) {
                                foreach ($page->getEntries() as $key => $adGroup) {
                                    $adGroupData[$key]["adGroupId"] = $adGroup->getId();
                                    $adGroupData[$key]["adGrroupName"] = $adGroup->getName();
                                    $adGroupData[$key]["adGrroupStatus"] = $adGroup->getStatus();
                                }
                            }

                            /* Insert values into database a/c campaign id */
                            if (!empty($adGroupData)) {
                                foreach ($adGroupData as $val):
                                    
                                    $dataCheck = $this->check_db($val['adGroupId'], $location_id); // calling function for check value is in database or not 
                                    if($dataCheck == 1)
                                    {
                                        $update = []; // variable for update 
                                        $update['location_id'] = $location_id;
                                        $update['parent_compaign_id'] = $campaignId;
                                        $update['adgroup_id'] = $val['adGroupId'];
                                        $update['adgroup_name'] = $val['adGrroupName'];
                                        $update['adgroup_status'] = $val['adGrroupStatus'];
                                        $update['updated_at'] = date("Y-m-d h:i:s");
                                        $query = $this->AdwordsAdgroup->query();
                                        $query->update()
                                                ->set($update)
                                                ->where(['location_id' => $location_id, 'adgroup_id' => $val['adGroupId']])
                                                ->execute();
                                    }
                                    else
                                    {
                                        $adgroup = $this->AdwordsAdgroup->newEntity();
                                        $adgroup->location_id = $location_id;
                                        $adgroup->parent_compaign_id = $campaignId;
                                        $adgroup->adgroup_id = $val['adGroupId'];
                                        $adgroup->adgroup_name = $val['adGrroupName'];
                                        $adgroup->adgroup_status = $val['adGrroupStatus'];
                                        $this->AdwordsAdgroup->save($adgroup);
                                    }
                                    
                                endforeach;
                            }

                        endforeach;
                    } catch (Exception $e) {

                        echo "Error :-" . $e->getMessage();
                    }


                    // die('here');
                }
            endforeach;
            
            /*
            $this->Flash->success(__("Adwords Adgroup data successfully added into database."));
            $this->redirect(['controller' => 'Adwords', 'action' => 'index']);
             * 
             */
        }
    }
    
     /**
     * Date :- 09-june-17
     * Function disc :- Function for check value is in database or not  
     * @RudrainnovativePvtLtd 
     */
    
    private function check_db($id, $location_id) {
        $dbData = $this->AdwordsAdgroup->find('all')->where(["location_id" => $location_id, 'adgroup_id' => $id])->all();
        if (iterator_count($dbData)) {
            return 1;
        } else {
            return 0;
        }
    }

}
