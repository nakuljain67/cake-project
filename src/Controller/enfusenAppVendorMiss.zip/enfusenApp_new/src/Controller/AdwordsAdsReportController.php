<?php

namespace App\Controller;

ini_set('max_execution_time', 500); // set maximum execution time 

require_once(ROOT . DS . 'vendor' . DS . "adwords" . DS . "vendor" . DS . "autoload.php");

use Google\AdsApi\AdWords\Reporting\v201702\ReportDownloader;
use Google\AdsApi\AdWords\Reporting\v201702\DownloadFormat;
use Cake\Core\App; // use core app controller namespace 

App::className('Controller', 'AdwordsDataController');  // calling AdwordsDataController 

Class AdwordsAdsReportController extends AppController {

    public function initialise() {
        parent::initialise();
        ob_start();
    }

    public function index( $location_id ) {
        $obj = new AdwordsDataController;
        $credential = $obj->credentialBuilder($location_id);
        $subData = $this->getSubaccounts($location_id);

        if (!empty($subData)) {
            foreach ($subData as $val):
                $session = $obj->reportSession($credential, $val["subAccountId"]);

                $reportQuery = 'SELECT AdGroupId,Id,Description,Description1,Description2,Status,Labels,Impressions,Clicks,Cost,Ctr,AveragePageviews
	                            ,AveragePosition,Conversions,CostPerConversion,ConversionRate,ViewThroughConversions,AllConversions,AverageCpc
	                            FROM AD_PERFORMANCE_REPORT DURING YESTERDAY';

                // Download report as a string.
                $reportDownloader = new ReportDownloader($session);
                $reportDownloadResult = $reportDownloader->downloadReportWithAwql($reportQuery, 'CSV');
                $csvData = $reportDownloadResult->getAsString(); // generate report as string
                $parsedData = $this->parseCsv($csvData); // calling function to parse 
                
                $table = $this->loadModel("AdwordsAdsReporting");
               
                if (!empty($parsedData)) {
                    foreach ($parsedData as $data):
                        $insert = $table->newEntity();
                        $insert->location_id = $location_id;
                        $insert->adgroup_id = $data["adgroup_id"];
                        $insert->ads_id = $data["ad_id"];
                        $insert->description = $data["description"];
                        $insert->description1 = $data["description1"];
                        $insert->description2 = $data["description2"];
                        $insert->ad_state = $data["ad_state"];
                        $insert->labels = $data["labels"];
                        $insert->impressions = $data["impression"];
                        $insert->click = $data["clicks"];
                        $insert->cost = $data["cost"];
                        $insert->ctr = $data["ctr"];
                        $insert->pagepersession = $data["pagepersession"];
                        $insert->avg_position = $data["avg_pos"];
                        $insert->conversions = $data["conversions"];
                        $insert->costperconversion = $data["costperconversion"];
                        $insert->conv_rate = $data["conv_rate"];
                        $insert->view_through_conversion = $data["view_through_conv"];
                        $insert->all_conversion = $data["all_conv"];
                        $insert->all_cpc = $data["avg_cpc"];
                        $table->save($insert);
                    endforeach;
                }

            endforeach;
        }
    }

    /**
     * Date :- 13-june-17 
     * Function disc :- function for fetch subaccount's from database according to user id  
     * @RudrainnovativePvtLtd 
     */
    private function getSubaccounts($location_id = null) {
        $subAccountData = []; // array for store sub account data 
        $subAccountModel = $this->loadModel('AdwordsSubaccount'); // load AdwordsSubaccount model 
        $data = $subAccountModel->find('all')->where(['location_id' => $location_id, 'can_manage_client != ' => 1])->all();

        if (!empty($data)) {
            foreach ($data as $key => $val) {
                $subAccountData[$key]['Id'] = $val->id;
                $subAccountData[$key]['subAccountId'] = $val->sub_cust_client_id;
                $subAccountData[$key]['subAccountName'] = $val->sub_cust_name;
            }
        }

        return $subAccountData; // return subAccount data from database 
    }

    /**
     * Date :- 13-june-17 
     * Function disc :- Function for Parse csv data 
     * @RudrainnovativePvtLtd 
     */
    public function parseCsv($csvData = null) {
        $dataArray = []; //array for store data performance data into array  
        $parsedArray = [];
        $lines = explode(PHP_EOL, $csvData);
//        pr($lines);
//        die;
        $total = count($lines);
        if ($total > 4) {

            for ($i = 2; $i < $total - 2; $i++) {
                $parsedArray[] = explode(",", $lines[$i]);
            }
           
            if (!empty($parsedArray)) {

                $count = count($parsedArray);
                for ($a = 0; $a < $count; $a++) {
                    $dataArray[$a]["adgroup_id"] = $parsedArray[$a][0];
                    $dataArray[$a]["ad_id"] = $parsedArray[$a][1];
                    $dataArray[$a]["description"] = $parsedArray[$a][2];
                    $dataArray[$a]["description1"] = $parsedArray[$a][3];
                    $dataArray[$a]["description2"] = $parsedArray[$a][4];
                    $dataArray[$a]["ad_state"] = $parsedArray[$a][5];
                    $dataArray[$a]["labels"] = $parsedArray[$a][6];
                    $dataArray[$a]["impression"] = $parsedArray[$a][7];
                    $dataArray[$a]["clicks"] = $parsedArray[$a][8];
                    $dataArray[$a]["cost"] = ($parsedArray[$a][9] > 0) ?  $parsedArray[$a][9] / 1000000 : 0;
                    $dataArray[$a]["ctr"] = $parsedArray[$a][10]/1000000;
                    $dataArray[$a]["pagepersession"] = $parsedArray[$a][11];
                    $dataArray[$a]["avg_pos"] = $parsedArray[$a][12];
                    $dataArray[$a]["conversions"] = $parsedArray[$a][13];
                    $dataArray[$a]["costperconversion"] = ($parsedArray[$a][14] > 0) ? $parsedArray[$a][14]/1000000 : 0;
                    $dataArray[$a]["conv_rate"] = $parsedArray[$a][15];
                    $dataArray[$a]["view_through_conv"] = $parsedArray[$a][16];
                    $dataArray[$a]["all_conv"] = $parsedArray[$a][17];
                    $dataArray[$a]["avg_cpc"] = ($parsedArray[$a][18] > 0) ? $parsedArray[$a][18] / 1000000 : 0;
                }
            }

            return $dataArray;
        }
    }
    
    /**
     * Date :- 13-june-17 
     * Function disc :- Function for display Ads reporting data list 
     * @RudrainnovativePvtLtd 
     */
    
    public function displayAdsReporting($location_id=1) {
        $array = []; 
        $table = $this->loadModel("AdwordsAdsReporting");
        $adsData = $table->find('all')->where(["location_id" => $location_id])->toArray();
        
        if(!empty($adsData)) {
           foreach($adsData as $key => $val):
               $array[$key]["ads_id"] = $val->ads_id;
               $array[$key]["description"] = $val->description;
               $array[$key]["ad_state"] = $val->ad_state;
               $array[$key]["labels"] = $val->labels;
               $array[$key]["impressions"] = $val->impressions;
               $array[$key]["click"] = $val->click;
               $array[$key]["cost"] = $val->cost;
               $array[$key]["ctr"] = $val->ctr;
               $array[$key]["pagepersession"] = $val->pagepersession;
               $array[$key]["avg_position"] = $val->avg_position;
               $array[$key]["conversions"] = $val->conversions;
               $array[$key]["costperconversion"] = $val->costperconversion;
               $array[$key]["conv_rate"] = $val->conv_rate;
               $array[$key]["view_through_conversion"] = $val->view_through_conversion;
               $array[$key]["all_conversion"] = $val->all_conversion;
               $array[$key]["all_cpc"] = $val->all_cpc;
               $array[$key]["created_at"] = $val->created_at;
           endforeach;
        }
        
        if(!empty($array)) {
            $this->set("AdsReport", $array);
        }
    }

}
