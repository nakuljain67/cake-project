<?php

namespace App\Controller;

require_once(ROOT . DS . 'vendor' . DS . "adwords" . DS . "vendor" . DS . "autoload.php");

use Google\AdsApi\AdWords\AdWordsServices;
use Google\AdsApi\AdWords\AdWordsSessionBuilder;
use Google\AdsApi\AdWords\v201702\cm\CampaignService;
use Google\AdsApi\AdWords\v201702\mcm\CustomerService;
use Google\AdsApi\AdWords\v201702\mcm\ManagedCustomerService;
use Google\AdsApi\AdWords\v201702\o\TargetingIdeaService;
use Google\AdsApi\AdWords\v201702\o\TargetingIdeaSelector;
use Google\AdsApi\AdWords\v201702\o\RelatedToQuerySearchParameter;
use Google\AdsApi\AdWords\v201702\cm\SortOrder;
use Google\AdsApi\AdWords\v201702\cm\OrderBy;
use Google\AdsApi\AdWords\v201702\cm\Paging;
use Google\AdsApi\AdWords\v201702\cm\Selector;
use Google\AdsApi\Common\OAuth2TokenBuilder;
use Google\AdsApi\AdWords\v201702\cm\AdGroupCriterionService;
use Google\AdsApi\AdWords\v201702\cm\CriterionType;
use Google\AdsApi\AdWords\v201702\cm\Predicate;
use Google\AdsApi\AdWords\v201702\cm\PredicateOperator;
use Google\AdsApi\AdWords\v201702\cm\AdGroupService;
use Cake\Core\App; // use core app controller namespace 

App::className('Controller', 'AdwordsDataController');  // calling AdwordsDataController 
App::className('Controller', 'AdwordsCampaignController');

Class AdwordsKeywordController extends AppController {

    /**
     * Date :- 24-may-17 
     * Function disc :- Function for get Keywords 
     * @RudrainnovativePvtLtd 
     */
    public function index( $location_id ) {
//        $location_id = 1; // only for testing purposes

        ob_start();
//        $i = 0;
        $obj = new AdwordsDataController;
        $campObj = new AdwordsCampaignController;
        $subAccountArray = $campObj->getSubaccounts($location_id);

        if (!empty($subAccountArray)) {
            foreach ($subAccountArray as $val) {
                $subClientId = $val['subAccountId'];
                $campIds = $obj->getCampaignId($subClientId);
                if (!empty($campIds)) {
                    foreach ($campIds as $campainId) {
                        
                        $addGroupIds = $this->getAdgroup($campainId);
                        
                        if (!empty($addGroupIds)) {
                            foreach ($addGroupIds as $adGroupId) {
                                $credentials = $obj->credentialBuilder($location_id); // generating credentials 
                                $session = $obj->sessionBuilder($credentials, $subClientId); // creating session
                                $keywordData = []; //store keyword data 
                                $adWordsServices = new AdWordsServices();
                                $adGroupCriterionService = $adWordsServices->get($session, AdGroupCriterionService::class);

                                // Create a selector to select all keywords for the specified ad group.
                                $selector = new Selector();
                                $selector->setFields(
                                        ['Id', 'CriteriaType', 'KeywordMatchType', 'KeywordText', 'AdGroupName', 'CpcBid', 'SystemServingStatus', 'ApprovalStatus', 'BiddingStrategyType', 'CpmBid', 'FirstPositionCpc', 'TopOfPageCpc', 'FirstPageCpc', 'Status', 'HasQualityScore', 'Criteria']);
                                $selector->setOrdering([new OrderBy('KeywordText', SortOrder::ASCENDING)]);
                                $selector->setPredicates([
                                    new Predicate('AdGroupId', PredicateOperator::IN, [$adGroupId]),
                                    new Predicate('CriteriaType', PredicateOperator::IN, [CriterionType::KEYWORD])
                                ]);

                                $page = $adGroupCriterionService->get($selector);

                                if (!empty($page)) {
                                    foreach ($page->getEntries() as $key => $adGroupCriterion) {
                                        $keywordData[$key]["keywordText"] = $adGroupCriterion->getCriterion()->getText();
                                        $keywordData[$key]["keywordMatchType"] = $adGroupCriterion->getCriterion()->getMatchType();
                                        $keywordData[$key]["keywordType"] = $adGroupCriterion->getCriterion()->getType();
                                        $keywordData[$key]["keywordId"] = $adGroupCriterion->getCriterion()->getId();
                                    }
                                }
                                
                                if (!empty($keywordData)) {
                                    foreach ($keywordData as $val) {
                                        $keyWord = $this->AdwordsKeyword->newEntity();
                                        $keyWord->location_id = $location_id;
                                        $keyWord->parent_adgroup_id = $adGroupId;
                                        $keyWord->keyword_id = $val['keywordId'];
                                        $keyWord->keyword_text = $val['keywordId'];
                                        $keyWord->keyword_text = $val['keywordText'];
                                        $keyWord->keyword_match_type = $val['keywordMatchType'];
                                        $keyWord->keyword_type = $val['keywordType'];
                                        $this->AdwordsKeyword->save($keyWord);
                                    }
                                }
                                  
                                 
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Date :- 24-may-17 
     * Function disc :- Function for fetch adgroupId a/c to campaign id  
     * @RudrainnovativePvtLtd 
     */
    private function getAdgroup($campaignId = null) {
        $return = [];
        $addGrp = $this->loadModel('AdwordsAdgroup');
        $addData = $addGrp->find('all')->where(['parent_compaign_id' => $campaignId])->all();

        if (!empty($addData)) {
            foreach ($addData as $val) {
                $return[] = $val->adgroup_id;
            }
        }
        return $return;
    }

}
