<?php

namespace App\Controller;

require_once(ROOT . DS . 'vendor' . DS . "adwords" . DS . "vendor" . DS . "autoload.php");

use Google\AdsApi\AdWords\AdWordsServices;
use Google\AdsApi\AdWords\v201702\mcm\ManagedCustomerService;
use Google\AdsApi\AdWords\v201702\cm\Selector;
use Cake\Core\App; // use core app controller namespace 

App::className('Controller', 'AdwordsDataController');  // calling AdwordsDataController 

Class AdwordsSubaccountController extends AppController {

    /**
     * Date :- 22-may-17 
     * Updated :- 08-june-17  
     * Function disc :- Function for get sub account details according to customer client id 
     * @RudrainnovativePvtLtd 
     */
    public function index($location_id) {
//		$location_id = 1;  // user id post input (Only for testing purpose)
        $check = 0; // varibale for check 
        $obj = new AdwordsDataController;
        $subCustomerDetails = []; // array to store sub customer account details 
        $credential = $obj->credentialBuilder($location_id); // creating credentials 
        $customerId = $obj->getCustomerId($location_id); // getting customer client id 

        if (count($customerId) == 1) {
            $customerId = $customerId[0];
        }

        try {
            $session = $obj->sessionBuilder($credential, $customerId); // set client customer id into session 
            $adWordsServices = new AdWordsServices();

            $managedCustomerService = $adWordsServices->get($session, ManagedCustomerService::class);

            // Create selector.
            $selector = new Selector();
            $selector->setFields(['CustomerId', 'Name', 'CanManageClients', 'TestAccount']);

            $page = $managedCustomerService->get($selector);  // get details 

            /* Loop for store details into array */
            foreach ($page->getEntries() as $key => $account) {
                $subCustomerDetails[$key]['customerId'] = $account->getCustomerId();
                $subCustomerDetails[$key]['name'] = $account->getName();
                $subCustomerDetails[$key]['canManageClient'] = $account->getCanManageClients();
            }
            
            $mainClientCustomerId = $session->getClientCustomerId(); // getting client customer id from session 

            /* Database insertion logic */
            foreach ($subCustomerDetails as $val):

                $checkData = $this->check_db($val['customerId'], $location_id);
                if ($checkData == 1) {
                    $update = []; // array for store update data 
                    $update["location_id"] = $location_id;
                    $update["main_cust_client_id"] = $mainClientCustomerId;
                    $update["sub_cust_client_id"] = $val['customerId'];
                    $update["sub_cust_name"] = $val['name'];
                    $update["can_manage_client"] = $val['canManageClient'];
                    $update["updated_at"] = date('Y-m-d h:i:s');

                    $query = $this->AdwordsSubaccount->query();
                    $query->update()
                            ->set($update)
                            ->where(['location_id' => $location_id, 'sub_cust_client_id' => $val['customerId']])
                            ->execute();
                } else {
                    $subAccount = $this->AdwordsSubaccount->newEntity();
                    $subAccount->location_id = $location_id;
                    $subAccount->main_cust_client_id = $mainClientCustomerId;
                    $subAccount->sub_cust_client_id = $val['customerId'];
                    $subAccount->sub_cust_name = $val['name'];
                    $subAccount->can_manage_client = $val['canManageClient'];
                    $this->AdwordsSubaccount->save($subAccount);

                    $check ++;
                }

            endforeach;
        } catch (Exception $e) {
            echo "Exception :-" . $e->getMessage();
        }
    }

    /**
     * Date :- 08-june-17
     * Function disc :- Function for check value is in database or not  
     * @RudrainnovativePvtLtd 
     */
    private function check_db($id, $location_id) {
        $dbData = $this->AdwordsSubaccount->find('all')->where(["location_id" => $location_id, 'sub_cust_client_id' => $id])->all();
        if (iterator_count($dbData)) {
            return 1;
        } else {
            return 0;
        }
    }

    /**
     * Date :- 24-may-17 
     * Function disc :- Function for get subaccount list from database for display 
     * @RudrainnovativePvtLtd 
     */
    public function disaplayAccount($location_id = null) {
        $location_id = 1; // only for testing purposes 
        $subAccounts = $this->AdwordsSubaccount->find('all')->where(['location_id' => $location_id])->all();

        if (iterator_count($subAccounts)) {
            $this->set('subAccounts', $subAccounts);
        }
    }

}
