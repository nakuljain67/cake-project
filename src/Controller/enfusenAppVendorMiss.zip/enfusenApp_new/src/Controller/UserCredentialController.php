<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class UserCredentialController extends AppController {

    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index() {
        $users1 = TableRegistry::get('api_locations');
        $data = $users1->find('all')->where(['smart_location_id != ""'])->toArray();
        $this->set("data", $data);
    }

    public function ajax() {
        if ($this->request->is('post')) {
            $data = $this->request->data;
            $users1 = TableRegistry::get('api_locations');
            $missed = $users1->find('all')->where(['smart_location_id' => $data['id']])->first();
            echo json_encode($missed);
            die;
        }
    }

    public function form() {
        if ($this->request->is('post')) {
            // pr($_POST);
            // die('here');
            $data = $this->request->data;

            if (!empty($data['callmatrix']['apikey']) && !empty($data['callmatrix']['apisecret']) && !empty($data['callmatrix']['location'])) {

                $apikey = $data['callmatrix']['apikey'];
                $apisecret = $data['callmatrix']['apisecret'];
                $location = $data['callmatrix']['location'];
                $new = [];
                $new["apikey"] = $apikey;
                $new["apisecret"] = $apisecret;
                //pr($new); die;
                $users_table = TableRegistry::get('api_locations');
                $matchcount = $users_table->find()->where(['smart_location_id' => $location])->count();
                if ($matchcount == 0) {
                    $insert = $users_table->newEntity();
                    $insert->calltracking_info = json_encode($new);
                    $users_table->save($insert);
                    echo "ok";
                } else {
                    $new = ['calltracking_info' => json_encode($new)];
                    $query = $users_table->query();
                    $query->update()->set($new)->where(['smart_location_id' => $location])->execute();
                    echo "notok";
                }
            } elseif (!empty($data['AdRoll']['apikey']) && !empty($data['AdRoll']['email']) && !empty($data['AdRoll']['password']) && !empty($data['AdRoll']['location'])) {
                $apikey = $data['AdRoll']['apikey'];
                $email = $data['AdRoll']['email'];
                $password = $data['AdRoll']['password'];
                $location = $data['AdRoll']['location'];
                $new = [];
                $new["apikey"] = $apikey;
                $new["email"] = $email;
                $new["password"] = $password;
                //pr($new); die;
                $users_table = TableRegistry::get('api_locations');
                $matchcount = $users_table->find()->where(['smart_location_id' => $location])->count();
                if ($matchcount == 0) {
                    $insert = $users_table->newEntity();
                    $insert->adroll_info = json_encode($new);
                    $users_table->save($insert);
                    echo "ok";
                } else {
                    $new = ['adroll_info' => json_encode($new)];
                    $query = $users_table->query();
                    $query->update()->set($new)->where(['smart_location_id' => $location])->execute();
                    echo "notok";
                }
            } elseif (!empty($data['twilio']['apikey']) && !empty($data['twilio']['apisecret']) && !empty($data['twilio']['location'])) {
                $apikey = $data['twilio']['apikey'];
                $apisecret = $data['twilio']['apisecret'];
                $location = $data['twilio']['location'];
                $new = [];
                $new["apikey"] = $apikey;
                $new["apisecret"] = $apisecret;
                $users_table = TableRegistry::get('api_locations');
                $matchcount = $users_table->find()->where(['smart_location_id' => $location])->count();
                if ($matchcount == 0) {
                    $insert = $users_table->newEntity();
                    $insert->twilio_info = json_encode($new);
                    $users_table->save($insert);
                    echo "ok";
                } else {
                    $new = ['twilio_info' => json_encode($new)];
                    $query = $users_table->query();
                    $query->update()->set($new)->where(['smart_location_id' => $location])->execute();
                    echo "notok";
                }
            } elseif (!empty($data['callrail']['apikey']) && !empty($data['callrail']['location'])) {
                $apikey = $data['callrail']['apikey'];
                $location = $data['callrail']['location'];
                $users_table = TableRegistry::get('api_locations');
                $matchcount = $users_table->find()->where(['smart_location_id' => $location])->count();
                if ($matchcount == 0) {
                    $insert = $users_table->newEntity();
                    $insert->callrail_info = $apikey;
                    $users_table->save($insert);
                    echo "ok";
                } else {
                    $new = ['callrail_info' => $apikey];
                    $query = $users_table->query();
                    $query->update()->set($new)->where(['smart_location_id' => $location])->execute();
                    echo "notok";
                }
            } else {
                echo "error";
            }
        }
        die;
    }

}
