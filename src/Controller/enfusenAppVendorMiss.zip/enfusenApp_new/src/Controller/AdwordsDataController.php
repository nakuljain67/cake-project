<?php

namespace App\Controller;

require_once(ROOT . DS . 'vendor' . DS . "adwords" . DS . "vendor" . DS . "autoload.php");

use Google\Auth\OAuth2;
use Google\AdsApi\AdWords\AdWordsServices;
use Google\AdsApi\AdWords\AdWordsSessionBuilder;
use Google\AdsApi\AdWords\v201702\cm\CampaignService;
use Google\AdsApi\AdWords\v201702\mcm\CustomerService;
use Google\AdsApi\AdWords\v201702\mcm\ManagedCustomerService;
use Google\AdsApi\AdWords\v201702\o\TargetingIdeaService;
use Google\AdsApi\AdWords\v201702\o\TargetingIdeaSelector;
use Google\AdsApi\AdWords\v201702\o\RelatedToQuerySearchParameter;
use Google\AdsApi\AdWords\v201702\cm\SortOrder;
use Google\AdsApi\AdWords\v201702\cm\OrderBy;
use Google\AdsApi\AdWords\v201702\cm\Paging;
use Google\AdsApi\AdWords\v201702\cm\Selector;
use Google\AdsApi\Common\OAuth2TokenBuilder;
use Google\AdsApi\AdWords\v201702\cm\AdGroupCriterionService;
use Google\AdsApi\AdWords\v201702\cm\CriterionType;
use Google\AdsApi\AdWords\v201702\cm\Predicate;
use Google\AdsApi\AdWords\v201702\cm\PredicateOperator;
use Google\AdsApi\AdWords\v201702\cm\AdGroupService;
use Google\AdsApi\AdWords\AdWordsSession;
use Google\AdsApi\AdWords\ReportSettingsBuilder;

Class AdwordsDataController extends AppController {
    
    private $clientId; //variable for store client id from database 
    private $secret; // variable for store client secret from database 

    private static $configIniFilePath = __DIR__ . "/../../adsapi_php.ini";  // include adsapi_php.ini path 

    public function initialize() {
        parent::initialize();
        ob_start();
        $this->getCredentials();
    }
    
    /**
     * Date :- 22-may-17 
     * Function disc :- function for generate credential ,auto set data from database also into credential
     * @RudrainnovativePvtLtd 
     */

    public function credentialBuilder($location_id = null) {
        $dbCredentials = $this->getDbCredentials($location_id); // function return database save credentials 
        $refresh_token = trim($dbCredentials->refresh_token);
        
        /* ------  set client credentials ---------------- */

        $oauth2_clientId = $this->clientId;
        $oauth2_clientSecret = $this->secret;
        $refresh_token = $refresh_token;
        $oAuth2Credential = (new OAuth2TokenBuilder())->fromFile(self::$configIniFilePath);
        $oAuth2Credential->withClientId($oauth2_clientId);
        $oAuth2Credential->withClientSecret($oauth2_clientSecret);
        $oAuth2Credential->withRefreshToken($refresh_token);
        $credential = $oAuth2Credential->build();
        
        return $credential; // return credentials 
    }

    /**
     * Date :- 22-may-17 
     * Function disc :- function for get credentials from database and return 
     * @RudrainnovativePvtLtd 
     */
    public function getDbCredentials($userid = null) {
        $apiOptions = $this->loadModel("ApiLocations");
        $data = $apiOptions->find('all', array("condition" => array("smart_location_id" => $userid)))->toArray();
        
        $token = $data[0]->adword_token;
        if(!empty($token)) {
            $decodeKeys = json_decode($token);
        }
        
        return $decodeKeys;
    }

    /**
     * Date :- 22-may-17 
     * Function disc :- function for build session 
     * @RudrainnovativePvtLtd 
     */
    public function sessionBuilder($credential = null, $customerId = null) {
        $sessionbuilder = new AdWordsSessionBuilder(); // object creation from AdWordsSessionBuilder class
        $session = $sessionbuilder->fromFile(self::$configIniFilePath)->withOAuth2Credential($credential)
                ->withClientCustomerId($customerId)
                ->build();
       return $session; // return session 
    }

    /**
     * Date :- 22-may-17 
     * Function disc :- Function for get main client customer id 
     * @RudrainnovativePvtLtd 
     */
    public function getCustomerId($location_id = null) {
        $customerId = []; // array for store customer id 
        $credential = $this->credentialBuilder($location_id);
        $session = $this->sessionBuilder($credential); // getting session with client credentials 
        $adWordsServices = new AdWordsServices(); // Creating object of Adwords services 
        $customerService = $adWordsServices->get($session, CustomerService::class);
        $customers = $customerService->getCustomers();
        $count = count($customers);

        /* Loop for count and return total clients data */
        for ($i = 0; $i < $count; $i++) {
            $customerId[] = $customers[$i]->getCustomerId();
        }

        if (!empty($customerId)) {
            return $customerId;
        } else {
            return false;
        }
    }

    /**
     * Date :- 24-may-17 
     * Function disc :- Function for set report setting
     * @RudrainnovativePvtLtd 
     */
    private function reportSettings() {
        $reportSettings = (new ReportSettingsBuilder())
                ->fromFile(self::$configIniFilePath)
                ->includeZeroImpressions(false)
                ->build();

        return $reportSettings;
    }

    /**
     * Date :- 24-may-17 
     * Function disc :- Function for set session for report 
     * @RudrainnovativePvtLtd 
     */
    public function reportSession($credential = null, $customerId = null) {
        $reportSettings = $this->reportSettings(); // get report setting from function

        $session = (new AdWordsSessionBuilder())
                ->fromFile(self::$configIniFilePath)
                ->withOAuth2Credential($credential)
                ->withClientCustomerId($customerId)
                ->withReportSettings($reportSettings)
                ->build();

        return $session;
    }

    /**
     * Date :- 24-may-17 
     * Function disc :- Function for Get campaign using subaccount id 
     * @RudrainnovativePvtLtd 
     */
    public function getCampaignId($subAccountId = null) {
        // $subAccountId = 7828610025 ; // Only for testing purposes 
        $campaignIds = []; //array for store campaign id for return it
        $campaignModel = $this->loadModel('AdwordsCampaign'); // load campaign model 
        $campData = $campaignModel->find('all')->where(['sub_client_id' => $subAccountId])->all();
        if (!empty($campData)) {
            foreach ($campData as $val):
                $campaignIds[] = $val->campaign_id;
            endforeach;
        }

        return $campaignIds;
    }
    
    /**
     * Date :-14-june-17
     * Function disc :- Function for get credentials for adwords from database   
     * @RudrainnovativePvtLtd 
     */
    private function getCredentials() {
        $model = $this->loadModel("ApiOptions");
        $dbCredentials = $model->find('all', array("conditions" => array("option_key" => "adword")))->toArray();

        if (!empty($dbCredentials)) {
            $credentials = $dbCredentials[0]->option_value;
            $credentialValue = json_decode($credentials);

            if (!empty($credentialValue)) {
                /* Setting client credentials from database */
                $this->clientId = $credentialValue->clientId;
                $this->secret = $credentialValue->secret;
                $this->redirect = $credentialValue->redirect;
            }
        }
    }

}
