<?php

namespace App\Controller;

use App\Controller\AppController;

Class AddrollController extends AppController {

    private static $location_id = 1; // location id variable (only for testing purpose)

    /**
     * Date :- 17-may-17 
     * Update :- 26-may-17
     * Function disc :- Display index file with Addroll data from database 
     * @RudrainnovativePvtLtd 
     */

    public function index() {
        try {
            $location_id = 1; // only for testing purposes 
            $return = []; // array to set campaign data display it into index page 
            $campTable = $this->loadModel('AdrollCampaign'); // load campaign model 
            $campData = $campTable->find('all')->where(['location_id' => $location_id])->all(); // data from db 

            if (iterator_count($campData)) {
                foreach ($campData as $key => $val):

                    $return[$key]['location_id'] = $val->location_id;
                    $return[$key]['parent_campaign_id'] = $val->id;
                    $return[$key]['campaign_name'] = $val->campaign_name;
                    $return[$key]['cpc'] = $val->cpc;
                    $return[$key]['budget'] = $val->budget;
                    $return[$key]['status'] = $val->status;
                    $return[$key]['impressions'] = $val->impressions;
                    $return[$key]['clicks'] = $val->clicks;
                    $return[$key]['spend'] = $val->spend;
                    $return[$key]['ctr'] = $val->ctr;
                    $return[$key]['cmp'] = $val->cmp;
                    $return[$key]['vtc'] = $val->vtc;
                    $return[$key]['vtc_rate'] = $val->vtc_rate;

                endforeach;
            }

            if (!empty($return))
                $this->set("addRoll", $return);
        } catch (Exception $e) {
            echo "Error :- " . $e->getMessage();
        }
    }

    /**
     * Date :- 13-may-17 
     * Function disc :- Function for connect addroll services 
     * Help Url :- https://developers.adroll.com/docs/crud-api/
     * @RudrainnovativePvtLtd 
     */
    public function connect() {

        if (!empty($_POST['AdRoll']['apikey']) && !empty($_POST['AdRoll']['email']) && !empty($_POST['AdRoll']['password'])) {
            // create curl resource
            $ch = curl_init();

            // set url
            $url = "https://services.adroll.com/api/v1/organization/get_advertisables?apikey=" . $_POST['AdRoll']['apikey'];

            /* Url for get campaign details related with campaing eid */
            // $url = "https://services.adroll.com/api/v1/campaign/get?campaign=NWS6TU5W3VEUFPRXV3HYWU&apikey=".$_POST['AdRoll']['apikey'];


            curl_setopt($ch, CURLOPT_URL, $url);

            // return the transfer as a string
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

            // Set credentials
            $credentials = $_POST['AdRoll']['email'] . ":" . $_POST['AdRoll']['password'];
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($ch, CURLOPT_USERPWD, $credentials);

            // $output contains the output string
            /* $output = curl_exec($ch);

              $adrollData = $this->Addroll->newEntity();
              $adrollData->adroll_data = $output;
              if($this->Addroll->save($adrollData))
              {
              $this->Flash->success(__('You are connected successfully.'));
              return $this->redirect(['action' => 'index']);
              } */
        } else {

            $this->Flash->error(__('Please Fill all the details correctly..'));
            return $this->redirect(['action' => 'index']);
        }
    }

    /**
     * Date :- 25-may-17 
     * Function disc :- Function for get organisation details  
     * Help Url :- https://developers.adroll.com/docs/crud-api/reference.html#get--api-v1-organization-get
     * @RudrainnovativePvtLtd 
     */
    public function getOrganisation() {
        try {
            $location_id = 1;
            $apiKey = 'ySjKBTbFxCrw31liNlmKU295C14s7ItD';
            $base_url = "https://services.adroll.com";

            // create curl resource
            $ch = curl_init();

            // set url
            $url = $base_url . "/api/v1/organization/get?apikey=" . $apiKey;



            curl_setopt($ch, CURLOPT_URL, $url);

            // return the transfer as a string
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

            // Set credentials
            $credentials = 'marketing@rawhide.org:St@rMvp68';
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($ch, CURLOPT_USERPWD, $credentials);

            // $output contains the output string
            $output = curl_exec($ch);
            $output = json_decode($output);

            if (!empty($output)) {
                $organisationData['billing_city'] = $output->results->billing_city;
                $organisationData['billing_name'] = $output->results->billing_name;
                $organisationData['created_date'] = $output->results->created_date;
                $organisationData['billing_street'] = $output->results->billing_street;
                $organisationData['billing_postal_code'] = $output->results->billing_postal_code;
                $organisationData['billing_country'] = $output->results->billing_country;
                $organisationData['billing_state'] = $output->results->billing_state;
                $organisationData['name'] = $output->results->name;
            }

            /* Code for insert Adroll organisation data into database */

            $adrollOrg = $this->loadModel('AdrollOrganisation');

            if (!empty($organisationData)) {
                $adOrg = $adrollOrg->newEntity();
                $adOrg->location_id = $location_id;
                $adOrg->billing_city = $organisationData['billing_city'];
                $adOrg->billing_name = $organisationData['billing_name'];
                $adOrg->billing_street = $organisationData['billing_street'];
                $adOrg->billing_postal_code = $organisationData['billing_postal_code'];
                $adOrg->billing_country = $organisationData['billing_country'];
                $adOrg->billing_state = $organisationData['billing_state'];
                $adOrg->name = $organisationData['billing_city'];
                $adOrg->creatd_date = $organisationData['created_date'];

                if ($adrollOrg->save($adOrg)) {
                    $this->Flash->success(__("Adroll Organisation information Updated into database."));
                    return $this->redirect(['action' => 'index']);
                } else {
                    $this->Flash->error(__("Adroll Organisation information Not Updated into database."));
                    return $this->redirect(['action' => 'index']);
                }
            }
        } catch (Exception $e) {
            echo "Error :-" . $e->getMessage();
        }
    }

    /**
     * Date :- 25-may-17 
     * Function disc :- Function for get user information  
     * Help Url :- https://developers.adroll.com/docs/crud-api/reference.html#get--api-v1-organization-get
     * @RudrainnovativePvtLtd 
     */
    public function getUsers($apiKey=null, $location_id=null) {
        try {
//            $location_id = 1; // only for testing 
            if(empty($apiKey)){
                $apiKey = ADROLL_API_KEY;
            }
            
            $base_url = ADROLL_BASE_URL;
            $userData = []; //blank array to store user data into array 
            // create curl resource
            $ch = curl_init();

            // set url
            $url = $base_url . "/api/v1/organization/get_users?apikey=" . $apiKey;



            curl_setopt($ch, CURLOPT_URL, $url);

            // return the transfer as a string
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

            // Set credentials
            $credentials = ADROLL_USER_NAME . ':' . ADROLL_USER_PASSWORD;
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($ch, CURLOPT_USERPWD, $credentials);

            // $output contains the output string
            $output = curl_exec($ch);
            $output = json_decode($output);

            if (!empty($output)) {
                $userData['id'] = $output->results[0]->id;
                $userData['first_name'] = $output->results[0]->first_name;
                $userData['last_name'] = $output->results[0]->last_name;
                $userData['last_login_date'] = $output->results[0]->last_login_date;
                $userData['role'] = $output->results[0]->role;
                $userData['email'] = $output->results[0]->email;
                $userData['username'] = $output->results[0]->username;
                $userData['organization_role'] = $output->results[0]->organization_role;
                $userData['eid'] = $output->results[0]->eid;
                $userData['created_date'] = $output->results[0]->created_date;
                $userData['advertisables_eid'] = !empty($output->results[0]->advertisables) ? $output->results[0]->advertisables[0] : '';
            }

            /* Insert data into database */

            if (!empty($userData)) {
                $adrollUserTable = $this->loadModel('AdrollUser'); // load adroll User model 


                $adrollUser = $adrollUserTable->newEntity();
                $adrollUser->location_id = $location_id;
                $adrollUser->adroll_id = $userData['id'];
                $adrollUser->first_name = $userData['first_name'];
                $adrollUser->last_name = $userData['last_name'];
                $adrollUser->advertisable_eid = $userData['advertisables_eid'];
                $adrollUser->last_login_date = $userData['last_login_date'];
                $adrollUser->role = $userData['role'];
                $adrollUser->email = $userData['email'];
                $adrollUser->user_name = $userData['username'];
                $adrollUser->organisation_role = $userData['organization_role'];
                $adrollUser->eid = $userData['eid'];
                $adrollUser->created_date = $userData['created_date'];

                if ($adrollUserTable->save($adrollUser)) {
                    $this->Flash->success(__('Adroll User information pulled successfully'));
                    return $this->redirect(['action' => 'index']);
                }
            }
        } catch (Exception $e) {
            echo "Error :-" . $e->getMessage();
        }
    }

    /**
     * Date :- 26-may-17 
     * Function disc :- Function for get user information  
     * Help Url :- https://developers.adroll.com/docs/crud-api/reference.html#get--api-v1-report-ad
     * @RudrainnovativePvtLtd 
     */
    public function getAddReport($location_id = null, $apiKey) {
        try {
//            $location_id = 1;
            $check = 0;
            $organisationData = []; // array to store organisation data 
            if(empty($apiKey))
            {
                $apiKey = ADROLL_API_KEY;
            }
            $base_url = ADROLL_BASE_URL;

            // create curl resource
            $ch = curl_init();

            $campTable = $this->loadModel('AdrollCampaign'); // calling adroll campaign model table 

            $campArray = []; // array for store campaign data 

            /* get data from campaign data tabel */
            $campData = $campTable->find('all')->where(['location_id' => $location_id])->all();
            if (iterator_count($campData)) {
                foreach ($campData as $key => $camp):
                    $campArray[$key]['id'] = $camp->id;
                    $campArray[$key]['eid'] = $camp->eid;
                endforeach;
            }

            /* Check if campaign data is not empty */
            if (!empty($campArray)) {
                foreach ($campArray as $camp):

                    // set url
                    $url = $base_url . "/api/v1/report/ad?apikey=" . $apiKey . "&data_format=entity&campaigns=" . $camp['eid'];

                    curl_setopt($ch, CURLOPT_URL, $url);

                    // return the transfer as a string
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

                    // Set credentials
                    $credentials = ADROLL_USER_NAME . ':' . ADROLL_USER_PASSWORD;
                    curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
                    curl_setopt($ch, CURLOPT_USERPWD, $credentials);

                    // $output contains the output string
                    $output = curl_exec($ch);
                    $output = json_decode($output);

                    $campAddModel = $this->loadModel('AdrollCampAds'); // Adroll camp ads table 

                    if (!empty($output->results)) {
                        foreach ($output->results as $val):

                            $ads = $campAddModel->newEntity();
                            $ads->location_id = $location_id;
                            $ads->parent_campaign_id = $camp['id'];
                            $ads->status = $val->status;
                            $ads->advertiser = $val->advertiser;
                            $ads->total_conversion_rate = $val->total_conversion_rate;
                            $ads->attributed_click_through_rev = $val->attributed_click_through_rev;
                            $ads->ad = $val->ad;
                            $ads->view_through_ratio = $val->view_through_ratio;
                            $ads->view_through_conversions = $val->view_through_conversions;
                            $ads->height = $val->height;
                            $ads->cost = $val->cost;
                            $ads->attributed_rev = $val->attributed_rev;
                            $ads->click_through_conversions = $val->click_through_conversions;
                            $ads->adjusted_click_through_ratio = $val->adjusted_click_through_ratio;
                            $ads->impressions = $val->impressions;
                            $ads->adjusted_vtc = $val->adjusted_vtc;
                            $ads->attributed_view_through_rev = $val->attributed_view_through_rev;
                            $ads->adjusted_cpa = $val->adjusted_cpa;
                            $ads->billing_cost = $val->billing_cost;
                            $ads->adjusted_view_through_ratio = $val->adjusted_view_through_ratio;
                            $ads->click_through_ratio = $val->click_through_ratio;
                            $ads->prospects = $val->prospects;
                            $ads->roi = $val->roi;
                            $ads->cpm = $val->cpm;
                            $ads->ctr = $val->ctr;
                            $ads->cpa = $val->cpa;
                            $ads->cpc = $val->cpc;
                            $ads->paid_impressions = $val->paid_impressions;
                            $ads->click_cpa = $val->click_cpa;
                            $ads->total_conversions = $val->total_conversions;
                            $ads->ad_size = $val->ad_size;
                            $ads->adjusted_ctc = $val->adjusted_ctc;
                            $ads->eid = $val->eid;
                            $ads->created_date = $val->created_date;
                            $ads->adjusted_total_conversion_rate = $val->adjusted_total_conversion_rate;
                            $ads->type = $val->type;
                            $ads->clicks = $val->clicks;
                            $ads->adjusted_total_conversions = $val->adjusted_total_conversions;

                            $campAddModel->save($ads);

                            $check ++;
                        endforeach;
                    }

                endforeach;

                echo 'All ads report generated successfully.';
                /*
                if ($check > 0 && $check != 0) {
                    $this->Flash->success(__('Ads data pulled successfully into database.'));
                    return $this->redirect(['action' => 'index']);
                } else {
                    $this->Flash->error(__('Ads data not pulled into database.'));
                    return $this->redirect(['action' => 'index']);
                }
                 * 
                 */
            }
        } catch (Exception $e) {
            echo "Error :- " . $e->getMessage();
        }
    }
    
     /**
     * Date :- 07-june-2017
     * Function disc :- Function for get Historical 30 days ads report 
     * Help Url :- https://developers.adroll.com/docs/crud-api/reference.html#get--api-v1-report-ad
     * @RudrainnovativePvtLtd 
     */
    public function getHistoricalAddReport($location_id = null, $apiKey) {
        try {
//            $location_id = 1;
            $check = 0;
            $organisationData = []; // array to store organisation data 
            if(empty($apiKey))
            {
                $apiKey = ADROLL_API_KEY;
            }
            $base_url = ADROLL_BASE_URL;

            // create curl resource
            $ch = curl_init();

            $campTable = $this->loadModel('AdrollCampaign'); // calling adroll campaign model table 

            $campArray = []; // array for store campaign data 

            /* get data from campaign data tabel */
            $campData = $campTable->find('all')->where(['location_id' => $location_id])->all();
            if (iterator_count($campData)) {
                foreach ($campData as $key => $camp):
                    $campArray[$key]['id'] = $camp->id;
                    $campArray[$key]['eid'] = $camp->eid;
                endforeach;
            }

            /* Check if campaign data is not empty */
            if (!empty($campArray)) {
                foreach ($campArray as $camp):

                    // set url
                    $url = $base_url . "/api/v1/report/ad?apikey=" . $apiKey . "&data_format=entity&campaigns=" . $camp['eid']."&past_days=30";
                   
                    curl_setopt($ch, CURLOPT_URL, $url);

                    // return the transfer as a string
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

                    // Set credentials
                    $credentials = ADROLL_USER_NAME . ':' . ADROLL_USER_PASSWORD;
                    curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
                    curl_setopt($ch, CURLOPT_USERPWD, $credentials);

                    // $output contains the output string
                    $output = curl_exec($ch);
                    $output = json_decode($output);
                    
                    $campAddModel = $this->loadModel('AdrollCampAds'); // Adroll camp ads table 

                    if (!empty($output->results)) {
                        foreach ($output->results as $val):

                            $ads = $campAddModel->newEntity();
                            $ads->location_id = $location_id;
                            $ads->parent_campaign_id = $camp['id'];
                            $ads->status = $val->status;
                            $ads->advertiser = $val->advertiser;
                            $ads->total_conversion_rate = $val->total_conversion_rate;
                            $ads->attributed_click_through_rev = $val->attributed_click_through_rev;
                            $ads->ad = $val->ad;
                            $ads->view_through_ratio = $val->view_through_ratio;
                            $ads->view_through_conversions = $val->view_through_conversions;
                            $ads->height = $val->height;
                            $ads->cost = $val->cost;
                            $ads->attributed_rev = $val->attributed_rev;
                            $ads->click_through_conversions = $val->click_through_conversions;
                            $ads->adjusted_click_through_ratio = $val->adjusted_click_through_ratio;
                            $ads->impressions = $val->impressions;
                            $ads->adjusted_vtc = $val->adjusted_vtc;
                            $ads->attributed_view_through_rev = $val->attributed_view_through_rev;
                            $ads->adjusted_cpa = $val->adjusted_cpa;
                            $ads->billing_cost = $val->billing_cost;
                            $ads->adjusted_view_through_ratio = $val->adjusted_view_through_ratio;
                            $ads->click_through_ratio = $val->click_through_ratio;
                            $ads->prospects = $val->prospects;
                            $ads->roi = $val->roi;
                            $ads->cpm = $val->cpm;
                            $ads->ctr = $val->ctr;
                            $ads->cpa = $val->cpa;
                            $ads->cpc = $val->cpc;
                            $ads->paid_impressions = $val->paid_impressions;
                            $ads->click_cpa = $val->click_cpa;
                            $ads->total_conversions = $val->total_conversions;
                            $ads->ad_size = $val->ad_size;
                            $ads->adjusted_ctc = $val->adjusted_ctc;
                            $ads->eid = $val->eid;
                            $ads->created_date = $val->created_date;
                            $ads->adjusted_total_conversion_rate = $val->adjusted_total_conversion_rate;
                            $ads->type = $val->type;
                            $ads->clicks = $val->clicks;
                            $ads->adjusted_total_conversions = $val->adjusted_total_conversions;

                            $campAddModel->save($ads);

                            $check ++;
                        endforeach;
                    }

                endforeach;

                echo 'All ads Historical report generated successfully.';
                /*
                if ($check > 0 && $check != 0) {
                    $this->Flash->success(__('Ads data pulled successfully into database.'));
                    return $this->redirect(['action' => 'index']);
                } else {
                    $this->Flash->error(__('Ads data not pulled into database.'));
                    return $this->redirect(['action' => 'index']);
                }
                 * 
                 */
            }
        } catch (Exception $e) {
            echo "Error :- " . $e->getMessage();
        }
    }

    /**
     * Date :- 25-may-17 
     * Function disc :- Function for get for get Campaigns a/c to User EID 
     * Help Url :- https://developers.adroll.com/docs/crud-api/reference.html#get--api-v1-advertisable-get_campaigns
     * @RudrainnovativePvtLtd 
     */
    public function getCampaigns($advertisableEid=null, $location_id=null ) {
        try {
//            $location_id = 1; // only for testing 
            $campaignData = []; // array for store campaign data 
            $check = 0;
            $apiKey = ADROLL_API_KEY;
            $base_url = ADROLL_BASE_URL;
//            $advertisableEid = 'SM4AXPLLSFEC7BLNURF3FT'; // only for testing 
            // create curl resource
            $ch = curl_init();

            // set url
            $url = $base_url . "/api/v1/advertisable/get_campaigns?apikey=" . $apiKey . "&advertisable=" . $advertisableEid;

            curl_setopt($ch, CURLOPT_URL, $url);

            // return the transfer as a string
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

            // Set credentials
            $credentials = ADROLL_USER_NAME . ':' . ADROLL_USER_PASSWORD;
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($ch, CURLOPT_USERPWD, $credentials);

            // $output contains the output string
            $output = curl_exec($ch);
            $output = json_decode($output);

            if (!empty($output)) {
                foreach ($output->results as $key => $val) {
                    $campaignData[$key]['updated_date'] = $val->updated_date;
                    $campaignData[$key]['start_date'] = $val->start_date;
                    $campaignData[$key]['status'] = $val->status;
                    $campaignData[$key]['is_active'] = $val->is_active;
                    $campaignData[$key]['cpm'] = $val->cpm;
                    $campaignData[$key]['advertisableEid'] = $val->advertisable;
                    $campaignData[$key]['name'] = $val->name;
                    $campaignData[$key]['cpc'] = $val->cpc;
                    $campaignData[$key]['budget'] = $val->budget;
                    $campaignData[$key]['eid'] = $val->eid;
                    $campaignData[$key]['created_date'] = $val->created_date;
                }
            }

            /* Database insert logic */

            $camTable = $this->loadModel('AdrollCampaign');

            if (!empty($campaignData)) {
                foreach ($campaignData as $data):

                    $checkEid = $this->matchEid($data['eid'], "AdrollCampaign"); // function check eid from database 

                    if ($checkEid == 1) {
                        $setArray = []; // blank array for setting adroll data into array for update 

                        /* Update campaing data a/c to eid */
                        $setArray['location_id'] = $location_id;
                        $setArray['parent_advertisable'] = $data['advertisableEid'];
                        $setArray['campaign_name'] = $data['name'];
                        $setArray['cpc'] = $data['cpc'];
                        $setArray['budget'] = $data['budget'];
                        $setArray['status'] = $data['status'];
                        $setArray['start_date'] = $data['start_date'];
                        $setArray['updated_date'] = $data['updated_date'];
                        $setArray['eid'] = $data['eid'];
                        $setArray['created_date'] = $data['created_date'];
                        $setArray['cmp'] = $data['cpm'];
                        $setArray['updated_at'] = date('Y-m-d h:i:s');

                        $query = $camTable->query();
                        $query->update()
                                ->set($setArray)
                                ->where(['eid' => $data['eid']])
                                ->execute();
                    } else {
                        /* insert campaign data into database */
                        $campData = $camTable->newEntity();
                        $campData->location_id = $location_id;
                        $campData->parent_advertisable = $data['advertisableEid'];
                        $campData->campaign_name = $data['name'];
                        $campData->cpc = $data['cpc'];
                        $campData->budget = $data['budget'];
                        $campData->status = $data['status'];
                        $campData->start_date = $data['start_date'];
                        $campData->updated_date = $data['updated_date'];
                        $campData->eid = $data['eid'];
                        $campData->created_date = $data['created_date'];
                        $campData->cmp = $data['cpm'];

                        $camTable->save($campData); //save campaing data 
                        // die('here insert');
                    }

                    $check ++;
                endforeach;
            }

            die('all campaign data fetched.');
            /*
            if ($check > 0 && $check != 0) {
                $this->Flash->success(__("Campaign data successfully updated into database."));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__("Campaign data not updated into database."));
                return $this->redirect(['action' => 'index']);
            }
             * 
             */
        } catch (Exception $e) {
            echo "Error :-" . $e->getMessage();
        }
    }

    /**
     * Date :- 26-may-17 
     * Function disc :- Function for check eid from database a/c table and condition 
     * @RudrainnovativePvtLtd 
     */
    private function matchEid($eid = null, $model = null, $campId = null) {
        $campData = []; //blank array 
        $campTable = $this->loadModel($model); // loding campaign model 
        if ($campId == null) {
            $campData = $campTable->find('all')->where(['eid' => $eid])->all(); // get data from database a/c to eid 
        } else {
            $campData = $campTable->find('all')->where(['eid' => $eid, 'parent_campaign_id' => $campId])->all(); // get data from database a/c to eid 
        }


        if (iterator_count($campData)) { // check $campData is empty or not 
            return 1;
        } else {
            return 0;
        }
    }

    /**
     * Date :- 25-may-17 
     * Updated at :- 26-may-17
     * Function disc :- Function for get for get Campaigns a/c to Campaign EID 
     * Help Url :- https://developers.adroll.com/docs/crud-api/reference.html#get--api-v1-report-campaign
     * @RudrainnovativePvtLtd 
     */
    public function getCampaignsReport($location_id = null, $apiKey) {
        ob_start();
//        $location_id = 1;
        $check = 0; // variable for check 
        if(empty($apiKey))
        {
            $apiKey = ADROLL_API_KEY;
        }
        $base_url = ADROLL_BASE_URL;
        $campaignArr = []; // blank array to store campaign eid information 

        /* Load Campaign table */
        $campEid = []; // array for store campaign eid from database 

        $campTable = $this->loadModel('AdrollCampaign');

        $campData = $campTable->find('all')->where(['location_id' => $location_id])->all();

        /* Check empty $campData or not */
        if (iterator_count($campData)) {
            foreach ($campData as $val):
                $campaignArr[] = $val->eid; // store all eid  
            endforeach;
        }

        $campaignStr = implode(',', $campaignArr);

        // create curl resource
        $ch = curl_init();

        // set url
        $url = $base_url . "/api/v1/report/campaign?apikey=" . $apiKey . "&data_format=entity&campaigns=" . $campaignStr;

        curl_setopt($ch, CURLOPT_URL, $url);

        // return the transfer as a string
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        // Set credentials
        $credentials = ADROLL_USER_NAME . ':' . ADROLL_USER_PASSWORD;
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_USERPWD, $credentials);

        // $output contains the output string
        $output = curl_exec($ch);
        $output = json_decode($output);

        $campaignReporting = $this->loadModel('AdrollCampaignReporting');

        if (!empty($output)) {
            foreach ($output->results as $data):
                $insert = $campaignReporting->newEntity();
                $insert->location_id = $location_id;
                $insert->parent_campaign_id = $data->eid;
                $insert->campaign = $data->campaign;
                $insert->status = $data->status;
                $insert->budget = $data->budget;
                $insert->impression = $data->impressions;
                $insert->clicks = $data->clicks;
                $insert->ctr = $data->ctr;
                $insert->cmp = $data->cpm;
                $insert->vtc = $data->view_through_conversions;
                $insert->vtc_rate = $data->view_through_ratio;
                $insert->ctc = $data->adjusted_ctc;
                $insert->ctc_rate = $data->click_through_ratio;
                $insert->conversion = $data->click_through_conversions;
                $insert->spend = $data->cost;
                $insert->roi = $data->roi;
                $campaignReporting->save($insert); // save into database 
                $check ++; // $check auto increment 
            endforeach;
        }

        echo 'Campaign Reporting saved into database .';
        
        /*
        if ($check > 0 && $check != 0) {
            $this->Flash->success(__("Campaign report updated successfully into database."));
            return $this->redirect(['action' => 'index']);
        } else {
            $this->Flash->error(__("Campaign report Error."));
            return $this->redirect(['action' => 'index']);
        }
         * 
         */
    }
    
    /**
     * Date :- 25-may-17 
     * Updated at :- 26-may-17
     * Function disc :- Function for get for get Campaigns a/c to Campaign EID 
     * Help Url :- https://developers.adroll.com/docs/crud-api/reference.html#get--api-v1-report-campaign
     * @RudrainnovativePvtLtd 
     */
    public function getHistoricalCampaignsReport($location_id = null, $apiKey) {
        ob_start();
//        $location_id = 1;
        $check = 0; // variable for check 
        if(empty($apiKey))
        {
            $apiKey = ADROLL_API_KEY;
        }
        
        $base_url = ADROLL_BASE_URL;
        $campaignArr = []; // blank array to store campaign eid information 

        /* Load Campaign table */
        $campEid = []; // array for store campaign eid from database 

        $campTable = $this->loadModel('AdrollCampaign');

        $campData = $campTable->find('all')->where(['location_id' => $location_id])->all();

        /* Check empty $campData or not */
        if (iterator_count($campData)) {
            foreach ($campData as $val):
                $campaignArr[] = $val->eid; // store all eid  
            endforeach;
        }

        $campaignStr = implode(',', $campaignArr);

        // create curl resource
        $ch = curl_init();

        // set url
        $url = $base_url . "/api/v1/report/campaign?apikey=" . $apiKey . "&data_format=entity&campaigns=" . $campaignStr.'&past_days=30';

        curl_setopt($ch, CURLOPT_URL, $url);

        // return the transfer as a string
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        // Set credentials
        $credentials = ADROLL_USER_NAME . ':' . ADROLL_USER_PASSWORD;
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_USERPWD, $credentials);

        // $output contains the output string
        $output = curl_exec($ch);
        $output = json_decode($output);
        
        $campaignReporting = $this->loadModel('AdrollCampaignReporting');

        if (!empty($output)) {
            foreach ($output->results as $data):
                $insert = $campaignReporting->newEntity();
                $insert->location_id = $location_id;
                $insert->parent_campaign_id = $data->eid;
                $insert->campaign = $data->campaign;
                $insert->status = $data->status;
                $insert->budget = $data->budget;
                $insert->impression = $data->impressions;
                $insert->clicks = $data->clicks;
                $insert->ctr = $data->ctr;
                $insert->cmp = $data->cpm;
                $insert->vtc = $data->view_through_conversions;
                $insert->vtc_rate = $data->view_through_ratio;
                $insert->ctc = $data->adjusted_ctc;
                $insert->ctc_rate = $data->click_through_ratio;
                $insert->conversion = $data->click_through_conversions;
                $insert->spend = $data->cost;
                $insert->roi = $data->roi;
                $campaignReporting->save($insert); // save into database 
                $check ++; // $check auto increment 
            endforeach;
        }

        echo 'Campaign Historical Reporting saved into database .';
        /*
        if ($check > 0 && $check != 0) {
            $this->Flash->success(__("Campaign report updated successfully into database."));
            return $this->redirect(['action' => 'index']);
        } else {
            $this->Flash->error(__("Campaign report Error."));
            return $this->redirect(['action' => 'index']);
        }
         * 
         */
    }

    /**
     * Date :- 26-may-17 
     * Function disc :- Function for display adds a/c comapign 
     * @RudrainnovativePvtLtd 
     */
    public function displayAds($campId = null) {
        $adsData = []; // blank array to store adroll ads data 
        $campAddModel = $this->loadModel('AdrollCampAds'); // Adroll camp ads table 
        $campAdsData = $campAddModel->find('all')->where(['parent_campaign_id' => $campId])->all();

        if (iterator_count($campAdsData)) {
            foreach ($campAdsData as $key => $val):
                $adsData[$key]['parent_campaign_id'] = $val->parent_campaign_id;
                $adsData[$key]['status'] = $val->status;
                $adsData[$key]['advertiser'] = $val->advertiser;
                $adsData[$key]['ad'] = $val->ad;
                $adsData[$key]['cost'] = $val->cost;
                $adsData[$key]['impressions'] = $val->impressions;
                $adsData[$key]['clicks'] = $val->clicks;
                $adsData[$key]['type'] = $val->type;
            endforeach;
        }

        $this->set('adrollAds', $adsData);
    }

}
