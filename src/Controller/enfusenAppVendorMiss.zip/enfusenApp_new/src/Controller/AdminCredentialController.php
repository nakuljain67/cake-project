<?php

namespace App\Controller;

use App\Controller\AppController;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[] paginate($object = null, array $settings = [])
 */
class AdminCredentialController extends AppController {

    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index() {
        $users_table = $this->loadModel('ApiOptions');
        $facebook = $users_table->find()->where(['option_key' => 'facebook'])->first();
        if (!empty($facebook)) {
            $a = json_decode($facebook->option_value);
        } else {
            $a = [];
        }
        $this->set('a', $a);
        $bing = $users_table->find()->where(['option_key' => 'bing'])->first();
        if (!empty($bing)) {
            $b = json_decode($bing->option_value);
        } else {
            $b = [];
        }

        $this->set('b', $b);
        $adword = $users_table->find()->where(['option_key' => 'adword'])->first();
        if (!empty($adword)) {
            $c = json_decode($adword->option_value);
        } else {
            $c = [];
        }
        $this->set('c', $c);
        $placesscout = $users_table->find()->where(['option_key' => 'placesscout'])->first();
        if (!empty($placesscout)) {
            $d = json_decode($placesscout->option_value);
        } else {
            $d = [];
        }
        $this->set('d', $d);
        $semrush = $users_table->find()->where(['option_key' => 'semrush'])->first();
        if (!empty($semrush)) {
            $e = json_decode($semrush->option_value);
        } else {
            $e = [];
        }
        $this->set('e', $e);
    }

    public function submit() {

        if (!empty($_POST['facebook']['clientId']) && !empty($_POST['facebook']['secret']) && !empty($_POST['facebook']['redirect'])) {
            $clientId = $_POST['facebook']['clientId'];
            $secret = $_POST['facebook']['secret'];
            $redirect = $_POST['facebook']['redirect'];
            $new = [];
            $new["clientId"] = $clientId;
            $new["secret"] = $secret;
            $new["redirect"] = $redirect;
            //pr($new); die;
            $users_table = $this->loadModel('ApiOptions');
            $matchcount = $users_table->find()->where(['option_key' => 'facebook'])->count();
            if ($matchcount == 0) {
                $insert = $users_table->newEntity();
                $insert->option_key = "facebook";
                $insert->option_value = json_encode($new);
                $users_table->save($insert);
                $this->Flash->success(__('Facebook credential save successfully.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $option = json_encode($new);

                $new = ['option_value' => $option];
                $query = $users_table->query();
                if ($query->update()->set($new)->where(['option_key' => 'facebook'])->execute()) {
                    $this->Flash->success(__('Facebook credential save successfully.'));
                    return $this->redirect(['action' => 'index']);
                } else {
                    $this->Flash->error(__('Facebook credential not save successfully.'));
                    return $this->redirect(['action' => 'index']);
                }
            }
        } elseif (!empty($_POST['bing']['clientId']) && !empty($_POST['bing']['secret']) && !empty($_POST['bing']['username']) && !empty($_POST['bing']['password']) && !empty($_POST['bing']['token']) && !empty($_POST['bing']['redirect'])) {
            $clientId = $_POST['bing']['clientId'];
            $secret = $_POST['bing']['secret'];
            $username = $_POST['bing']['username'];
            $password = $_POST['bing']['password'];
            $token = $_POST['bing']['token'];
            $redirect = $_POST['bing']['redirect'];
            $new = [];
            $new["clientId"] = $clientId;
            $new["secret"] = $secret;
            $new["username"] = $username;
            $new["password"] = $password;
            $new["token"] = $token;
            $new["redirect"] = $redirect;
            //pr($new); die;
            $users_table = $this->loadModel('ApiOptions');
            $matchcount = $users_table->find()->where(['option_key' => 'bing'])->count();
            if ($matchcount == 0) {
                $insert = $users_table->newEntity();
                $insert->option_key = "bing";
                $insert->option_value = json_encode($new);
                $users_table->save($insert);
                $this->Flash->success(__('Bing credential save successfully.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $option = json_encode($new);
                $new = ['option_value' => $option];
                $query = $users_table->query();
                $query->update()->set($new)->where(['option_key' => 'bing'])->execute();
                $this->Flash->success(__('Bing credential save successfully.'));
                return $this->redirect(['action' => 'index']);
            }
        } elseif (!empty($_POST['placesscout']['username']) && !empty($_POST['placesscout']['password']) && !empty($_POST['placesscout']['api_url']) && !empty($_POST['placesscout']['documentation_url'])) {
            $username = $_POST['placesscout']['username'];
            $password = $_POST['placesscout']['password'];
            $api_url = $_POST['placesscout']['api_url'];
            $documentation_url = $_POST['placesscout']['documentation_url'];
            $new = [];
            $new["username"] = $username;
            $new["password"] = $password;
            $new["api_url"] = $api_url;
            $new["documentation_url"] = $documentation_url;
            //pr($new); die;
            $users_table = $this->loadModel('ApiOptions');
            $matchcount = $users_table->find()->where(['option_key' => 'placesscout'])->count();
            if ($matchcount == 0) {
                $insert = $users_table->newEntity();
                $insert->option_key = "placesscout";
                $insert->option_value = json_encode($new);
                $users_table->save($insert);
                $this->Flash->success(__('Placesscout credential save successfully.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $option = json_encode($new);
                $new = ['option_value' => $option];
                $query = $users_table->query();
                $query->update()->set($new)->where(['option_key' => 'placesscout'])->execute();
                $this->Flash->success(__('Placesscout credential save successfully.'));
                return $this->redirect(['action' => 'index']);
            }
        } elseif (!empty($_POST['semrush']['api_key']) && !empty($_POST['semrush']['api_url'])) {
            $api_key = $_POST['semrush']['api_key'];
            $api_url = $_POST['semrush']['api_url'];
            $new = [];
            $new["api_key"] = $api_key;
            $new["api_url"] = $api_url;
            $users_table = $this->loadModel('ApiOptions');
            $matchcount = $users_table->find()->where(['option_key' => 'semrush'])->count();
            if ($matchcount == 0) {
                $insert = $users_table->newEntity();
                $insert->option_key = "semrush";
                $insert->option_value = json_encode($new);
                $users_table->save($insert);
                $this->Flash->success(__('Semrush credential save successfully.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $option = json_encode($new);
                $new = ['option_value' => $option];
                $query = $users_table->query();
                $query->update()->set($new)->where(['option_key' => 'semrush'])->execute();
                $this->Flash->success(__('Semrush credential save successfully.'));
                return $this->redirect(['action' => 'index']);
            }
        } elseif (!empty($_POST['adwords']['clientId']) && !empty($_POST['adwords']['secret']) && !empty($_POST['adwords']['redirect'])) {
            $clientId = $_POST['adwords']['clientId'];
            $secret = $_POST['adwords']['secret'];
            $redirect = $_POST['adwords']['redirect'];
            $new = [];
            $new["clientId"] = $clientId;
            $new["secret"] = $secret;
            $new["redirect"] = $redirect;
            //pr($new); die;
            $users_table = $this->loadModel('ApiOptions');
            $matchcount = $users_table->find()->where(['option_key' => 'adword'])->count();
            if ($matchcount == 0) {
                $insert = $users_table->newEntity();
                $insert->option_key = "adword";
                $insert->option_value = json_encode($new);
                $users_table->save($insert);
                $this->Flash->success(__('Adword credential save successfully.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $option = json_encode($new);
                $new = ['option_value' => $option];
                $query = $users_table->query();
                $query->update()->set($new)->where(['option_key' => 'adword'])->execute();
                $this->Flash->success(__('Adword credential save successfully.'));
                return $this->redirect(['action' => 'index']);
            }
        } else {
            $this->Flash->success(__('Invalid credential.'));
            return $this->redirect(['action' => 'index']);
        }
    }

}
