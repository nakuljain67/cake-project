<?php

namespace App\Controller;

ini_set('max_execution_time', 500); // set maximum execution time 

require_once(ROOT . DS . 'vendor' . DS . "adwords" . DS . "vendor" . DS . "autoload.php");

use Google\AdsApi\AdWords\Reporting\v201702\ReportDownloader;
use Google\AdsApi\AdWords\Reporting\v201702\DownloadFormat;
use Cake\Core\App; // use core app controller namespace 

App::className('Controller', 'AdwordsDataController');  // calling AdwordsDataController 

Class AdwordsAdgroupReportController extends AppController {


    /**
     * Date :- 13-june-17 
     * Function disc :- function for fetch subaccount's from database according to user id  
     * @RudrainnovativePvtLtd 
     */
    private function getSubaccounts($location_id = null) {
        $subAccountData = []; // array for store sub account data 
        $subAccountModel = $this->loadModel('AdwordsSubaccount'); // load AdwordsSubaccount model 
        $data = $subAccountModel->find('all')->where(['location_id' => $location_id, 'can_manage_client != ' => 1])->all();

        if (!empty($data)) {
            foreach ($data as $key => $val) {
                $subAccountData[$key]['Id'] = $val->id;
                $subAccountData[$key]['subAccountId'] = $val->sub_cust_client_id;
                $subAccountData[$key]['subAccountName'] = $val->sub_cust_name;
            }
        }
        
        return $subAccountData; // return subAccount data from database 
    }


    /**
     * Date :- 24-may-17 
     * Updated :- 12-june-17
     * Function disc :- Function for Parse csv data 
     * @RudrainnovativePvtLtd 
     */
    public function parseCsv($csvData = null) {
        $dataArray = []; //array for store data performance data into array  
        $parsedArray = [];
        $lines = explode(PHP_EOL, $csvData);

        $total = count($lines);
        if ($total > 4) {

            for ($i = 2; $i < $total - 2; $i++) {
                $parsedArray[] = explode(",", $lines[$i]);
            }
            
            if (!empty($parsedArray)) {
                
                $count = count($parsedArray);
                for ($a = 0; $a < $count; $a++) {
                    $dataArray[$a]["campaign_id"] = $parsedArray[$a][0];
                    $dataArray[$a]["adgroup_id"] = $parsedArray[$a][1];
                    $dataArray[$a]["adgroup_name"] = $parsedArray[$a][2];
                    $dataArray[$a]["impression"] = $parsedArray[$a][3];
                    $dataArray[$a]["clicks"] = $parsedArray[$a][4];
                    $dataArray[$a]["cost"] = $parsedArray[$a][5]/1000000;
                    $dataArray[$a]["ctr"] = $parsedArray[$a][6];
                    $dataArray[$a]["avg_cpc"] = $parsedArray[$a][7] / 1000000;
                    $dataArray[$a]["avg_pos"] = $parsedArray[$a][8];
                    $dataArray[$a]["conversions"] = $parsedArray[$a][9];
                    $dataArray[$a]["costperconv"] = $parsedArray[$a][10]/1000000;
                    $dataArray[$a]["conv_rate"] = $parsedArray[$a][11];
                    $dataArray[$a]["view_through_conv"] = $parsedArray[$a][12];
                    $dataArray[$a]["all_conv"] = $parsedArray[$a][13];
                    $dataArray[$a]["search_imp_share"] = $parsedArray[$a][14];
                    $dataArray[$a]["bounce_rate"] = $parsedArray[$a][15];
                    $dataArray[$a]["default_max_cpc"] = $parsedArray[$a][16]/1000000;
                }
            }

            return $dataArray;
        }
    }

    /**
     * Date :- 13-june-17
     * Function disc :- Function for get adwords adgroup reporting
     * @RudrainnovativePvtLtd 
     */
    
    public function adwordsAdgroupReporting($location_id)
    {
//        $location_id = 1; // send userid in post 
        $obj = new AdwordsDataController;
        $credential = $obj->credentialBuilder($location_id);
        $subData = $this->getSubaccounts($location_id);
        
        if(!empty($subData)) {
            foreach($subData as $val):
                $session = $obj->reportSession($credential, $val["subAccountId"]);
               
                $reportQuery = 'SELECT CampaignId,AdGroupId,AdGroupName,Impressions,Clicks,Cost,Ctr,AverageCpc
                                ,AveragePosition,Conversions,CostPerConversion,ConversionRate,ViewThroughConversions,AllConversions,SearchImpressionShare,BounceRate,CpcBid
                                FROM ADGROUP_PERFORMANCE_REPORT DURING YESTERDAY';

                // Download report as a string.
                $reportDownloader = new ReportDownloader($session);
                $reportDownloadResult = $reportDownloader->downloadReportWithAwql($reportQuery, 'CSV');
                $csvData = $reportDownloadResult->getAsString(); // generate report as string 

                $parsedData = $this->parseCsv($csvData); // calling function to parse 
                $table = $this->loadModel("AdwordsAdgroupReporting");
                
                if(!empty($parsedData)) {
                    foreach($parsedData as $data):
                        $insert = $table->newEntity();
                        $insert->location_id = $location_id;
                        $insert->campaign_id = $data["campaign_id"];
                        $insert->adgroup_id = $data["adgroup_id"];
                        $insert->adgroup_name = $data["adgroup_name"];
                        $insert->impression = $data["impression"];
                        $insert->clicks = $data["clicks"];
                        $insert->cost = $data["cost"];
                        $insert->ctr = $data["ctr"];
                        $insert->avg_cpc = $data["avg_cpc"];
                        $insert->avg_position = $data["avg_pos"];
                        $insert->conversion = $data["conversions"];
                        $insert->cost_per_conv = $data["costperconv"];
                        $insert->conv_rate = $data["conv_rate"];
                        $insert->view_throuth_conv = $data["view_through_conv"];
                        $insert->all_conv = $data["all_conv"];
                        $insert->search_imp_share = $data["search_imp_share"];
                        $insert->bounce_rate = $data["bounce_rate"];
                        $insert->default_max_cpc = $data["default_max_cpc"];
                        $table->save($insert);
                    endforeach;
                }
                
            endforeach;
        }
        
    }
    
    /**
     * Date :- 13-june-17
     * Function disc :- Function for display Adwords Adgroup performance reporting 
     * @RudrainnovativePvtLtd 
     */
    
    public function displayAdgrpReporting($location_id = 1)
    {
        $array = []; // blank array to store and return data into page 
        $table = $this->loadModel("AdwordsAdgroupReporting");
        $adgoupData = $table->find('all')->where(["location_id" => $location_id])->toArray();
        
        if(!empty($adgoupData)) {
           
           foreach($adgoupData as $key => $data):
               $array[$key]["campaign_id"] = $data["campaign_id"];
               $array[$key]["adgroup_id"] = $data["adgroup_id"];
               $array[$key]["adgroup_name"] = $data["adgroup_name"];
               $array[$key]["impression"] = $data["impression"];
               $array[$key]["clicks"] = $data["clicks"];
               $array[$key]["cost"] = $data["cost"];
               $array[$key]["ctr"] = $data["ctr"];
               $array[$key]["avg_cpc"] = $data["avg_cpc"];
               $array[$key]["avg_position"] = $data["avg_position"];
               $array[$key]["conversion"] = $data["conversion"];
               $array[$key]["cost_per_conv"] = $data["cost_per_conv"];
               $array[$key]["conv_rate"] = $data["conv_rate"];
               $array[$key]["view_throuth_conv"] = $data["view_throuth_conv"];
               $array[$key]["all_conv"] = $data["all_conv"];
               $array[$key]["search_imp_share"] = $data["search_imp_share"];
               $array[$key]["bounce_rate"] = $data["bounce_rate"];
               $array[$key]["default_max_cpc"] = $data["default_max_cpc"];
               $array[$key]["created_at"] = $data["created_at"];
           endforeach;
        }
        
        if(!empty($array)) {
            $this->set("AdgroupData", $array);
        }
    }

}
