<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;

class BingApiController extends AppController {

    private $location_id; // variable for store location
    private $subAccount; // variable for store subaccont model
    private $limit;     // variable for store limit 

    /**
     * Date :- 16-june-17 
     * Function disc :- function for initialize  
     * @RudrainnovativePvtLtd 
     */

    public function initialize() {
        header('Access-Control-Allow-Origin: *');
        $allow = array("192.168.1.69", "35.163.234.186");
        $this->autoRender = false;
        ini_set("soap.wsdl_cache_enabled", "0");
        ini_set("soap.wsdl_cache_ttl", "0");
        $this->location_id = $this->check_validrequest();
        $this->limit = 50;

        /* Loding models */

        $this->subAccount = TableRegistry::get('bing_sub_user_data');
    }

    public function index() {
        echo "Welcome to API Engine House";
    }

    /**
     * Date :- 16-june-17 
     * Function disc :- function for get sub-accounts a/c to location id 
     * @RudrainnovativePvtLtd 
     */
    public function getSubaccounts() {
        $return = []; // array for store return data 
        $limit = isset($_POST["limit"]) ? $_POST["limit"] : $this->limit ;
        $offset = isset($_POST["offset"]) ? $_POST["offset"] : 0;
        $bingSubaccounts = $this->subAccount->find('all')->where(["location_id" => $this->location_id])->limit($limit)->offset($offset)->all();
        if (iterator_count($bingSubaccounts)) {
            foreach ($bingSubaccounts as $key => $value):
                $return[$key]["id"] = $value->id;
                $return[$key]["location_id"] = $value->location_id;
                $return[$key]["parent_bingid"] = $value->parent_bingid;
                $return[$key]["account_type"] = $value->account_type;
                $return[$key]["bill_to_customer_id"] = $value->bill_to_customer_id;
                $return[$key]["country_code"] = $value->country_code;
                $return[$key]["currency_type"] = $value->currency_type;
                $return[$key]["account_id"] = $value->account_id;
                $return[$key]["language"] = $value->language;
                $return[$key]["name"] = $value->name;
                $return[$key]["number"] = $value->number;
                $return[$key]["parent_customer_id"] = $value->parent_customer_id;
                $return[$key]["primary_user_id"] = $value->primary_user_id;
                $return[$key]["status"] = $value->account_life_cycle_status;
                $return[$key]["timezone"] = $value->timezone;
            endforeach;
        } else {
            $this->json(0, "Invalid location id");
        }

        if (!empty($return)) {
            $this->json(1, 'Bing Subaccount list', $return);
        }
    }

    /**
     * Date :- 16-june-17 
     * Function disc :- function for get campaigns a/c to location id or a/c to sub-account id 
     * parameters :- location_id, accountId, offset, start date, end date
     * @RudrainnovativePvtLtd 
     */
    public function getCampaigns() {

        $campaignData = "";
        $campaignModel = ConnectionManager::get('default');
        $subaccountId = isset($_POST['accountid']) ? $_POST['accountid'] : ""; //415852 only for testing 
        $limit = isset($_POST['limit']) ? $_POST["limit"] : $this->limit;
        $offset = isset($_POST['offset']) ? $_POST['offset'] : 0;
        $start_date = isset($_POST["start_date"]) ? $_POST["start_date"] : "";
        $end_date = isset($_POST["end_date"]) ? $_POST["end_date"] : "";

        /* Conditions to send data according to input conditions */
        if (!empty($subaccountId) && empty($start_date) && empty($end_date)) {
            $campaignData = $campaignModel->execute("SELECT *, b.created_at as reporting_date FROM bing_campaign_data 
            CROSS JOIN bing_campaign_reporting b ON b.campaign_id = bing_campaign_data.campaign_id
            WHERE bing_campaign_data.location_id = $this->location_id AND bing_campaign_data.parent_id = $subaccountId LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && empty($subaccountId)) {
            $campaignData = $campaignModel->execute("SELECT * , b.created_at AS reporting_date FROM bing_campaign_data "
                    . "CROSS JOIN bing_campaign_reporting b ON b.campaign_id = bing_campaign_data.campaign_id "
                    . "WHERE bing_campaign_data.location_id = $this->location_id "
                    . "AND b.created_at <= '" . $start_date . "' AND b.created_at >= '" . $end_date . "' LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && !empty($subaccountId)) {
            $campaignData = $campaignModel->execute("SELECT * , b.created_at AS reporting_date FROM bing_campaign_data "
                    . "CROSS JOIN bing_campaign_reporting b ON b.campaign_id = bing_campaign_data.campaign_id "
                    . "WHERE bing_campaign_data.location_id = $this->location_id "
                    . "AND b.created_at <= '" . $start_date . "' AND b.created_at >= '" . $end_date . "' AND bing_campaign_data.parent_id = $subaccountId LIMIT $limit OFFSET $offset ");
        } else {
            $campaignData = $campaignModel->execute("SELECT *, b.created_at as reporting_date FROM bing_campaign_data 
            CROSS JOIN bing_campaign_reporting b ON b.campaign_id = bing_campaign_data.campaign_id
            WHERE bing_campaign_data.location_id = $this->location_id LIMIT $limit OFFSET $offset ");
        }

        $outputData = $campaignData->fetchAll("assoc"); // get data from database to return 

        if (!empty($outputData)) {
            $this->json(1, 'Bing Campaign list', $outputData);
        } else {
            $this->json(0, 'No campaigns found');
        }
    }
    
    /**
     * Date :- 16-june-17 
     * Function disc :- function for get bing ad-group 
     * parameters :- location_id, campaignId, offset, start date, end date
     * @RudrainnovativePvtLtd 
     */
    
    public function getAdgroups() {
        $adgroupData = "";
        $model = ConnectionManager::get('default');
        $campaignId = isset($_POST['campaignid']) ? $_POST['campaignid'] : ""; 
        $limit = isset($_POST['limit']) ? $_POST["limit"] : $this->limit;
        $offset = isset($_POST['offset']) ? $_POST['offset'] : 0;
        $start_date = isset($_POST["start_date"]) ? $_POST["start_date"] : "";
        $end_date = isset($_POST["end_date"]) ? $_POST["end_date"] : "";
        
         /* Conditions to send data according to input conditions */
        if (!empty($campaignId) && empty($start_date) && empty($end_date)) {
            $adgroupData = $model->execute("SELECT *, b.created_at as reporting_date FROM bing_adgroup_data 
            CROSS JOIN bing_adgroup_reporting b ON b.adgroup_id = bing_adgroup_data.adgroup_id
            WHERE bing_adgroup_data.location_id = $this->location_id AND bing_adgroup_data.parent_campaign_id = $campaignId LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && empty($campaignId)) {
            $adgroupData = $model->execute("SELECT * , b.created_at AS reporting_date FROM bing_adgroup_data "
                    . "CROSS JOIN bing_adgroup_reporting b ON b.adgroup_id = bing_adgroup_data.adgroup_id "
                    . "WHERE bing_adgroup_data.location_id = $this->location_id "
                    . "AND b.created_at <= '" . $start_date . "' AND b.created_at >= '" . $end_date . "' LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && !empty($campaignId)) {
            $adgroupData = $model->execute("SELECT * , b.created_at AS reporting_date FROM bing_adgroup_data "
                    . "CROSS JOIN bing_adgroup_reporting b ON b.adgroup_id = bing_adgroup_data.adgroup_id "
                    . "WHERE bing_adgroup_data.location_id = $this->location_id "
                    . "AND b.created_at <= '" . $start_date . "' AND b.created_at >= '" . $end_date . "' AND bing_adgroup_data.parent_campaign_id = $campaignId LIMIT $limit OFFSET $offset ");
        } else {
            $adgroupData = $model->execute("SELECT *, b.created_at as reporting_date FROM bing_adgroup_data 
            CROSS JOIN bing_adgroup_reporting b ON b.adgroup_id = bing_adgroup_data.adgroup_id
            WHERE bing_adgroup_data.location_id = $this->location_id LIMIT $limit OFFSET $offset ");
        }

        $outputData = $adgroupData->fetchAll("assoc"); // get data from database to return 

        if (!empty($outputData)) {
            $this->json(1, 'Bing Adgroups list', $outputData);
        } else {
            $this->json(0, 'No Adgroups found');
        }
    }
    
    /**
     * Date :- 16-june-17 
     * Function disc :- function for get bing Keywords  
     * parameters :- location_id, adgroupId, offset, start date, end date
     * @RudrainnovativePvtLtd 
     */
    
    public function getKeyword() {
        $keywordData = "";
        $model = ConnectionManager::get('default');
        $adgroupId = isset($_POST['adgroupid']) ? $_POST['adgroupid'] : ""; 
        $limit = isset($_POST['limit']) ? $_POST["limit"] : $this->limit;
        $offset = isset($_POST['offset']) ? $_POST['offset'] : 0;
        $start_date = isset($_POST["start_date"]) ? $_POST["start_date"] : "";
        $end_date = isset($_POST["end_date"]) ? $_POST["end_date"] : "";
        
         /* Conditions to send data according to input conditions */
        if (!empty($adgroupId) && empty($start_date) && empty($end_date)) {
            $keywordData = $model->execute("SELECT *, b.created_at as reporting_date FROM bing_keyword_data 
            CROSS JOIN bing_keyword_reporting b ON b.keyword_id = bing_keyword_data.keyword_id
            WHERE bing_keyword_data.location_id = $this->location_id AND bing_keyword_data.adgroup_id = $adgroupId LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && empty($adgroupId)) {
            $keywordData = $model->execute("SELECT * , b.created_at AS reporting_date FROM bing_keyword_data "
                    . "CROSS JOIN bing_keyword_reporting b ON b.keyword_id = bing_keyword_data.keyword_id "
                    . "WHERE bing_keyword_data.location_id = $this->location_id "
                    . "AND b.created_at <= '" . $start_date . "' AND b.created_at >= '" . $end_date . "' LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && !empty($adgroupId)) {
            $keywordData = $model->execute("SELECT * , b.created_at AS reporting_date FROM bing_keyword_data "
                    . "CROSS JOIN bing_keyword_reporting b ON b.keyword_id = bing_keyword_data.keyword_id "
                    . "WHERE bing_keyword_data.location_id = $this->location_id "
                    . "AND b.created_at <= '" . $start_date . "' AND b.created_at >= '" . $end_date . "' AND bing_keyword_data.adgroup_id = $adgroupId LIMIT $limit OFFSET $offset ");
        } else {
            $keywordData = $model->execute("SELECT *, b.created_at as reporting_date FROM bing_keyword_data 
            CROSS JOIN bing_keyword_reporting b ON b.keyword_id = bing_keyword_data.keyword_id
            WHERE bing_keyword_data.location_id = $this->location_id LIMIT $limit OFFSET $offset ");
        }

        $outputData = $keywordData->fetchAll("assoc"); // get data from database to return 

        if (!empty($outputData)) {
            $this->json(1, 'Bing Keyword list', $outputData);
        } else {
            $this->json(0, 'No keyword found');
        }
    }
    
    /**
     * Date :- 19-june-17 
     * Function disc :- Function for get Bing Ads performance reporting a/c to main account id 
     * parameters :- location_id, adgroupId, offset, start date, end date
     * @RudrainnovativePvtLtd 
     */
    
    public function getAds() {
        $adsData = "";
        $model = ConnectionManager::get('default');
        $adgroupId = isset($_POST['adgroupid']) ? $_POST['adgroupid'] : ""; 
        $limit = isset($_POST['limit']) ? $_POST["limit"] : $this->limit;
        $offset = isset($_POST['offset']) ? $_POST['offset'] : 0;
        $start_date = isset($_POST["start_date"]) ? $_POST["start_date"] : "";
        $end_date = isset($_POST["end_date"]) ? $_POST["end_date"] : "";
        
         /* Conditions to send data according to input conditions */
        if (!empty($adgroupId) && empty($start_date) && empty($end_date)) {
            $adsData = $model->execute("SELECT *, b.created_at as reporting_date FROM bing_ads_data 
            CROSS JOIN bing_ads_reporting b ON b.ads_id = bing_ads_data.ads_id
            WHERE bing_ads_data.location_id = $this->location_id AND bing_ads_data.addgroup_id = $adgroupId LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && empty($adgroupId)) {
            $adsData = $model->execute("SELECT * , b.created_at AS reporting_date FROM bing_ads_data "
                    . "CROSS JOIN bing_ads_reporting b ON b.ads_id = bing_ads_data.ads_id "
                    . "WHERE bing_ads_data.location_id = $this->location_id "
                    . "AND b.created_at <= '" . $start_date . "' AND b.created_at >= '" . $end_date . "' LIMIT $limit OFFSET $offset ");
        } else if (!empty($start_date) && !empty($end_date) && !empty($adgroupId)) {
            $adsData = $model->execute("SELECT * , b.created_at AS reporting_date FROM bing_ads_data "
                    . "CROSS JOIN bing_ads_reporting b ON b.ads_id = bing_ads_data.ads_id "
                    . "WHERE bing_ads_data.location_id = $this->location_id "
                    . "AND b.created_at <= '" . $start_date . "' AND b.created_at >= '" . $end_date . "' AND bing_ads_data.addgroup_id = $adgroupId LIMIT $limit OFFSET $offset ");
        } else {
            $adsData = $model->execute("SELECT *, b.created_at as reporting_date FROM bing_ads_data 
            CROSS JOIN bing_ads_reporting b ON b.ads_id = bing_ads_data.ads_id
            WHERE bing_ads_data.location_id = $this->location_id LIMIT $limit OFFSET $offset ");
        }

        $outputData = $adsData->fetchAll("assoc"); // get data from database to return 

        if (!empty($outputData)) {
            $this->json(1, 'Bing Ads list', $outputData);
        } else {
            $this->json(0, 'No Ads found');
        }
    }
    
    
    

}
