<?php

namespace App\Controller;

require_once(ROOT . DS . 'vendor' . DS . "bingAds" . DS . "vendor" . DS . "autoload.php");
require_once(ROOT . DS . 'vendor' . DS . "bingAds" . DS . "AuthHelper.php");

use App\Controller\AppController;
use Microsoft\BingAds\Auth\ApiEnvironment;
use Microsoft\BingAds\Auth\AuthorizationData;
use Microsoft\BingAds\Auth\OAuthTokenRequestException;
use Microsoft\BingAds\Auth\OAuthWebAuthCodeGrant;

/* --------- NEW ------------------------ */
use SoapVar;
use SoapFault;
use Exception;
// Specify the Microsoft\BingAds\v10\CampaignManagement classes that will be used.
use Microsoft\BingAds\V10\CampaignManagement\CampaignType;
// Specify the Microsoft\BingAds\v9\CustomerManagement classes that will be used.
use Microsoft\BingAds\V9\CustomerManagement\GetUserRequest;
use Microsoft\BingAds\V9\CustomerManagement\SearchAccountsRequest;
use Microsoft\BingAds\V9\CustomerManagement\Paging;
use Microsoft\BingAds\V9\CustomerManagement\Predicate;
use Microsoft\BingAds\V9\CustomerManagement\PredicateOperator;
// Specify the Microsoft\BingAds\Auth classes that will be used.
use Microsoft\BingAds\Auth\ServiceClient;
use Microsoft\BingAds\Auth\ServiceClientType;
// Specify the Microsoft\BingAds\Samples classes that will be used.
use cakeApi\bingads\AuthHelper;

/* ---------------------- END ------------------------- */

/* ------------------ Reporting ----------------------- */
// Specify the BingAds\Reporting classes that will be used.
use Microsoft\BingAds\V11\Reporting\SubmitGenerateReportRequest;
use Microsoft\BingAds\V11\Reporting\AccountPerformanceReportRequest;
use Microsoft\BingAds\V11\Reporting\CampaignPerformanceReportRequest;
use Microsoft\BingAds\V11\Reporting\AdGroupPerformanceReportRequest;
use Microsoft\BingAds\V11\Reporting\KeywordPerformanceReportRequest;
use Microsoft\BingAds\V11\Reporting\AdPerformanceReportRequest;
use Microsoft\BingAds\V11\Reporting\ReportFormat;
use Microsoft\BingAds\V11\Reporting\ReportAggregation;
use Microsoft\BingAds\V11\Reporting\AdGroupReportScope;
use Microsoft\BingAds\V11\Reporting\AccountThroughAdGroupReportScope;
use Microsoft\BingAds\V11\Reporting\CampaignReportScope;
use Microsoft\BingAds\V11\Reporting\AccountReportScope;
use Microsoft\BingAds\V11\Reporting\ReportTime;
use Microsoft\BingAds\V11\Reporting\ReportTimePeriod;
//use Microsoft\BingAds\V9\Reporting\Date;
use Microsoft\BingAds\V9\Reporting\AccountPerformanceReportFilter;
use Microsoft\BingAds\V9\Reporting\KeywordPerformanceReportFilter;
use Microsoft\BingAds\V9\Reporting\DeviceTypeReportFilter;
use Microsoft\BingAds\V9\Reporting\AccountPerformanceReportColumn;
use Microsoft\BingAds\V9\Reporting\AudiencePerformanceReportColumn;
use Microsoft\BingAds\V9\Reporting\KeywordPerformanceReportColumn;
use Microsoft\BingAds\V9\Reporting\PollGenerateReportRequest;
use Microsoft\BingAds\V9\Reporting\ReportRequestStatusType;
use Microsoft\BingAds\V9\Reporting\KeywordPerformanceReportSort;
// Used for get client account data (31-may-17)
use Microsoft\BingAds\V11\CampaignManagement\GetCampaignsByAccountIdRequest;
use Microsoft\BingAds\V11\CampaignManagement\GetAdGroupsByCampaignIdRequest;
use Microsoft\BingAds\V11\CampaignManagement\GetKeywordsByAdGroupIdRequest;
use Microsoft\BingAds\V11\CampaignManagement\GetAdsByAdGroupIdRequest;
use Cake\Datasource\ConnectionManager;

/* --------------------- END ---------------------------- */

Class BingController extends AppController {
    /* Define all the credentials for bing ads */

    PRIVATE STATIC $url = BING_URL_REDIRECT;
    PRIVATE STATIC $DeveloperToken = BING_DEVELOPER_TOKEN;
    PRIVATE STATIC $ApiEnvironment = ApiEnvironment::Production;
    PRIVATE STATIC $UserName = BING_USER_NAME;
    PRIVATE STATIC $Password = BING_USER_PASSWORD;
    PRIVATE STATIC $ClientId = BING_CLIENT_ID;
    PRIVATE STATIC $ClientSecret = BING_CLIENT_SECRET;
    private $customerProxy;
    private $proxy;
    private $userData;
    private $ReportingProxy;
    private $authorizationData;
    private $campaignProxy;
    private $reportProxy;
    private $adsProxy;
    private $bingUser; // var for store model BingUserTable 
    private $bingSubuser; // var for store model BingSubuserTable 
    private $bingCampaign; // var for store model BingCampaign
    private $bingAdgroup; // variable for store model adgroups 
    Private $bingKeyword; // variable for store keyword model 
    private $bingAds; // variable for store bing ads model 

    /**
     * Date :- 1-may-17 
     * Function disc :- Function for initialize  
     * @RudrainnovativePvtLtd 
     */

    public function initialize() {
        ob_start();
        ini_set('default_socket_timeout', 180);
        $this->bingUser = $this->loadModel("BingUser"); // load model 
        $this->bingSubuser = $this->loadModel("BingSubuser"); // load model 
        $this->bingCampaign = $this->loadModel('BingCampaign'); //$bingCampaign
        $this->bingAdgroup = $this->loadModel("BingAdgroup"); // load model ('bing_adgroup_data')
        $this->bingKeyword = $this->loadModel('BingKeyword'); // load model BingKeyword
        $this->bingAds = $this->loadModel("BingAds"); //load bing ads model 

        AuthHelper::AuthenticateWithOAuth();
        $this->customerProxy = new ServiceClient(ServiceClientType::CustomerManagementVersion11, $GLOBALS['AuthorizationData'], AuthHelper::GetApiEnvironment());
        $this->campaignProxy = new ServiceClient(ServiceClientType::CampaignManagementVersion11, $GLOBALS['AuthorizationData'], AuthHelper::GetApiEnvironment());
    }

    /**
     * Date :- may-17 
     * Function disc :- Function for get Keywords 
     * @RudrainnovativePvtLtd 
     */
    public function index() {
        
        $return = [];
        $table = $this->loadModel('ApiLocations');
        $all = $table->find("all", array("condition" => array("status" => 1, "bing_token <>" => "")))->toArray();
        $return = [];
        if (!empty($all)) {
            foreach($all as $key => $val):
                $return['location'][$key]["location_id"] = $val->smart_location_id;
            endforeach;
            
            $return['redirectUrl'] = $this->redirectUri(); // Get redirect url from function 

            $this->set("locations", $return); // send data into another page view 
        }

        if (!empty($_SESSION['AuthorizationData'])) {
            unset($_SESSION['AuthorizationData']);
        }
    }

    /* Function for set redirect uri for bing ads */

    private function redirectUri() {
        $link = 'https://login.live.com/oauth20_authorize.srf?client_id=' . self::$ClientId . '&scope=bingads.manage&response_type=code&redirect_uri=' . self::$url . '&grant_type=authorization_code&state=45415';

        return $link;
    }

    /* Function for geting oauthcallback after account authentication */

    public function oauth2Callback() {
        try {

            if (!isset($_SESSION['AuthorizationData']) || !isset($_SESSION['AuthorizationData']->Authentication)) {
                $authentication = (new OAuthWebAuthCodeGrant())
                        ->withClientId(self::$ClientId)
                        ->withClientSecret(self::$ClientSecret)
                        ->withRedirectUri('https://' . $_SERVER['HTTP_HOST'] . $this->redirectUri())
                        ->withState(rand(0, 999999999));


                $_SESSION['AuthorizationData'] = (new AuthorizationData())
                        ->withAuthentication($authentication)
                        ->withDeveloperToken(self::$DeveloperToken);

                $_SESSION['state'] = $_SESSION['AuthorizationData']->Authentication->State;


                header('Location: ' . $_SESSION['AuthorizationData']->Authentication->GetAuthorizationEndpoint());
            }

            if ($_GET['code'] != null) {

                $_SESSION['AuthorizationData']->Authentication->RequestOAuthTokensByResponseUri($_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);

                $this->callBingAdsServices(); //callint callBingAdsServices 
            }
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
        }
    }

    /**
     * Date :- 31-may-17 
     * Function disc :- Function for calling bing ads services
     * @RudrainnovativePvtLtd 
     */
    public function callBingAdsServices() {
        if (!isset($_SESSION['AuthorizationData']) ||
                !isset($_SESSION['AuthorizationData']->Authentication) ||
                !isset($_SESSION['AuthorizationData']->Authentication->OAuthTokens)
        ) {
            $this->Flash->error(__('Authorization failled.'));
            return $this->redirect(['action' => "index"]);
        } else {

            /* save authentications into database */
            if (isset($_SESSION['AuthorizationData']) && !empty($_SESSION['AuthorizationData'])) {
                $bingTokens = []; // array for store bing tokens

                /* Getting Tokens after oauth verification */
                $bingTokens['accesstoken'] = $_SESSION['AuthorizationData']->Authentication->OAuthTokens->AccessToken;
                $bingTokens['refreshtoken'] = $_SESSION['AuthorizationData']->Authentication->OAuthTokens->RefreshToken;
                $bingTokens['expiry'] = $_SESSION['AuthorizationData']->Authentication->OAuthTokens->AccessTokenExpiresInSeconds;
                $bingTokens['state'] = $_SESSION['AuthorizationData']->Authentication->State;

                $tokens = json_encode($bingTokens);

                $apiLocations = $this->loadModel("ApiLocations");
//                $insert = $apiLocations->newEntity();
//                $insert->smart_location_id = $location_id;
//                $insert->bing_token = $tokens;
                return $this->redirect(['action' => "index"]);
                if ($apiLocations->save($insert)) { // values added into database in api_location table 
//                    $this->Flash->success(__('Successfully connect with bing ads.'));
                    
                }
            }
        }
    }

    /**
     * Date :- 31-may-17 
     * Function disc :- Function for get user by user id 
     * @RudrainnovativePvtLtd 
     */
    public function GetUser($userId = null, $location_id=null) {
        try {
            if (empty($location_id)) {
                $location_id = 1;
            }
            $proxy = $this->customerProxy;
            $userArr = []; // empty array to store user information 
            $request = new GetUserRequest();
            $request->UserId = $userId;

            $bingUsers = $proxy->GetService()->GetUser($request)->User;

            if (!empty($bingUsers)) {
                $userArr['location_id'] = $location_id;
                $userArr["email"] = $bingUsers->ContactInfo->Email;
                $userArr["phone"] = $bingUsers->ContactInfo->Phone1;
                $userArr["customerId"] = $bingUsers->CustomerId;
                $userArr["bingId"] = $bingUsers->Id;
                $userArr["lastModifiedByUserId"] = $bingUsers->LastModifiedByUserId;
                $userArr["lastModifiedTime"] = $bingUsers->LastModifiedTime;
                $userArr["lcId"] = $bingUsers->Lcid;
                $userArr["name"] = $bingUsers->Name->FirstName . " " . $bingUsers->Name->LastName;
                $userArr["secretAnswer"] = $bingUsers->SecretAnswer;
                $userArr["secretQuestion"] = $bingUsers->SecretQuestion;
                $userArr["userStatus"] = $bingUsers->UserLifeCycleStatus;
                $userArr["userName"] = $bingUsers->UserName;
            }

            if (!empty($userArr)) {
                /* Check value is in database or not */
                $check = $this->checkDb($location_id, $userArr["bingId"], "bing_main_customer_data");
                if ($check == 1) {
                    $userArr['updated_at'] = date('Y-m-d h:i:s');

                    $query = $this->bingUser->query();
                    $query->update()
                            ->set($userArr)
                            ->where(['location_id' => $location_id, 'bingId' => $userArr["bingId"]])
                            ->execute();

                    $this->SearchAccountsByUserId($bingUsers->Id, $location_id); // calling function for save sub-users into database  
                } else {
                    $insert = $this->bingUser->newEntity();
                    $insert->location_id = $location_id;
                    $insert->email = $userArr["email"];
                    $insert->phone = $userArr["phone"];
                    $insert->customerId = $userArr["customerId"];
                    $insert->bingId = $userArr["bingId"];
                    $insert->lastModifiedByUserId = $userArr["lastModifiedByUserId"];
                    $insert->lastModifiedTime = $userArr["lastModifiedTime"];
                    $insert->lcId = $userArr["lcId"];
                    $insert->name = $userArr["name"];
                    $insert->secretAnswer = $userArr["secretAnswer"];
                    $insert->secretQuestion = $userArr["secretQuestion"];
                    $insert->userStatus = $userArr["userStatus"];
                    $insert->userName = $userArr["userName"];

                    if ($this->bingUser->save($insert)) {
                        $this->SearchAccountsByUserId($bingUsers->Id, $location_id); // calling function for save bing sub-users into database 
                    }
                }
            }
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 31-may-17 
     * Update :- 1-june-17
     * Function disc :- Function for get campaigns using account id 
     * @RudrainnovativePvtLtd 
     */
    public function getCampaigns($parentId, $location_id) {
        try {
//        $location_id = 1;     // only for testing purposes 
//        $parentId = 2562315; // only for testing purpose 
            $campaignData = []; // array to store campaign data a/c to client id 
            $campaignArr = []; // array to store all campign data for save into database 

            ini_set("soap.wsdl_cache_enabled", "0");
            ini_set("soap.wsdl_cache_ttl", "0");

            $dbUsers = $this->bingSubuser->find('all')->where(["location_id" => $location_id, "parent_bingid" => $parentId])->toArray();

            if (!empty($dbUsers)) {
                foreach ($dbUsers as $val):
                    $GLOBALS['AuthorizationData']->AccountId = $val->account_id; // set account id 
                    $GLOBALS['AuthorizationData']->CustomerId = $val->parent_customer_id; // set main customer client id 
                    $proxy = new ServiceClient(ServiceClientType::CampaignManagementVersion11, $GLOBALS['AuthorizationData'], AuthHelper::GetApiEnvironment());

                    $request = new GetCampaignsByAccountIdRequest();
                    $request->AccountId = $val->account_id;
                    $request->CampaignType = CampaignType::SearchAndContent;

                    $campaignData[] = $proxy->GetService()->GetCampaignsByAccountId($request)->Campaigns;
                endforeach;

                $count = count($campaignData);
                $a = 0;

                for ($i = 0; $i < $count; $i++) {
                    if (!empty((array) $campaignData[$i])) {
                        foreach ($campaignData[$i]->Campaign as $key => $val):
                            $campaignArr[$a][$key]["parentid"] = $GLOBALS['AuthorizationData']->AccountId;
                            $campaignArr[$a][$key]["budget_type"] = $val->BudgetType;
                            $campaignArr[$a][$key]["daily_budget"] = $val->DailyBudget;
                            $campaignArr[$a][$key]["description"] = $val->Description;
                            $campaignArr[$a][$key]["id"] = $val->Id;
                            $campaignArr[$a][$key]["name"] = $val->Name;
                            $campaignArr[$a][$key]["native_bid_adjustment"] = $val->NativeBidAdjustment;
                            $campaignArr[$a][$key]["status"] = $val->Status;
                            $campaignArr[$a][$key]["timezone"] = $val->TimeZone;
                            $campaignArr[$a][$key]["campaign_type"] = $val->CampaignType;
                            $a++;
                        endforeach;
                    }
                }
            }

            if (!empty($campaignArr)) {
                foreach ($campaignArr as $val):
                    foreach ($val as $data):

                        $check = $this->checkDb($location_id, $data['id'], "bing_campaign_data");
                        if ($check == 1) {
                            $update = []; // wmpty array for update table 
                            $update["location_id"] = $location_id;
                            $update["parent_id"] = $data['parentid'];
                            $update["budget_type"] = $data['budget_type'];
                            $update["daily_budget"] = $data['daily_budget'];
                            $update["description"] = $data['description'];
                            $update["campaign_id"] = $data['id'];
                            $update["name"] = $data['name'];
                            $update["native_bid_adjustment"] = $data['native_bid_adjustment'];
                            $update["status"] = $data['status'];
                            $update["timezone"] = $data['timezone'];
                            $update["campaign_type"] = $data['campaign_type'];
                            $update["updated_at"] = date("Y-m-d h:i:s");

                            $query = $this->bingCampaign->query();
                            $query->update()
                                    ->set($update)
                                    ->where(['location_id' => $location_id, 'campaign_id' => $data['id']])
                                    ->execute();
                        } else {
                            $insert = $this->bingCampaign->newEntity();
                            $insert->location_id = $location_id;
                            $insert->parent_id = $data['parentid'];
                            $insert->budget_type = $data['budget_type'];
                            $insert->daily_budget = $data['daily_budget'];
                            $insert->description = $data['description'];
                            $insert->campaign_id = $data['id'];
                            $insert->name = $data['name'];
                            $insert->native_bid_adjustment = $data['native_bid_adjustment'];
                            $insert->status = $data['status'];
                            $insert->timezone = $data['timezone'];
                            $insert->campaign_type = $data['campaign_type'];

                            $this->bingCampaign->save($insert);
                        }

                    endforeach;
                endforeach;
            }

            die("all done");
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 31-may-17 
     * Function disc :-  Searches by UserId for accounts that the user can manage.
     * @RudrainnovativePvtLtd 
     */
    private function SearchAccountsByUserId($userId, $location_id, $parentId = null) {

        try {
            $accountData = []; // empty array to store bing account data information 
            $proxy = $this->customerProxy;
            $pageInfo = new Paging();
            $pageInfo->Index = 0;    // The first page
            $pageInfo->Size = 100;   // The first 100 accounts for this page of results    

            $predicate = new Predicate();
            $predicate->Field = "UserId";
            $predicate->Operator = PredicateOperator::Equals;
            $predicate->Value = $userId;

            $request = new SearchAccountsRequest();
            $request->Ordering = null;
            $request->PageInfo = $pageInfo;
            $request->Predicates = array($predicate);

            $bingAccounts = $proxy->GetService()->SearchAccounts($request)->Accounts;
            $model = $this->bingSubuser; // load bind sub user model 

            if ($parentId == null) {
                $userData = $this->bingUser->find('all')->where(['location_id' => $location_id])->toArray();
                if (!empty($userData)) {
                    $parentId = $userData[0]->bingId;
                }
            }

            if (!empty($bingAccounts)) {
                foreach ($bingAccounts->Account as $key => $val):

                    $accountData[$key]["location_id"] = $location_id;
                    $accountData[$key]["parent_bingid"] = $parentId;
                    $accountData[$key]["account_type"] = $val->AccountType;
                    $accountData[$key]["bill_to_customer_id"] = $val->BillToCustomerId;
                    $accountData[$key]["country_code"] = $val->CountryCode;
                    $accountData[$key]["currency_type"] = $val->CurrencyType;
                    $accountData[$key]["account_financial_status"] = $val->AccountFinancialStatus;
                    $accountData[$key]["account_id"] = $val->Id;
                    $accountData[$key]["language"] = $val->Language;
                    $accountData[$key]["name"] = $val->Name;
                    $accountData[$key]["number"] = $val->Number;
                    $accountData[$key]["parent_customer_id"] = $val->ParentCustomerId;
                    $accountData[$key]["primary_user_id"] = $val->PrimaryUserId;
                    $accountData[$key]["account_life_cycle_status"] = $val->AccountLifeCycleStatus;
                    $accountData[$key]["timezone"] = $val->TimeZone;

                endforeach;
            }

            /* Check if data is not empty then save it into database */
            if (!empty($accountData)) {
                foreach ($accountData as $val):

                    $check = $this->checkDb($location_id, $val["account_id"], "bing_sub_user_data");
                    if ($check == 1) {
                        $val['updated_at'] = date("Y-m-d h:i:s");
                        $query = $this->bingSubuser->query();
                        $query->update()
                                ->set($val)
                                ->where(['location_id' => $location_id, 'account_id' => $val['account_id']])
                                ->execute();
                    } else {
                        /* insert all new sub account data */
                        $insert = $model->newEntity();
                        $insert->location_id = $val['location_id'];
                        $insert->parent_bingid = $val['parent_bingid'];
                        $insert->account_type = $val['account_type'];
                        $insert->bill_to_customer_id = $val['bill_to_customer_id'];
                        $insert->country_code = $val['country_code'];
                        $insert->currency_type = $val['currency_type'];
                        $insert->account_financial_status = $val['account_financial_status'];
                        $insert->account_id = $val['account_id'];
                        $insert->language = $val['language'];
                        $insert->name = $val['name'];
                        $insert->number = $val['number'];
                        $insert->parent_customer_id = $val['parent_customer_id'];
                        $insert->primary_user_id = $val['primary_user_id'];
                        $insert->account_life_cycle_status = $val['account_life_cycle_status'];
                        $insert->timezone = $val['timezone'];

                        $model->save($insert);
                    }

                endforeach;
            }

            die("Done All"); // only for show task completion 
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 31-may-17 
     * Updated :- 2-june-17
     * Function disc :- Function for get Adgroups a/c to campaign id  
     * @RudrainnovativePvtLtd 
     */
    private function fetchAdgroups($campaignId) {

        $parentSubuserId = ""; // variable for store sub customer id 
        $parentClientId = ""; // variable for store main client customer id 

        try {
            if (!empty($campaignId)) {
                $campaignData = $this->bingCampaign->find('all')->where(['campaign_id' => $campaignId])->toArray();
                $parentId = $campaignData[0]->parent_id;

                $parentData = $this->bingSubuser->find('all')->where(['account_id' => $parentId])->toArray();

                $parentSubuserId = $parentData[0]->account_id; // sub user customer id 
                $parentClientId = $parentData[0]->parent_customer_id; // main client customer id 

                $GLOBALS['AuthorizationData']->AccountId = $parentSubuserId; // set account id 
                $GLOBALS['AuthorizationData']->CustomerId = $parentClientId; // set main customer client id 

                $proxy = new ServiceClient(ServiceClientType::CampaignManagementVersion11, $GLOBALS['AuthorizationData'], AuthHelper::GetApiEnvironment()); //  set session data into variable 

                $request = new GetAdGroupsByCampaignIdRequest();
                $request->CampaignId = $campaignId;

                $adGroupData = $proxy->GetService()->GetAdGroupsByCampaignId($request)->AdGroups;
            }

            return $adGroupData; //return all addgroups related to campaign id 
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 31-may-17 
     * Function disc :- Function for get keywords a/c to ad-group id  
     * @RudrainnovativePvtLtd 
     */
    private function fetchKeywords($adGroupId) {
        try {
            if (!empty($adGroupId)) {

                $connection = ConnectionManager::get('default');
                $results = $connection->execute("SELECT bing_campaign_data.parent_id FROM bing_adgroup_data LEFT JOIN bing_campaign_data ON bing_adgroup_data.parent_campaign_id = bing_campaign_data.campaign_id
WHERE bing_adgroup_data.adgroup_id = '" . $adGroupId . "'")->fetchAll();

                $parentId = !empty($results[0][0]) ? $results[0][0] : ""; // parent id 
                $parentData = $this->bingSubuser->find('all')->where(['account_id' => $parentId])->toArray();
                $subClientId = $parentData[0]->account_id;
                $parentClientId = $parentData[0]->parent_customer_id;

                $GLOBALS['AuthorizationData']->AccountId = $subClientId; // set account id 
                $GLOBALS['AuthorizationData']->CustomerId = $parentClientId; // set main customer client id 

                $proxy = new ServiceClient(ServiceClientType::CampaignManagementVersion11, $GLOBALS['AuthorizationData'], AuthHelper::GetApiEnvironment()); //  set session data into variable 
                $request = new GetKeywordsByAdGroupIdRequest();
                $request->AdGroupId = $adGroupId;

                $kewordData = $proxy->GetService()->GetKeywordsByAdGroupId($request)->Keywords;

                if (!empty($kewordData)) {
                    return $kewordData;
                } // return all keyword data a/c to adgroup id
            }
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 31-may-17 
     * Updated :- 05-june-17
     * Function disc :- Function for get add's according to ad-group id 
     * @RudrainnovativePvtLtd 
     */
    public function fetchAdds($adGroupId) {

        try {
            if (!empty($adGroupId)) {
                $connection = ConnectionManager::get('default');
                $results = $connection->execute("SELECT bing_campaign_data.parent_id FROM bing_adgroup_data LEFT JOIN bing_campaign_data ON bing_adgroup_data.parent_campaign_id = bing_campaign_data.campaign_id
WHERE bing_adgroup_data.adgroup_id = '" . $adGroupId . "'")->fetchAll();

                $parentId = !empty($results[0][0]) ? $results[0][0] : ""; // parent id 
                $parentData = $this->bingSubuser->find('all')->where(['account_id' => $parentId])->toArray();
                $subClientId = $parentData[0]->account_id;
                $parentClientId = $parentData[0]->parent_customer_id;

                $GLOBALS['AuthorizationData']->AccountId = $subClientId; // set account id 
                $GLOBALS['AuthorizationData']->CustomerId = $parentClientId; // set main customer client id 

                $proxy = new ServiceClient(ServiceClientType::CampaignManagementVersion11, $GLOBALS['AuthorizationData'], AuthHelper::GetApiEnvironment()); //  set session data into variable 

                $adType = ["Text", "Image", "Product", "AppInstall", "ExpandedText", "DynamicSearch"]; // ads type array 
                $request = new GetAdsByAdGroupIdRequest();
                $request->AdGroupId = $adGroupId;
                $request->AdTypes = $adType;

                $adds = $proxy->GetService()->GetAdsByAdGroupId($request)->Ads;

                return $adds;
            }
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 05-june-17 
     * Function disc :-  Function for generate Campaign performance report a/c to account id 
     * @RudrainnovativePvtLtd 
     */
    public function GetCampaignPerformanceReportRequest($accountId) {

        try {
            $CampaignPerformanceReportColumn = [];
            $CampaignPerformanceReportColumn[] = 'CampaignId';
            $CampaignPerformanceReportColumn[] = 'CampaignName';
            $CampaignPerformanceReportColumn[] = 'AccountId';
            $CampaignPerformanceReportColumn[] = 'TimePeriod';
            $CampaignPerformanceReportColumn[] = 'Clicks';
            $CampaignPerformanceReportColumn[] = 'Status';
            $CampaignPerformanceReportColumn[] = 'Impressions';
            $CampaignPerformanceReportColumn[] = 'Ctr';
            $CampaignPerformanceReportColumn[] = 'AverageCpc';
            $CampaignPerformanceReportColumn[] = 'Spend';
            $CampaignPerformanceReportColumn[] = 'AveragePosition';
            $CampaignPerformanceReportColumn[] = 'Conversions';
            $CampaignPerformanceReportColumn[] = 'CostPerAssist';
            $CampaignPerformanceReportColumn[] = 'QualityScore';


            $this->reportProxy = new ServiceClient(ServiceClientType::ReportingVersion11, $GLOBALS['AuthorizationData'], ApiEnvironment::Production);


            $report = new CampaignPerformanceReportRequest();
            $report->Format = ReportFormat::Csv;
            $report->ReportName = 'Daily Campaign Performance Report';
            $report->ReturnOnlyCompleteData = false;
            $report->Aggregation = ReportAggregation::Daily;

            $report->Scope = new CampaignReportScope();
            $report->Scope->AccountIds = array();
            $report->Scope->AccountIds[] = $accountId;
            $report->Scope->Campaigns = null;

            $report->Time = new ReportTime();
            $report->Time->PredefinedTime = ReportTimePeriod::Yesterday;

            $report->Columns = $CampaignPerformanceReportColumn;

            $encodedReport = new SoapVar($report, SOAP_ENC_OBJECT, 'CampaignPerformanceReportRequest', $this->reportProxy->GetNamespace());

            $reportRequestId = $this->SubmitGenerateReport($encodedReport);

            /* download performance report bing ads api */

            $waitTime = 30 * 1;
            $reportRequestStatus = null;

            $DownloadPath = __DIR__ . "/../../report/performanceReport.zip";

            for ($i = 0; $i < 10; $i++) {
                sleep($waitTime);
                $reportRequestStatus = $this->PollGenerateReport($reportRequestId);

                if ($reportRequestStatus->Status == ReportRequestStatusType::Success ||
                        $reportRequestStatus->Status == ReportRequestStatusType::Error) {
                    break;
                }
            }

            /* --------- For Check Report status ($reportRequestStatus) -------- */

            if ($reportRequestStatus != null) {
                if ($reportRequestStatus->Status == ReportRequestStatusType::Success) {
                    $reportDownloadUrl = $reportRequestStatus->ReportDownloadUrl;

                    $this->DownloadFile($reportDownloadUrl, $DownloadPath);
                }
            }

            $this->extractParseZip(); //  Function call for unzip file and save records into database 
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 05-june-17 
     * Function disc :-  Function for generate Campaign historical performance report a/c to account id 
     * @RudrainnovativePvtLtd 
     */
    function GetCampaignPerformanceHistoricalReportRequest($accountId) {

        try {
            $CampaignPerformanceReportColumn = [];
            $CampaignPerformanceReportColumn[] = 'CampaignId';
            $CampaignPerformanceReportColumn[] = 'CampaignName';
            $CampaignPerformanceReportColumn[] = 'AccountId';
            $CampaignPerformanceReportColumn[] = 'TimePeriod';
            $CampaignPerformanceReportColumn[] = 'Clicks';
            $CampaignPerformanceReportColumn[] = 'Status';
            $CampaignPerformanceReportColumn[] = 'Impressions';
            $CampaignPerformanceReportColumn[] = 'Ctr';
            $CampaignPerformanceReportColumn[] = 'AverageCpc';
            $CampaignPerformanceReportColumn[] = 'Spend';
            $CampaignPerformanceReportColumn[] = 'AveragePosition';
            $CampaignPerformanceReportColumn[] = 'Conversions';
            $CampaignPerformanceReportColumn[] = 'CostPerAssist';
            $CampaignPerformanceReportColumn[] = 'QualityScore';


            $this->reportProxy = new ServiceClient(ServiceClientType::ReportingVersion11, $GLOBALS['AuthorizationData'], ApiEnvironment::Production);


            $report = new CampaignPerformanceReportRequest();
            $report->Format = ReportFormat::Csv;
            $report->ReportName = 'Historical Campaign Performance Report';
            $report->ReturnOnlyCompleteData = false;
            $report->Aggregation = ReportAggregation::Monthly;

            $report->Scope = new CampaignReportScope();
            $report->Scope->AccountIds = array();
            $report->Scope->AccountIds[] = $accountId;
            $report->Scope->Campaigns = null;

            $report->Time = new ReportTime();
            $report->Time->PredefinedTime = ReportTimePeriod::LastMonth;

            $report->Columns = $CampaignPerformanceReportColumn;

            $encodedReport = new SoapVar($report, SOAP_ENC_OBJECT, 'CampaignPerformanceReportRequest', $this->reportProxy->GetNamespace());

            $reportRequestId = $this->SubmitGenerateReport($encodedReport);

            /* download performance report bing ads api */

            $waitTime = 30 * 1;
            $reportRequestStatus = null;

            $DownloadPath = __DIR__ . "/../../report/performanceReport.zip";

            for ($i = 0; $i < 10; $i++) {
                sleep($waitTime);
                $reportRequestStatus = $this->PollGenerateReport($reportRequestId);

                if ($reportRequestStatus->Status == ReportRequestStatusType::Success ||
                        $reportRequestStatus->Status == ReportRequestStatusType::Error) {
                    break;
                }
            }

            /* --------- For Check Report status ($reportRequestStatus) -------- */

            if ($reportRequestStatus != null) {
                if ($reportRequestStatus->Status == ReportRequestStatusType::Success) {
                    $reportDownloadUrl = $reportRequestStatus->ReportDownloadUrl;

                    $this->DownloadFile($reportDownloadUrl, $DownloadPath);
                }
            }

            $this->extractParseZip(); //  Function call for unzip file and save records into database 
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 05-june-17 
     * Function disc :-  Function for generate AdGroup performance report a/c to account id 
     * @RudrainnovativePvtLtd 
     */
    public function GetAdgroupPerformanceReportRequest($accountId) {

        $clientId = $this->getCustomerClientId($accountId); // get client id from database 

        try {
            $AdgroupPerformanceReportColumn = [];
            $AdgroupPerformanceReportColumn[] = 'AdGroupId';
            $AdgroupPerformanceReportColumn[] = 'Status';
            $AdgroupPerformanceReportColumn[] = 'Clicks';
            $AdgroupPerformanceReportColumn[] = 'Ctr';
            $AdgroupPerformanceReportColumn[] = 'AverageCpc';
            $AdgroupPerformanceReportColumn[] = 'Spend';
            $AdgroupPerformanceReportColumn[] = 'Conversions';
            $AdgroupPerformanceReportColumn[] = 'AveragePosition';
            $AdgroupPerformanceReportColumn[] = 'Impressions';
            $AdgroupPerformanceReportColumn[] = 'ConversionRate';

            $GLOBALS['AuthorizationData']->AccountId = $accountId; // set account id 
            $GLOBALS['AuthorizationData']->CustomerId = $clientId; // set main customer client id 

            $this->reportProxy = new ServiceClient(ServiceClientType::ReportingVersion11, $GLOBALS['AuthorizationData'], ApiEnvironment::Production);

            $report = new AdGroupPerformanceReportRequest();
            $report->Format = ReportFormat::Csv;
            $report->ReportName = 'Daily AdGroup Performance Report';
            $report->ReturnOnlyCompleteData = false;
            $report->Aggregation = ReportAggregation::Daily;

            $report->Scope = new AccountThroughAdGroupReportScope();
            $report->Scope->AccountIds = array();
            $report->Scope->AccountIds[] = $accountId;
            $report->Scope->AdGroups = null;
            $report->Scope->Campaigns = null;

            $report->Time = new ReportTime();
            $report->Time->PredefinedTime = ReportTimePeriod::Yesterday;

            $report->Columns = $AdgroupPerformanceReportColumn;

            $encodedReport = new SoapVar($report, SOAP_ENC_OBJECT, 'AdGroupPerformanceReportRequest', $this->reportProxy->GetNamespace());

            $reportRequestId = $this->SubmitGenerateReport($encodedReport);

            /* download performance report bing ads api */

            $waitTime = 30 * 1;
            $reportRequestStatus = null;

            $DownloadPath = __DIR__ . "/../../report/performanceReport.zip";

            for ($i = 0; $i < 10; $i++) {
                sleep($waitTime);
                $reportRequestStatus = $this->PollGenerateReport($reportRequestId);

                if ($reportRequestStatus->Status == ReportRequestStatusType::Success ||
                        $reportRequestStatus->Status == ReportRequestStatusType::Error) {
                    break;
                }
            }

            /* --------- For Check Report status ($reportRequestStatus) -------- */

            if ($reportRequestStatus != null) {
                if ($reportRequestStatus->Status == ReportRequestStatusType::Success) {
                    $reportDownloadUrl = $reportRequestStatus->ReportDownloadUrl;

                    $this->DownloadFile($reportDownloadUrl, $DownloadPath);
                }
            }

            $this->extractParseZip(); // calling function for unzip file and save data into database
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 06-june-17 
     * Function disc :-  Function for generate AdGroup performance report a/c to account id 
     * @RudrainnovativePvtLtd 
     */
    public function GetAdgroupHistoricalPerformanceReportRequest($accountId) {

        $clientId = $this->getCustomerClientId($accountId); // get client id from database 

        try {
            $AdgroupPerformanceReportColumn = [];
            $AdgroupPerformanceReportColumn[] = 'AdGroupId';
            $AdgroupPerformanceReportColumn[] = 'Status';
            $AdgroupPerformanceReportColumn[] = 'Clicks';
            $AdgroupPerformanceReportColumn[] = 'Ctr';
            $AdgroupPerformanceReportColumn[] = 'AverageCpc';
            $AdgroupPerformanceReportColumn[] = 'Spend';
            $AdgroupPerformanceReportColumn[] = 'Conversions';
            $AdgroupPerformanceReportColumn[] = 'AveragePosition';
            $AdgroupPerformanceReportColumn[] = 'Impressions';
            $AdgroupPerformanceReportColumn[] = 'ConversionRate';

            $GLOBALS['AuthorizationData']->AccountId = $accountId; // set account id 
            $GLOBALS['AuthorizationData']->CustomerId = $clientId; // set main customer client id 

            $this->reportProxy = new ServiceClient(ServiceClientType::ReportingVersion11, $GLOBALS['AuthorizationData'], ApiEnvironment::Production);

            $report = new AdGroupPerformanceReportRequest();
            $report->Format = ReportFormat::Csv;
            $report->ReportName = 'Historical AdGroup Performance Report';
            $report->ReturnOnlyCompleteData = false;
            $report->Aggregation = ReportAggregation::Monthly;

            $report->Scope = new AccountThroughAdGroupReportScope();
            $report->Scope->AccountIds = array();
            $report->Scope->AccountIds[] = $accountId;
            $report->Scope->AdGroups = null;
            $report->Scope->Campaigns = null;

            $report->Time = new ReportTime();
            $report->Time->PredefinedTime = ReportTimePeriod::LastMonth;

            $report->Columns = $AdgroupPerformanceReportColumn;

            $encodedReport = new SoapVar($report, SOAP_ENC_OBJECT, 'AdGroupPerformanceReportRequest', $this->reportProxy->GetNamespace());

            $reportRequestId = $this->SubmitGenerateReport($encodedReport);

            /* download performance report bing ads api */

            $waitTime = 30 * 1;
            $reportRequestStatus = null;

            $DownloadPath = __DIR__ . "/../../report/performanceReport.zip";

            for ($i = 0; $i < 10; $i++) {
                sleep($waitTime);
                $reportRequestStatus = $this->PollGenerateReport($reportRequestId);

                if ($reportRequestStatus->Status == ReportRequestStatusType::Success ||
                        $reportRequestStatus->Status == ReportRequestStatusType::Error) {
                    break;
                }
            }

            /* --------- For Check Report status ($reportRequestStatus) -------- */

            if ($reportRequestStatus != null) {
                if ($reportRequestStatus->Status == ReportRequestStatusType::Success) {
                    $reportDownloadUrl = $reportRequestStatus->ReportDownloadUrl;

                    $this->DownloadFile($reportDownloadUrl, $DownloadPath);
                }
            }

            $this->extractParseZip(); // calling function for unzip file and save data into database 
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 05-june-17 
     * Function disc :-  Function for generate Keyword Daily performance report a/c to account id 
     * @RudrainnovativePvtLtd 
     */
    public function GetKeywordPerformanceReportRequest($accountId) {

        $clientId = $this->getCustomerClientId($accountId); // get client id from database 

        try {
            $KeywordPerformanceReportColumn = [];
            $KeywordPerformanceReportColumn[] = 'AdGroupId';
            $KeywordPerformanceReportColumn[] = 'KeywordId';
            $KeywordPerformanceReportColumn[] = 'Keyword';
            $KeywordPerformanceReportColumn[] = 'TimePeriod';
            $KeywordPerformanceReportColumn[] = 'Clicks';
            $KeywordPerformanceReportColumn[] = 'Impressions';
            $KeywordPerformanceReportColumn[] = 'Ctr';
            $KeywordPerformanceReportColumn[] = 'AverageCpc';
            $KeywordPerformanceReportColumn[] = 'Spend';
            $KeywordPerformanceReportColumn[] = 'AveragePosition';

            $GLOBALS['AuthorizationData']->AccountId = $accountId; // set account id 
            $GLOBALS['AuthorizationData']->CustomerId = $clientId; // set main customer client id 
            $this->reportProxy = new ServiceClient(ServiceClientType::ReportingVersion11, $GLOBALS['AuthorizationData'], ApiEnvironment::Production);

            $report = new KeywordPerformanceReportRequest();
            $report->Format = ReportFormat::Csv;
            $report->ReportName = 'Daily Keyword Performance Report';
            $report->ReturnOnlyCompleteData = false;
            $report->Aggregation = ReportAggregation::Daily;

            $report->Scope = new AccountThroughAdGroupReportScope();
            $report->Scope->AccountIds = array();
            $report->Scope->AccountIds[] = $accountId;
            $report->Scope->Campaigns = null;

            $report->Time = new ReportTime();
            $report->Time->PredefinedTime = ReportTimePeriod::Yesterday;

            $report->Columns = $KeywordPerformanceReportColumn;

            $encodedReport = new SoapVar($report, SOAP_ENC_OBJECT, 'KeywordPerformanceReportRequest', $this->reportProxy->GetNamespace());

            $reportRequestId = $this->SubmitGenerateReport($encodedReport);

            /* download performance report bing ads api */

            $waitTime = 30 * 1;
            $reportRequestStatus = null;

            $DownloadPath = __DIR__ . "/../../report/performanceReport.zip";

            for ($i = 0; $i < 10; $i++) {
                sleep($waitTime);
                $reportRequestStatus = $this->PollGenerateReport($reportRequestId);

                if ($reportRequestStatus->Status == ReportRequestStatusType::Success ||
                        $reportRequestStatus->Status == ReportRequestStatusType::Error) {
                    break;
                }
            }

            /* --------- For Check Report status ($reportRequestStatus) -------- */

            if ($reportRequestStatus != null) {
                if ($reportRequestStatus->Status == ReportRequestStatusType::Success) {
                    $reportDownloadUrl = $reportRequestStatus->ReportDownloadUrl;

                    $this->DownloadFile($reportDownloadUrl, $DownloadPath);
                }
            }

            $this->extractParseZip(); // calling function for unzip csv and save it into database 
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 05-june-17 
     * Function disc :-  Function for generate keyword historical performance report a/c to account id 
     * @RudrainnovativePvtLtd 
     */
    public function GetKeywordHistoricalPerformanceReportRequest($accountId) {

        $clientId = $this->getCustomerClientId($accountId);

        try {
            $KeywordPerformanceReportColumn = [];
            $KeywordPerformanceReportColumn[] = 'AdGroupId';
            $KeywordPerformanceReportColumn[] = 'KeywordId';
            $KeywordPerformanceReportColumn[] = 'Keyword';
            $KeywordPerformanceReportColumn[] = 'TimePeriod';
            $KeywordPerformanceReportColumn[] = 'Clicks';
            $KeywordPerformanceReportColumn[] = 'Impressions';
            $KeywordPerformanceReportColumn[] = 'Ctr';
            $KeywordPerformanceReportColumn[] = 'AverageCpc';
            $KeywordPerformanceReportColumn[] = 'Spend';
            $KeywordPerformanceReportColumn[] = 'AveragePosition';

            $GLOBALS['AuthorizationData']->AccountId = $accountId; // set account id 
            $GLOBALS['AuthorizationData']->CustomerId = $clientId; // set main customer client id 
            $this->reportProxy = new ServiceClient(ServiceClientType::ReportingVersion11, $GLOBALS['AuthorizationData'], ApiEnvironment::Production);

            $report = new KeywordPerformanceReportRequest();
            $report->Format = ReportFormat::Csv;
            $report->ReportName = 'Historical Keyword Performance Report';
            $report->ReturnOnlyCompleteData = false;
            $report->Aggregation = ReportAggregation::Monthly;

            $report->Scope = new AccountThroughAdGroupReportScope();
            $report->Scope->AccountIds = array();
            $report->Scope->AccountIds[] = $accountId;
            $report->Scope->Campaigns = null;

            $report->Time = new ReportTime();
            $report->Time->PredefinedTime = ReportTimePeriod::LastMonth;

            $report->Columns = $KeywordPerformanceReportColumn;

            $encodedReport = new SoapVar($report, SOAP_ENC_OBJECT, 'KeywordPerformanceReportRequest', $this->reportProxy->GetNamespace());

            $reportRequestId = $this->SubmitGenerateReport($encodedReport);

            /* download performance report bing ads api */

            $waitTime = 30 * 1;
            $reportRequestStatus = null;

            $DownloadPath = __DIR__ . "/../../report/performanceReport.zip";

            for ($i = 0; $i < 10; $i++) {
                sleep($waitTime);
                $reportRequestStatus = $this->PollGenerateReport($reportRequestId);

                if ($reportRequestStatus->Status == ReportRequestStatusType::Success ||
                        $reportRequestStatus->Status == ReportRequestStatusType::Error) {
                    break;
                }
            }

            /* --------- For Check Report status ($reportRequestStatus) -------- */

            if ($reportRequestStatus != null) {
                if ($reportRequestStatus->Status == ReportRequestStatusType::Success) {
                    $reportDownloadUrl = $reportRequestStatus->ReportDownloadUrl;

                    $this->DownloadFile($reportDownloadUrl, $DownloadPath);
                }
            }

            $this->extractParseZip(); // calling function for unzip csv and save it into database 
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 06-june-17 
     * Function disc :-  Function for generate Ads Daily performance report a/c to account id 
     * @RudrainnovativePvtLtd 
     */
    public function GetAdsPerformanceReportRequest($accountId) {

        $clientId = $this->getCustomerClientId($accountId); //  get customer client id from database 

        try {
            $AddPerformanceReportColumn = [];
            $AddPerformanceReportColumn[] = 'AdGroupId';
            $AddPerformanceReportColumn[] = 'AdId';
            $AddPerformanceReportColumn[] = 'Clicks';
            $AddPerformanceReportColumn[] = 'Ctr';
            $AddPerformanceReportColumn[] = 'AverageCpc';
            $AddPerformanceReportColumn[] = 'Spend';
            $AddPerformanceReportColumn[] = 'AveragePosition';
            $AddPerformanceReportColumn[] = 'CampaignId';
            $AddPerformanceReportColumn[] = 'Impressions';

            $GLOBALS['AuthorizationData']->AccountId = $accountId; // set account id 
            $GLOBALS['AuthorizationData']->CustomerId = $clientId; // set main customer client id 
            $this->reportProxy = new ServiceClient(ServiceClientType::ReportingVersion11, $GLOBALS['AuthorizationData'], ApiEnvironment::Production);
            $report = new AdPerformanceReportRequest();
            $report->Format = ReportFormat::Csv;
            $report->ReportName = 'Daily Ads Performance Report';
            $report->ReturnOnlyCompleteData = false;
            $report->Aggregation = ReportAggregation::Daily;

            $report->Scope = new AccountThroughAdGroupReportScope();
            $report->Scope->AccountIds = array();
            $report->Scope->AccountIds[] = $accountId;
            $report->Scope->Campaigns = null;

            $report->Time = new ReportTime();
            $report->Time->PredefinedTime = ReportTimePeriod::Yesterday;

            $report->Columns = $AddPerformanceReportColumn;

            $encodedReport = new SoapVar($report, SOAP_ENC_OBJECT, 'AdPerformanceReportRequest', $this->reportProxy->GetNamespace());

            $reportRequestId = $this->SubmitGenerateReport($encodedReport);

            /* download performance report bing ads api */

            $waitTime = 30 * 1;
            $reportRequestStatus = null;

            $DownloadPath = __DIR__ . "/../../report/performanceReport.zip";

            for ($i = 0; $i < 10; $i++) {
                sleep($waitTime);
                $reportRequestStatus = $this->PollGenerateReport($reportRequestId);

                if ($reportRequestStatus->Status == ReportRequestStatusType::Success ||
                        $reportRequestStatus->Status == ReportRequestStatusType::Error) {
                    break;
                }
            }

            /* --------- For Check Report status ($reportRequestStatus) -------- */

            if ($reportRequestStatus != null) {
                if ($reportRequestStatus->Status == ReportRequestStatusType::Success) {
                    $reportDownloadUrl = $reportRequestStatus->ReportDownloadUrl;

                    $this->DownloadFile($reportDownloadUrl, $DownloadPath);
                }
            }
            $this->extractParseZip(); // calling function for unzip csv and save it into database 
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 06-june-17 
     * Function disc :-  Function for generate Ads Daily performance report a/c to account id 
     * @RudrainnovativePvtLtd 
     */
    function GetAdsHistoricalPerformanceReportRequest($accountId) {

        $clientId = $this->getCustomerClientId($accountId); //  get customer client id from database 

        try {
            $AddPerformanceReportColumn = [];
            $AddPerformanceReportColumn[] = 'AdGroupId';
            $AddPerformanceReportColumn[] = 'AdId';
            $AddPerformanceReportColumn[] = 'Clicks';
            $AddPerformanceReportColumn[] = 'Ctr';
            $AddPerformanceReportColumn[] = 'AverageCpc';
            $AddPerformanceReportColumn[] = 'Spend';
            $AddPerformanceReportColumn[] = 'AveragePosition';
            $AddPerformanceReportColumn[] = 'CampaignId';
            $AddPerformanceReportColumn[] = 'Impressions';

            $GLOBALS['AuthorizationData']->AccountId = $accountId; // set account id 
            $GLOBALS['AuthorizationData']->CustomerId = $clientId; // set main customer client id 
            $this->reportProxy = new ServiceClient(ServiceClientType::ReportingVersion11, $GLOBALS['AuthorizationData'], ApiEnvironment::Production);

            $report = new AdPerformanceReportRequest();
            $report->Format = ReportFormat::Csv;
            $report->ReportName = 'Historical Ads Performance Report';
            $report->ReturnOnlyCompleteData = false;
            $report->Aggregation = ReportAggregation::Monthly;

            $report->Scope = new AccountThroughAdGroupReportScope();
            $report->Scope->AccountIds = array();
            $report->Scope->AccountIds[] = $accountId;
            $report->Scope->Campaigns = null;

            $report->Time = new ReportTime();
            $report->Time->PredefinedTime = ReportTimePeriod::LastMonth;

            $report->Columns = $AddPerformanceReportColumn;

            $encodedReport = new SoapVar($report, SOAP_ENC_OBJECT, 'AdPerformanceReportRequest', $this->reportProxy->GetNamespace());

            $reportRequestId = $this->SubmitGenerateReport($encodedReport);

            /* download performance report bing ads api */

            $waitTime = 30 * 1;
            $reportRequestStatus = null;

            $DownloadPath = __DIR__ . "/../../report/performanceReport.zip";

            for ($i = 0; $i < 10; $i++) {
                sleep($waitTime);
                $reportRequestStatus = $this->PollGenerateReport($reportRequestId);

                if ($reportRequestStatus->Status == ReportRequestStatusType::Success ||
                        $reportRequestStatus->Status == ReportRequestStatusType::Error) {
                    break;
                }
            }

            /* --------- For Check Report status ($reportRequestStatus) -------- */

            if ($reportRequestStatus != null) {
                if ($reportRequestStatus->Status == ReportRequestStatusType::Success) {
                    $reportDownloadUrl = $reportRequestStatus->ReportDownloadUrl;

                    $this->DownloadFile($reportDownloadUrl, $DownloadPath);
                }
            }

            $this->extractParseZip(); // calling function for unzip csv and save it into database 
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 31-may-17 
     * Function disc :- Request the report. Use the ID that the request returns to check for the completion of the report.
     * @RudrainnovativePvtLtd 
     */
    private function SubmitGenerateReport($report) {

        try {

            $request = new SubmitGenerateReportRequest();
            $request->ReportRequest = $report;

            $reportId = $this->reportProxy->GetService()->SubmitGenerateReport($request)->ReportRequestId;

            if (!empty($reportId)) {
                return $reportId; // return report id 
            }
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 31-may-17 
     * Function disc :- Check the status of the report request. The guidance of how often to poll for status is from every five to 15 minutes depending on the amount
     *  of data being requested. For smaller reports, you can poll every couple of minutes. You should stop polling and try again later if the request is taking longer than an hour.
     * @RudrainnovativePvtLtd 
     */
    private function PollGenerateReport($reportRequestId) {

        $request = new PollGenerateReportRequest();
        $request->ReportRequestId = $reportRequestId;

        return $this->reportProxy->GetService()->PollGenerateReport($request)->ReportRequestStatus;
    }

    /**
     * Date :- 31-may-17 
     * Function disc :- Using the URL that the PollGenerateReport operation returned, send an HTTP request to get the report and write it to the specified ZIP file.
     * @RudrainnovativePvtLtd 
     */
    private function DownloadFile($reportDownloadUrl, $downloadPath) {
        try {
            if (!$reader = fopen($reportDownloadUrl, 'rb')) {
                throw new Exception("Failed to open URL " . $reportDownloadUrl . ".");
            }

            if (!$writer = fopen($downloadPath, 'wb')) {
                fclose($reader);
                throw new Exception("Failed to create ZIP file " . $downloadPath . ".");
            }

            $bufferSize = 100 * 1024;

            while (!feof($reader)) {
                if (false === ($buffer = fread($reader, $bufferSize))) {
                    fclose($reader);
                    fclose($writer);
                    throw new Exception("Read operation from URL failed.");
                }

                if (fwrite($writer, $buffer) === false) {
                    fclose($reader);
                    fclose($writer);
                    $exception = new Exception("Write operation to ZIP file failed.");
                }
            }

            fclose($reader);
            fflush($writer);
            fclose($writer);
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 1-june-17
     * Function disc :- function for check values is in database or not 
     * @RudrainnovativePvtLtd 
     */
    private function checkDb($location_id, $Id, $table) {
        $userData = []; // blank array to store user data come from database 

        if ($table == "bing_main_customer_data") {
            $userData = $this->bingUser->find('all')->where(['location_id' => $location_id, 'bingId' => $Id])->all();
        } else if ($table == "bing_sub_user_data") {
            $userData = $this->bingSubuser->find('all')->where(["location_id" => $location_id, "account_id" => $Id])->all();
        } else if ($table == "bing_campaign_data") {
            $userData = $this->bingCampaign->find('all')->where(["location_id" => $location_id, "campaign_id" => $Id])->all();
        } else if ($table == "bing_adgroup_data") {
            $userData = $this->bingAdgroup->find('all')->where(['location_id' => $location_id, 'adgroup_id' => $Id])->all();
        } else if ($table == "bing_keyword_data") {
            $userData = $this->bingKeyword->find('all')->where(['location_id' => $location_id, 'keyword_id' => $Id])->all();
        } else if ($table == "bing_ads_data") {
            $userData = $this->bingAds->find('all')->where(['location_id' => $location_id, 'ads_id' => $Id])->all();
        }

        /* Return responce according to data check in databse */
        if (iterator_count($userData)) {
            return 1;
        } else {
            return 0;
        }
    }

    /**
     * Date :- 1-june-17
     * Function disc :- Function for display account information 
     * @RudrainnovativePvtLtd 
     */
    public function displayData() {
        $bingData = $userData = $this->bingUser->find('all')->toArray();
        $userdata = []; // blank array for store user data 
        if (!empty($bingData)) {
            $userdata['email'] = $bingData[0]->email;
            $userdata['phone'] = $bingData[0]->phone;
            $userdata['customerId'] = $bingData[0]->customerId;
            $userdata['bingId'] = $bingData[0]->bingId;
            $userdata['name'] = $bingData[0]->name;
            $userdata['userStatus'] = $bingData[0]->userStatus;
        }

        $this->set('bingdata', $userdata);
    }

    /**
     * Date :- 1-june-17
     * Function disc :- Function for display sub account information 
     * @RudrainnovativePvtLtd 
     */
    public function displaySubaccount() {
        $bingData = $userData = $this->bingSubuser->find('all')->toArray();
        $userdata = []; // blank array for store user data 
        if (!empty($bingData)) {
            $this->set('bingdata', $bingData);
        }
    }

    /**
     * Date :- 1-june-17
     * Update :- 09-june-17
     * Function disc :- Function for get campaing data a/c to user account 
     * @RudrainnovativePvtLtd 
     */
    public function displayCampaign($id) {
        $userdata = []; // blank array for store user data 
        $bingData = $userData = $this->bingCampaign->find('all')->where(['parent_id' => $id])->toArray();
        if (!empty($bingData)) {
            foreach ($bingData as $key => $val):
                $userdata[$key]['budget_type'] = $val->budget_type;
                $userdata[$key]['daily_budget'] = $val->daily_budget;
                $userdata[$key]['description'] = $val->description;
                $userdata[$key]['campaign_id'] = $val->campaign_id;
                $userdata[$key]['name'] = $val->name;
                $userdata[$key]['native_bid_adjustment'] = $val->native_bid_adjustment;
                $userdata[$key]['status'] = $val->status;
            endforeach;
        }

        if (!empty($bingData)) {
            $this->set('bingdata', $userdata);
        }
    }

    /**
     * Date :- 09-june-17
     * Function disc :- Function for Display Ad-Groups 
     * @RudrainnovativePvtLtd 
     */
    public function displayAdgroups($id) {
        $dataArray = []; // blank array for store data 
        $adgroups = $this->bingAdgroup->find('all')->where(['parent_campaign_id' => $id])->toArray();
        if (!empty($adgroups)) {
            foreach ($adgroups as $key => $val):

                $dataArray[$key]['adgroup_id'] = $val->adgroup_id;
                $dataArray[$key]['name'] = $val->name;
                $dataArray[$key]['pricingmodel'] = $val->pricingmodel;
                $dataArray[$key]['bid_amount'] = $val->searchbid_amount;
                $dataArray[$key]['status'] = $val->status;

            endforeach;
        }

        if (!empty($dataArray)) {
            $this->set("bingAdgroup", $dataArray); // set into variable to display into another page 
        }
    }

    /**
     * Date :- 09-june-17
     * Function disc :- Function for Display Campaign reporting  
     * @RudrainnovativePvtLtd 
     */
    public function displayCampaignReporting($id) {
        $dataArray = []; // blank array for store data 
        $model = $this->loadModel("BingCampaignReporting");
        $campReportData = $model->find('all')->where(['campaign_id' => $id])->toArray();
        if (!empty($campReportData)) {
            pr($campReportData);
            die('here');
        }
    }

    /**
     * Date :- 12-june-17
     * Function disc :- Function for display ads according to ad-group id   
     * @RudrainnovativePvtLtd 
     */
    public function displayAds($id) {
        $dataArray = []; // blank array for store data 
        $model = $this->loadModel("BingAds");
        $bingData = $model->find('all')->where(['addgroup_id' => $id])->toArray();
        if (!empty($bingData)) {
            foreach ($bingData as $key => $ads):

                $dataArray[$key]["ads_id"] = $ads->ads_id;
                $dataArray[$key]["status"] = $ads->status;
                $dataArray[$key]["type"] = $ads->type;
                $dataArray[$key]["destination_url"] = $ads->destination_url;
                $dataArray[$key]["display_url"] = $ads->display_url;
                $dataArray[$key]["text"] = $ads->text;
                $dataArray[$key]["title"] = $ads->title;

            endforeach;
        }

        $this->set("bingAds", $dataArray);
    }

    /**
     * Date :- 2-june-17
     * Function disc :- Function for pull all adgroups according to client's campaign 
     * @RudrainnovativePvtLtd 
     */
    public function pullAdgroups($location_id = null) {
//        $location_id = 1; //  only for testing purposes 
        $adgroupData = []; // array for store particular adgroup data to store into database 
        try {
            $userdata = $this->bingUser->find('all')->where(['location_id' => $location_id])->toArray();
            if (!empty($userdata)) {
                $client_id = $userdata[0]->bingId;
                $subData = $this->bingSubuser->find('all')->where(['parent_bingid' => $client_id])->toArray();

                if (!empty($subData)) {
                    foreach ($subData as $data):
                        $accountId = $data->account_id;
                        $campData = $this->bingCampaign->find('all')->where(['parent_id' => $accountId])->toArray();
                        if (!empty($campData)) {
                            foreach ($campData as $key => $value):
                                $campaignId = $value->campaign_id;
                                $adGroups = $this->fetchAdgroups($campaignId); // calling function to get adgroup data 

                                if (!empty($adGroups->AdGroup))
                                /* Insert adgroups into database */
                                    foreach ($adGroups->AdGroup as $key => $val):

                                        $adgroupData[$key]["campaignId"] = $campaignId;
                                        $adgroupData[$key]["AdDistribution"] = $val->AdDistribution;
                                        $adgroupData[$key]["AdRotation_EndDate"] = !empty($val->AdRotation->EndDate) ? $val->AdRotation->EndDate : '';
                                        $adgroupData[$key]["AdRotation_StartDate"] = !empty($val->AdRotation->StartDate) ? $val->AdRotation->StartDate : '';
                                        $adgroupData[$key]["AdRotation_Type"] = !empty($val->AdRotation->Type) ? $val->AdRotation->Type : '';
                                        $adgroupData[$key]["ContentMatchBid_Amount"] = !empty($val->ContentMatchBid->Amount) ? $val->ContentMatchBid->Amount : '';
                                        $adgroupData[$key]["Id"] = $val->Id;
                                        $adgroupData[$key]["Language"] = $val->Language;
                                        $adgroupData[$key]["Name"] = $val->Name;
                                        $adgroupData[$key]["PricingModel"] = $val->PricingModel;
                                        $adgroupData[$key]["SearchBid_Amount"] = $val->SearchBid->Amount;
                                        $adgroupData[$key]["StartDate"] = $val->StartDate->Year . "-" . $val->StartDate->Month . "-" . $val->StartDate->Day;
                                        $adgroupData[$key]["Status"] = $val->Status;

                                    endforeach;

                                /* database insertion code */
                                foreach ($adgroupData as $data):

                                    $check = $this->checkDb($location_id, $data["Id"], "bing_adgroup_data");
                                    if ($check == 1) {
                                        $update["location_id"] = $location_id;
                                        $update["parent_campaign_id"] = $data["campaignId"];
                                        $update["add_distribution"] = $data["AdDistribution"];
                                        $update["add_rotation_startdate"] = $data["AdRotation_StartDate"];
                                        $update["add_rotation_enddate"] = $data["AdRotation_EndDate"];
                                        $update["adrotation_type"] = $data["AdRotation_Type"];
                                        $update["contentmatchbid_amount"] = $data["ContentMatchBid_Amount"];
                                        $update["adgroup_id"] = $data["Id"];
                                        $update["language"] = $data["Language"];
                                        $update["name"] = $data["Name"];
                                        $update["pricingmodel"] = $data["PricingModel"];
                                        $update["searchbid_amount"] = $data["SearchBid_Amount"];
                                        $update["startdate"] = $data["StartDate"];
                                        $update["status"] = $data["Status"];
                                        $update["updated_at"] = date("Y-m-d h:i:s");

                                        $query = $this->bingAdgroup->query();
                                        $query->update()
                                                ->set($update)
                                                ->where(['location_id' => $location_id, 'adgroup_id' => $data["Id"]])
                                                ->execute();
                                    } else {
                                        $insert = $this->bingAdgroup->newEntity();
                                        $insert->location_id = $location_id;
                                        $insert->parent_campaign_id = $data["campaignId"];
                                        $insert->add_distribution = $data["AdDistribution"];
                                        $insert->add_rotation_startdate = $data["AdRotation_StartDate"];
                                        $insert->add_rotation_enddate = $data["AdRotation_EndDate"];
                                        $insert->adrotation_type = $data["AdRotation_Type"];
                                        $insert->contentmatchbid_amount = $data["ContentMatchBid_Amount"];
                                        $insert->adgroup_id = $data["Id"];
                                        $insert->language = $data["Language"];
                                        $insert->name = $data["Name"];
                                        $insert->pricingmodel = $data["PricingModel"];
                                        $insert->searchbid_amount = $data["SearchBid_Amount"];
                                        $insert->startdate = $data["StartDate"];
                                        $insert->status = $data["Status"];

                                        $this->bingAdgroup->save($insert); // data inserted into database 
                                    }

                                endforeach;

                            endforeach;
                        }

                    endforeach;
                }
            }

            die('all adgroups are pulled ..');
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage(); // display exception 
        }
    }

    /**
     * Date :- 2-june-17
     * Function disc :- Function for pull all keywords according to adgroups id  
     * @RudrainnovativePvtLtd 
     */
    public function pullKeywords($location_id) {
        //$location_id = 1; // only for testing purpose 
        $adgroupData = $this->bingAdgroup->find('all')->where(['location_id' => $location_id])->toArray();

        if (!empty($adgroupData)) {
            foreach ($adgroupData as $data):
                $dataArray = []; // array for store keyword data into databse 
                $keywordData = $this->fetchKeywords($data->adgroup_id);
                $parentId = $data->adgroup_id;

                if (!empty($keywordData)) {
                    if (!empty($keywordData->Keyword)) {
                        foreach ($keywordData->Keyword as $key => $val):
                            $dataArray[$key]["adgroupId"] = $parentId;
                            $dataArray[$key]["bid_amount"] = !empty($val->Bid->Amount) ? $val->Bid->Amount : '';
                            $dataArray[$key]["Id"] = !empty($val->Id) ? $val->Id : '';
                            $dataArray[$key]["matchtype"] = !empty($val->MatchType) ? $val->MatchType : '';
                            $dataArray[$key]["status"] = !empty($val->Status) ? $val->Status : '';
                            $dataArray[$key]["text"] = !empty($val->Text) ? $val->Text : '';
                        endforeach;
                    }
                }

                /* Database insertion code */
                if (!empty($dataArray)) {
                    foreach ($dataArray as $value):

//                       echo $value['Id'];

                        /* Please check error */
                        $check = $this->checkDb($location_id, $value['Id'], "bing_keyword_data");
                        if ($check == 1) {
                            $update["location_id"] = $location_id;
                            $update["adgroup_id"] = $value['adgroupId'];
                            $update["bid_amount"] = $value['bid_amount'];
                            $update["status"] = $value['status'];
                            $update["keyword_id"] = $value['Id'];
                            $update["matchtype"] = $value['matchtype'];
                            $update["text"] = $value['text'];
                            $update['updated_at'] = date("Y-m-d h:i:s");
                            $query = $this->bingKeyword->query();
                            $query->update()
                                    ->set($update)
                                    ->where(['location_id' => $location_id, 'keyword_id' => $value['Id']])
                                    ->execute();
                        } else {
                            $insert = $this->bingKeyword->newEntity();
                            $insert->location_id = $location_id;
                            $insert->adgroup_id = $value['adgroupId'];
                            $insert->bid_amount = $value['bid_amount'];
                            $insert->status = $value['status'];
                            $insert->keyword_id = $value['Id'];
                            $insert->matchtype = $value['matchtype'];
                            $insert->text = $value['text'];

                            $this->bingKeyword->save($insert);
                        }

                    endforeach;
                }

            endforeach;
            die('all done');
        }
    }

    /**
     * Date :- 5-june-17
     * Function disc :- Function for pull all ads according to adGroups Id   
     * @RudrainnovativePvtLtd 
     */
    public function pullAds($location_id) {
        try {
//            $location_id = 1; // only for testing purpose 
            $ads_id = ""; // for storing ads id 
            $adgroupData = $this->bingAdgroup->find('all')->where(['location_id' => $location_id])->toArray();

            if (!empty($adgroupData)) {
                foreach ($adgroupData as $data):
                    $dataArray = []; // array for store keyword data into databse 
                    $ads_id = $data->adgroup_id;
                    if (!empty($data->adgroup_id))
                        $adsdData = $this->fetchAdds($data->adgroup_id);
                    if (!empty($adsdData->Ad)) {
                        foreach ($adsdData->Ad as $key => $val):
                            $dataArray[$key]["AdFormatPreference"] = $val->AdFormatPreference;
                            $dataArray[$key]["Id"] = $val->Id;
                            $dataArray[$key]["Status"] = $val->Status;
                            $dataArray[$key]["Type"] = $val->Type;
                            $dataArray[$key]["DestinationUrl"] = $val->DestinationUrl;
                            $dataArray[$key]["DisplayUrl"] = $val->DisplayUrl;
                            $dataArray[$key]["Text"] = $val->Text;
                            $dataArray[$key]["Title"] = $val->Title;
                        endforeach;
                    }

                    if (!empty($dataArray)) {
                        foreach ($dataArray as $value):

                            $checkData = $this->checkDb($location_id, $value['Id'], "bing_ads_data");

                            if ($checkData == 1) {
                                $update["location_id"] = $location_id;
                                $update["addgroup_id"] = $ads_id;
                                $update["ads_id"] = $value["Id"];
                                $update["adformatepreference"] = $value["AdFormatPreference"];
                                $update["status"] = $value["Status"];
                                $update["type"] = $value["Type"];
                                $update["destination_url"] = $value["DestinationUrl"];
                                $update["display_url"] = $value["DisplayUrl"];
                                $update["text"] = $value["Text"];
                                $update["title"] = $value["Title"];
                                $update["updated_at"] = date("Y-m-d h:i:s");
                                $query = $this->bingAds->query();
                                $query->update()
                                        ->set($update)
                                        ->where(['location_id' => $location_id, 'ads_id' => $value['Id']])
                                        ->execute();
                            } else {
                                $insert = $this->bingAds->newEntity();
                                $insert->location_id = $location_id;
                                $insert->addgroup_id = $ads_id;
                                $insert->ads_id = $value["Id"];
                                $insert->adformatepreference = $value["AdFormatPreference"];
                                $insert->status = $value["Status"];
                                $insert->type = $value["Type"];
                                $insert->destination_url = $value["DestinationUrl"];
                                $insert->display_url = $value["DisplayUrl"];
                                $insert->text = $value["Text"];
                                $insert->title = $value["Title"];

                                $this->bingAds->save($insert); // ads inserted into database
                            }

                        endforeach;
                    }

                endforeach;
                die('All Ads Done');
            }
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 6-june-17
     * Function disc :- Function for extract and prase zip file   
     * @RudrainnovativePvtLtd 
     */
    public function extractParseZip() {
        try {
            $filename = __DIR__ . "/../../report/performanceReport.zip";
            $destination = __DIR__ . "/../../report/";

            /* Load php zil lib for unzip file */
            $zip = new \ZipArchive;
            $csvFile = ""; // variable for store csv file name 

            /* Extract zip file at following destination */
            if (file_exists($filename)) {
                if ($zip->open($filename) === TRUE) {
                    $zip->extractTo($destination);
                    $zip->close();

                    /* List all files at following location */
                    $dir = $destination;
                    $files = scandir($dir);
                    if (!empty($files)) {
                        foreach ($files as $val):
                            $str = explode(".", $val);
                            foreach ($str as $data):
                                if (!empty($data) && $data == "csv") {
                                    $csvFile = implode(".", $str);
                                }
                            endforeach;
                        endforeach;
                    }

                    /* Parse csv file to get contents */
                    $filePath = __DIR__ . "/../../report/" . $csvFile;

                    /* condition for check file is exits or not at given path */
                    if (file_exists($filePath)) {

                        chmod($filePath, 0777); //  set 777 file permission to file 
                        $csv = array_map('str_getcsv', file($filePath));
                        if (!empty($csv))
                            $this->savePerformanceReport($csv); //  calling function for save csv data into database 
                    }
                } else {
                    echo 'failed to extract file';
                }
            }
        } catch (Exception $e) {
            echo "Exception :" . $e->getMessage(); // display exception message 
        }
    }

    /**
     * Date :- 6-june-17
     * Function disc :- Function for parse db name and performance data 
     * @RudrainnovativePvtLtd 
     */
    private function savePerformanceReport($csv) {
        
        /* Code for parse csv data and store it into a array */
        if (!empty($csv)) {

            $reportName = !empty($csv[0][0]) ? $csv[0][0] : "";
            if ($reportName != "") {
                $nameArr = explode(':', $reportName);
                $report_name = str_replace('"', "", $nameArr[1]); // get report name 
                $recordCount = $csv[8][0];
                $strArr = explode(':', $recordCount);
                $total = $strArr[1]; // total performance reporting data 

                if ($total > 0) {
                    $total += 10;
                    for ($i = 11; $i <= $total; $i++) {
                        $performanceData = $csv[$i]; // store csv value in a variable 
                        if (trim($report_name) == "Daily Campaign Performance Report" || trim($report_name) == "Historical Campaign Performance Report") {
                            $this->save_into_db("BingCampaignReporting", $performanceData); // for save into database 
                        } else if (trim($report_name) == "Daily Keyword Performance Report" || trim($report_name) == "Historical Keyword Performance Report") {
                            $this->save_into_db("BingKeywordReporting", $performanceData); // for save into database 
                        } else if (trim($report_name) == "Daily Ads Performance Report" || trim($report_name) == "Historical Ads Performance Report") {
                            $this->save_into_db("BingAdsReporting", $performanceData); // for save into database 
                        } else if (trim($report_name) == "Daily AdGroup Performance Report" || trim($report_name) == "Historical AdGroup Performance Report") {
                            $this->save_into_db("BingAdgroupReporting", $performanceData); // calling function to save data into database 
                        } else {
                            die("Please check report name ."); //  if records are fake 
                        }
                    }
                }
            }

            /* Script for delete all files from given folder */
            $path = $filePath = __DIR__ . "/../../report";
            $files = glob($path . '/*'); // get all file names
            foreach ($files as $file) { // iterate files
                if (is_file($file))
                    unlink($file); // delete file
            }

            echo "all files saved into database";
        }
    }

    /**
     * Date :- 6-june-17
     * Function disc :- Function for save data into database according to condition    
     * @RudrainnovativePvtLtd 
     */
    private function save_into_db($model, $dataArray, $location_id = 1) {
        if ($model == "BingCampaignReporting") {

            $model = $this->loadModel("BingCampaignReporting");
            $insert = $model->newEntity();
            $insert->location_id = $location_id;
            $insert->campaign_id = $dataArray[0];
            $insert->clicks = $dataArray[4];
            $insert->impression = $dataArray[6];
            $insert->ctr = $dataArray[7];
            $insert->avg_cpc = $dataArray[8];
            $insert->spend = $dataArray[9];
            $insert->avg_pos = $dataArray[10];
            $insert->conversion = $dataArray[11];
            $insert->cpa = $dataArray[12];
            $insert->qual_score = $dataArray[13];
            $model->save($insert); // campaign reporting inserted into database 
        } else if ($model == "BingKeywordReporting") {

            $model = $this->loadModel("BingKeywordReporting");
            $insert = $model->newEntity();
            $insert->location_id = $location_id;
            $insert->adgroup_id = $dataArray[0];
            $insert->keyword_id = $dataArray[1];
            $insert->keyword = $dataArray[2];
            $insert->clicks = $dataArray[4];
            $insert->impression = $dataArray[5];
            $insert->ctr = $dataArray[6];
            $insert->avg_cpc = $dataArray[7];
            $insert->spend = $dataArray[8];
            $insert->avg_pos = $dataArray[9];
            $model->save($insert); // keyword reporting inserted into database 
        } else if ($model == "BingAdsReporting") {

            $model = $this->loadModel("BingAdsReporting");
            $insert = $model->newEntity();
            $insert->location_id = $location_id;
            $insert->ads_id = $dataArray[1];
            $insert->campaign_id = $dataArray[7];
            $insert->adgroup_id = $dataArray[0];
            $insert->clicks = $dataArray[2];
            $insert->impression = $dataArray[8];
            $insert->ctr = $dataArray[3];
            $insert->avg_cpc = $dataArray[4];
            $insert->spend = $dataArray[5];
            $insert->avg_pos = $dataArray[6];
            $model->save($insert); // ads reporting insert into database 
        } else if ($model = "BingAdgroupReporting") {

            $model = $this->loadModel('BingAdgroupReporting');
            $insert = $model->newEntity();
            $insert->location_id = $location_id;
            $insert->adgroup_id = $dataArray[0];
            $insert->clicks = $dataArray[2];
            $insert->impression = $dataArray[8];
            $insert->ctr = $dataArray[3];
            $insert->avg_cpc = $dataArray[4];
            $insert->spend = $dataArray[5];
            $insert->avg_pos = $dataArray[7];
            $insert->conversions = $dataArray[6];
            $insert->conv_rate = $dataArray[9];
            $model->save($insert); //  adgroup performance reporting added into database 
        }
    }

    /**
     * Date :- 6-june-17
     * Function disc :- Private function for get customer client id for set in Global["Authentication"] for reporting  
     * @RudrainnovativePvtLtd 
     */
    private function getCustomerClientId($accountId) {
        if (isset($accountId) && $accountId != "") {
            $subData = $this->bingSubuser->find('all')->where(["account_id" => $accountId])->toArray();

            if (!empty($subData)) {
                return $subData[0]->parent_customer_id; // return customer client id 
            }
        }
    }

}
