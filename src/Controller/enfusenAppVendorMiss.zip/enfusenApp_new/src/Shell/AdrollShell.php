<?php

namespace App\Shell;

use Cake\Console\Shell;
use App\Controller\AddrollController;

class AdrollShell extends Shell {

    private $adroll; // variable for store adroll class object 
    private $location_id; // var for store location id 
    private $adrollUser; // var for store adroll user model
    private $campaignReporting;
    private $binAds;

    /**
     * Date :- 07-june-17 
     * Function disc :- initialize all variable and data for adroll 
     * @Rudrainnovatives 
     */
    public function initialize() {
        parent::initialize();
        $this->adroll = new AddrollController();
        $this->location_id = 1; // only for testing purposes 
        $this->adrollUser = $this->loadModel('AdrollUser'); // calling adroll user table 
        $this->campaignReporting = $this->loadModel('AdrollCampaignReporting'); //calling model
        $this->bingAds = $this->loadModel('AdrollCampAds');
    }

    /**
     * Date :- 07-june-17 
     * Function disc :- Cron function for get Adroll User details 
     * @Rudrainnovatives 
     */
    public function main() {
        $api_key = ADROLL_API_KEY;
        $this->adroll->getUsers($api_key, $this->location_id);
    }

    /**
     * Date :- 07-june-17 
     * Function disc :- Cron function for get Adroll campaigns 
     * @Rudrainnovatives 
     */
    public function pullCampaigns() {
        $userData = $this->adrollUser->find('all')->where(['location_id' => $this->location_id])->toArray(); // get value from adroll user table 
        $advertisableEid = $userData[0]->advertisable_eid; // advertisable id from database 
        $this->adroll->getCampaigns($advertisableEid, $this->location_id);
    }

    /**
     * Date :- 07-june-17 
     * Function disc :- Cron function for pull campaign reporting 
     * @Rudrainnovatives 
     */
    public function pullCampaignReporting() {
        $api_key = ADROLL_API_KEY;
        $check = $this->check_value($this->campaignReporting, $this->location_id);

        if ($check == 1) {
            $this->adroll->getCampaignsReport($this->location_id, $api_key);
        } else if ($check == 0) {
            $this->adroll->getCampaignsReport($this->location_id, $api_key);
            $this->out("Historical campaign report done");
            $this->adroll->getHistoricalCampaignsReport($this->location_id, $api_key);
        }
    }

    /**
     * Date :- 07-june-17 
     * Function disc :- Cron function for pull campaign reporting 
     * @Rudrainnovatives 
     */
    public function pullAdsReporting() {
        $api_key = ADROLL_API_KEY;
        $check = $this->check_value($this->bingAds, $this->location_id);

        if ($check == 1) {
            $this->adroll->getAddReport($this->location_id, $api_key);
        } else if ($check == 0) {
            $this->adroll->getAddReport($this->location_id, $api_key);
            $this->out("Historical campaign report done");
            $this->adroll->getHistoricalAddReport($this->location_id, $api_key);
        }
    }

    /**
     * Date :- 07-june-17 
     * Function disc :- Cron function for check value is in database or not  
     * @Rudrainnovatives 
     */
    public function check_value($db, $location_id) {
        $dbData = $db->find('all')->where(['location_id' => $location_id])->all();

        if (iterator_count($dbData)) {
            return 1;
        } else {
            return 0;
        }
    }

}
