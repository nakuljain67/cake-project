<?php
/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link      http://cakephp.org CakePHP(tm) Project
 * @since     3.0.0
 * @license   http://www.opensource.org/licenses/mit-license.php MIT License
 */
namespace App\Shell;
require_once(ROOT . DS . 'vendor' . DS ."callmetrics" . DS . "lib" . DS . "ctm.php");
use Cake\Console\ConsoleOptionParser;
use Cake\Console\Shell;
use Cake\Log\Log;
use Cake\ORM\TableRegistry;
use AuthToken;
use Number;
/**
 * Simple console wrapper around Psy\Shell.
 */
class CallTrackingMetricsShell extends Shell
{

  public function main()
    {
   $users1 = TableRegistry::get('api_locations');
$missed = $users1->find('all')->where(['status' => '1'])->where(['calltracking_info != ""'])->toArray();
    //pr($missed);die;
    foreach ($missed as $key => $new) {
    $values = json_decode($new->calltracking_info);
    $apikey= $values->apikey;
    $apisecret= $values->apisecret;
     $location= $new->smart_location_id;
    $auth_token = AuthToken::authorize($apikey,$apisecret);
    $account_id = $auth_token->account_id;
    $headers = 'Basic ' . base64_encode( "$apikey:$apisecret");
    $curl = curl_init();
       curl_setopt_array($curl, array(
       CURLOPT_URL => "https://api.calltrackingmetrics.com/api/v1/accounts/".$account_id."/calls?time_duration=today",
       CURLOPT_RETURNTRANSFER => true,
       CURLOPT_ENCODING => "",
       CURLOPT_MAXREDIRS => 10,
       CURLOPT_TIMEOUT => 30,
       CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
       CURLOPT_CUSTOMREQUEST => "GET",
       CURLOPT_HTTPHEADER => array(
   // "Authorization" => 'Basic ' . base64_encode( "$apikey:$apisecret"),   
    "Authorization: {$headers}",
    "content-type: application/json"
          ),
        ));
            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            $res= json_decode($response);
            //pr($res); die;            
                            $mobile = [];
                            $i = 0;
                            foreach($res->calls as $data)
                            {
                                $mobile[$i]["id"] = $data->id;
                                $mobile[$i]["sid"] = $data->sid;
                                $mobile[$i]["account_id"] = $data->account_id;
                                $mobile[$i]["name"] = $data->name;
                                $mobile[$i]["cnam"] = $data->cnam;
                                $mobile[$i]["search"] = $data->search;
                                $mobile[$i]["referrer"] = $data->referrer;
                                $mobile[$i]["location"] = $data->location;
                                $mobile[$i]["source"] = $data->source;
                                $mobile[$i]["source_id"] = $data->source_id;
                                $mobile[$i]["source_sid"] = $data->source_sid;
                                $mobile[$i]["tgid"] = $data->tgid;
                                $mobile[$i]["likelihood"] = $data->likelihood;
                                $mobile[$i]["duration"] = $data->duration;
                                $mobile[$i]["direction"] = $data->direction;
                                $mobile[$i]["talk_time"] = $data->talk_time;
                                $mobile[$i]["ring_time"] = $data->ring_time;
                                $mobile[$i]["hold_time"] = $data->hold_time;
                                $mobile[$i]["parent_id"] = $data->parent_id;
                                $mobile[$i]["email"] = $data->email;
                                $mobile[$i]["street"] = $data->street;
                                $mobile[$i]["city"] = $data->city;
                                $mobile[$i]["state"] = $data->state;
                                $mobile[$i]["country"] = $data->country;
                                $mobile[$i]["postal_code"] = $data->postal_code;
                                $mobile[$i]["called_at"] = $this->change_date($data->called_at);

                                $mobile[$i]["tracking_number_id"] = $data->tracking_number_id;
                                $mobile[$i]["tracking_number_sid"] = $data->tracking_number_sid;
                                $mobile[$i]["tracking_number"] = $data->tracking_number;
                                $mobile[$i]["dial_status"] = $data->dial_status;
                                $mobile[$i]["is_new_caller"] = $data->is_new_caller;
                                $mobile[$i]["indexed_at"] = $data->indexed_at;
                                $mobile[$i]["business_number"] = $data->business_number;
                                $mobile[$i]["business_label"] = $data->business_label;
                                $mobile[$i]["receiving_number_id"] = $data->receiving_number_id;
                                $mobile[$i]["receiving_number_sid"] = $data->receiving_number_sid;
                                $mobile[$i]["billed_amount"] = $data->billed_amount;
                                $mobile[$i]["billed_at"] = $data->billed_at;             
                                $mobile[$i]["tracking_number_format"] = $data->tracking_number_format;
                                $mobile[$i]["business_number_format"] = $data->business_number_format;
                                $mobile[$i]["caller_number_format"] = $data->caller_number_format;
                                $mobile[$i]["caller_number"] = $data->caller_number;
                                $mobile[$i]["call_status"] = $data->call_status;
                                $mobile[$i]["audio"] = $data->audio;
                                $mobile[$i]["day"] = $data->day;
                                $mobile[$i]["month"] = $data->month;
                                $mobile[$i]["hour"] = $data->hour;
                                $mobile[$i]["latitude"] = $data->latitude;
                                $mobile[$i]["longitude"] = $data->longitude;
                                $mobile[$i]["extended_lookup_on"] = $data->extended_lookup_on;
                                $i++;
                            }

                             if(!empty($mobile))
                {
                            foreach($mobile as $val){
                                $users_table = TableRegistry::get('calldetails');
                                $insert = $users_table->newEntity();
                                $insert->location_id =  $location;
                                $insert->call_id = $val['id'];
                                $insert->sid =  $val['sid'];
                                $insert->account_id =  $val['account_id'];
                                $insert->called_at =  $val['called_at'];
                                $insert->postal_code =  $val['postal_code'];
                                $insert->country =  $val['country'];
                                $insert->state =  $val['state'];
                                $insert->city =  $val['city'];
                                $insert->street =  $val['street'];
                                $insert->email =  $val['email'];
                                $insert->parent_id =  $val['parent_id'];
                                $insert->hold_time =  $val['hold_time'];
                                $insert->ring_time =  $val['ring_time'];
                                $insert->talk_time =  $val['talk_time'];
                                $insert->direction =  $val['direction'];
                                $insert->duration =  $val['duration'];
                                $insert->likelihood =  $val['likelihood'];
                                $insert->tgid =  $val['tgid'];
                                $insert->source_sid =  $val['source_sid'];
                                $insert->source_id =  $val['source_id'];
                                $insert->source =  $val['source'];
                                $insert->location =  $val['location'];
                                $insert->referrer =  $val['referrer'];
                                $insert->search =  $val['search'];
                                $insert->cnam =  $val['cnam'];
                                $insert->name =  $val['name'];        
                            $insert->extended_lookup_on =  $val['extended_lookup_on'];
                            $insert->longitude =  $val['longitude'];
                            $insert->latitude =  $val['latitude'];
                            $insert->hour =  $val['hour'];
                            $insert->month =  $val['month'];
                            $insert->day =  $val['day'];
                            $insert->audio =  $val['audio'];
                            $insert->call_status =  $val['call_status'];
                            $insert->caller_number =  $val['caller_number'];
                            $insert->caller_number_format =  $val['caller_number_format'];
                            $insert->business_number_format =  $val['business_number_format'];
                            $insert->tracking_number_format =  $val['tracking_number_format'];
                            $insert->billed_at =  $val['billed_at'];
                        $insert->billed_amount =  $val['billed_amount'];
                        $insert->receiving_number_sid =  $val['receiving_number_sid'];
                        $insert->receiving_number_id =  $val['receiving_number_id'];
                        $insert->business_label =  $val['business_label'];
                        $insert->business_number =  $val['business_number'];
                        $insert->indexed_at =  $val['indexed_at'];
                        $insert->is_new_caller =  $val['is_new_caller'];
                        $insert->dial_status =  $val['dial_status'];
                        $insert->tracking_number =  $val['tracking_number'];
                        $insert->tracking_number_sid =  $val['tracking_number_sid'];
                        $insert->tracking_number_id =  $val['tracking_number_id'];
                        $users_table->save($insert);
                    }
                }


       if( $res->total_pages >'1') {
       for($j=2; $j<=$res->total_pages; $j++ ){
       $curl = curl_init();
       curl_setopt_array($curl, array(
       CURLOPT_URL => "https://api.calltrackingmetrics.com/api/v1/accounts/".$account_id."/calls?time_duration=today&page=".$j,
       CURLOPT_RETURNTRANSFER => true,
       CURLOPT_ENCODING => "",
       CURLOPT_MAXREDIRS => 10,
       CURLOPT_TIMEOUT => 30,
       CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
       CURLOPT_CUSTOMREQUEST => "GET",
       CURLOPT_HTTPHEADER => array(
   // "Authorization" => 'Basic ' . base64_encode( "$apikey:$apisecret"),   
    "Authorization: {$headers}",
    "content-type: application/json"
          ),
        ));
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    $res= json_decode($response);
   // pr($res); die;

                           $mobile = [];
                            $i = 0;
                            foreach($res->calls as $data)
                            {
                                $mobile[$i]["id"] = $data->id;
                                $mobile[$i]["sid"] = $data->sid;
                                $mobile[$i]["account_id"] = $data->account_id;
                                $mobile[$i]["name"] = $data->name;
                                $mobile[$i]["cnam"] = $data->cnam;
                                $mobile[$i]["search"] = $data->search;
                                $mobile[$i]["referrer"] = $data->referrer;
                                $mobile[$i]["location"] = $data->location;
                                $mobile[$i]["source"] = $data->source;
                                $mobile[$i]["source_id"] = $data->source_id;
                                $mobile[$i]["source_sid"] = $data->source_sid;
                                $mobile[$i]["tgid"] = $data->tgid;
                                $mobile[$i]["likelihood"] = $data->likelihood;
                                $mobile[$i]["duration"] = $data->duration;
                                $mobile[$i]["direction"] = $data->direction;
                                $mobile[$i]["talk_time"] = $data->talk_time;
                                $mobile[$i]["ring_time"] = $data->ring_time;
                                $mobile[$i]["hold_time"] = $data->hold_time;
                                $mobile[$i]["parent_id"] = $data->parent_id;
                                $mobile[$i]["email"] = $data->email;
                                $mobile[$i]["street"] = $data->street;
                                $mobile[$i]["city"] = $data->city;
                                $mobile[$i]["state"] = $data->state;
                                $mobile[$i]["country"] = $data->country;
                                $mobile[$i]["postal_code"] = $data->postal_code;
                                $mobile[$i]["called_at"] = $this->change_date($data->called_at);
                                $mobile[$i]["tracking_number_id"] = $data->tracking_number_id;
                                $mobile[$i]["tracking_number_sid"] = $data->tracking_number_sid;
                                $mobile[$i]["tracking_number"] = $data->tracking_number;
                                $mobile[$i]["dial_status"] = $data->dial_status;
                                $mobile[$i]["is_new_caller"] = $data->is_new_caller;
                                $mobile[$i]["indexed_at"] = $data->indexed_at;
                                $mobile[$i]["business_number"] = $data->business_number;
                                $mobile[$i]["business_label"] = $data->business_label;
                                $mobile[$i]["receiving_number_id"] = $data->receiving_number_id;
                                $mobile[$i]["receiving_number_sid"] = $data->receiving_number_sid;
                                $mobile[$i]["billed_amount"] = $data->billed_amount;
                                $mobile[$i]["billed_at"] = $data->billed_at;             
                                $mobile[$i]["tracking_number_format"] = $data->tracking_number_format;
                                $mobile[$i]["business_number_format"] = $data->business_number_format;
                                $mobile[$i]["caller_number_format"] = $data->caller_number_format;
                                $mobile[$i]["caller_number"] = $data->caller_number;
                                $mobile[$i]["call_status"] = $data->call_status;
                                $mobile[$i]["audio"] = $data->audio;
                                $mobile[$i]["day"] = $data->day;
                                $mobile[$i]["month"] = $data->month;
                                $mobile[$i]["hour"] = $data->hour;
                                $mobile[$i]["latitude"] = $data->latitude;
                                $mobile[$i]["longitude"] = $data->longitude;
                                $mobile[$i]["extended_lookup_on"] = $data->extended_lookup_on;
                                $i++;
                            }

                             if(!empty($mobile))
                {
                    foreach($mobile as $val) {
                        $users_table = TableRegistry::get('calldetails');
                        $insert = $users_table->newEntity();
                        $insert->location_id =  $location;
                        $insert->call_id = $val['id'];
                        $insert->sid =  $val['sid'];
                        $insert->account_id =  $val['account_id'];
                                $insert->called_at =  $val['called_at'];
                                $insert->postal_code =  $val['postal_code'];
                                $insert->country =  $val['country'];
                                $insert->state =  $val['state'];
                                $insert->city =  $val['city'];
                                $insert->street =  $val['street'];
                                $insert->email =  $val['email'];
                                $insert->parent_id =  $val['parent_id'];
                                $insert->hold_time =  $val['hold_time'];
                                $insert->ring_time =  $val['ring_time'];
                                $insert->talk_time =  $val['talk_time'];
                                $insert->direction =  $val['direction'];
                                $insert->duration =  $val['duration'];
                                $insert->likelihood =  $val['likelihood'];
                                $insert->tgid =  $val['tgid'];
                                $insert->source_sid =  $val['source_sid'];
                                $insert->source_id =  $val['source_id'];
                                $insert->source =  $val['source'];
                                $insert->location =  $val['location'];
                                $insert->referrer =  $val['referrer'];
                                $insert->search =  $val['search'];
                                $insert->cnam =  $val['cnam'];
                                $insert->name =  $val['name'];        
                        $insert->extended_lookup_on =  $val['extended_lookup_on'];
                        $insert->longitude =  $val['longitude'];
                        $insert->latitude =  $val['latitude'];
                        $insert->hour =  $val['hour'];
                        $insert->month =  $val['month'];
                        $insert->day =  $val['day'];
                        $insert->audio =  $val['audio'];
                        $insert->call_status =  $val['call_status'];
                        $insert->caller_number =  $val['caller_number'];
                        $insert->caller_number_format =  $val['caller_number_format'];
                        $insert->business_number_format =  $val['business_number_format'];
                        $insert->tracking_number_format =  $val['tracking_number_format'];
                        $insert->billed_at =  $val['billed_at'];
                        $insert->billed_amount =  $val['billed_amount'];
                        $insert->receiving_number_sid =  $val['receiving_number_sid'];
                        $insert->receiving_number_id =  $val['receiving_number_id'];
                        $insert->business_label =  $val['business_label'];
                        $insert->business_number =  $val['business_number'];
                        $insert->indexed_at =  $val['indexed_at'];
                        $insert->is_new_caller =  $val['is_new_caller'];
                        $insert->dial_status =  $val['dial_status'];
                        $insert->tracking_number =  $val['tracking_number'];
                        $insert->tracking_number_sid =  $val['tracking_number_sid'];
                        $insert->tracking_number_id =  $val['tracking_number_id'];
                        $users_table->save($insert);
                    }
                }
              }
           }
 }
 $this->out("Success");
}

  public function historicalData()
    {
    $users1 = TableRegistry::get('api_locations');
$missed = $users1->find('all')->where(['status' => '1'])->where(['calltracking_info != ""'])->toArray();
    //pr($missed);die;
    foreach ($missed as $key => $new) {
    $values = json_decode($new->calltracking_info);
    $apikey= $values->apikey;
    $apisecret= $values->apisecret;
     $location= $new->smart_location_id;
    $auth_token = AuthToken::authorize($apikey,$apisecret);
    $account_id = $auth_token->account_id;
    $headers = 'Basic ' . base64_encode( "$apikey:$apisecret");
    $curl = curl_init();
       curl_setopt_array($curl, array(
       CURLOPT_URL => "https://api.calltrackingmetrics.com/api/v1/accounts/".$account_id."/calls?time_duration=last3months",
       CURLOPT_RETURNTRANSFER => true,
       CURLOPT_ENCODING => "",
       CURLOPT_MAXREDIRS => 10,
       CURLOPT_TIMEOUT => 30,
       CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
       CURLOPT_CUSTOMREQUEST => "GET",
       CURLOPT_HTTPHEADER => array(
   // "Authorization" => 'Basic ' . base64_encode( "$apikey:$apisecret"),   
    "Authorization: {$headers}",
    "content-type: application/json"
          ),
        ));
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
          $res= json_decode($response);
            
                            $mobile = [];
                            $i = 0;
                            foreach($res->calls as $data)
                            {
                                $mobile[$i]["id"] = $data->id;
                                $mobile[$i]["sid"] = $data->sid;
                                $mobile[$i]["account_id"] = $data->account_id;
                                $mobile[$i]["name"] = $data->name;
                                $mobile[$i]["cnam"] = $data->cnam;
                                $mobile[$i]["search"] = $data->search;
                                $mobile[$i]["referrer"] = $data->referrer;
                                $mobile[$i]["location"] = $data->location;
                                $mobile[$i]["source"] = $data->source;
                                $mobile[$i]["source_id"] = $data->source_id;
                                $mobile[$i]["source_sid"] = $data->source_sid;
                                $mobile[$i]["tgid"] = $data->tgid;
                                $mobile[$i]["likelihood"] = $data->likelihood;
                                $mobile[$i]["duration"] = $data->duration;
                                $mobile[$i]["direction"] = $data->direction;
                                $mobile[$i]["talk_time"] = $data->talk_time;
                                $mobile[$i]["ring_time"] = $data->ring_time;
                                $mobile[$i]["hold_time"] = $data->hold_time;
                                $mobile[$i]["parent_id"] = $data->parent_id;
                                $mobile[$i]["email"] = $data->email;
                                $mobile[$i]["street"] = $data->street;
                                $mobile[$i]["city"] = $data->city;
                                $mobile[$i]["state"] = $data->state;
                                $mobile[$i]["country"] = $data->country;
                                $mobile[$i]["postal_code"] = $data->postal_code;
                                $mobile[$i]["called_at"] = $this->change_date($data->called_at);
                                $mobile[$i]["tracking_number_id"] = $data->tracking_number_id;
                                $mobile[$i]["tracking_number_sid"] = $data->tracking_number_sid;
                                $mobile[$i]["tracking_number"] = $data->tracking_number;
                                $mobile[$i]["dial_status"] = $data->dial_status;
                                $mobile[$i]["is_new_caller"] = $data->is_new_caller;
                                $mobile[$i]["indexed_at"] = $data->indexed_at;
                                $mobile[$i]["business_number"] = $data->business_number;
                                $mobile[$i]["business_label"] = $data->business_label;
                                $mobile[$i]["receiving_number_id"] = $data->receiving_number_id;
                                $mobile[$i]["receiving_number_sid"] = $data->receiving_number_sid;
                                $mobile[$i]["billed_amount"] = $data->billed_amount;
                                $mobile[$i]["billed_at"] = $data->billed_at;             
                                $mobile[$i]["tracking_number_format"] = $data->tracking_number_format;
                                $mobile[$i]["business_number_format"] = $data->business_number_format;
                                $mobile[$i]["caller_number_format"] = $data->caller_number_format;
                                $mobile[$i]["caller_number"] = $data->caller_number;
                                $mobile[$i]["call_status"] = $data->call_status;
                                $mobile[$i]["audio"] = $data->audio;
                                $mobile[$i]["day"] = $data->day;
                                $mobile[$i]["month"] = $data->month;
                                $mobile[$i]["hour"] = $data->hour;
                                $mobile[$i]["latitude"] = $data->latitude;
                                $mobile[$i]["longitude"] = $data->longitude;
                                $mobile[$i]["extended_lookup_on"] = $data->extended_lookup_on;
                                $i++;
                            }
                             if(!empty($mobile))
                { 
                    foreach($mobile as $val){
                        $users_table = TableRegistry::get('calldetails');
                        $insert = $users_table->newEntity();
                        $insert->location_id =  $location;
                        $insert->call_id = $val['id'];
                        $insert->sid =  $val['sid'];
                        $insert->account_id =  $val['account_id'];
                                $insert->called_at =  $val['called_at'];
                                $insert->postal_code =  $val['postal_code'];
                                $insert->country =  $val['country'];
                                $insert->state =  $val['state'];
                                $insert->city =  $val['city'];
                                $insert->street =  $val['street'];
                                $insert->email =  $val['email'];
                                $insert->parent_id =  $val['parent_id'];
                                $insert->hold_time =  $val['hold_time'];
                                $insert->ring_time =  $val['ring_time'];
                                $insert->talk_time =  $val['talk_time'];
                                $insert->direction =  $val['direction'];
                                $insert->duration =  $val['duration'];
                                $insert->likelihood =  $val['likelihood'];
                                $insert->tgid =  $val['tgid'];
                                $insert->source_sid =  $val['source_sid'];
                                $insert->source_id =  $val['source_id'];
                                $insert->source =  $val['source'];
                                $insert->location =  $val['location'];
                                $insert->referrer =  $val['referrer'];
                                $insert->search =  $val['search'];
                                $insert->cnam =  $val['cnam'];
                                $insert->name =  $val['name'];        
                        $insert->extended_lookup_on =  $val['extended_lookup_on'];
                        $insert->longitude =  $val['longitude'];
                        $insert->latitude =  $val['latitude'];
                        $insert->hour =  $val['hour'];
                        $insert->month =  $val['month'];
                        $insert->day =  $val['day'];
                        $insert->audio =  $val['audio'];
                        $insert->call_status =  $val['call_status'];
                        $insert->caller_number =  $val['caller_number'];
                        $insert->caller_number_format =  $val['caller_number_format'];
                        $insert->business_number_format =  $val['business_number_format'];
                        $insert->tracking_number_format =  $val['tracking_number_format'];
                        $insert->billed_at =  $val['billed_at'];
                        $insert->billed_amount =  $val['billed_amount'];
                        $insert->receiving_number_sid =  $val['receiving_number_sid'];
                        $insert->receiving_number_id =  $val['receiving_number_id'];
                        $insert->business_label =  $val['business_label'];
                        $insert->business_number =  $val['business_number'];
                        $insert->indexed_at =  $val['indexed_at'];
                        $insert->is_new_caller =  $val['is_new_caller'];
                        $insert->dial_status =  $val['dial_status'];
                        $insert->tracking_number =  $val['tracking_number'];
                        $insert->tracking_number_sid =  $val['tracking_number_sid'];
                        $insert->tracking_number_id =  $val['tracking_number_id'];
                        $users_table->save($insert);
                    }
                }


       if( $res->total_pages >'1') {
       for($j=2; $j<=$res->total_pages; $j++ ){
       $curl = curl_init();
       curl_setopt_array($curl, array(
       CURLOPT_URL => "https://api.calltrackingmetrics.com/api/v1/accounts/".$account_id."/calls?time_duration=last3months&page=".$j,
       CURLOPT_RETURNTRANSFER => true,
       CURLOPT_ENCODING => "",
       CURLOPT_MAXREDIRS => 10,
       CURLOPT_TIMEOUT => 30,
       CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
       CURLOPT_CUSTOMREQUEST => "GET",
       CURLOPT_HTTPHEADER => array(
   // "Authorization" => 'Basic ' . base64_encode( "$apikey:$apisecret"),   
    "Authorization: {$headers}",
    "content-type: application/json"
          ),
        ));
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    $res= json_decode($response);
   // pr($res); die;

                           $mobile = [];
                            $i = 0;
                            foreach($res->calls as $data)
                            {
                                $mobile[$i]["id"] = $data->id;
                                $mobile[$i]["sid"] = $data->sid;
                                $mobile[$i]["account_id"] = $data->account_id;
                                $mobile[$i]["name"] = $data->name;
                                $mobile[$i]["cnam"] = $data->cnam;
                                $mobile[$i]["search"] = $data->search;
                                $mobile[$i]["referrer"] = $data->referrer;
                                $mobile[$i]["location"] = $data->location;
                                $mobile[$i]["source"] = $data->source;
                                $mobile[$i]["source_id"] = $data->source_id;
                                $mobile[$i]["source_sid"] = $data->source_sid;
                                $mobile[$i]["tgid"] = $data->tgid;
                                $mobile[$i]["likelihood"] = $data->likelihood;
                                $mobile[$i]["duration"] = $data->duration;
                                $mobile[$i]["direction"] = $data->direction;
                                $mobile[$i]["talk_time"] = $data->talk_time;
                                $mobile[$i]["ring_time"] = $data->ring_time;
                                $mobile[$i]["hold_time"] = $data->hold_time;
                                $mobile[$i]["parent_id"] = $data->parent_id;
                                $mobile[$i]["email"] = $data->email;
                                $mobile[$i]["street"] = $data->street;
                                $mobile[$i]["city"] = $data->city;
                                $mobile[$i]["state"] = $data->state;
                                $mobile[$i]["country"] = $data->country;
                                $mobile[$i]["postal_code"] = $data->postal_code;
                                $mobile[$i]["called_at"] = $this->change_date($data->called_at);
                                $mobile[$i]["tracking_number_id"] = $data->tracking_number_id;
                                $mobile[$i]["tracking_number_sid"] = $data->tracking_number_sid;
                                $mobile[$i]["tracking_number"] = $data->tracking_number;
                                $mobile[$i]["dial_status"] = $data->dial_status;
                                $mobile[$i]["is_new_caller"] = $data->is_new_caller;
                                $mobile[$i]["indexed_at"] = $data->indexed_at;
                                $mobile[$i]["business_number"] = $data->business_number;
                                $mobile[$i]["business_label"] = $data->business_label;
                                $mobile[$i]["receiving_number_id"] = $data->receiving_number_id;
                                $mobile[$i]["receiving_number_sid"] = $data->receiving_number_sid;
                                $mobile[$i]["billed_amount"] = $data->billed_amount;
                                $mobile[$i]["billed_at"] = $data->billed_at;             
                                $mobile[$i]["tracking_number_format"] = $data->tracking_number_format;
                                $mobile[$i]["business_number_format"] = $data->business_number_format;
                                $mobile[$i]["caller_number_format"] = $data->caller_number_format;
                                $mobile[$i]["caller_number"] = $data->caller_number;
                                $mobile[$i]["call_status"] = $data->call_status;
                                $mobile[$i]["audio"] = $data->audio;
                                $mobile[$i]["day"] = $data->day;
                                $mobile[$i]["month"] = $data->month;
                                $mobile[$i]["hour"] = $data->hour;
                                $mobile[$i]["latitude"] = $data->latitude;
                                $mobile[$i]["longitude"] = $data->longitude;
                                $mobile[$i]["extended_lookup_on"] = $data->extended_lookup_on;
                                $i++;
                            }

                             if(!empty($mobile))
                {
                    foreach($mobile as $val) {
                        $users_table = TableRegistry::get('calldetails');
                        $insert = $users_table->newEntity();
                        $insert->location_id =  $location;
                        $insert->call_id = $val['id'];
                        $insert->sid =  $val['sid'];
                        $insert->account_id =  $val['account_id'];
                                $insert->called_at =  $val['called_at'];
                                $insert->postal_code =  $val['postal_code'];
                                $insert->country =  $val['country'];
                                $insert->state =  $val['state'];
                                $insert->city =  $val['city'];
                                $insert->street =  $val['street'];
                                $insert->email =  $val['email'];
                                $insert->parent_id =  $val['parent_id'];
                                $insert->hold_time =  $val['hold_time'];
                                $insert->ring_time =  $val['ring_time'];
                                $insert->talk_time =  $val['talk_time'];
                                $insert->direction =  $val['direction'];
                                $insert->duration =  $val['duration'];
                                $insert->likelihood =  $val['likelihood'];
                                $insert->tgid =  $val['tgid'];
                                $insert->source_sid =  $val['source_sid'];
                                $insert->source_id =  $val['source_id'];
                                $insert->source =  $val['source'];
                                $insert->location =  $val['location'];
                                $insert->referrer =  $val['referrer'];
                                $insert->search =  $val['search'];
                                $insert->cnam =  $val['cnam'];
                                $insert->name =  $val['name'];        
                        $insert->extended_lookup_on =  $val['extended_lookup_on'];
                        $insert->longitude =  $val['longitude'];
                        $insert->latitude =  $val['latitude'];
                        $insert->hour =  $val['hour'];
                        $insert->month =  $val['month'];
                        $insert->day =  $val['day'];
                        $insert->audio =  $val['audio'];
                        $insert->call_status =  $val['call_status'];
                        $insert->caller_number =  $val['caller_number'];
                        $insert->caller_number_format =  $val['caller_number_format'];
                        $insert->business_number_format =  $val['business_number_format'];
                        $insert->tracking_number_format =  $val['tracking_number_format'];
                        $insert->billed_at =  $val['billed_at'];
                        $insert->billed_amount =  $val['billed_amount'];
                        $insert->receiving_number_sid =  $val['receiving_number_sid'];
                        $insert->receiving_number_id =  $val['receiving_number_id'];
                        $insert->business_label =  $val['business_label'];
                        $insert->business_number =  $val['business_number'];
                        $insert->indexed_at =  $val['indexed_at'];
                        $insert->is_new_caller =  $val['is_new_caller'];
                        $insert->dial_status =  $val['dial_status'];
                        $insert->tracking_number =  $val['tracking_number'];
                        $insert->tracking_number_sid =  $val['tracking_number_sid'];
                        $insert->tracking_number_id =  $val['tracking_number_id'];
                        $users_table->save($insert);
                    }
                }
              }
           }
          }
           $this->out("Success");
         }
         
         private function change_date($date)
         {
            $newDate = date('Y-m-d h:i:s', strtotime($date));
            return $newDate;
        }
}
