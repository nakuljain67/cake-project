<?php

namespace App\Shell;

use Cake\Console\ConsoleOptionParser;
use Cake\Console\Shell;
use Cake\Log\Log;
use App\Controller\AppController;
use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[] paginate($object = null, array $settings = [])
 */
class MasterCreShell extends Shell {

    private $app;
    private $conn;
    private $smartdata;
    private $smart;
    
    public function initialize() {
        parent::initialize();
        ini_set('max_execution_time', 90000);
        $this->loadModel('Apilocations');
        $this->app = new AppController();
        $this->conn = ConnectionManager::get('default');
        $this->smartdata = "smart";
        $this->smart = ConnectionManager::get($this->smartdata);
    }

    public function main() {        
        $this->out("Welcome to Master CRE");
        $this->hr();
    }
    
    public function monthlyCreFill() {
        // Run master cre every first day of month
        $fromdate = date("Y-m-1 00:00:00", strtotime("-1 month"));
        $todate = date("Y-m-t 23:59:59", strtotime("-1 month"));
        $sql = "SELECT * FROM tbl_cre_urls WHERE (result IS NOT NULL && result != '') AND rundate >= '".$fromdate."' AND rundate <= '".$todate."' GROUP BY url";
        $result = $this->smart->execute($sql)->fetchAll("obj");
        
        foreach($result as $row){
            $total_organic='';$title_length=''; $title_relevancy='';$description_length='';$description_relevancy='';$size='';$words='';$load_time='';$text_ratio='';$total_links='';$external_links='';$broken_links='';$notitle_links='';$norel_links='';$total_images='';$noalt_images='';$total_htags='';$total_h1tags='';$total_h2tags='';$total_h3tags='';$total_h4tags='';$total_h5tags='';$total_h6tags='';$age="";$total_cpc='';$total_referral='';$total_social='';$total_direct='';$total_visits='';$organic_conversion='';$referral_conversion='';$cpc_conversion='';$social_conversion='';$direct_conversion='';$total_conversion='';$organic_conversion_rate='';$cpc_conversion_rate='';$referral_conversion_rate='';$social_conversion_rate='';$direct_conversion_rate='';$total_conversion_rate='';$timeonsite='';$bounceRate='';
            $keyword = ''; $rank = '0'; $search_vol = '0'; $difficulty = '0.00'; $cpc = '0.00';
            $res = json_decode($row->result);
            //pr($res); die;
            
            $url = $CurPageURL = $row->url;                
            $title_length = $res->title->title_length > 0?$res->title->title_length:0;
            $title_relevancy = $res->title->title_relevancy;
            $description_length = (isset($res->desc->desc_length) > 0)?$res->desc->desc_length:0;
            $last_run_date = $row->rundate;
            $description_relevancy = (isset($res->desc->desc_relevancy))?$res->desc->desc_relevancy:0;
            $size = $res->page_size + $res->arcss->css_size + $res->js->js_size + $res->images->img_size;
            $words = $res->content->total_words;
            $load_time = number_format($res->page_speed,2);
            $text_ratio = $res->text_ratio;
            $total_links = count((array)$res->links->external_links) + count((array)$res->links->internal_links);
            $external_links = count((array)$res->links->external_links);
            $broken_links = count((array) $res->links->broken_links);
            $notitle_links = count((array)($res->links->no_title));
            $norel_links = count((array)($res->links->no_rel));
            $total_images = $res->images->total_images;
            $noalt_images = count($res->images->alt_miss);
            $total_htags = $res->headings->totalh1 + $res->headings->totalh2 + $res->headings->totalh3 + $res->headings->totalh4
            + $res->headings->totalh5 + $res->headings->totalh6;
            $total_h1tags = $res->headings->totalh1;
            $total_h2tags = $res->headings->totalh2;
            $total_h3tags = $res->headings->totalh3;
            $total_h4tags = $res->headings->totalh4;
            $total_h5tags = $res->headings->totalh5;
            $total_h6tags = $res->headings->totalh6;

            $robots_meta_tag = isset($res->desc->robots_meta_tag) && $res->desc->robots_meta_tag == 1?'Yes':'No';
            $doctype_available = isset($res->doctpye) && $res->doctpye == 1?'Yes':'No';
            $any_iframe = isset($res->iframe) && $res->iframe == 1?'Yes':'No';
            $canonical_tag = isset($res->canonical_tag) && $res->canonical_tag == 1?'Yes':'No';
            $mobile_friendly = isset($res->mobile_friendly) && $res->mobile_friendly == 1?'Yes':'No';
            $score = isset($res->score)?$res->score:0;
            $seo_friendly_url = isset($res->seo_friendly) && $res->seo_friendly == 1?'Yes':'No';
            $favicon = isset($res->favicon) && $res->favicon == 1?'Yes':'No';
            $CurPageURL = $row->url;
            
        }
    }
}
