<?php

namespace App\Shell;
use Cake\Console\Shell;
use App\Controller\TwilioController;

class TwilioShell extends Shell { 

	private $twilio;

	public function initialize() {
        parent::initialize();
        $this->twilio = new TwilioController();
    }

    public function main() {
        $location_id = 1;
        $apiKey = "AC3e486c4443c0e0b24e8427014b7acacb";
        $apisecret = "3c1a51246f8a564359d7ea63e3779549";

        $this->twilio->todayLog($location_id, $apiKey, $apisecret);
        $this->out("Twilio call log saved into database .");
    }

}