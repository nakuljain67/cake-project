<?php
/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link      http://cakephp.org CakePHP(tm) Project
 * @since     3.0.0
 * @license   http://www.opensource.org/licenses/mit-license.php MIT License
 */
namespace App\Shell;
require_once(ROOT . DS . 'vendor' . DS ."facebook1" . DS . "vendor" . DS . "autoload.php");
require_once(ROOT . DS . 'vendor' . DS ."facebook" . DS . "vendor" . DS . "autoload.php");
use Cake\ORM\TableRegistry;
use Cake\Console\ConsoleOptionParser;
use Cake\Console\Shell;
use Cake\Log\Log;
use FacebookAds\Api;
use FacebookAds\Object\User;
use FacebookAds\Object\AdAccount;
use FacebookAds\Object\AdAccountUser;
use FacebookAds\Object\Fields\AdAccountFields;
use FacebookAds\Object\Campaign;
use FacebookAds\Object\Fields\AdCampaignFields;
use FacebookAds\Object\Fields\AdSetFields;
use FacebookAds\Object\Fields\CampaignFields;
use FacebookAds\Object\Fields\AdFields;
use FacebookAds\Object\Fields\AdsInsightsFields;

class FacebookShell extends Shell
{

    /**
     * Start the shell and interactive console.
     *
     * @return int|null
     */
      public function updateToken()
        {
                    $users_table = $this->loadModel('ApiOptions');
                    $matchcount =$users_table->find()->where(['option_key' => 'facebook'])->first();
                    $data = json_decode($matchcount->option_value);     
                    $app_id =$data->clientId;
                    $app_secret =$data->secret;
                    $redirect = $data->redirect;
    $users1 = TableRegistry::get('api_locations');
    $missed = $users1->find('all')->where(['status' => '1'])->where(['fb_token != ""'])->toArray();
    foreach ($missed as $key => $new) {
       $data = json_decode($new->fb_token);
        $access_token =$data->token->access_token;
        $expires_in = $data->expires_in;
         $location_id = $new ->smart_location_id;
            $today=date('d-m-Y');
            if ($today == $expires_in)  {
            $graph_url = "https://graph.facebook.com/oauth/access_token?client_id=".$app_id."&client_secret=".$app_secret."&grant_type=fb_exchange_token&fb_exchange_token=".$access_token;
            $result = file_get_contents($graph_url);
            $new = json_decode($result);
            $access_token1 = $new->access_token;
            $graph_url1 = "https://graph.facebook.com/oauth/client_code?access_token=".$access_token1."&client_secret=".$app_secret."&redirect_uri=".$redirect."&client_id=".$app_id;
            $result1 = file_get_contents($graph_url1);
            $new1 = json_decode($result1);
            $code = $new1->code;
            $graph_url2 = "https://graph.facebook.com/oauth/access_token?code=".$code."&client_id=".$app_id."&redirect_uri=".$redirect;
              $result2 = file_get_contents($graph_url2);
              $new2 = json_decode($result2);
              $token = $new2->access_token;    
              $today = date('d-m-Y');
              $expires_in = date('d-m-Y', strtotime($today. ' + 30 days'));   
              $new = [];
              $new['token'] = $new2;
              $new['expires_in'] = $expires_in;     
              $users_table1 = TableRegistry::get('api_locations');
            $query = $users_table1->query();
          $query->update()->set(['fb_token' => json_encode($new)])->where(['smart_location_id' => $location_id])->execute();
           }  
          }   
        }

       public function Campaign() {
                  $users_table = $this->loadModel('ApiOptions');
                    $matchcount =$users_table->find()->where(['option_key' => 'facebook'])->first();
                    $data = json_decode($matchcount->option_value);     
                    $clientId =$data->clientId;
                    $secret =$data->secret;
                $users1 = TableRegistry::get('api_locations');
               $missed = $users1->find('all')->where(['status' => '1'])->where(['fb_token != ""'])->toArray();
                foreach ($missed as $key => $new) {
                  $data = json_decode($new->fb_token);
                    $access_token =$data->token->access_token;
                    $location_id = $new ->smart_location_id;
            // Initialize a new Session and instanciate an Api object
                Api::init($clientId, $secret, $access_token);
            // The Api object is now available trough singleton
            $api = Api::instance();
            $me = new User('me');
            $fields = array(
                  AdSetFields:: NAME,
                  AdSetFields:: ACCOUNT_ID,
                );
            $accounts = $me->getAdAccounts($fields);
                $account_id =[];
              $account_name =[];
              $i=0;
            // Output account ID  
            foreach ($accounts as $account) {
            if ($account->account_id != "263632148") {
             $account_id = $account->account_id;
             $account_name = $account->name;
             $account = new AdAccount($account->id);
             $params = array(
                 'limit' => 1000,
            );
             $fields = array(
              CampaignFields::NAME,
              CampaignFields::OBJECTIVE,
              CampaignFields::STATUS, 
            );
            $campaigns = $account->getCampaigns($fields, $params);
            foreach ($campaigns as $campaign) {
                 $users_table = $this->loadModel('FacebookCampaign');
                 $insert = $users_table->newEntity();
                 $insert->location_id =$location_id;
                 $insert->account_id= $account_id;
                 $insert->account_name = $account_name;
                 $insert->campaign_id = $campaign->id; 
                  $insert->campaign_name =$campaign->name;
                  $insert->status = $campaign->status;
                  $insert->objective = $campaign->objective;
                  $fields = array (
                     AdsInsightsFields:: IMPRESSIONS  ,
                     AdsInsightsFields:: CLICKS ,
                     AdsInsightsFields:: SPEND ,
                     AdsInsightsFields:: CPC ,
                     AdsInsightsFields:: CTR ,
            );
              $campaign = new Campaign($campaign->id);
              $stats = $campaign->getInsights($fields);
               foreach ($stats as $stat)  {
                  $insert->impression = $stat->impressions;
                   $insert->clicks = $stat->clicks;
                   $insert->spent = $stat->spend;
                    $insert->cpc = $stat->cpc;
                     $insert->ctr = $stat->ctr;
                  }
                  $users_table->save($insert);
 }
}
}
}
}

public function Ad() {  
                     $users_table = $this->loadModel('ApiOptions');
                    $matchcount =$users_table->find()->where(['option_key' => 'facebook'])->first();
                    $data = json_decode($matchcount->option_value);     
                    $clientId =$data->clientId;
                    $secret =$data->secret;
          $users1 = TableRegistry::get('api_locations');
           $missed = $users1->find('all')->where(['status' => '1'])->where(['fb_token != ""'])->toArray();
            foreach ($missed as $key => $new) {
              $data = json_decode($new->fb_token);
                $access_token =$data->token->access_token;
                $location_id = $new ->smart_location_id;
        // Initialize a new Session and instanciate an Api object
             Api::init($clientId, $secret, $access_token);
        // The Api object is now available trough singleton
          $api = Api::instance();
          $me = new User('me');
            $fields = array(
            AdSetFields:: NAME,
            AdSetFields:: ACCOUNT_ID,
            );
          $accounts = $me->getAdAccounts($fields);
        // Output account ID
          foreach ($accounts as $account) {
            if ($account->account_id != "263632148") {
            $account_id = $account->account_id;
            $account_name = $account->name;
            $account = new AdAccount($account->id);
             $params = array(
               'limit' => 1000,
                 );
            $fields = array(
              AdFields::NAME,
              AdFields::STATUS, 
               AdFields:: BID_AMOUNT,
               AdFields:: CREATED_TIME,
                AdFields::CAMPAIGN_ID,
                AdFields::ADSET_ID,
            );
          $campaigns = $account->getAds($fields, $params);

               foreach ($campaigns as $campaign) {
                 $users_table = TableRegistry::get('facebook_ads');
                $insert = $users_table->newEntity();
                $insert->location_id =$location_id;
                $insert->account_id= $account_id;
                $insert->account_name = $account_name;
                $insert->ad_id = $campaign->id; 
                $insert->ad_name =$campaign->name;
                $insert->status = $campaign->status;
                $insert->amount = $campaign->bid_amount;
                $insert->ad_creation= $campaign->created_time;
                $insert->ad_set_id= $campaign->adset_id;
                $insert->campaign_id= $campaign->campaign_id;
                     $fields = array (
                   AdsInsightsFields::IMPRESSIONS  ,
                   AdsInsightsFields::CLICKS ,
                   AdsInsightsFields::SPEND ,
                   AdsInsightsFields:: CPC ,
                   AdsInsightsFields:: CTR ,
        );
          $campaign = new Ad($campaign->id);
          $stats = $campaign->getInsights($fields);
           foreach ($stats as $stat)  {
              $insert->impression = $stat->impressions;
               $insert->clicks = $stat->clicks;
               $insert->spent = $stat->spend;
                $insert->cpc = $stat->cpc;
                 $insert->ctr = $stat->ctr;
              }

                $users_table->save($insert);
        }
  }
}
}
}

public function AdSet() 
{
    $users_table = $this->loadModel('ApiOptions');
                    $matchcount =$users_table->find()->where(['option_key' => 'facebook'])->first();
                    $data = json_decode($matchcount->option_value);     
                    $clientId =$data->clientId;
                    $secret =$data->secret;
          $users1 = TableRegistry::get('api_locations');
         $missed = $users1->find('all')->where(['status' => '1'])->where(['fb_token != ""'])->toArray();
          foreach ($missed as $key => $new) {
             $data = json_decode($new->fb_token);
              $access_token =$data->token->access_token;
              $location_id = $new ->smart_location_id;
      // Initialize a new Session and instanciate an Api object
           Api::init($clientId, $secret, $access_token);
          // The Api object is now available trough singleton
        $api = Api::instance();
        $me = new User('me');
        $fields = array(
          AdSetFields:: NAME,
          AdSetFields:: ACCOUNT_ID,
          );
        $accounts = $me->getAdAccounts($fields);
        // Output account ID
        foreach ($accounts as $account) {
         if ($account->account_id != "263632148") {
          $account_id = $account->account_id;
          $account_name = $account->name;
          $account = new AdAccount($account->id);
           $params = array(
            'limit' => 1000,
              );
          $fields = array(
            AdSetFields:: NAME,
            AdSetFields:: STATUS, 
            AdSetFields:: BID_AMOUNT,
            AdSetFields:: CREATED_TIME,
            AdSetFields:: CAMPAIGN_ID,
          );
            $campaigns = $account->getAdSets($fields, $params);
             foreach ($campaigns as $campaign) {
               $users_table = TableRegistry::get('facebook_ad_sets');
             $insert = $users_table->newEntity();
              $insert->location_id = $location_id;
             $insert->account_id= $account_id;
             $insert->account_name = $account_name;
              $insert->ad_id = $campaign->id; 
              $insert->ad_name =$campaign->name;
              $insert->status = $campaign->status;
              $insert->amount = $campaign->bid_amount;
              $insert->ad_creation= $campaign->created_time;
              $insert->campaign_id= $campaign->campaign_id;
                   $fields = array (
               AdsInsightsFields::IMPRESSIONS  ,
               AdsInsightsFields::CLICKS ,
               AdsInsightsFields::SPEND ,
               AdsInsightsFields:: CPC ,
               AdsInsightsFields:: CTR ,
      );
        $campaign = new AdSet($campaign->id);
        $stats = $campaign->getInsights($fields);
         foreach ($stats as $stat)  {
            $insert->impression = $stat->impressions;
             $insert->clicks = $stat->clicks;
             $insert->spent = $stat->spend;
              $insert->cpc = $stat->cpc;
               $insert->ctr = $stat->ctr;
            }
              $users_table->save($insert);
        }
    }
  }
}
  }


}
