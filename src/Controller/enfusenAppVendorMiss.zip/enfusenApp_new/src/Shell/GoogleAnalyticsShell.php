<?php

namespace App\Shell;

use Cake\Console\ConsoleOptionParser;
use Cake\Console\Shell;
use Cake\Log\Log;
use App\Controller\AppController;
use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[] paginate($object = null, array $settings = [])
 */
class GoogleAnalyticsShell extends Shell {

    private $app;
    private $conn;
    private $smartdata;
    private $smart;
    
    public function initialize() {
        parent::initialize();
        ini_set('max_execution_time', 90000);
        $this->loadModel('Apilocations');
        $this->app = new AppController();
        $this->conn = ConnectionManager::get('default');
        $this->smartdata = "smart";
        $this->smart = ConnectionManager::get($this->smartdata);
    }

    public function main() {
        exit();
    }

    public function mainAnalytics($location_id = "", $StartDate = "", $EndDate = "") {
        try {
            if($StartDate == "" || $EndDate == ""){
                $date = date("Y-m-d", strtotime("-1 day"));
                $StartDate = $date;
                $EndDate = $date;
            }
            else{
                $StartDate = date("Y-m-d", strtotime($StartDate));
                $EndDate = date("Y-m-d", strtotime($EndDate));
            }
            
            $client = $this->app->googleclient();                                    
            // start metrics of GA
            $Metrics = GAPrefix . "pageviews, " . GAPrefix . "timeOnPage, " . GAPrefix . "bounceRate"; //.GAPrefix."adClicks"
            $Dimensions = GAPrefix . "hostname, " . GAPrefix . "pagePath, " . GAPrefix . "source, " . GAPrefix . "medium, " . GAPrefix . "date, " . GAPrefix . "hour, " . GAPrefix . "minute";
            $RptParams = array('dimensions' => $Dimensions, 'sort' => "-" . GAPrefix . "source", 'max-results' => '10000', 'start-index' => 1);
            // end metrics of GA                                  
              
            if($location_id > 0){
                $dataexists = $this->Apilocations->find("All")->select(['Apilocations.smart_location_id', 
                    'Apilocations.google_token', 'Apilocations.analytics_child'])->where([
                    'AND' => ['Apilocations.status' => "1", 'Apilocations.google_token !=' => "", 'Apilocations.smart_location_id' => $location_id]
                ]);
            }
            else{
                $dataexists = $this->Apilocations->find("All")->select(['Apilocations.smart_location_id', 
                    'Apilocations.google_token', 'Apilocations.analytics_child'])->where([
                    'AND' => ['Apilocations.status =' => "1", 'Apilocations.google_token !=' => ""]
                ]);
            }
            
            $results = $dataexists->all();            
            foreach ($results as $result) {
                $location_id = $result->smart_location_id;
                
                $sql = "SHOW TABLES LIKE 'api_main_analytics_".$location_id."'";
                $stmt = $this->conn->execute($sql);
                $row = $stmt->fetch('obj');
                if (empty($row)) {
                    // create table main analytics table
                    $main_analytic_file = ROOT . DS . 'vendor' . DS . "dynamic_tables" . DS . "main_analytics.sql";
                    $main_analytic = file_get_contents($main_analytic_file);
                    $main_analytic = str_replace("[LOCATION_ID]", $location_id, $main_analytic);
                    $this->conn->execute($main_analytic);

                    // create table short analytics table
                    $short_analytic_file = ROOT . DS . 'vendor' . DS . "dynamic_tables" . DS . "short_analytics.sql";
                    $short_analytic = file_get_contents($short_analytic_file);
                    $short_analytic = str_replace("[LOCATION_ID]", $location_id, $short_analytic);
                    $this->smart->execute($short_analytic);
                }                
                  
                $google_token = $result->google_token;
                $google_childs = $result->analytics_child;
                if ($google_token != '' && $google_childs) {
                    $tokendetail = json_decode($google_token);
                    $analytic_childs = json_decode($google_childs);
                    
                    if (isset($analytic_childs->profile) && $analytic_childs->profile != '') {
                        $tableId = $analytic_childs->profile;
                        $client->fetchAccessTokenWithRefreshToken($tokendetail->refresh_token);
                        $analytics = new \Google_Service_Analytics($client);

                        $StopFlag = false;
                        $RptDataRows = array();
                        while (!$StopFlag) {
                            $RptData = $analytics->data_ga->get(urldecode(GAPrefix . $tableId), $StartDate, $EndDate, $Metrics, $RptParams);                            
                            $CurRptDataRows = $RptData->getRows();                            
                            
                            foreach ($CurRptDataRows as $CurRptDataRow)
                                $RptDataRows[] = $CurRptDataRow;
                            $StopFlag = !($RptData != null && $RptData->nextLink != null);
                            $RptParams['start-index'] = $RptParams['start-index'] + $RptParams['max-results'];
                        }

                        $this->save_main_ga_data($location_id, $tableId, $RptDataRows, $StartDate, $EndDate);
                    }
                }
                
            }
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
        }
    }
        
    private function save_main_ga_data($location_id, $tableId, $RptDataRows, $StartDate, $EndDate) {             
        
        $main_analytics = TableRegistry::get('api_main_analytics_' . $location_id, array('table' => 'api_main_analytics_' . $location_id));
        // start : delete already have data of dates
        $main_analytics->deleteAll([
            'AND' => ['location_id' => $location_id, 'dateOfVisit >=' => $StartDate, 'dateOfVisit <=' => $EndDate]
        ]);        
        // end : delete already have data of dates
        
        $results = array();        
        foreach ($RptDataRows as $RptDataRow) {
            $res = array();
            $res['location_id'] = $location_id;
            $res['tableId'] = $tableId;
            $res['pageURL'] = $RptDataRow[0] . $RptDataRow[1];
            $res['source'] = $RptDataRow[2];
            $res['medium'] = $RptDataRow[3];
            $res['dateOfVisit'] = date("Y-m-d",  strtotime($RptDataRow[4]));
            $res['timeOfVisit'] = $RptDataRow[5].':'.$RptDataRow[6];
            
            $res['visits'] = $RptDataRow[7];            
            $res['timeOnSite'] = $RptDataRow[8];
            $res['bounceRate'] = $RptDataRow[9];            
            $res['created'] = date("Y-m-d H:i:s");            
            $results[] = $res;
        }
        
        $entities = $main_analytics->newEntities($results);
        $main_analytics->saveMany($entities);
    }
    
}
