<?php

namespace App\Shell;

use Cake\Console\Shell;
use Cake\ORM\TableRegistry;
use App\Controller\AppController;
use App\Controller\CreController;
use Cake\Datasource\ConnectionManager;

class RunKeywordShell extends Shell {

    private $app;
    private $smartdata;
    private $smart;

    public function initialize() {
        parent::initialize();
        $this->app = new AppController();
        $this->smartdata = "smart";
        $this->smart = ConnectionManager::get($this->smartdata);
        $this->connection = ConnectionManager::get('default');
    }

    public function main() {
        $this->out("You are in");
    }

    public function autoSyncKeywords($location_id) {
        
        $arr_campaigns = array();
        $not_need_btl_acc = array();
        $sqlQueryToGetAllCampaigns = "SELECT * FROM tbl_campaigns WHERE location_id = ".$location_id." AND status = 1";
        $new_campaigns = $this->smart->execute($sqlQueryToGetAllCampaigns)->fetchAll("assoc");
        $weekday = 'Monday';
        $today = date('l');
        $now = time();

        if (count($new_campaigns) > 0) {

            foreach ($new_campaigns as $index => $new_campaign) {

                $location_id = $new_campaign['location_id'];
                $campaign_id = $new_campaign['id'];
                $user_id = $new_campaign['modified_by'];

                if (!in_array($location_id, $not_need_btl_acc)) {
                    $checkvalidloc = $this->checklocationvalidity($location_id);
                    if ($checkvalidloc) {
                        $showallkeywords = 0;
                        if ($new_campaign['is_running'] == 1) {
                            // brand new report generated
                            $report_result = $this->getrankreporthourly($new_campaign, $user_id, $location_id, $showallkeywords);
                        } else {
                            $sqlQueryToInsert = "SELECT count(id) as total FROM tbl_campaigns_temp WHERE campaign_id = " . $campaign_id;
                            $result = $this->smart->execute($sqlQueryToInsert)->fetchAll("assoc");
                            if (!empty($result)) {
                                $onlykeywordsrun = $result[0]['id'];
                                if ($onlykeywordsrun > 0) {
                                    // get report where only keywords run, delete it once completed
                                    $report_result = $this->getpartialrankreport($new_campaign, $user_id, $location_id, $showallkeywords);
                                }
                            }
                        }
                    }
                }
            }
        } else {
            $this->app->json(0, "No Running Campaign Found");
        }
    }

    // function to be add to crontab - dev - 4 July 2017
    public function dailyKeywordsCheck($location_id) {

        $this->autoRender = false;

        $arr_campaigns = array();
        $not_need_btl_acc = array();
        $sqlQueryToGetAllCampaigns = "SELECT * FROM tbl_campaigns WHERE location_id = ".$location_id." AND status = 1";
        $new_campaigns = $this->smart->execute($sqlQueryToGetAllCampaigns)->fetchAll("assoc");
        $weekday = 'Monday';
        $today = date('l');
        $now = time();

        if (count($new_campaigns) > 0) {

            foreach ($new_campaigns as $index => $new_campaign) {

                $location_id = $new_campaign['location_id'];
                $campaign_id = $new_campaign['id'];
                $user_id = $new_campaign['modified_by'];

                if (!in_array($location_id, $not_need_btl_acc)) {

                    $checkvalidloc = $this->checklocationvalidity($location_id);

                    if ($checkvalidloc) {

                        $showallkeywords = 0;

                        if ($new_campaign['is_running'] == 0) {

                            $campaignid = $new_campaign['id'];
                            // Start get weekly scheduled report result
                            if ($today == $weekday) {
                                $report_result = $this->getrankreporthourly($new_campaign, $user_id, $location_id, $showallkeywords);
                            }
                            // End get weekly scheduled report result

                            if (trim($new_campaign['ranking_id']) != '') {

                                $sq = "SELECT count(k.id) FROM tbl_keywords k INNER JOIN tbl_keygroup g ON k.group_id = "
                                        . "g.id WHERE k.location_id = :location_id AND g.location_id = :location_id AND g.status = 1 AND k.campaign_id = :campaign_id AND (k.rankdetail = '' OR k.rankdetail IS NULL)";
                                $chechasvalidkeywords = $this->smart->execute($sq, ["location_id" => $location_id, "campaign_id" => $campaignid])->fetchAll("assoc");

                                if ($chechasvalidkeywords > 0) {
                                    $report_result = $this->runOnlyKeywordsDailyCheck($new_campaign, $showallkeywords, $user_id, $location_id);
                                }
                            } else {
                                $sq = "SELECT count(k.id) FROM tbl_keywords k INNER JOIN tbl_keygroup g ON k.group_id = "
                                        . "g.id WHERE k.location_id = :location_id AND g.location_id = :location_id AND g.status = 1 AND k.campaign_id = :campaign_id";
                                $chechasvalidkeywords = $this->smart->execute($sq, ["location_id" => $location_id, "campaign_id" => $campaignid])->fetchAll("assoc");
                                if ($chechasvalidkeywords > 0) {
                                    $report_result = $this->runKeywordCampaignDailyCheck($new_campaign, $showallkeywords, $user_id, $location_id);
                                }
                            }
                        }
                    }
                }
            }
        } else {

            $this->app->json(0, "No Campaign Found to run");
        }
    }

    public function runKeywordCampaignDailyCheck($campaign, $showallkeywords, $user_id, $location_id) {

        $UserID = $user_id;

        $locationDetails = $this->getLocationDetails($location_id);

        $bname = $locationDetails['location_name'];
        if ($bname == '') {
            return FALSE;
        }

        $all_competitors = $this->getAllCompetitors($location_id, "daily_chk_keyword");
        $removed_http = array();
        //fetch all competitors
        foreach ($all_competitors as $index => $value) {
            array_push($removed_http, str_replace(array("http://", "https://", "/", "www."), "", $value->website));
        }

        $competitor_urls = $removed_http;
        $name = $campaign['name'];
        $campaignid = $campaign['id'];
        $ranking_id = $campaign['ranking_id'];
        $target_country = $campaign['target_country'];

        $sqlQuery = "SELECT k.keyword FROM tbl_keywords k INNER JOIN tbl_keygroup g "
                . "ON k.group_id = g.id WHERE k.location_id = :location_id AND g.location_id = :location_id AND k.campaign_id = :campaign_id AND g.status = 1";
        $keywords = $this->smart->execute($sqlQuery, ["location_id" => $location_id, "campaign_id" => $campaignid])->fetchAll("assoc");

        if (empty($keywords)) {
            return FALSE;
        }

        $placeclient = $this->get_option($locationDetails['agency_id'], 'place_client_id');
        $placesscout_api_info = $this->getCredentials();
        $username = $placesscout_api_info['username'];
        $password = $placesscout_api_info['password'];
        $main_api_url = $placesscout_api_info['api_url'];

        if (!$placeclient) {

            $client = array();
            $client['Name'] = $locationDetails['agency_name'];
            $client['CustomClientId'] = md5($locationDetails['agency_id']); //md5(DB_NAME);
            $client['PrimaryEmail'] = $locationDetails['agency_email'];
            $curl_url = 'clients';
            $new_client = $this->app->pc_post($username, $password, $main_api_url, $curl_url, json_encode($client)); //Create New Client
            $new_client = json_decode($new_client);
            $client_id = $new_client->id;
            $customClientId = $new_client->customClientId;
            $this->set_option($locationDetails['agency_id'], 'place_client_id', $client_id);
            $this->set_option($locationDetails['agency_id'], 'custom_client_id', $customClientId);
        } else {

            $client_id = $placeclient;

            $customClientId = $this->get_option($locationDetails['agency_id'], 'custom_client_id');
        }

        if (empty($locationDetails['country_id'])) {
            return false;
        }
        if (empty($locationDetails['state_id'])) {
            return false;
        }
        if (empty($locationDetails['city_id'])) {
            return false;
        }
        if (empty($locationDetails['website'])) {
            return false;
        }
        if (empty($locationDetails['address'])) {
            return false;
        }

        $country = trim(trim($this->getCountryDetailsById($locationDetails['country_id'])));
        $state = trim(trim($this->getStateDetailsById($locationDetails['state_id'])));
        $city = trim(trim($this->getCityDetailsById($locationDetails['city_id'])));
        $website = $locationDetails['website'];
        $address = trim($locationDetails['address']);
        $zipCode = $locationDetails['zip_code'];
        $place_location_id = $this->get_user_meta($location_id, "place_location_id", TRUE);



        if ($place_location_id == "") {
            $location = array();
            $location['ClientId'] = $client_id;
            $location['BusinessName'] = $bname;
            $location['LocationName'] = $bname;
            $location['StreetAddress'] = $address;
            $location['City'] = $city;
            $location['State'] = $state;
            $location['Zip'] = $zipCode;
            $location['Country'] = $country;
            $location['Email'] = $locationDetails['location_email'];
            $location['Website'] = $website;
            $curl_url = 'clientlocations';

            $new_location = $this->app->pc_post($username, $password, $main_api_url, $curl_url, json_encode($location)); //Create New Client
            $new_location = json_decode($new_location);
            $place_location_id = $new_location->id;
            $this->add_user_meta($location_id, "place_location_id", $place_location_id);
        }

        // report generate
        $rankreport = array();
        $rankreport['LocationId'] = $place_location_id;
        $rankreport['ClientId'] = $client_id;
        $rankreport['Name'] = $name;
        $rankreport['SelectedCountry'] = $target_country;
        $rankreport['SelectedSearchEngines'] = array(
            array('SearchEngine' => 'GoogleOrganic', 'NumberOfResultsToGather' => 50),
            array('SearchEngine' => 'GooglePlaces', 'NumberOfResultsToGather' => 50),
            array('SearchEngine' => 'BingOrganic', 'NumberOfResultsToGather' => 50),
            array('SearchEngine' => 'BingMaps', 'NumberOfResultsToGather' => 50),
            array('SearchEngine' => 'GoogleMobileOrganic', 'NumberOfResultsToGather' => 50),
            array('SearchEngine' => 'GoogleMobileMaps', 'NumberOfResultsToGather' => 50)
        );

        $tracked_sites = array();
        $tracked_site = array(
            'Site' => $website,
            'TrackedSiteType' => 'Website'
        );
        array_push($tracked_sites, $tracked_site);

        if (!empty($competitor_urls)) {
            foreach ($competitor_urls as $competitor_url) {
                if (trim($competitor_url) != '') {
                    $tracked_site = array(
                        'Site' => $competitor_url,
                        'TrackedSiteType' => 'Website'
                    );
                    array_push($tracked_sites, $tracked_site);
                }
            }
        }

        $rankreport['TrackedSites'] = $tracked_sites;
        $rankreport['CarouselBusinessName'] = $bname;
        $listkeywords = array();

        foreach ($keywords as $index => $keyword) {
            $google_location = $campaign['local_location'];
            if (empty($google_location) || $google_location == '') {
                $google_location = $campaign['target_country'];
            }

            $ar = array(
                'Keyword' => $keyword['keyword'],
                'GoogleLocation' => "$google_location"
            );

            array_push($listkeywords, $ar);
        }

        $rankreport['KeywordSearches'] = $listkeywords;

        $rankreport['SchedulerSettings'] = array(
            'RepeatInterval' => 'Weekly',
            'DaysOfWeek' => array("sunday")
        );

        if ($ranking_id == '' || empty($ranking_id)) {
            // new rank report
            $curl_url = 'rankingreports';
            $rank_report = $this->app->pc_post($username, $password, $main_api_url, $curl_url, json_encode($rankreport)); //Create New Client
            $rank_report = json_decode($rank_report);
            if ($rank_report->responseStatus->errorCode) {
                //fetch_error(site_url(), $user_id, $campaign, json_encode($rank_report));
                return FALSE;
            }

            $ranking_id = $rank_report->id;

            $sqlQueryToUpdate = "UPDATE tbl_campaigns SET ranking_id = ':ranking_id' WHERE id = :id";
            $this->smart->execute($sqlQueryToUpdate, ["ranking_id" => $ranking_id, "id" => $campaignid]);

            // run rank report
        } else {
            //update and // run report rank report
            $rankreport['Id'] = $ranking_id;
            $curl_url = 'rankingreports/' . $ranking_id;
            $rank_report = $this->pc_put($username, $password, $main_api_url, $curl_url, json_encode($rankreport)); //Create New Client
            $rank_report = json_decode($rank_report);
            if ($rank_report->responseStatus->errorCode) {
                //fetch_error(site_url(), $user_id, $campaign, json_encode($rank_report));
                return FALSE;
            }
        }

        // Run Rank Report
        $runreport = array(
            'ReportId' => $ranking_id
        );
        $curl_url = 'rankingreports/' . $ranking_id . '/runreport/';
        $res = $this->app->pc_post($username, $password, $main_api_url, $curl_url, json_encode($runreport)); //Run Rank Report
        $res = json_decode($res);
        if ($res->responseStatus->errorCode) {
            //fetch_error(site_url(), $user_id, $campaign, json_encode($rank_report));                        
            return FALSE;
        }
        $sqlQueryToUpdateData = "UPDATE tbl_campaigns SET is_running = 1, rundate = NOW() WHERE id = :id";
        $this->smart->execute($sqlQueryToUpdateData, ["id" => $campaignid]);
        return TRUE;
    }

    public function runOnlyKeywordsDailyCheck($campaign, $showallkeywords, $user_id, $location_id) {

        $UserID = $user_id;
        $locationDetails = $this->getLocationDetails($location_id);
        $bname = $locationDetails['location_name'];
        if ($bname == '') {
            return FALSE;
        }
        $all_competitors = $this->getAllCompetitors($location_id, "daily_chk_keyword");
        $removed_http = array();
        //fetch all competitors
        foreach ($all_competitors as $index => $value) {
            array_push($removed_http, str_replace(array("http://", "https://", "/", "www."), "", $value->website));
        }
        $competitor_urls = $removed_http;

        $name = $campaign['name'];
        $campaignid = $campaign['id'];
        $ranking_id = $campaign['ranking_id'];
        $target_country = $campaign['target_country'];
        if ($ranking_id == '' || empty($ranking_id)) {
            return FALSE;
        }

        $sqlQueryKeywords = "SELECT k.keyword FROM tbl_keywords k INNER JOIN tbl_keygroup g "
                . "ON k.group_id = g.id WHERE k.location_id = :location_id AND g.location_id = :location_id AND k.campaign_id = :campaign_id AND g.status = 1";
        $keywords = $this->smart->execute($sqlQueryKeywords, ["location_id" => $location_id, "campaign_id" => $campaignid])->fetchAll("assoc");

        $sqlQueryNewKeywords = "SELECT k.id, k.keyword FROM tbl_keywords k INNER JOIN tbl_keygroup g "
                . "ON k.group_id = g.id WHERE k.location_id = :location_id AND g.location_id = :location_id AND k.campaign_id = :campaign_id AND k.rankdetail IS NULL AND g.status = 1";
        $newkeywords = $this->smart->execute($sqlQueryNewKeywords, ["location_id" => $location_id, "campaign_id" => $campaignid])->fetchAll("assoc");

        if (empty($newkeywords)) {
            return FALSE;
        }

        // array build for new keywords
        $listnewkeywords = array();
        $idskeywords = "";
        foreach ($newkeywords as $index => $keyword) {
            $keyid = $keyword['id'];
            $sql = "SELECT count(id) as total FROM tbl_campaigns_temp WHERE campaign_id = $campaignid AND FIND_IN_SET($keyid, idskeywords)";
            $exs = $this->smart->execute($sql)->fetchAll("assoc");
            if (!empty($exs) && count($exs) > 0) {
                continue;
            }
            $idskeywords .= $keyid . ",";
            $google_location = $campaign['local_location'];
            if (empty($google_location) || $google_location == '') {
                $google_location = $campaign['target_country'];
            }

            $ar = array(
                'Keyword' => $keyword['keyword'],
                'GoogleLocation' => "$google_location"
            );

            array_push($listnewkeywords, $ar);
        }
        // send back if already sub keyword report executing
        if ($idskeywords == "") {
            return FALSE;
        }
        $idskeywords = substr($idskeywords, 0, -1);
        // end : array build for new keywords        

        $placeclient = $client_id = $this->get_option($locationDetails['agency_id'], 'place_client_id');
        $placesscout_api_info = $this->getCredentials();
        $username = $placesscout_api_info["username"];
        $password = $placesscout_api_info["password"];
        $main_api_url = $placesscout_api_info["api_url"];

        if (!$placeclient) {
            return FALSE;
        }

        $country = trim(trim($this->getCountryDetailsById($locationDetails['country_id'])));
        $state = trim(trim($this->getStateDetailsById($locationDetails['state_id'])));
        $city = trim(trim($this->getCityDetailsById($locationDetails['city_id'])));
        $website = $locationDetails['website'];
        $address = trim($locationDetails['address']);
        $zipCode = $locationDetails['zip_code'];
        $place_location_id = $this->get_user_meta($location_id, "place_location_id", TRUE);

        if ($place_location_id == '') {
            return FALSE;
        }

        // report generate
        $rankreport = array();
        $rankreport['LocationId'] = $place_location_id;
        $rankreport['ClientId'] = $client_id;
        $rankreport['Name'] = $name;
        $rankreport['SelectedCountry'] = $target_country;
        $rankreport['SelectedSearchEngines'] = array(
            array('SearchEngine' => 'GoogleOrganic', 'NumberOfResultsToGather' => 50),
            array('SearchEngine' => 'GooglePlaces', 'NumberOfResultsToGather' => 50),
            array('SearchEngine' => 'BingOrganic', 'NumberOfResultsToGather' => 50),
            array('SearchEngine' => 'BingMaps', 'NumberOfResultsToGather' => 50),
            array('SearchEngine' => 'GoogleMobileOrganic', 'NumberOfResultsToGather' => 50),
            array('SearchEngine' => 'GoogleMobileMaps', 'NumberOfResultsToGather' => 50)
        );

        $tracked_sites = array();
        $tracked_site = array(
            'Site' => $website,
            'TrackedSiteType' => 'Website'
        );
        array_push($tracked_sites, $tracked_site);

        if (!empty($competitor_urls)) {
            foreach ($competitor_urls as $competitor_url) {
                if (trim($competitor_url) != '') {
                    $tracked_site = array(
                        'Site' => $competitor_url,
                        'TrackedSiteType' => 'Website'
                    );
                    array_push($tracked_sites, $tracked_site);
                }
            }
        }

        $rankreport['TrackedSites'] = $tracked_sites;
        $rankreport['CarouselBusinessName'] = $bname;
        $listkeywords = array();

        foreach ($keywords as $inx => $keyword) {
            $google_location = $campaign['local_location'];
            if (empty($google_location) || $google_location == '') {
                $google_location = $campaign['target_country'];
            }

            $ar = array(
                'Keyword' => $keyword['keyword'],
                'GoogleLocation' => "$google_location"
            );

            array_push($listkeywords, $ar);
        }

        $rankreport['KeywordSearches'] = $listkeywords;

        $rankreport['SchedulerSettings'] = array(
            'RepeatInterval' => 'Weekly',
            'DaysOfWeek' => array("sunday")
        );

        // update only report at placesscout
        $rankreport['Id'] = $ranking_id;
        $curl_url = 'rankingreports/' . $ranking_id;
        $rank_report = $this->pc_put($username, $password, $main_api_url, $curl_url, json_encode($rankreport)); //Create New Client
        $rank_report = json_decode($rank_report);
        if ($rank_report->responseStatus->errorCode) {
            //fetch_error(site_url(), $user_id, $campaign, json_encode($rank_report));
            return FALSE;
        }

        // add new report for selective keywords only, it will delete once, report will produce result
        unset($rankreport['KeywordSearches']);
        unset($rankreport['SchedulerSettings']);
        unset($rankreport['Name']);

        $rankreport['Name'] = $name . '_' . $campaignid;
        $rankreport['KeywordSearches'] = $listnewkeywords;
        $curl_url = 'rankingreports';
        $rank_report_new = $this->app->pc_post($username, $password, $main_api_url, $curl_url, json_encode($rankreport)); //Create New report
        $rank_report_new = json_decode($rank_report_new);
        if ($rank_report_new->responseStatus->errorCode) {
            //fetch_error(site_url(), $user_id, $campaign, json_encode($rank_report_new));
            return FALSE;
        }
        $ranking_id = $rank_report_new->id;
        // add new report         
        // Run new keywords report
        $runreport = array(
            'ReportId' => $ranking_id
        );
        $curl_url = 'rankingreports/' . $ranking_id . '/runreport/';
        $res = $this->app->pc_post($username, $password, $main_api_url, $curl_url, json_encode($runreport)); //Run Rank Report
        $res = json_decode($res);
        if ($res->responseStatus->errorCode) {
            //fetch_error(site_url(), $user_id, $campaign, json_encode($rank_report));                        
            return FALSE;
        }

        // add keywords that are running with new rank report id
        $campaigntbl = TableRegistry::get('tbl_campaigns_temp');

        $arr_temp_campaipgn = array(
            "campaign_id" => $campaignid,
            "report_id" => $ranking_id,
            "idskeywords" => $idskeywords
        );
        $campaigntbl->save($arr_temp_campaipgn);

        return TRUE;
    }

    // function used in AutoSync Keyword API
    public function getrankreporthourly($campaign, $user_id, $location_id, $showallkeywords) {

        // This function only inserts new record or update existing record.
        $CurClientID = $location_id;
        $lastrankdate = '';
        $campaignid = $campaign['id'];
        if ($campaign['rankdate'] != '') {
            $lastrankdate = date("Y-m-d H:i:s", strtotime($campaign['rankdate']));
        }
        $placesscout_api_info = $this->getCredentials();
        $username = $placesscout_api_info["username"];
        $password = $placesscout_api_info["password"];
        $main_api_url = $placesscout_api_info["api_url"];

        $ranking_id = $campaign['ranking_id'];
        $curl_url = 'rankingreports/' . $ranking_id . '/runs/newest';

        $rank_report = $this->app->pc_get($username, $password, $main_api_url, $curl_url); //Create New Client    
        $rank_report = json_decode($rank_report);

        if (isset($rank_report->responseStatus) && $rank_report->responseStatus->errorCode) {
            // This function is used to make entry for error log 
            // error_log
            return FALSE;
        }
        if ($rank_report->isReportRunComplete != true) {
            return FALSE;
        }

        $results = $rank_report->keywordRankingResults;

        $locationDetails = $this->getLocationDetails($location_id);

        $rankdatestamp = $rank_report->date;
        $epoch = explode('(', $rankdatestamp);
        $timeseconds = (intval(substr(trim($epoch[1]), 0, -2))) / 1000;
        $rnkdate = date("Y-m-d H:i:s", $timeseconds);

        if ($lastrankdate == '' || $rnkdate > $lastrankdate) {

            // if report is completed
            $all_competitors = $this->getAllCompetitors($location_id);
            $removed_http = array();
            //fetch all competitors
            foreach ($all_competitors as $index => $value) {
                array_push($removed_http, str_replace(array("http://", "https://", "/", "www."), "", $value));
            }

            if (!empty($results)) {

                foreach ($results as $rankurl => $urlsdata) {

                    $rankurlcheck = str_replace(array("http://", "https://", "www."), array("", "", ""), $this->app->fully_trim($rankurl));

                    $comp_key_value = $this->searchForCompetitorValue($rankurlcheck, $removed_http);

                    if ($comp_key_value >= 0) {

                        // keywords table for client 
                        $keword_res = TableRegistry::get('tbl_keywords');
                        $queryToUpdateKeywords = $keword_res->query();
                        // competitors table for competitor
                        $competitor_res = TableRegistry::get('tbl_compititors_data');
                        $queryToUpdateCompetitorData = $competitor_res->query();

                        foreach ($urlsdata as $kyindex => $data) {

                            $keyword = strtolower(trim($data->keywordSearch->keyword));
                            // Matching Keyword in Db
                            $sqlQueryToFindKeyword = "SELECT id FROM tbl_keywords WHERE LOWER(TRIM(keyword)) = ':keyword' AND campaign_id = :campaign_id AND location_id = :location_id";

                            $keydataid = $this->smart->execute($sqlQueryToFindKeyword, ["keyword" => $keyword, "campaign_id" => $campaignid, "location_id" => $location_id])->fetchAll("assoc");

                            if (!empty($keydataid)) {

                                $keyword_id = $keydataid[0]['id'];
                                // for client url
                                if ($comp_key_value == 0) {

                                    $sqlQueryToInsert = "INSERT INTO tbl_keywords_history (campaign_id, group_id, "
                                            . "location_id, keyword, isprimary,ranked_url,rank,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank,dateOfRank,"
                                            . "googleSearchVolume, cpc, difficulty, user_id, created) "
                                            . "SELECT campaign_id, group_id,location_id, keyword, isprimary,ranked_url,rank,maps_rank,mobile_rank,mobile_maps_rank,bing_rank  ,bing_maps_rank,dateOfRank,"
                                            . "googleSearchVolume, cpc, difficulty, user_id, "
                                            . "created FROM tbl_keywords WHERE id = " . $keyword_id;

                                    $this->smart->execute($sqlQueryToInsert);
                                    // updating keyword

                                    $insert_opp['rank'] = $data->googleOrganicRankings->rank;
                                    $insert_opp['maps_rank'] = $data->googlePlacesRankings->rank;
                                    $insert_opp['mobile_rank'] = $data->googleMobileOrganicRankings->rank;
                                    $insert_opp['mobile_maps_rank'] = $data->googleMobileMapsRankings->rank;
                                    $insert_opp['bing_rank'] = $data->bingOrganicRankings->rank;
                                    $insert_opp['bing_maps_rank'] = $data->bingLocalRankings->rank;
                                    $insert_opp['dateOfRank'] = date("Y-m-d h:i:s");

                                    $keywordUpdateQuery = $queryToUpdateKeywords->update()
                                            ->set($insert_opp)
                                            ->where(['campaign_id' => $campaignid, "keyword" => $keyword, "id" => $keyword_id])
                                            ->execute();
                                } else {
                                    // for competitor url

                                    $insert_opp_comp['location_id'] = $location_id;
                                    $insert_opp_comp['keyword_id'] = $keyword_id;
                                    $insert_opp_comp['compt_id'] = $comp_key_value;
                                    $insert_opp_comp['ranked_url'] = $data->googleMobileMapsRankings->rankedUrl;
                                    $insert_opp_comp['rank'] = $data->bingOrganicRankings->rank;
                                    $insert_opp_comp['rank_date'] = date("Y-m-d h:i:s");
                                    $insert_opp_comp['user_id'] = $user_id;
                                    $insert_opp_comp['created'] = date("Y-m-d h:i:s");
                                    $insert_opp_comp['created_by'] = $user_id;

                                    $isThisRecordExists = "SELECT id FROM tbl_compititors_data WHERE keyword_id = :keyword_id AND location_id = :location_id";
                                    $is_exists_result = $this->smart->execute($isThisRecordExists, ["keyword_id" => $keyword_id, "location_id" => $location_id])->fetchAll("assoc");

                                    if (!empty($is_exists_result)) {

                                        $sqlQueryToInsert = "INSERT INTO tbl_compititors_data_history (location_id, keyword_id, "
                                                . "compt_id, ranked_url, rank,rank_date,user_id,created,created_by) "
                                                . "SELECT location_id, keyword_id,location_id, compt_id, ranked_url, rank,rank_date,user_id,created,created_by"
                                                . " FROM tbl_compititors_data WHERE keyword_id = " . $keyword_id . " AND location_id = " . $location_id;

                                        // updating keyword
                                        $keywordUpdateQuery = $queryToUpdateCompetitorData->update()
                                                ->set($insert_opp_comp)
                                                ->where(['campaign_id' => $campaignid, "keyword" => $keyword, "location_id" => $location_id])
                                                ->execute();
                                    } else {

                                        $comp_entity = $competitor_res->newEntity($insert_opp_comp);
                                        $keword_res->save($comp_entity);
                                    }
                                }
                            } else {
                                // insert keyword  

                                if ($comp_key_value == 0) {
                                    // for client url
                                    $insert_opp['rank'] = $data->googleOrganicRankings->rank;
                                    $insert_opp['maps_rank'] = $data->googlePlacesRankings->rank;
                                    $insert_opp['mobile_rank'] = $data->googleMobileOrganicRankings->rank;
                                    $insert_opp['mobile_maps_rank'] = $data->googleMobileMapsRankings->rank;
                                    $insert_opp['bing_rank'] = $data->bingOrganicRankings->rank;
                                    $insert_opp['bing_maps_rank'] = $data->bingLocalRankings->rank;
                                    $insert_opp['dateOfRank'] = date("Y-m-d h:i:s");

                                    $entity = $keword_res->newEntity($insert_opp);
                                    $keword_res->save($entity);
                                    $new_keyword_id = $entity->id;
                                }
                            }
                        }
                    }
                }// foreach loop ends
            } // if else ends here
        }
    }

    public function fetch_error($agencyUrl, $user_id, $campaign, $error) {
        // error log entry here 
    }

    public function checklocationvalidity($location_id) {        
        return false;
//        $sql = 'SELECT status FROM tbl_locations WHERE id = ' . $location_id;
//        $sqlResult = $this->smart->execute($sql)->fetchAll("assoc");
//        if (!empty($sqlResult)) {
//            if ($sqlResult[0]['status'] == 1) {
//                return true;
//            }
//            return false;
//        }
//        return false;
    }

    public function getpartialrankreport($campaign, $user_id, $location_id, $showallkeywords) {
        // Working
        $CurClientID = $location_id;
        $campaignid = $campaign['id'];
        $sqlQueryToRun = "SELECT * FROM tbl_campaigns_temp WHERE campaign_id = :campaign_id";
        $tempcamps = $this->smart->execute($sqlQueryToRun, ["campaign_id" => $campaignid])->fetchAll("assoc");
        if (empty($tempcamps)) {
            return false;
        }
        // get data from placescout
        $placesscout_api_info = $this->getCredentials();
        $username = $placesscout_api_info["username"];
        $password = $placesscout_api_info["password"];
        $main_api_url = $placesscout_api_info["api_url"];

        foreach ($tempcamps as $index => $tempcamp) {
            $id = $tempcamp['id'];
            $ranking_id = $tempcamp['report_id'];
            $curl_url = 'rankingreports/' . $ranking_id . '/runs/newest';
            $rank_report = $this->app->pc_get($username, $password, $main_api_url, $curl_url); //Create New Client    
            $rank_report = json_decode($rank_report);

            if (isset($rank_report->responseStatus) && $rank_report->responseStatus->errorCode) {
                //fetch_error(site_url(), $user_id, $campaign, json_encode($rank_report));
                return FALSE;
            }
            if (empty($rank_report) || !isset($rank_report->isReportRunComplete)) {
                return FALSE;
            }
            if ($rank_report->isReportRunComplete != true) {
                return FALSE;
            }

            $results = $rank_report->keywordRankingResults;
            /* $competitor_urls = array();
              $competitor_urls = (array) $results;
              $competitor_urls = array_keys($competitor_urls);
              array_shift($competitor_urls); */

            $rankdatestamp = $rank_report->date;
            $epoch = explode('(', $rankdatestamp);
            $timeseconds = (intval(substr(trim($epoch[1]), 0, -2))) / 1000;
            $rnkdate = date("Y-m-d H:i:s", $timeseconds);

            // if report is completed
            $all_competitors = $this->getAllCompetitors($location_id);
            $removed_http = array();
            //fetch all competitors
            foreach ($all_competitors as $index => $value) {
                array_push($removed_http, str_replace(array("http://", "https://", "/", "www."), "", $value));
            }

            $ownwebsite = $this->get_user_meta($user_id, "website", true);
            $trimmedownweb = str_replace(array("http://", "https://", "www."), array("", "", ""), trim(trim($ownwebsite, "/")));

            if (!empty($results)) {

                foreach ($results as $rankurl => $urlsdata) {

                    $rankurlcheck = str_replace(array("http://", "https://", "www."), array("", "", ""), $this->fully_trim($rankurl));

                    $comp_key_value = $this->searchForCompetitorValue($rankurlcheck, $removed_http);

                    if ($comp_key_value >= 0) {

                        // keywords table for client 
                        $keword_res = TableRegistry::get('tbl_keywords');
                        $queryToUpdateKeywords = $keword_res->query();
                        // competitors table for competitor
                        $competitor_res = TableRegistry::get('tbl_compititors_data');
                        $queryToUpdateCompetitorData = $competitor_res->query();

                        foreach ($urlsdata as $kyindex => $data) {

                            $keyword = strtolower(trim($data->keywordSearch->keyword));
                            // Matching Keyword in Db
                            $sqlQueryToFindKeyword = "SELECT id FROM tbl_keywords WHERE LOWER(TRIM(keyword)) = ':keyword' AND campaign_id = :campaign_id AND location_id = :location_id";
                            $keydataid = $this->smart->execute($sqlQueryToFindKeyword, ["keyword" => $keyword, "campaign_id" => $campaignid, "location_id" => $location_id])->fetchAll("assoc");

                            if (!empty($keydataid)) {
                                $keyword_id = $keydataid[0]['id'];
                                // for client url
                                if ($comp_key_value == 0) {

                                    // updating keyword
                                    $insert_opp['rank'] = $data->googleOrganicRankings->rank;
                                    $insert_opp['maps_rank'] = $data->googlePlacesRankings->rank;
                                    $insert_opp['mobile_rank'] = $data->googleMobileOrganicRankings->rank;
                                    $insert_opp['mobile_maps_rank'] = $data->googleMobileMapsRankings->rank;
                                    $insert_opp['bing_rank'] = $data->bingOrganicRankings->rank;
                                    $insert_opp['bing_maps_rank'] = $data->bingLocalRankings->rank;
                                    $insert_opp['dateOfRank'] = date("Y-m-d h:i:s");

                                    $keywordUpdateQuery = $queryToUpdateKeywords->update()
                                            ->set($insert_opp)
                                            ->where(['campaign_id' => $campaignid, "keyword" => $keyword, "location_id" => $location_id])
                                            ->execute();
                                } else if ($comp_key_value > 0) {

                                    // for competitor url
                                    $insert_opp_comp['location_id'] = $location_id;
                                    $insert_opp_comp['keyword_id'] = $keyword_id;
                                    $insert_opp_comp['compt_id'] = $comp_key_value;
                                    $insert_opp_comp['ranked_url'] = $data->googleMobileMapsRankings->rankedUrl;
                                    $insert_opp_comp['rank'] = $data->bingOrganicRankings->rank;
                                    $insert_opp_comp['rank_date'] = date("Y-m-d h:i:s");
                                    $insert_opp_comp['user_id'] = $user_id;
                                    $insert_opp_comp['created'] = date("Y-m-d h:i:s");
                                    $insert_opp_comp['created_by'] = $user_id;

                                    $isThisRecordExists = "SELECT id FROM tbl_compititors_data WHERE keyword_id = :keyword_id AND location_id = :location_id";
                                    $is_exists_result = $this->smart->execute($isThisRecordExists, ["keyword_id" => $keyword_id, "location_id" => $location_id])->fetchAll("assoc");
                                    if (!empty($is_exists_result)) {
                                        // updating keyword
                                        $keywordUpdateQuery = $queryToUpdateCompetitorData->update()
                                                ->set($insert_opp_comp)
                                                ->where(['campaign_id' => $campaignid, "keyword" => $keyword, "location_id" => $location_id])
                                                ->execute();
                                    }
                                }
                            }
                        }
                    }
                }

                // delete temp report record from our db and from placesscout also 
                $sqlQueryToDelete = "DELETE FROM tbl_campaigns_temp WHERE id = :id";
                $runToDelete = $this->smart->execute($sqlQueryToDelete, ["id" => $id]);

                $curl_url = 'rankingreports/' . $ranking_id;
                $this->pc_delete($username, $password, $main_api_url, $curl_url);
                if ($campaign['is_running'] == 1) {
                    $sqlQueryToUpdateCampaignsTbl = "UPDATE tbl_campaigns SET is_running = 0 WHERE id = :id";
                    $this->smart->execute($sqlQueryToUpdateCampaignsTbl, ["id" => $campaignid]);
                }
                return true;
            }
        }
    }
	
	   public function pc_put($username, $password, $main_api_url, $curl_url, $data_string, $additional = array()) {
        $url = $main_api_url . $curl_url;
        $ch = curl_init();
        $location_id = isset($additional['location_id']) ? intval($additional['location_id']) : 0;

        if ($location_id > 0) {
            $headers = array("Content-Length: " . strlen($data_string), "location_id: " . $location_id);
        } else {
            $headers = array("Content-Length: " . strlen($data_string));
        }

        $contentType = isset($additional['contentType']) ? trim($additional['contentType']) : "";
        if ($contentType != '') {
            array_push($headers, $contentType);
        }

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

        curl_setopt($ch, CURLOPT_USERPWD, $username . ":" . $password);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }

    public function pc_delete($username, $password, $main_api_url, $curl_url, $additional = array()) {
        $FinalURL = $main_api_url . $curl_url;

        $location_id = isset($additional['location_id']) ? intval($additional['location_id']) : 0;
        if ($location_id > 0) {
            $headers = array("location_id: " . $location_id);
        } else {
            $headers = array();
        }
        $contentType = isset($additional['contentType']) ? trim($additional['contentType']) : "";
        if ($contentType != '') {
            array_push($headers, $contentType);
        }

        $ch = curl_init($FinalURL);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        if ($username != "" && $password != "") {
            curl_setopt($ch, CURLOPT_USERPWD, $username . ":" . $password);
        }
        return $result_on = curl_exec($ch);
    }


    public function getAllCompetitors($location_id, $type = '') {

        $this->loadmodel("Competitor");

        $location_details = $this->getLocationDetails($location_id)['website'];

        // get all competitors
        $competitors = $this->Competitor->find("all", ["conditions" => ["location_id" => $location_id], "fields" => ["id", "website"]])->toArray();

        $competitors_array = array();
        $comp_summary = array();
        array_push($competitors_array, array("key" => 0, "value" => $this->fully_trim($location_details)));
        if (!empty($type) && $type == "daily_chk_keyword") {
            return $competitors;
        }
        foreach ($competitors as $competitor) {
            array_push($competitors_array, array("key" => $competitor->id, "value" => $this->fully_trim($competitor->website)));
        }
        return $competitors_array;
    }

	public function fully_trim($str) {
        return rtrim(str_replace(array('http://', 'https://', 'www.'), "", $str), '/\\');
    }
	
    public function searchForCompetitorValue($value, $array) {
        foreach ($array as $key => $val) {

            if ($val['value'] === $value) {
                return $val['key'];
            }
        }
        return null;
    }

    public function getAgencyDetailsById($agency_id) {

        $sqlQueryToGetAgencyDetails = "SELECT ag.name,ag.email,lc.address,lc.country_id,lc.state_id,lc.city_id,lc.zip_code FROM tbl_agencies ag INNER JOIN tbl_locations lc on ag.id = lc.agency_id where ag.id = :agency_id AND lc.agency_id = :agency_id  order by lc.id desc limit 1";

        $details = $this->smart->execute($sqlQueryToGetAgencyDetails, ['agency_id' => $agency_id])->fetchAll("assoc");

        if (!empty($details)) {
            return $details[0];
        } else {
            return array();
        }
    }

    public function getLocationDetails($location_id) {

        $sqlQueryToGetAgencyDetails = "SELECT lc.agency_id,lc.name as location_name,lc.email as location_email,lc.website,ag.name as agency_name,ag.email as agency_email,lc.address,lc.country_id,lc.state_id,lc.city_id,lc.zip_code FROM tbl_agencies ag INNER JOIN tbl_locations lc on ag.id = lc.agency_id where lc.id = :location_id  order by lc.id desc limit 1";

        $details = $this->smart->execute($sqlQueryToGetAgencyDetails, ['location_id' => $location_id])->fetchAll("assoc");

        if (!empty($details)) {
            return $details[0];
        } else {
            return array();
        }
    }

    private function getCredentials() {
        $model = $this->loadModel('ApiOptions');
        $credentials = $model->find('all')->where(["option_key" => "placesscout"])->toArray();

        if (!empty($credentials)) {
            $jsonKey = $credentials[0]->option_value; // getting credentials from database 
            $key = json_decode($jsonKey, 1);
            if (!empty($key)) {
                return $key;
            } else {
                return false;
            }
        }
    }
	
	
    function getCountryDetailsById($id) {

        try {

            $countryTable = TableRegistry::get('tbl_countries');
            $query = $countryTable->find()->where(["id" => $id]);
            $code = '';
            $country = '';
            $phonecode = '';
            $status = '';
            if ($query->count() > 0) {

                foreach ($query as $data):
                    $code = $data->code;
                    $country = $data->country;
                    $phonecode = $data->phonecode;
                    $status = $data->status;
                endforeach;

                return array(
                    "code" => $code,
                    "name" => $country,
                    "phonecode" => $phonecode,
                    "status" => $status
                );
            }
            return array();
        } catch (Exception $ex) {
            
        }
    }

    /* get state details by id */

    function getStateDetailsById($id) {

        try {

            $countryTable = TableRegistry::get('tbl_states');
            $query = $countryTable->find()->where(["id" => $id]);
            $country = '';
            $name = '';
            if ($query->count() > 0) {

                foreach ($query as $data):
                    $name = $data->name;
                    $country = $this->getCountryDetailsById($data->country_id)['name'];
                endforeach;

                return array(
                    "name" => $name,
                    "country" => $country
                );
            }
            return array();
        } catch (Exception $ex) {
            
        }
    }

    /* get city details by id */

    function getCityDetailsById($id) {

        try {

            $countryTable = TableRegistry::get('tbl_cities');
            $query = $countryTable->find()->where(["id" => $id]);
            $state = '';
            $name = '';
            $country = '';
            if ($query->count() > 0) {

                foreach ($query as $data):
                    $name = $data->name;
                    $state = $this->getStateDetailsById($data->state_id)['name'];
                    $country = $this->getStateDetailsById($data->state_id)['country'];
                endforeach;

                return array(
                    "name" => $name,
                    "state" => $state,
                    "country" => $country
                );
            }
            return array();
        } catch (Exception $ex) {
            
        }
    }
	
	 public function get_option($agency_id, $option_key) {

        $tbl_options = TableRegistry::get('tbl_options');
        $tbl_options_query = $tbl_options->query();

        $total_rows = $tbl_options_query->find('all', [
                    'conditions' => ['agency_id' => $agency_id, "option_key" => $option_key]
                ])->toArray();

        $option_value = '';

        if (count($total_rows) > 0) {

            $option_value = $total_rows[0]['option_value'];
        }

        return $option_value;
    }

    public function set_option($agency_id, $option_key, $option_value) {
        
        $tbl_options = TableRegistry::get('tbl_options');
        $tbl_options_query = $tbl_options->query();

        if (empty($this->get_user_meta($location_id, $option_key))) {
            if ($tbl_options_query->insert(['agency_id', 'option_key', 'option_value', 'created'])
                            ->values(
                                    [
                                        'agency_id' => $agency_id,
                                        'option_key' => $option_key,
                                        'option_value' => $option_value,
                                        'created' => date("Y-m-d H:i:s")
                                    ]
                            )
                            ->execute()) {
                return true;
            }
            return false;
        }
        return false;
    }
	
	    public function get_user_meta($location_id, $option_key) {

        $tbl_options = TableRegistry::get('tbl_options');
        $tbl_options_query = $tbl_options->query();

        $total_rows = $tbl_options_query->find('all', [
                    'conditions' => ['location_id' => $location_id, "option_key" => $option_key]
                ])->toArray();

        $option_value = '';

        if (count($total_rows) > 0) {

            $option_value = $total_rows[0]['option_value'];
        }

        return $option_value;
    }

    public function add_user_meta($location_id, $option_key, $option_value) {

        $tbl_options = TableRegistry::get('tbl_options');
        $tbl_options_query = $tbl_options->query();

        if (empty($this->get_user_meta($location_id, $option_key))) {
            if ($tbl_options_query->insert(['location_id', 'option_key', 'option_value', 'created'])
                            ->values(
                                    [
                                        'location_id' => $location_id,
                                        'option_key' => $option_key,
                                        'option_value' => $option_value,
                                        'created' => date("Y-m-d H:i:s")
                                    ]
                            )
                            ->execute()) {
                return true;
            }
            return false;
        }
        return false;
    }
	
	
    public function update_user_meta($location_id, $option_key, $option_value) {

        $tbl_options = TableRegistry::get('tbl_options');
        $tbl_options_query = $tbl_options->query();

        if (!empty($this->get_user_meta($location_id, $option_key))) {

            if ($tbl_options_query->update()
                            ->set(
                                    [
                                        'option_value' => $option_value,
                                        'updated' => date("Y-m-d H:i:s")
                                    ]
                            )
                            ->where(['location_id' => $location_id, "option_key" => $option_key])
                            ->execute()) {
                return true;
            } else {

                return false;
            }
        }
        return false;
    }


}

?>