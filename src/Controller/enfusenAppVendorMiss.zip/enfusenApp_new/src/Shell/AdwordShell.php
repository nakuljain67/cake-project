<?php

namespace App\Shell;

use Cake\Console\Shell;
use App\Controller\AdwordsSubaccountController;
use App\Controller\AdwordsCampaignController;
use App\Controller\AdwordsAdgroupController;
use App\Controller\AdwordsKeywordController;
use App\Controller\AdwordsAdsController;
use App\Controller\AdwordsCampaignReportController;
use App\Controller\AdwordsAdgroupReportController;
use App\Controller\AdwordsKeywordReportController;
use App\Controller\AdwordsAdsReportController;

class AdwordShell extends Shell {
    
    private $subAccount; // variable for store subaccount controller 
    private $campaign; // variable for store campaign controller 
    private $adgroup; // variable for store adgroup controller 
    private $keywords; // variable for store keyword controller 
    private $ads; // variable for store ads controller object 
    private $campaginReporting; //variable for store campain performance reporting
    private $adroupReporting; // variable for store adgroup class object
    private $keywordReporting; // variable for store keyword reporting class object 
    private $adsReporting; // variable for store ads reporting class object 
    private $location_id;
    
    /**
     * Date :- 08-june-17 
     * Function disc :- Function for initialize  
     * @RudrainnovativePvtLtd
     */

    public function initialize() {
        parent::initialize();
        
        $this->subAccount = new AdwordsSubaccountController();
        $this->campaign = new AdwordsCampaignController();
        $this->adgroup = new AdwordsAdgroupController();
        $this->keywords = new AdwordsKeywordController();
        $this->ads = new AdwordsAdsController();
        $this->campaignReporting = new AdwordsCampaignReportController();
        $this->adroupReporting = new AdwordsAdgroupReportController();
        $this->keywordReporting = new AdwordsKeywordReportController();
        $this->adsReporting = new AdwordsAdsReportController();
    }
    
    public function main() {
        $this->out("Welcome to Adwords Cron Engine");
    }
    
    /**
     * Date :- 08-june-17 
     * Function disc :- Function for pull sub-account data according to location id  
     * @RudrainnovativePvtLtds 
     */
    
    public function pullSubaccounts() {
        $location_id = 1; // only for testing
        $this->subAccount->index($location_id);
        $this->out("All subaccounts added into database.");
    }
    
    /**
     * Date :- 08-june-17 
     * Function disc :- Function for pull campaign data according to location id  
     * @RudrainnovativePvtLtds 
     */
    
    public function pullCampaigns() {
        $location_id = 1; // only for testing 
        $this->campaign->index($location_id);
        $this->out("All camapaigns saved into database.");
        
    }
    
    /**
     * Date :- 09-june-17 
     * Function disc :- Function for pull Adwords adgroups according to campaign id  
     * @RudrainnovativePvtLtds 
     */
    
    public function pullAdgroups() {
        $location_id = 1; // only for testing 
        $this->adgroup->index($location_id);
        $this->out("All camapaigns saved into database.");
    }
    
    /**
     * Date :- 09-june-17 
     * Function disc :- Function for pull Adwords Keywords according to location id 
     * @RudrainnovativePvtLtds 
     */
    
    public function pullKeywords() {
        $location_id = 1; // only for testing 
        $this->keywords->index($location_id);
        $this->out("All keywords saved into database.");
    }
    
    /**
     * Date :- 12-june-17 
     * Function disc :- Function for pull Adwords Ads according to location id 
     * @RudrainnovativePvtLtds 
     */
    
    public function pullAds() {
        $location_id = 1;
        $this->ads->index($location_id);
        $this->out("All ads saved into database.");
    }
    
    /**
     * Date :- 12-june-17 
     * Function disc :- Function for pull Campaign reporting 
     * @RudrainnovativePvtLtds 
     */
    public function pullCampaignReporting() {
        $location_id = 1;
        $this->campaignReporting->getCampaignReporting($location_id);
        $this->out("Campaign reporting saved into database.");
    }
    
    /**
     * Date :- 13-june-17 
     * Function disc :- Function for pull ad-groups performance reporting  
     * @RudrainnovativePvtLtds 
     */
    
    public function pullAdgroupReporting() {
        $location_id = 1;
        $this->adroupReporting->adwordsAdgroupReporting($location_id);
        $this->out("AdGroup reporting saved into database.");
    }
    
    /**
     * Date :- 13-june-17 
     * Function disc :- Function for pull adwords keywords reporting 
     * @RudrainnovativePvtLtds 
     */
    public function pullKeywordReporting() {
        $location_id = 1;
        $this->keywordReporting->index($location_id);
        $this->out("Adwords keyword reporting saved into database .");
    }
    
    /**
     * Date :- 13-june-17 
     * Function disc :- Function for pull Adwords ads performance reporting 
     * @RudrainnovativePvtLtds 
     */
    
    public function pullAdsReporting() {
        $location_id = 1;
        $this->adsReporting->index($location_id);
        $this->out("Adwords Ads reporting saved into database.");
    }
    
    /**
     * Date :- 14-june-17 
     * Function disc :- Function for get locations 
     * @RudrainnovativePvtLtds 
     */
    
    public function getLocations() {
        $locationsArray = []; // array for store all locations 
        $model = $this->loadModel("ApiLocations");
        $dbCredentials = $model->find('all', array("conditions" => array("status" => 1, "adword_token <>" => "")))->toArray();
        
        if(!empty($dbCredentials)) {
            foreach($dbCredentials as $val):
//                $this->location_id = $val->smart_location_id;
                $locationsArray[] = $val->smart_location_id;
            endforeach;
        }
        
        return $locationsArray;
    }
    
    public function test($location)
    {
        sleep(15);
        @mail('aman@rudrainnovatives.com','Location '.$location, 'location no '.$location);        
    }
    
    /**
     * Date :- 16-june-17 
     * Function disc :- Function for Batch job for increase performance 
     * @RudrainnovativePvtLtds 
     */
    
    public function batch()
    {        
        $locations = ["1", "2"];
        if(!empty($locations))
        {
            foreach($locations as $val):
                $shell_command = "nohup bin/cake adword test ".$val." > /dev/null 2>&1 &";
                exec($shell_command, $ret, $out);
            endforeach;
        }
    }
    
    
    
    

}
