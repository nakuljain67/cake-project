<?php

namespace App\Shell;

use Cake\Console\Shell;
use App\Controller\CallRailController;

class CallrailShell extends Shell {
    
    private $table; //  variable for store model table value
    private $callrail; // variable for create callrail controller object 
    
    public function initialize() {
        parent::initialize();
        $this->table = $this->loadModel("callRail");
        $this->callrail = new CallRailController(); //  calling controller 
    }
    
    public function main()
    {
        $location_id = 1; 
        $api_key = CALL_RAIL_APIKEY;
        $accountId = 327429711;
        
        $check = $this->check_data($location_id);
        if($check == 1)
        {
            $this->callrail->getTodaylog($location_id, $api_key, $accountId);
            $this->out('Yesterday data pulled successfully.');
        }
        else 
        {
            $this->callrail->callLog($location_id, $api_key, $accountId);
            $this->out('Historical data pulled successfully.');
            $this->callrail->getTodaylog($location_id, $api_key, $accountId);
            $this->out('All call logs saved into database.');
        }
    }
    
    /**
     * Date :- 09-june-17 
     * Function disc :- Function for check value is in database or not  
     * @RudrainnovativePvtLtd
     */
    
    private function check_data($location_id) {
        $data = $this->table->find('all')->where(['location_id' => $location_id])->all();
        if(iterator_count($data))
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    
    

}