<?php

namespace App\Shell;

use Cake\Console\ConsoleOptionParser;
use Cake\Console\Shell;
use Cake\Log\Log;
use App\Controller\AppController;
use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[] paginate($object = null, array $settings = [])
 */
class SiteauditShell extends Shell {

    private $app;
    private $smartdata;
    private $conn;
    private $smart;

    public function initialize() {
        parent::initialize();
        ini_set('max_execution_time', 90000);
        $this->app = new AppController();
        $this->loadModel('Apilocations');
        $this->smartdata = "smart";
        $this->conn = ConnectionManager::get('default');
        $this->smart = ConnectionManager::get($this->smartdata);
    }

    public function main() {
        $this->out("You are in site audit");
    }

    public function siteauditCron($location_id) {
        try {
            $sem = $this->semrush_api_info();
            $main_api_url = $sem['main_api_url'];
            $key = $sem['key'];
            $audit = TableRegistry::get('tbl_site_audit', array('connectionName' => $this->smartdata));
            $in_progress_audit = $audit->find("all", [
                        'conditions' => ['location_id' => $location_id, 'LOWER(audit_status)' => 'in progress'],
                        'order' => ['last_audit' => 'asc'],
                    ])->first();
            
            if (!empty($in_progress_audit)) {
                
                $campaign_id = $in_progress_audit->campaign_id;
                $location_id = $in_progress_audit->location_id;
                $user_id = $in_progress_audit->user_id;
                $rerun = $in_progress_audit->rerun;
                $check_all_info = $in_progress_audit->all_info;
                $check_audit_id = $in_progress_audit->id;
                if ($check_all_info == '') {
                    $curl_url = 'reports/v1/projects/' . $campaign_id . '/siteaudit/info?key=' . $key; // need to work here
                    $all_info = $this->app->pc_get($username = '', $password = '', $main_api_url, $curl_url);
                    $all_info = json_decode($all_info);
                    $all_info = serialize($all_info);
                    $curl_url = 'reports/v1/projects/' . $campaign_id . '/siteaudit/meta/issues?key=' . $key;
                    $error_name = $this->app->pc_get($username = '', $password = '', $main_api_url, $curl_url);
                    $error_name_list = serialize(json_decode($error_name));
                    $query = $audit->query();
                    $query->update()
                            ->set(
                                    [
                                        'all_info' => $all_info,
                                        'error_name_list' => $error_name_list
                                    ]
                            )
                            ->where(['id' => $check_audit_id])
                            ->execute();
                }
                $all_site_audit = $audit->find("all")->where(['id' => $check_audit_id])->first();
                $site_audit_result = unserialize($all_site_audit->all_info);
                $errors_list = $site_audit_result->current_snapshot->errors;
                $warning_list = $site_audit_result->current_snapshot->warnings;
                $notices_list = $site_audit_result->current_snapshot->notices;
                $snapshot_id = $site_audit_result->current_snapshot->snapshot_id;
                $defects_list = $site_audit_result->defects;
                if (!empty($defects_list)) {
                    $this->smart->query("CREATE TABLE IF NOT EXISTS `tbl_site_audit_error_page_list_$location_id` (
                        `id` int(15) NOT NULL AUTO_INCREMENT,
                        `snapshot_id` varchar(50) NOT NULL,
                        `issue_id` int(11) NOT NULL,
                        `target_url` varchar(700) NOT NULL,
                        `page_id` varchar(100) NOT NULL,
                        `discovered` varchar(50) NOT NULL,
                        `info` text NOT NULL,
                        `source_url` varchar(700) NOT NULL,
                        `data_info` text NOT NULL,
                        `error_details` text NOT NULL,
                        `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        PRIMARY KEY (`id`)
                      ) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;");
                    $this->smart->query("truncate table `tbl_site_audit_error_page_list_$location_id`");

                    foreach ($defects_list as $issue_id => $limit_data) {
                        $sql = "SELECT * FROM `tbl_site_audit_error_page_list_$location_id` WHERE `snapshot_id` = '$snapshot_id' && `issue_id` = $issue_id LIMIT 1";
                        $check_existing_issue_id = $this->smart->execute($sql)->fetchAll("assoc");

                        if (empty($check_existing_issue_id)) {

                            // echo ' Issue ID: ' . $issue_id . ', Limit Data: ' . $limit_data . '<br/>';
                            $curl_url = 'reports/v1/projects/' . $campaign_id . '/siteaudit/snapshot/' . $snapshot_id . '/issue/' . $issue_id . '?page=1&filter=&sort=index_asc&limit=' . $limit_data . '&key=' . $key;
                            $all_page_error_list = $this->app->pc_get($username = '', $password = '', $main_api_url, $curl_url);
                            //pr($all_page_error_list);exit;
                            $all_page_error_list = json_decode($all_page_error_list);
                            //pr($all_page_error_list);   die;

                            if (!empty($all_page_error_list->data)) {
                                foreach ($all_page_error_list->data as $row_page) {
                                    $insue_list_ins = array();
                                    $insue_list_ins['snapshot_id'] = $snapshot_id;
                                    $insue_list_ins['issue_id'] = $issue_id;
                                    if (isset($row_page->target_url)) {
                                        $insue_list_ins['target_url'] = $row_page->target_url;
                                    }

                                    $insue_list_ins['page_id'] = $row_page->page_id;
                                    $insue_list_ins['discovered'] = $row_page->discovered;
                                    $insue_list_ins['data_info'] = serialize($row_page);
                                    if (isset($row_page->info)) {
                                        $insue_list_ins['info'] = serialize($row_page->info);
                                    }
                                    if (isset($row_page->source_url)) {
                                        $insue_list_ins['source_url'] = $row_page->source_url;
                                    }
                                    $this->smart->insert('tbl_site_audit_error_page_list_' . $location_id, $insue_list_ins);
                                }
                                //pr($all_page_error_list);
                                // exit;
                            } else {
                                $insue_list_ins['user_id'] = $user_id;
                                $insue_list_ins['snapshot_id'] = $snapshot_id;
                                $insue_list_ins['issue_id'] = $issue_id;
                                $insue_list_ins['data_info'] = serialize($all_page_error_list);
                                $this->smart->insert('tbl_site_audit_error_page_list', $insue_list_ins);
                            }
                        }
                    }
                    $update_audit_status['audit_status'] = 'get_error';
                    $this->smart->update('tbl_site_audit', $update_audit_status, array('id' => $check_audit_id));
                    // echo 'Get All Error Page List';
                }
                
            }

            $get_error_audit = $this->smart->execute("SELECT * FROM `tbl_site_audit` WHERE location_id = ".$location_id." AND audit_status = 'get_error' order by `last_audit` asc")->fetchAll("assoc");
            if (!empty($get_error_audit)) {
                //pr($get_error_audit); die;
                $user_id = $get_error_audit[0]['user_id'];
                $location_id = $get_error_audit[0]['location_id'];
                $snapshot_id = $get_error_audit[0]['snapshot_id'];
                $campaign_id = $get_error_audit[0]['campaign_id'];
                $check_audit_id = $get_error_audit[0]['id'];
                $sql1 = "SELECT page_id FROM `tbl_site_audit_error_page_list_$location_id` WHERE snapshot_id = '$snapshot_id' && `source_url` != '' && `error_details` = '' && `page_id` != '' group by `page_id` order by `id` asc limit 200";
                $page_url_list = $this->smart->execute($sql1)->fetchAll("assoc");

                if (!empty($page_url_list)) {
                    foreach ($page_url_list as $index_count => $row_page_list) {
                        //  pr($row_page_list); die;
                        $page_id = $row_page_list['page_id'];
                        // echo $info = $row_page_list['id'] . ' - Index: ' . $index_count . ', Campaign Id, ' . $campaign_id . ', User Id: ' . $user_id . ', Page Id: ' . $page_id . '<br/>';
                        $curl_url = 'reports/v1/projects/' . $campaign_id . '/siteaudit/page/' . $page_id . '?key=' . $key;
                        $audit_page_info = $this->app->pc_get($username = '', $password = '', $main_api_url, $curl_url);
                        $audit_page_info = json_decode($audit_page_info);
                        $insert_error_details['error_details'] = serialize($audit_page_info);
                        $this->smart->update('tbl_site_audit_error_page_list_' . $location_id, $insert_error_details, array('page_id' => $page_id, 'snapshot_id' => $snapshot_id));
                    }
                }

                $sql = "SELECT id FROM `tbl_site_audit_error_page_list_$location_id` WHERE snapshot_id = '$snapshot_id' && `source_url` != '' && `error_details` = '' && `page_id` != '' group by `page_id` order by `id` asc limit 1";
                $page_url_list = $this->smart->execute($sql)->fetchAll("assoc");
                if (empty($page_url_list)) {
                    $update_audit_status['audit_status'] = 'Completed';
                    $this->smart->update('tbl_site_audit', $update_audit_status, array('id' => $check_audit_id));
                    // echo "completed site audit";
                }
            }
//////////////error module end//////////////////////////////////////////////
            $this->out("Success");
        } catch (Exception $exc) {
            
        }
    }

    private function semrush_api_info() {

        $options = TableRegistry::get('api_options');
        $query = $options->find("all", [
            "conditions" => ["option_key" => "semrush"],
            "fields" => ["option_value"],
        ]);

        $data = $query->first();
        if (!empty($data)) {
            $parsedata = json_decode($data->option_value);
            $sm_api['key'] = $parsedata->api_key;
            $mainapiurl = $sm_api['main_api_url'] = $parsedata->api_url;
        } else {
            // default
            $sm_api['key'] = "562e2601cd42d050497232b4b6510a31";
            $mainapiurl = $sm_api['main_api_url'] = "http://api.semrush.com/";
        }

        $mainapiurl = rtrim($mainapiurl, "/");
        $sm_api['semrush_project_url'] = $mainapiurl . "/reports/v1/projects/";
        return $sm_api;
    }

}
