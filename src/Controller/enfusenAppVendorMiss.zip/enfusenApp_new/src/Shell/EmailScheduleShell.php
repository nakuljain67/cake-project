<?php

namespace App\Shell;

use Cake\Console\ConsoleOptionParser;
use Cake\Console\Shell;
use Cake\Log\Log;
use App\Controller\AppController;
use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[] paginate($object = null, array $settings = [])
 */
class EmailScheduleShell extends Shell {

    private $app;
    private $smartdata;
    private $conn;
    private $smart;

    public function initialize() {
        parent::initialize();
        ini_set('max_execution_time', 90000);
        $this->app = new AppController();
        $this->loadModel('Apilocations');
        $this->smartdata = "smart";
        $this->conn = ConnectionManager::get('default');
        $this->smart = ConnectionManager::get($this->smartdata);
    }
    public function main(){
        exit('Get out');
    }
    
    public function sendScheduledEmail($location_id = 0) {
        try {
            $interval_time = 30; // minute
            $before_days = date('Y-m-d H:i:s', time() - 1 * 24 * 3600); //It is ok
            $current_time = date('H:i', time());
            $increase_time = date('H:i:s', time() + $interval_time * 60);
            // $weekday = 'Monday';
            $weekday = 'Friday'; // temp
            $con = '';
            $anotherDate = "";
            //$sch_id = isset($_GET['sch_id']) ? intval($_GET['sch_id']) : 0;
            if (date('l') == $weekday || date('d') == '01') {
                if (date('l') == $weekday) {
                    $con = " and sch_frequency = 'Weekly'";
                }
                if (date('d') == '01') {
                    $con = " and sch_frequency = 'Monthly'";
                }
                if (date('l') == $weekday && date('d') == '01') {
                    $con = '';
                }
                $current_time . '<br/>';
                $sql = "SELECT * FROM `tbl_sch_settings` WHERE location_id = $location_id AND `modified` <= '" . date("Y-m-d H:i:s") . "' $con group by id order by `location_id` asc";
                $all_report = $this->smart->execute($sql)->fetchAll('assoc');                
                if (!empty($all_report)) {
                    
                    $today = date("m/d/Y");
                    $from_date = date('Y-m-d', time() - 31 * 24 * 3600);
                    $to_date = date('Y-m-d', time() - 2 * 24 * 3600);
                    $call_page = 'schedule_report';
                    function httpPost($url, $data) {
                        $curl = curl_init($url);
                        curl_setopt($curl, CURLOPT_POST, true);
                        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                        $response = curl_exec($curl);
                        curl_close($curl);
                        return $response;
                    }

                    $moodle = SMART_URL."Keyword/cronScheduleReport";
                    $data = array('all_report' => $all_report);
                    $result = httpPost($moodle, $data);
                    $this->out($result);
                } else {
                    $this->out("No Schedule Report");
                }
            } else {
                $this->out('No Schedule Report');
            }
        } catch (Exception $exc) {
            
        }
    }

}
