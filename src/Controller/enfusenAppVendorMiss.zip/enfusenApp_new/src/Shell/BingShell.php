<?php

namespace App\Shell;

use Cake\Console\Shell;
use App\Controller\BingController;

class BingShell extends Shell {

    private $bing; // variable for calling bing controller 
    private $location_id; // variable for store location id 
    private $apioptions; // variable for store api options model 
    private $bingCampaign; // variable for store campaign model
    private $bingSub; // variable for store sub accounts model 
    private $bingMain; // variable for save bing main model 
    private $bingCamapginReporting; // variable for store bing campaign reporting model 
    private $bingAdgroupReporting; // variable for store adgroup model 
    private $bingKeywordReporting;
    private $bingAdsReporting;

    /**
     * Date :- 07-june-17 
     * Function disc :- initialize all variable and data  
     * @Rudrainnovatives 
     */
    public function initialize() {
        parent::initialize();
        ini_set('default_socket_timeout', 180);
        $this->location_id = 1;
        $this->bing = new BingController(); // creating controller object 
        $this->apioptions = $this->loadModel('ApiOptions'); // calling api option model 
        $this->bingCampaign = $this->loadModel('BingCampaign'); // calling campaign data model 
        $this->bingSub = $this->loadModel('BingSubuser'); // calling subaccount model 
        $this->bingMain = $this->loadModel("BingUser"); //calling bing main user model 
        $this->bingCamapginReporting = $this->loadModel('BingCampaignReporting'); // calling bing campaign reporting table
        $this->bingAdgroupReporting = $this->loadModel('BingAdgroupReporting');
        $this->bingKeywordReporting = $this->loadModel('BingKeywordReporting');
        $this->bingAdsReporting = $this->loadModel('BingAdsReporting');
    }

    /**
     * Date :- 07-june-17 
     * Function disc :- Index function 
     * @Rudrainnovatives 
     */
    public function main() {
        $this->bing->GetUser(null, $this->location_id);
    }

    /**
     * Date :- 07-june-17 
     * Function disc :- function for set cron to get all campaigns according to account id 
     * @Rudrainnovatives 
     */
    public function getCampaign() {
        $subData = $this->bingMain->find('all')->where(['location_id' => $this->location_id])->toArray();
        if (!empty($subData)) {
            $clientId = $subData[0]->bingId;
            $this->bing->getCampaigns($clientId, $this->location_id);
        }
    }

    /**
     * Date :- 07-june-17 
     * Function disc :- function for set cron to pull all adGroups 
     * @Rudrainnovatives 
     */
    public function pullAdgroups() {
        $this->bing->pullAdgroups($this->location_id);
    }

    /**
     * Date :- 07-june-17 
     * Function disc :- function for set cron to pull all keywords 
     * @Rudrainnovatives 
     */
    public function pullKeywords() {
        $this->bing->pullKeywords($this->location_id);
    }

    /**
     * Date :- 07-june-17 
     * Function disc :- function for set cron to pull all ads 
     * @Rudrainnovatives 
     */
    public function pullAds() {
        $this->bing->pullAds($this->location_id);
    }

    /**
     * Date :- 07-june-17 
     * Function disc :- function for set cron to pull campaign performance report 
     * @Rudrainnovatives 
     */
    public function pullCampaignPerformanceReport() {
        $accountId = 415852;
        $checkdata = $this->check_value($this->bingCamapginReporting, $this->location_id);
        if ($checkdata == 1) {
            $this->bing->GetCampaignPerformanceReportRequest($accountId);
        } else if ($checkdata == 0) {
            $this->bing->GetCampaignPerformanceHistoricalReportRequest($accountId);
            $this->out("Campaign historical done");
            $this->bing->GetCampaignPerformanceReportRequest($accountId);
        }
    }

    /**
     * Date :- 07-june-17 
     * Function disc :- function for set cron to pull Ad-group performance report 
     * @Rudrainnovatives 
     */
    public function pullAdgroupPerformanceReport() {
        $accountId = 415852;
        $checkdata = $this->check_value($this->bingAdgroupReporting, $this->location_id);
        if ($checkdata == 1) {
            $this->bing->GetAdgroupPerformanceReportRequest($accountId);
        } else if ($checkdata == 0) {
            $this->bing->GetAdgroupHistoricalPerformanceReportRequest($accountId);
            $this->out("Adgroup historical done");
            $this->bing->GetAdgroupPerformanceReportRequest($accountId);
        }
    }

    /**
     * Date :- 07-june-17 
     * Function disc :- function for set cron to pull Keyword performance report 
     * @Rudrainnovatives 
     */
    public function pullKeywordPerformanceReport() {
        $accountId = 415852;
        $checkdata = $this->check_value($this->bingKeywordReporting, $this->location_id);
        if ($checkdata == 1) {
            $this->bing->GetKeywordPerformanceReportRequest($accountId);
        } else if ($checkdata == 0) {
            $this->bing->GetKeywordHistoricalPerformanceReportRequest($accountId);
            $this->out("Keyword historical done");
            $this->bing->GetKeywordPerformanceReportRequest($accountId);
        }
    }

    /**
     * Date :- 07-june-17 
     * Function disc :- function for set cron to pull Keyword performance report 
     * @Rudrainnovatives 
     */
    public function pullAdsPerformanceReport() {
        $accountId = 415852;
        $checkdata = $this->check_value($this->bingAdsReporting, $this->location_id);
        if ($checkdata == 1) {
            $this->bing->GetAdsPerformanceReportRequest($accountId);
        } else if ($checkdata == 0) {
            $this->bing->GetAdsHistoricalPerformanceReportRequest($accountId);
            $this->out("Keyword historical done");
            $this->bing->GetAdsPerformanceReportRequest($accountId);
        }
    }

    /**
     * Date :- 07-june-17 
     * Function disc :- Function for check value is in database or not  
     * @Rudrainnovatives 
     */
    public function check_value($db, $location_id) {
        $dbData = $db->find('all')->where(['location_id' => $location_id])->all();
        if (iterator_count($dbData)) {
            return 1;
        } else {
            return 0;
        }
    }
    
    /**
     * Date :- 19-june-17 
     * Function disc :- Function for get all sub account id according to location id   
     * @Rudrainnovatives 
     */
    
    public function getSubaccounts($location_id) {
        $returnArray = []; // blank array for return data 
        $accounts = $this->bingSub->find('all')->where(["location_id" => $location_id, "account_life_cycle_status" => "Active"])->all();
    
        if(iterator_count($accounts)) {
            foreach ($accounts as $key => $val):
                $returnArray[$key]["account_id"] = $val->account_id;
            endforeach;
        }
        
       return $returnArray; //  return all sub account data array 
    }

}
