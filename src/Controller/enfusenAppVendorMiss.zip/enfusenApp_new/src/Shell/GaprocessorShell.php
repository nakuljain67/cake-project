<?php

namespace App\Shell;

use Cake\Console\ConsoleOptionParser;
use Cake\Console\Shell;
use Cake\Log\Log;
use App\Controller\AppController;
use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[] paginate($object = null, array $settings = [])
 */
class GaprocessorShell extends Shell {

    private $app;
    private $smartdata;
    private $conn;
    private $smart;

    public function initialize() {
        parent::initialize();
        ini_set('max_execution_time', 90000);
        $this->app = new AppController();
        $this->loadModel('Apilocations');        
        $this->conn = ConnectionManager::get('default');        
        $this->smartdata = "smart";
        $this->smart = ConnectionManager::get($this->smartdata);
    }

    public function main() {
        exit();
    }

    public function shortAnalytics($location_id = "", $StartDate = "", $EndDate = "") {
        try {
                        
           if($location_id > 0){
                $dataexists = $this->Apilocations->find("All")->select(['Apilocations.smart_location_id', 
                    'Apilocations.google_token', 'Apilocations.analytics_child'])->where([
                    'AND' => ['Apilocations.status' => "1", 'Apilocations.google_token !=' => "", 'Apilocations.smart_location_id' => $location_id]
                ]);
            }
            else{
                $dataexists = $this->Apilocations->find("All")->select(['Apilocations.smart_location_id', 
                    'Apilocations.google_token', 'Apilocations.analytics_child'])->where([
                    'AND' => ['Apilocations.status =' => "1", 'Apilocations.google_token !=' => ""]
                ]);
            }
            
            $results = $dataexists->all();
            foreach ($results as $result) {
                $location_id = $result->smart_location_id;
                
                if($StartDate == "" || $EndDate == ""){
                    $previous_date = date("Y-m-d", strtotime("-1 days"));
                    $dateOfVisit = date("Y-m-d");
                }
                else{                    
                    $previous_date = date("Y-m-d", strtotime($StartDate));
                    $dateOfVisit = date("Y-m-d", strtotime($EndDate." +1day"));
                }
                                
                $sql = "SHOW TABLES LIKE 'api_main_analytics_" . $location_id . "'";
                $stmt = $this->conn->execute($sql);
                $row = $stmt->fetch('obj');
                if (empty($row)) {
                    // create table main analytics table
                    $main_analytic_file = ROOT . DS . 'vendor' . DS . "dynamic_tables" . DS . "main_analytics.sql";
                    $main_analytic = file_get_contents($main_analytic_file);
                    $main_analytic = str_replace("[LOCATION_ID]", $location_id, $main_analytic);
                    $this->conn->execute($main_analytic);

                    // create table short analytics table
                    $short_analytic_file = ROOT . DS . 'vendor' . DS . "dynamic_tables" . DS . "short_analytics.sql";
                    $short_analytic = file_get_contents($short_analytic_file);
                    $short_analytic = str_replace("[LOCATION_ID]", $location_id, $short_analytic);
                    $this->smart->execute($short_analytic);
                }

                while ($previous_date < $dateOfVisit) {
                    $date = $previous_date;                    
                    $previous_date = date('Y-m-d', strtotime('+1 days', strtotime($previous_date)));                                        
                    $sql = "SELECT COUNT(id) as total FROM api_short_analytics_" . $location_id . " WHERE dateOfVisit >= ?";
                    $stmt = $this->smart->execute($sql, [$date]);
                    $row = $stmt->fetch('obj');
                    if ($row->total == 0) {
                        // if data not pulled for the day
                        $rsdata = $this->getgadailydata($location_id, $StartDate, $EndDate);
                        $results = array();
                        foreach ($rsdata as $rs) {
                            $keyword = "";
                            $rank = "";
                            $exact_landing_page = str_replace(array("http://", "https://", "www."), array("", "", ""), trim(trim($rs->pageURL), "/"));
                            $sql = "SELECT keyword, rank FROM tbl_keywords WHERE location_id = ? AND "
                                    . "TRIM(BOTH  '/' FROM REPLACE(REPLACE(REPLACE (ranked_url, 'http://', ''),'https://',''),'www.','')) = ? "
                                    . "ORDER BY modified DESC LIMIT 1";
                            $stmt = $this->smart->execute($sql, [$location_id, $exact_landing_page]);
                            $row = $stmt->fetch('obj');
                            if (!empty($row)) {
                                $keyword = $row->keyword;
                                $rank = $row->rank;
                            }

                            $res = array();
                            $res['location_id'] = $location_id;
                            $res['keyword'] = $keyword;
                            $res['currentRank'] = $rank;
                            $res['pageURL'] = $rs->pageURL;
                            $res['dateOfVisit'] = $rs->dateOfVisit;
                            $res['organic'] = $rs->total_organic;
                            $res['social'] = $rs->total_social;
                            $res['referral'] = $rs->total_referral;
                            $res['none'] = $rs->total_direct;
                            $res['email'] = $rs->total_email;
                            $res['total'] = $rs->total_visit;
                            $res['cpc'] = $rs->total_cpc;
                            $res['bounceRate'] = $rs->bounceRate;
                            $res['timeOnSite'] = $rs->timeonsite;
                            $res['created'] = date("Y-m-d H:i:s");
                            $results[] = $res;
                        }

                        $short_analytics = TableRegistry::get('api_short_analytics_' . $location_id, array('table' => 'api_short_analytics_' . $location_id, 'connectionName' => $this->smartdata));
                        $entities = $short_analytics->newEntities($results);
                        $lastres = $short_analytics->saveMany($entities);
                    }
                }
            }
        } catch (Exception $exc) {
            
        }
    }

    public function getgadailydata($location_id, $StartDate, $EndDate) {
        try {
            $sql = "SELECT pageURL, dateOfVisit,  
                    sum(visits) as total_visit,
                    sum( `bounceRate` ) AS bounceRate,
                    sum(`timeOnSite`) as timeonsite,
                    sum(case when medium = 'email' || `source` = 'email' then 1 else 0 end) total_email,
                    sum(case when medium = 'organic' ||  `source` = 'organic' then 1 else 0 end) total_organic,
                    sum(case when medium = 'cpc' || medium = 'adword' || medium = 'ppc' || `source` = 'cpc' || `source` = 'adword' || `source` = 'ppc' then 1 else 0 end) total_cpc,
                    sum(case when `source` not like '%facebook%' and `source` not like '%twitter%' and `source` not like '%linkedin%' and `source` not like '%tumblr%' and `source` not like '%blogger%' and `source` not like '%pinterest%'  and `source` not like '%youtube%' and `source` not like '%yelp%' and `source` not like '%foursquare%' and `source` not like '%instagram%' and `source` not like '%plus.%' and `source` not like '%bbb.%' and `source` not like '%angieslist%' and medium = 'referral' then 1 else 0 end) total_referral,
                    sum(case when `source` like '%facebook%' || `source` like '%twitter%' || `source` like '%linkedin%' || `source` like '%tumblr%' || `source` like '%blogger%' || `source` like '%pinterest%' || `source` like '%youtube%' || `source` like '%yelp%' || `source` like '%foursquare%' || `source` like '%instagram%' || `source` like '%plus.%' || `source` like '%bbb.%' || `source` like '%angieslist%' || `source` = 'social' || medium = 'social'  then 1 else 0 end) total_social,
                    sum(case when medium = 'none' || `source` = 'none' then 1 else 0 end) total_direct
                    FROM `api_main_analytics_$location_id` WHERE `dateOfVisit` >= ? AND `dateOfVisit` <= ? and visits > 0 group by `pageURL` order by `pageURL` asc";

            $stmt = $this->conn->execute($sql, [$StartDate, $EndDate]);
            $data = $stmt->fetchAll('obj');
            //$main_analytics = TableRegistry::get('api_main_analytics_' . $location_id, array('table' => 'api_main_analytics_' . $location_id));            
            return $data;
        } catch (Exception $ex) {
            
        }
    }

}
