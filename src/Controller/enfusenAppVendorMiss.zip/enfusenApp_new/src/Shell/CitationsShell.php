<?php

namespace App\Shell;

use Cake\Console\ConsoleOptionParser;
use Cake\Console\Shell;
use Cake\Log\Log;
use App\Controller\AppController;
use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[] paginate($object = null, array $settings = [])
 */
class CitationsShell extends Shell {

    private $conn;
    private $smart;
    private $app;

    public function initialize() {
        parent::initialize();
        $this->conn = ConnectionManager::get('default');
        $this->app = new AppController();
        $this->smartdata = "smart";
        $this->smart = ConnectionManager::get($this->smartdata);
    }

    public function main() {
        $this->out("Citations Cron...");
    }

    /**
     * Date :- 27-june-17
     * Function disc :- Function for get citations report 
     */
    public function getCitationReport() {
        $tbl_citationsList = TableRegistry::get('tbl_citationlist', array('connectionName' => $this->smartdata));
        $citationsData = $tbl_citationsList->find('all')->where(["status" => "In Progress"])->toArray();

        $update = [];

        if (!empty($citationsData)) {

            foreach ($citationsData as $val):

                $reportId = $val->reportId; // report id from database
                $citationId = $val->citation_id; // citation id from database
                $citationListId = $val->id; // getting citation list id 

                $placesscoutDetails = $this->getCredentials(); // credentials from database 

                if (!empty($placesscoutDetails)) {

                    $username = $placesscoutDetails["username"];
                    $password = $placesscoutDetails["password"];
                    $main_api_url = $placesscoutDetails["api_url"];

                    $curl_url = 'citationreports/' . $reportId . '/runs/newest';
                    $encode_competitive_citation_data = $this->app->pc_get($username, $password, $main_api_url, $curl_url, array("contentType" => "Content-Type: application/json"));
                    $competitive_citation_data = json_decode($encode_competitive_citation_data);

                    if (!empty($competitive_citation_data->competitorCitationData)) {

                        /* competitive_citation section */
                        $update["competitive_citation"] = $encode_competitive_citation_data;
                        $this->updateCitationDetails($update, $citationId); // function call for save citation data into database
                        $this->out("competitive_citation updated");
                        $update = []; // blank array when data updated into database 

                        /* basic_data sections */
                        $curl_url = 'citationreports/' . $reportId;
                        $contentType = "Content-Type: application/json";
                        $basic_citationreports = $this->app->pc_get($username, $password, $main_api_url, $curl_url, array("contentType" => "Content-Type: application/json"));
                        $update["basic_data"] = $basic_citationreports;
                        $this->updateCitationDetails($update, $citationId); // function call for save citation data into database
                        $this->out("basic_data updated");
                        $update = [];

                        /* citations_data section */
                        $curl_url = 'citationreports/' . $reportId . '/citations';
                        $contentType = "Content-Type: application/json";
                        $citations_data = $this->app->pc_get($username, $password, $main_api_url, $curl_url, array("contentType" => "Content-Type: application/json"));
                        $update["citations_data"] = $citations_data;
                        $this->updateCitationDetails($update, $citationId); // function call for save citation data into database
                        $this->out("citations_data updated");
                        $update = [];

                        /* Add citations competitor report data into database */
                        if (!empty($competitive_citation_data)) {
                            foreach ($competitive_citation_data->competitorCitationData as $row_single_com):

                                $citationReportCitationsId = $row_single_com->citationReportCitationsId;
                                $post_data['CitationReportCitationsIds'] = $citationReportCitationsId;
                                $curl_url = 'leadgenreports/citations/bulk';
                                $contentType = "Content-Type: application/json";
                                $citations = $this->app->pc_post($username, $password, $main_api_url, $curl_url, json_encode($post_data), array("contentType" => "Content-Type: application/json"));

                                /* setting content in array for insert into database */
                                $abc['citation_tracker_id'] = $citationListId;
                                $abc['CitationReportCitationsId'] = $citationReportCitationsId;
                                $abc['citations'] = $citations;

                                $this->addCitationCompetitor($abc, $citationId); // save tbl_citation_competitor data into database 

                            endforeach;

                            $this->out("tbl_citation_competitor Updated into database");
                        }

                        $update["status"] = "complete";
                        $this->updateCitationDetails($update, $citationId);
                        $this->out("All report Done");
                    }
                } else {
                    $this->out("Admin Credentials not fount");
                }

            endforeach;
        } else {
            $this->out("No citations are in progress");
        }
    }

    /**
     * Date :- 27-june-17
     * Function disc :- Function for update citations report 
     */
    private function updateCitationDetails($updateData, $id) {
        $tbl_citationsList = TableRegistry::get('tbl_citationlist', array('connectionName' => $this->smartdata));        
        $query = $tbl_citationsList->query();
        $query->update()->set($updateData)->where(["id" => $id])->execute();
    }

    /**
     * Date :- 27-june-17
     * Function disc :- Function for add / update citations competitor data into database 
     */
    private function addCitationCompetitor($data, $citation_list_id) {
        $tbl_citation_com = TableRegistry::get('tbl_citation_competitor', array('connectionName' => $this->smartdata));
        $exits = $tbl_citation_com->exists(["citation_tracker_id" => $citation_list_id]);

        if ($exits == 1) {

            // Update value into database 
            $query = $tbl_citation_com->query();
            $query->update()->set($data)->where(["citation_tracker_id" => $citation_list_id])->execute();
        } else {

            // Insert value into database
            $insert = $tbl_citation_com->newEntity();
            $insert->citation_tracker_id = $data["citation_tracker_id"];
            $insert->citationReportCitationsId = $data["CitationReportCitationsId"];
            $insert->citations = $data["citations"];
            $tbl_citation_com->save($insert);
        }
    }

    /**
     * Date :- 29-june-17
     * Function disc :- Function for get placesscout credentials from database 
     */
    private function getCredentials() {
        $model = $this->loadModel('ApiOptions');
        $credentials = $model->find('all')->where(["option_key" => "placesscout"])->toArray();

        if (!empty($credentials)) {
            $jsonKey = $credentials[0]->option_value; // getting credentials from database 
            $key = json_decode($jsonKey, 1);
            if (!empty($key)) {
                return $key;
            } else {
                return false;
            }
        }
    }

    /**
     * Date :- 3-july-17
     * Function disc :- Function for run single citation report by report id  
     */
    public function singleCitationRun($citation_list_id, $reportId) {
        
        if (!empty($citation_list_id) && !empty($reportId)) {

            $placesscoutDetails = $this->getCredentials(); // credentials from database 

            if (!empty($placesscoutDetails)) {

                $username = $placesscoutDetails["username"];
                $password = $placesscoutDetails["password"];
                $main_api_url = $placesscoutDetails["api_url"];

                $curl_url = 'citationreports/' . $reportId . '/runs/newest';                                
                $encode_competitive_citation_data = $this->app->pc_get($username, $password, $main_api_url, $curl_url, array("contentType" => "Content-Type: application/json"));
                
                $competitive_citation_data = json_decode($encode_competitive_citation_data);
                
                if (!empty($competitive_citation_data->competitorCitationData) || !empty($competitive_citation_data->totalCitationsByType)) {

                    /* competitive_citation section */
                    $update["competitive_citation"] = $encode_competitive_citation_data;
                    $this->updateCitationDetails($update, $citation_list_id); // function call for save citation data into database
                    $update = []; // blank array when data updated into database 
                    
                    /* basic_data sections */
                    $curl_url = 'citationreports/' . $reportId;
                    $basic_citationreports = $this->app->pc_get($username, $password, $main_api_url, $curl_url, array("contentType" => "Content-Type: application/json"));
                    $update["basic_data"] = $basic_citationreports;
                    $this->updateCitationDetails($update, $citation_list_id); // function call for save citation data into database
                    $update = [];

                    /* citations_data section */
                    $curl_url = 'citationreports/' . $reportId . '/citations';
                    $citations_data = $this->app->pc_get($username, $password, $main_api_url, $curl_url, array("contentType" => "Content-Type: application/json"));
                    $update["citations_data"] = $citations_data;
                    $this->updateCitationDetails($update, $citation_list_id); // function call for save citation data into database
                    $update = [];

                    /* Add citations competitor report data into database */
                    if (!empty($competitive_citation_data)) {
                        foreach ($competitive_citation_data->competitorCitationData as $row_single_com):

                            $citationReportCitationsId = $row_single_com->citationReportCitationsId;
                            $post_data['CitationReportCitationsIds'] = $citationReportCitationsId;
                            $curl_url = 'leadgenreports/citations/bulk';
                            $contentType = "Content-Type: application/json";
                            $citations = $this->app->pc_post($username, $password, $main_api_url, $curl_url, json_encode($post_data), array("contentType" => "Content-Type: application/json"));

                            $abc['citation_tracker_id'] = $citation_list_id;
                            $abc['CitationReportCitationsId'] = $citationReportCitationsId;
                            $abc['citations'] = $citations;

                            $this->addCitationCompetitor($abc, $citation_list_id); // save tbl_citation_competitor data into database 

                        endforeach;

                        $this->out("tbl_citation_competitor Updated into database");
                    }
                    
                    $update["status"] = "complete";
                    $this->updateCitationDetails($update, $citation_list_id);
                    $this->out("All report Done");
                }else {
                    $this->out("Empty Data Found");
                }
            } else {
                $this->out("Admin Credentials not fount");
            }
        } else {
            $this->out("Provide report id and id");
        }
    }

    /**
     * Date :- 06-july-17
     * Function Disc :- Function for run batch job 
     */
    public function scheduleCitations() {
        
        $tbl_citationsList = TableRegistry::get('tbl_citationlist', array('connectionName' => $this->smartdata));
        $citationsData = $tbl_citationsList->find('all')->where(["status" => "In Progress"])->toArray();
        
        if (!empty($citationsData)) {

            foreach ($citationsData as $val):
                $reportId = $val->reportId;
                $citationId = $val->citation_id;
                $citation_list_id = $val->id;
                
                $shell_command = "nohup bin/cake Citations singleCitationRun " . $citation_list_id . " " . $reportId . " > /dev/null 2>&1 &";
                $this->out($shell_command); 
                
                //exec($shell_command, $ret, $out);
            endforeach;
            $this->out("Citation Reporting Run");
            
        } else {
            $this->out('No citation is in Progress');
        }
    }

}
