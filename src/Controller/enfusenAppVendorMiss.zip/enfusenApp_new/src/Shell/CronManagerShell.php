<?php

namespace App\Shell;

use Cake\Console\ConsoleOptionParser;
use Cake\Console\Shell;
use Cake\Log\Log;
use App\Controller\AppController;
use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;
use App\Shell\CitationsShell;

class CronManagerShell extends Shell {

    private $conn;
    private $smart;
    private $app;

    public function initialize() {
        parent::initialize();
        $this->conn = ConnectionManager::get('default');
        $this->app = new AppController();
        $this->smartdata = "smart";
        $this->smart = ConnectionManager::get($this->smartdata);
    }

    public function main() {
        $this->out("welcome to crom manager shell");
    }

    /**
     * Date :- 3-july-17 
     * Function disc :- function for schedule citations cron 
     */
    public function scheduleCitations() {
//        $api_cron_schedular = TableRegistry::get('api_cron_schedular');
//        $citationbatch = $api_cron_schedular->findByApi_name("citation")->select(["schedule"])->first();
        // cron time : */15 * * * *  : after every 15 minutes
        $tbl_citationsList = TableRegistry::get('tbl_citationlist', array('connectionName' => $this->smartdata));
        $citationsData = $tbl_citationsList->find('all')->where(["LOWER(status)" => "in progress"])->toArray();

        if (!empty($citationsData)) {

            foreach ($citationsData as $val):
                $reportId = $val->reportId;
                $citation_list_id = $val->id;
                $shell_command = "nohup bin/cake Citations singleCitationRun " . $citation_list_id . " " . $reportId . " > /dev/null 2>&1 &";
                exec($shell_command, $ret, $out);
            endforeach;
            $this->out("Done all");
        } else {
            $this->out('No citation is in Progress');
        }
    }

    public function scheduleSiteaudit() {
        // cron time : */15 * * * *  : after every 15 minutes
        $tbl_siteAudit = TableRegistry::get('tbl_site_audit', array('connectionName' => $this->smartdata));
        $siteAuditData = $tbl_siteAudit->find('all')->where(["LOWER(audit_status) <>" => "completed"])->toArray();

        if (!empty($siteAuditData)) {

            foreach ($siteAuditData as $val):
                $location_id = $val->location_id;
                $shell_command = "nohup bin/cake Siteaudit siteauditCron " . $location_id . " > /dev/null 2>&1 &";
                exec($shell_command, $ret, $out);
            endforeach;
            $this->out("Done all");
        } else {
            $this->out('No site audit is in Progress');
        }
    }

    public function scheduleGoogleAnalytics() {
        // cron time : 0 2 * * *  : 2AM midnight
        $this->loadModel('Apilocations');
        $results = $this->Apilocations->find("All")->select(['Apilocations.smart_location_id'])->where([
                    'AND' => ['Apilocations.status =' => "1", 'Apilocations.google_token !=' => "", 'Apilocations.analytics_child !=' => ""]
                ])->all();

        if (!empty($results)) {

            foreach ($results as $result):
                $location_id = $result->smart_location_id;
                $shell_command = "nohup bin/cake GoogleAnalytics mainAnalytics " . $location_id . " > /dev/null 2>&1 &";
                exec($shell_command, $ret, $out);
            endforeach;
            $this->out("Done all");
        } else {
            $this->out('No site audit is in Progress');
        }
    }

    public function scheduleShortGAnalytics() {
        // cron time : 0 */6 * * *  : after every 6 hrs
        $this->loadModel('Apilocations');
        $results = $this->Apilocations->find("All")->select(['Apilocations.smart_location_id'])->where([
                    'AND' => ['Apilocations.status =' => "1", 'Apilocations.google_token !=' => "", 'Apilocations.analytics_child !=' => ""]
                ])->all();

        if (!empty($results)) {

            foreach ($results as $result):
                $location_id = $result->smart_location_id;
                $shell_command = "nohup bin/cake Gaprocessor shortAnalytics " . $location_id . " > /dev/null 2>&1 &";
                exec($shell_command, $ret, $out);
            endforeach;
            $this->out("Done all");
        } else {
            $this->out('No site audit is in Progress');
        }
    }

    public function scheduleAutoSyncKeywords() {
        // cron time : 0 */1 * * *  : after every 1 hrs
        $this->loadModel('Apilocations');
        $results = $this->Apilocations->find("All")->select(['Apilocations.smart_location_id'])->where(['Apilocations.status =' => "1"])->all();

        if (!empty($results)) {
            foreach ($results as $result):
                $location_id = $result->smart_location_id;
                $shell_command = "nohup bin/cake RunKeyword autoSyncKeywords " . $location_id . " > /dev/null 2>&1 &";
                exec($shell_command, $ret, $out);
            endforeach;
            $this->out("Done all");
        } else {
            $this->out('No site audit is in Progress');
        }
    }

    public function scheduleDailyKeywordsCheck() {
        // cron time : 0 3 * * *  : daily at midnight 3AM
        $this->loadModel('Apilocations');
        $results = $this->Apilocations->find("All")->select(['Apilocations.smart_location_id'])->where(['Apilocations.status =' => "1"])->all();

        if (!empty($results)) {
            foreach ($results as $result):
                $location_id = $result->smart_location_id;
                $shell_command = "nohup bin/cake RunKeyword dailyKeywordsCheck " . $location_id . " > /dev/null 2>&1 &";
                exec($shell_command, $ret, $out);
            endforeach;
            $this->out("Done all");
        } else {
            $this->out('No site audit is in Progress');
        }
    }

    public function emailScheduledReportsCheck() {
        // cron time : 0 5 * * *  : daily at midnight 5AM
        $tbl_schedule = TableRegistry::get('tbl_sch_settings', array('connectionName' => $this->smartdata));
        $scheduleData = $tbl_schedule->find('all')->select(["location_id"])->where(["sch_status" => 1])->group('location_id')->all();
        //$sql = "SELECT * FROM `tbl_sch_settings` WHERE location_id = $location_id AND `modified` <= '" . date("Y-m-d H:i:s") . "' $con group by id order by `location_id` asc";        
        if (!empty($scheduleData)) {
            foreach ($scheduleData as $val):
                $location_id = $val->location_id;
                $shell_command = "nohup bin/cake EmailSchedule sendScheduledEmail " . $location_id . " > /dev/null 2>&1 &";
                exec($shell_command, $ret, $out);
            endforeach;
            $this->out("Done all");
        } else {
            $this->out('No schedule report found');
        }
    }

    public function dailySearchConsole() {
        // cron time : 30 12 * * *  : daily at midnight 12:30AM
        $this->loadModel('Apilocations');
        $results = $this->Apilocations->find("All")->select(['Apilocations.smart_location_id'])->where(['Apilocations.status =' => "1", 'Apilocations.google_search_token !=' => ""])->all();

        if (!empty($results)) {
            foreach ($results as $result):
                $location_id = $result->smart_location_id;
                $shell_command = "nohup bin/cake DailySearchConsole searchConsoleFill " . $location_id . " > /dev/null 2>&1 &";
                exec($shell_command, $ret, $out);
            endforeach;
            $this->out("Done all");
        } else {
            $this->out('No search console data found');
        }
    }

}
