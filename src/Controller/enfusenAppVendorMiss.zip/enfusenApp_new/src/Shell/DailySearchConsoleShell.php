<?php

namespace App\Shell;

use Cake\Console\ConsoleOptionParser;
use Cake\Console\Shell;
use Cake\Log\Log;
use App\Controller\AppController;
use Cake\Datasource\ConnectionManager;
use Cake\ORM\TableRegistry;

require_once(ROOT . DS . 'vendor' . DS . "gaconnect" . DS . "vendor" . DS . "autoload.php");

/**
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[] paginate($object = null, array $settings = [])
 */
class DailySearchConsoleShell extends Shell {

    private $app;
    private $conn;
    private $smartdata;
    private $smart;

    public function initialize() {
        parent::initialize();
        ini_set('max_execution_time', 90000);
        $this->loadModel('Apilocations');
        $this->app = new AppController();
        $this->conn = ConnectionManager::get('default');
        $this->smartdata = "smart";
        $this->smart = ConnectionManager::get($this->smartdata);
    }

    public function main() {
        exit();
    }

    public function searchConsoleFill($location_id = "") {
        /* Cron run daily to add at 12:30 AM to add data of last 30 days into tbl_options table */
        try {
            $location_id = intval($location_id);
            $sql = "SELECT google_search_token FROM api_locations WHERE smart_location_id = " . $location_id . " AND (google_search_token IS NOT NULL AND google_search_token != '')";
            $res = $this->conn->execute($sql)->fetch("obj");
            if (!empty($res)) {
                $curTimestamp = date("Y-m-d", strtotime("-1 day"));

                $result = $this->smart->execute("SELECT l.website, l.agency_id, l.created_by, op.updated FROM tbl_locations l INNER JOIN tbl_options op "
                                . "ON l.id = op.location_id WHERE op.location_id = " . $location_id . " and "
                                . "op.option_key = 'search_console_data'")->fetch('obj');

                $website = "";
                $lastTimestamp = "";
                $agency_id = 0;
                $user_id = 0;
                if (!empty($result)) {
                    $lastTimestamp = date("Y-m-d", strtotime($result->updated));
                    $website = $res->website;
                    $agency_id = $res->agency_id;
                    $user_id = $res->created_by;
                } else {
                    $locdetail = $this->smart->execute("SELECT website, agency_id, created_by FROM "
                                    . "tbl_locations WHERE id = " . $location_id)->fetch('obj');
                    if (empty($locdetail)) {
                        $website = $locdetail->website;
                        $agency_id = $res->agency_id;
                        $user_id = $res->created_by;
                    }
                }

                if ($lastTimestamp != $curTimestamp) {

                    $TableRevSeo = TableRegistry::get("tbl_reverse_seo");
                    $revQuery = $TableRevSeo->query();

                    $credentials = json_decode($res->google_search_token);
                    if (!empty($credentials) && count((array) $credentials) > 0) {
                        $limit = 20;
                        $offset = 0;
                        $search_urls = $this->PullSearchConsoleMetrics(array("location_url" => $website, "start_date" => date("Y-m-d", strtotime("-31 days")), "end_date" => date("Y-m-d", strtotime("-1 days")), "limit" => $limit, "offset" => $offset, "refressToken" => $credentials->refresh_token));
                        $dataurls = json_encode($search_urls);
                        if (!empty($dataurls)) {
                            // combining all results into reverse seo table
                            if (count($search_urls) > 0) {
                                // iterating over keywords found in search console.
                                foreach ($search_urls as $index => $value) {

                                    $sqlQuery = 'SELECT id FROM tbl_reverse_seo WHERE location_id = ' . $location_id . ' and LOWER(TRIM(keyword)) = "' . strtolower(trim($value['keyword'])) . '"';
                                    $sqlResult = $this->smart->execute($sqlQuery)->fetchAll("assoc");
                                    if (count($sqlResult) > 0) {
                                        // update reverse seo entry
                                        $revSeoTableUpdate = "Update tbl_reverse_seo SET page_url = '" . $value['url'] . "', clicks = " . $value['clicks'] . ", impressions = " . $value['impressions'] . ", avg_position = " . $value['position'] . ", ctr = " . $value['ctr'] . ", modified = '" . date("Y-m-d h:i:s") . "' WHERE location_id = " . $location_id . " and LOWER(TRIM(keyword)) = '" . strtolower(trim($value['keyword'])) . "'";
                                        $this->smart->execute($revSeoTableUpdate);
                                    } else {
                                        // reverse seo entry
                                        $revQuery->insert(['location_id', 'page_url', 'keyword', 'clicks', 'impressions', 'avg_position', 'ctr', 'created', 'created_by', 'modified_by'])
                                                ->values(
                                                        [
                                                            'location_id' => $location_id,
                                                            'page_url' => $value['url'],
                                                            'keyword' => strtolower(trim($value['keyword'])),
                                                            'clicks' => $value['clicks'],
                                                            'impressions' => $value['impressions'],
                                                            'avg_position' => $value['position'],
                                                            'ctr' => $value['ctr'],
                                                            'created' => date("Y-m-d h:i:s"),
                                                            'created_by' => $user_id,
                                                            'modified_by' => $user_id
                                                        ]
                                                )
                                                ->execute();
                                    }
                                }
                            }

                            if (!empty($result)) {
                                $sqlupdt = "UPDATE tbl_options SET option_value = '" . $dataurls . "' WHERE location_id = " . $location_id . " AND option_key='search_console_data'";
                            } else {
                                $sqlupdt = "INSERT INTO tbl_options (agency_id, location_id, option_key, option_value, created, created_by, updated_by) "
                                        . "VALUES(" . $agency_id . "," . $location_id . ",'search_console_data','" . $dataurls . "','" . date('Y-m-d H:i:s') . "', " . $user_id . ", " . $user_id . ")";
                            }
                            $this->smart->execute($sqlupdt);
                        }
                    }
                }
            }
        } catch (\Exception $ex) {
            $this->out($ex->getMessage());
        } catch (\PDOException $ex) {
            $this->out($ex->getMessage());
        }
        //pr($date);
    }

    private function PullSearchConsoleMetrics($data = array()) {

        $this->autoRender = false;

        $results = array();

        try {

            if (!empty($data["location_url"]) && !empty($data["refressToken"])) {

                $client = $this->googleclient();
                $client->fetchAccessTokenWithRefreshToken($data["refressToken"]);
                //$client->fetchAccessTokenWithRefreshToken("1/zJjWcAubp21S_xtRgh_4VNSx7G1S1X16Gv3SW1eXfQk");

                $service = new \Google_Service_Webmasters($client);

                $q = new \Google_Service_Webmasters_SearchAnalyticsQueryRequest();

                $startDate = $data["start_date"];
                $endDate = $data["end_date"];
                $url = $data["location_url"];

                $q->setStartDate($startDate);
                $q->setEndDate($endDate);
                $q->setDimensions(['page', 'query']);
                $q->setSearchType('web');
                $q->setRowLimit('2'); // Maximum 1000 keywords can fetch from webmaster
                $q->setStartRow('0');
                try {
                    $u = $service->searchanalytics->query($url, $q);
                } catch (\Exception $e) {
                    $u = "";
                }

                if (!empty($u)) {
                    $searchConsoleArray = array();

                    for ($i = 0; $i < count($u->rows); $i++) {

                        $res = array();
                        $res['url'] = $u->rows[$i]->keys[0];
                        $res['start_date'] = $startDate;
                        $res['end_date'] = $endDate;
                        $res['keyword'] = $u->rows[$i]->keys[1];
                        $res['clicks'] = $u->rows[$i]->clicks;
                        $res['impressions'] = $u->rows[$i]->impressions;
                        $res['ctr'] = $u->rows[$i]->ctr;
                        $res['position'] = $u->rows[$i]->position;
                        $res['created'] = date("Y-m-d H");
                        $results[] = $res;
                    }
                }
            }
        } catch (\Exception $ex) {
            
        }

        return $results;
    }

}
