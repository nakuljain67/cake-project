<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\ORM\TableRegistry;
use Cake\Validation\Validator;

class UserTable extends Table {
    
    /*This Code has not been used to this api session*/
    
    /* Default method to initialize */

    public function initialize(array $config) {

        parent::initialize($config);
        $this->setTable('tbl_users');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
        $this->belongsTo('Usertype')->setForeignKey('utype_id');
    }

    public function is_user_valid($data = array()) {

        $email = isset($data['email']) ? trim($data['email']) : "";
        $password = isset($data['password']) ? trim($data['password']) : "";

        $results = $this->find("all", [
                    'conditions' => ['email' => $email, "password" => md5($password)]
                ])->all()->toArray();

        $user_details = array();

        if (count($results) > 0):

            foreach ($results as $user):

                array_push($user_details, array(
                    "firstName" => $user->fname,
                    "lastName" => $user->lname,
                    "email" => $user->email,
                    "dob" => $user->dob,
                    "phone" => $user->phone,
                    "about" => $user->about,
                    "country" => $this->getCountryDetailsById($user->country_id)['name'],
                    "state" => $this->getStateDetailsById($user->state_id)['name'],
                    "city" => $this->getCityDetailsById($user->city_id)['name'],
                    "address" => $user->address,
                    "zipcode" => $user->zip_code,
                    "occupation" => $user->occupation,
                    "token" => $userToken,
                    "user_id" => $user->id,
                    "agency_id" => $user->agency_id
                ));

            endforeach;

        endif;

        return $user_details;
    }

    public function genusertoken() {

        $usr_token_tbl = TableRegistry::get('tbl_userlive_tokens');
        $user_tkn = $usr_token_tbl->newEntity();
        $user_tkn->userid = $user->id;
        $user_tkn->token = $userToken;
        $user_tkn->token_created = date("Y-m-d H:i:s");
        $user_tkn->token_expire = date("Y-m-d H:i:s");

        if ($usr_token_tbl->save($user_tkn)) {
            //record inserted now...:)
        }
    }

}

?>