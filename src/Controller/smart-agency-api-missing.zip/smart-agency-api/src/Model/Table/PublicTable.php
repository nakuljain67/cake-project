<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class PublicTable extends Table {
    /* Default method to initialize */

    public function initialize(array $config) {
        parent::initialize($config);
    }

    public function saveSearchMetrics($data = array()) {
        // this function is handled by PublicController
    }

}

?>