<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\ORM\TableRegistry;
use Cake\Validation\Validator;

class UserlivetokensTable extends Table {
    
    /*This Code has not been used to this api session*/
    
    /* Default method to initialize */

    public function initialize(array $config) {

        parent::initialize($config);
        $this->setTable('tbl_userlive_tokens');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');        
        $this->belongsTo('User')->setForeignKey('userid');
    }

}

?>