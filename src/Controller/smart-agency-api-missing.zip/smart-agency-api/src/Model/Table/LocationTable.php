<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;
use App\Controller\AppController;

class LocationTable extends Table {
    /* Default method to initialize */
    private $app;
    public function initialize(array $config) {

        parent::initialize($config);
        $this->setTable('tbl_locations');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
        $this->belongsTo('City')->setForeignKey('city_id');
        $this->belongsTo('State')->setForeignKey('state_id');
        $this->belongsTo('Country')->setForeignKey('country_id');
        $this->app = new AppController();
    }

    public function addCity($city, $state_id) {
        $cities = TableRegistry::get('tbl_cities');        
        $query = $cities->query();
        $results = $cities->find("all", [
                    'conditions' => ['name' => $city, 'state_id' => $state_id]
                ])->first();        
        if (empty($results)) {                    
            $id = $query->insert(['name', 'state_id'])
                    ->values(
                            [
                                'name' => $city,
                                'state_id' => $state_id                           
                            ]
                    )
                    ->execute();
            $result = $query->find('all', ['fields' => 'id'])->last();
            if(!empty($result)){
                $id = $result->id;
                return $id;
            }
        }        
        return 0;        
    }

    /* create location */

    public function create($data = array(), $app) {

        /* post variables */
        $agency_id = isset($data['agency_id']) ? intval($data['agency_id']) : "5";
        //$account_type = isset($data['account_type']) ? trim($data['account_type']) : "";
        $website = isset($data['website']) ? trim($data['website']) : "";
        $name = isset($data['name']) ? trim($data['name']) : "";
        $services = isset($data['services']) ? trim($data['services']) : "";        
        $conv_verified = isset($data['conv_verified']) ? intval($data['conv_verified']) : "0";
        $status = isset($data['status']) ? intval($data['status']) : 1;
        $token = isset($data['token']) ? $data['token'] : '';
        
        $target = isset($data['target']) && trim($data['target']) != '' ? $data['target'] : '';
        $email = isset($data['email']) ? trim($data['email']) : "";
        $phone = isset($data['phone']) ? trim($data['phone']) : "";
        $about = isset($data['about']) ? trim($data['about']) : "";
        $country_id = isset($data['country_id']) ? intval($data['country_id']) : "";
        $state_id = isset($data['state_id']) ? intval($data['state_id']) : "";
        $city_id = isset($data['city_id']) ? intval($data['city_id']) : "";

        $city = isset($data['city']) ? htmlspecialchars(trim($data['city'])) : "";
        $success_array = array();
        $new_city_id = "";
        if ($city != '') {
            $new_city_id = $this->addCity($city, $state_id);
            if($new_city_id == 0){                
                return "-1";
            }
        }

        $address = isset($data['address']) ? trim($data['address']) : "";
        $zip_code = isset($data['zip_code']) ? trim($data['zip_code']) : "";
        $created_by = isset($data['user_id']) ? trim($data['user_id']) : "";

        
        $query = $this->query();

        if ($query->insert(['agency_id', 'account_type', 'website', 'name', 'services', 'target', 'email', 'phone', 'about', 'country_id', 'state_id', 'city_id', 'address', 'zip_code', 'conv_verified', 'status', 'created', 'created_by'])
                        ->values(
                                [
                                    'agency_id' => $agency_id,
                                    //'account_type' => $account_type,
                                    'website' => $website,
                                    'name' => $name,
                                    'services' => $services,
                                    'target' => $target,
                                    'email' => $email,
                                    'phone' => $phone,
                                    'about' => $about,
                                    'country_id' => $country_id,
                                    'state_id' => $state_id,
                                    'city_id' => $city_id,
                                    'address' => $address,
                                    'zip_code' => $zip_code,
                                    'conv_verified' => 0,
                                    'status' => $status,
                                    'created' => date("Y-m-d H:i:s"),
                                    'created_by' => $created_by
                                ]
                        )
                        ->execute()) {

            $result = $this->find('all')->last();
            $result->location_id = $result->id;
            if($new_city_id != ''){
                $result->city_id = $new_city_id;
            }
            unset($result->id);
            array_push($success_array, $result);
        }
        
        return $success_array;
    }

    /* edit location */

    public function edit($data = array(), $canupdate) {

        $locationId = isset($data['location_id']) ? intval($data['location_id']) : 0;

        $agency_id = isset($data['agency_id']) ? intval($data['agency_id']) : "";
        $account_type = isset($data['account_type']) ? trim($data['account_type']) : "";
        if($canupdate == 1){
            $website = isset($data['website']) ? trim($data['website']) : "";
        }
        
        $name = isset($data['name']) ? trim($data['name']) : "";
        $services = isset($data['services']) ? trim($data['services']) : "";
        $target = isset($data['target']) ? trim($data['target']) : "";
        $conv_verified = isset($data['conv_verified']) ? intval($data['conv_verified']) : "";
        $status = isset($data['status']) ? intval($data['status']) : "";
        $created_by = isset($data['created_by']) ? intval($data['created_by']) : "";
        $email = isset($data['email']) ? trim($data['email']) : "";
        $phone = isset($data['phone']) ? trim($data['phone']) : "";
        $about = isset($data['about']) ? trim($data['about']) : "";
        $country_id = isset($data['country_id']) ? intval($data['country_id']) : "";
        $state_id = isset($data['state_id']) ? intval($data['state_id']) : "";
        $city_id = isset($data['city_id']) ? intval($data['city_id']) : "";
        $address = isset($data['address']) ? trim($data['address']) : "";
        $zip_code = isset($data['zip_code']) ? trim($data['zip_code']) : "";
        
        $results = $this->find("all", [
                    'conditions' => ['id' => $locationId]
                ])->all()->toArray();
        
        $arr = [
                    'agency_id' => $agency_id,
                    'account_type' => $account_type,                    
                    'name' => $name,
                    'services' => $services,
                    'target' => $target,
                    'email' => $email,
                    'phone' => $phone,
                    'about' => $about,
                    'country_id' => $country_id,
                    'state_id' => $state_id,
                    'city_id' => $city_id,
                    'address' => $address,
                    'zip_code' => $zip_code,                                        
                    'status' => $status                                        
            ];
        if($canupdate == 1){
            $arr['website'] = $website;
        }
            
        if (count($results) > 0):
                                    
            $query = $this->query();
            if ($query->update()
                            ->set($arr)
                            ->where(['id' => $locationId])
                            ->execute()) {
                return true;
            } else {
                return false;
            }

        else:

        endif;
    }

    /* get all location */

    public function getlist($data = array(), $offset, $limit) {

        $agencyId = isset($data['agency_id']) ? $data['agency_id'] : 0;
        $limit = isset($data['limit']) ? $data['limit'] : $limit;
        $offset = isset($data['offset']) ? $data['offset'] : $offset;
        $status = isset($data['status']) ? intval($data['status']) : 1;
        $offset = $offset - 1;
        if($offset < 0){
            $offset = 0;
        }
        else if($offset >= 1){
            $offset = $offset * $limit;
        }
        
        $search_txt = isset($data['search_txt']) ? htmlspecialchars(trim($data['search_txt'])) : "";        
        
        if($search_txt == ''){           
            $results = $this->find("all", [
                    'conditions' => ['agency_id' => $agencyId, 'Location.status' => $status],
                    'order' => ['created' => 'DESC'],
                    'limit' => $limit,
                    'offset' => $offset
                ])->contain(['City','State','Country'])->all()->toArray();
        } else {
                        
            $results = $this->find("all", [
                    'conditions' => ['OR' => [
                            ['agency_id' => $agencyId, 'Location.status' => $status, 'Location.name like' => '%'.$search_txt.'%'],
                            ['agency_id' => $agencyId, 'Location.status' => $status, 'Location.website like' => '%'.$search_txt.'%']
                        ]
                    ],
                    'order' => ['created' => 'DESC'],
                    'limit' => $limit,
                    'offset' => $offset
                ])->contain(['City','State','Country'])->all()->toArray();
        }

        $locations_array = array();
        $connection = ConnectionManager::get('default');
        
        $tablecitation = TableRegistry::get('Citationlist');
                                
        if (count($results) > 0):
            
            $keywordvl = 0; $crevl = 0; $sitevl = 0; $citationvl = 0;
            $results_me = $this->app->market_values(); 
            foreach ($results_me as $me_index => $me_values) {
                if ($me_index == "kv") {
                    $keywordvl = $me_values;
                } else if ($me_index == "cre") {
                    $crevl = $me_values;
                }if ($me_index == "sa") {
                    $sitevl = $me_values;
                }if ($me_index == "ca") {
                    $citationvl = $me_values;
                }
            }
            
            foreach ($results as $location):
                
                $content_score = 0; $siteaudit_score = 0; $citation_score = 0; $visibility_score = 0; $market_eff_score = 0;
                $total_keywords = 0; $google_analytics = 0; $conversion_tracking_code = 0; $keyword_campaign = 0;
                $site_audit_code = 0; $citation_code = 0;        

                $market_visibility = 0;
                $market_siteaudit = 0;
                $market_citation = 0;
                $market_cre = 0;
                
                // CRE score
                $query = "SELECT AVG(score) as content_score FROM `tbl_cre_urls` WHERE location_id = :location_id AND score > 0";
                $rescont = $connection->execute($query, ['location_id' => $location->id])->fetch('obj');
                if(!empty($rescont)){
                    $content_score = round($rescont->content_score, 2);
                    $market_cre = sprintf("%.2f", ($content_score * $crevl)/100);
                }
                
                // Total keywords
                $query = "SELECT count(id) as total_keywords FROM `tbl_keywords` WHERE location_id = :location_id AND group_id IN(SELECT id FROM tbl_keygroup WHERE status = 1 AND location_id = :location_id)";
                $restotal = $connection->execute($query, ['location_id' => $location->id])->fetch('obj');
                if(!empty($restotal)){
                    $total_keywords = $restotal->total_keywords;
                    $query = "SELECT COUNT(id) as totaltop10 FROM tbl_keywords WHERE location_id = :location_id AND (rank <= 10 AND rank IS NOT NULL) AND group_id IN(SELECT id FROM tbl_keygroup WHERE status = 1 AND location_id = :location_id)";
                    $ranktop10res = $connection->execute($query, ['location_id' => $location->id])->fetch('obj');
                    if(empty($ranktop10)){
                        $ranktop10 = $ranktop10res->totaltop10;
                        if($total_keywords > 0){
                            $visibility_score = sprintf("%.2f", ($ranktop10 / $total_keywords) * 100);
                            $market_visibility = sprintf("%.2f", ($visibility_score * $keywordvl)/100);
                            $visibility_score = $visibility_score . '%';
                        }
                    }
                }
                
                // Google analytic
                $response = $this->app->pc_post("", "", API_ENGINE_URI, "/getallconnections", "", array('location_id' => $location->id));
                $response = json_decode($response);
                if (isset($response->arr->google_token) && $response->arr->google_token != '') {
                    $google_analytics = 1;
                }
                
                // Conversion tracking
                $conversion_tracking_code = $location->conv_verified == 1?1:0;
                
                // site audit score
                $audit = TableRegistry::get('tbl_site_audit');
                $site_audit_info = $audit->find("all", [
                    'conditions' => ["location_id" => $location->id],
                    'fields' => 'all_info',
                    'order' => ['id' => 'desc']
                ])->first();
                
                if (!empty($site_audit_info)) {
                    $site_audit_result = unserialize($site_audit_info->all_info);
                    $siteaudit_score = $site_audit_result->current_snapshot->quality->value;
                    $market_siteaudit = sprintf("%.2f", ($siteaudit_score * $sitevl)/100);
                    $siteaudit_score = $siteaudit_score . '%';
                }
                
                $citData = $tablecitation->find('all')->select(["citations_data"])->where(["location_id" => $location->id, "LOWER(status)" => "complete"])->order(["modified" => 'DESC'])->first();
                if(!empty($citData)){
                    $totalcit = 0; $verified = 0;
                    $citations_data = json_decode($citData->citations_data);
                    if(!empty($citations_data)) {
                        foreach($citations_data->citations as $value){
                            if($value->isCitationVerified == 1){
                                $verified++;
                            }
                            $totalcit++;
                        }
                    }
                    if($totalcit > 0){
                        $citation_score = round(($verified / $totalcit) * 100 ,2);
                        $market_citation = sprintf("%.2f", ($citation_score * $citationvl)/100);
                        $citation_score = $totalcit."%";
                    }
                }
                
                
                $market_eff_value_all = $market_cre + $market_visibility + $market_siteaudit + $market_citation;
                
                array_push($locations_array, array(
                    "id" => $location->id,
                    "agency_id" => $location->agency_id,
                    "account_type" => $location->account_type,
                    "website" => $location->website,
                    "name" => $location->name,
                    "target" => $location->target,
                    "services" => $location->services,
                    "email" => $location->email,
                    "phone" => $location->phone,
                    "about" => $location->about,
                    "country_id" => $location->country_id,
                    "country" => $location->country,
                    "state_id" => $location->state_id,
                    "state" => $location->state,
                    "city_id" => $location->city_id,
                    "city" => $location->city,
                    "address" => $location->address,
                    "zip_code" => $location->zip_code,
                    "conv_verified" => $location->conv_verified,
                    "status" => $location->status,
                    "created" => $location->created,
                    "created_by" => $location->created_by,
                    "scores" => array(
                        "mar_eff_score" => $market_eff_value_all,
                        "keyword" => $visibility_score,
                        "content" => $content_score,
                        "site_audit" => $siteaudit_score,
                        "citation" => $citation_score,
                        "total_keywords" => $total_keywords,
                        "target" => $location->target,
                        "google_analytics" => $google_analytics,
                        "conversion_tracking_code" => $conversion_tracking_code,
                        "keyword_campaign" => $total_keywords > 0?1:0,
                        "site_audit_code" => $market_siteaudit > 0?1:0,
                        "citation_code" => $market_citation > 0?1:0
                    )
                ));
            endforeach;

        endif;

        return $locations_array;
    }

    /* remove location */

    public function remove($data = array()) {

        $location_id = isset($data['location_id']) ? intval($data['location_id']) : 0;
        $agency_id = isset($data['agency_id']) ? intval($data['agency_id']) : 0;

        $total_rows = $this->find('all', [
                    'conditions' => ['id' => $location_id, 'agency_id' => $agency_id]
                ])->count();

        if ($total_rows > 0):

            $query = $this->query();
            if ($query->delete()
                            ->where(['id' => $location_id, 'agency_id' => $agency_id])
                            ->execute()) {
                return true;
            }

            return false;
        endif;

        return false;
    }

}

?>
