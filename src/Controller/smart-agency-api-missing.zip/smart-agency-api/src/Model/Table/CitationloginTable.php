<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;

class CitationloginTable extends Table {
    /* Default method to initialize */

    public function initialize(array $config) {
        parent::initialize($config);
        $this->table('tbl_citation_logindata');
    }

}

