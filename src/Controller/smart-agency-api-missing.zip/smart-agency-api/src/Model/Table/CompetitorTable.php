<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Datasource\ConnectionManager;

class CompetitorTable extends Table {
    /* Default method to initialize */

    public function initialize(array $config) {
        parent::initialize($config);
        $this->setTable('tbl_compititors');
        $this->connection = ConnectionManager::get('default');
    }

    /* Create Campain starts here */

    public function createLocationCampaign($data = array()) {

        $this->setTable('tbl_compititors');

        $query = $this->query();

        if ($query->insert(['name', 'website', 'location_id', 'created', 'created_by', 'modified_by'])
                        ->values(
                                [
                                    'website' => $data['website'],
                                    'location_id' => $data['location_id'],
                                    'created' => date("Y-m-d H:i:s"),
                                    'created_by' => $data['user_id'],
                                    'modified_by' => $data['user_id']
                                ]
                        )
                        ->execute()) {

            return true;
        }
        //return $success_array;
        return false;
    }

    public function editLocationCampaign($data = array()) {

        $this->setTable('tbl_compititors');

        $query = $this->query();

        if ($query->update()
                        ->set(
                                [
                                    'name' => $data['name'],
                                    'website' => $data['website'],
                                    'modified' => date("Y-m-d H:i:s"),
                                    'modified_by' => $data['user_id']
                                ]
                        )
                        ->where(['id' => $data['id'], "location_id" => $data['location_id']])
                        ->execute()) {

            return true;
        } else {

            return false;
        }
    }

    public function deleteLocationCampaign($data = array()) {

        $this->setTable('tbl_compititors');

        $query = $this->query();
        // soft delete
        if ($query->update()
                        ->set(
                                [
                                    'location_id' => 0,
                                    'delete_location_id' => $data['location_id'],
                                    'modified_by' => $data['user_id']
                                ]
                        )
                        ->where(['id' => $data['id'], "location_id" => $data['location_id']])
                        ->execute()) {

            return true;
        } else {

            return false;
        }
    }

    public function is_valid_campaign($campagin_id) {

        $this->setTable('tbl_compititors');

        $results = $this->find("all", [
                    'conditions' => ['id' => $campagin_id]
                ])->all()->toArray();

        if (count($results) > 0):
            return true;
        endif;
        return false;
    }

    // added on 23 june 2017 - sanjay@rudrainnovatives.com
    public function getCompetitorKeywords($data = array(), $offset, $limit, $comp_id, $app) {

        $this->setTable("tbl_keyword_research");
        $KeywordResearchQuery = $this->query();

        $location_id = isset($data['location_id']) ? $data['location_id'] : 0;
        $limit = isset($data['limit']) ? $data['limit'] : $limit;
        $offset = isset($data['offset']) ? $data['offset'] : $offset;
        $condition = array();
        if (!empty($comp_id)) {
            if ($comp_id == -1) {
                $comp_id = 0;
            }
            $condition = array('location_id' => $location_id, "competitor_id" => $comp_id, "status" => 1);
        } else {
            $condition = array('location_id' => $location_id, "status" => 1);
        }
        $offset = $offset - 1;
        if ($offset < 0) {
            $offset = 0;
        } else if ($offset >= 1) {
            $offset = $offset * $limit;
        }

        $results = $KeywordResearchQuery->find("all", [
                    'conditions' => $condition,
                    'order' => ['created' => 'DESC'],
                    'limit' => $limit,
                    'offset' => $offset
                ])->all()->toArray();
        $keywords_array = array();

        if (count($results) > 0) {

            foreach ($results as $keyword) {
                array_push($keywords_array, array(
                    "id" => $keyword->id,
                    "url" => $keyword->url,
                    "keyword" => $keyword->keyword,
                    "position" => $keyword->position,
                    "prev_position" => $keyword->prev_position,
                    "difference" => $keyword->difference,
                    "search_volume" => $keyword->search_volume,
                    "cpc" => $app->FormatMoney($keyword->cpc),
                    "competition" => $app->PerSentFormat($keyword->competition * 10000),
                    "traffic_percent" => $app->PerSentFormat($keyword->traffic_percent * 100),
                    "traffic_cost" => $app->PerSentFormat($keyword->traffic_cost * 100),
                    "result" => $keyword->results
                ));
            }
        }
        return $keywords_array;
    }

    public function listLocationCampaign($data = array()) {

        $this->setTable('tbl_compititors');
        try {
            $campaigns_array = array();
            $results = $this->find("all", [
                        'conditions' => ['location_id' => $data['location_id']]
                    ])->all()->toArray();

            if (count($results) > 0):

                foreach ($results as $campaign):

                    array_push($campaigns_array, array(
                        "id" => $campaign->id,
                        "name" => $campaign->name,
                        "website" => $campaign->website,
                    ));

                endforeach;

            endif;

            return $campaign;
        } catch (Exception $ex) {
            
        }
    }

    public function getCompetitorsDetail($location_id, $app) {

        $competitors_array = array();
        $total_keywords = 0;
        $CompLists = $this->connection
                ->execute("SELECT  id,website,modified from tbl_compititors where location_id = " . $location_id)
                ->fetchAll('assoc');

        $location_url = $app->getLocationUrlById($location_id);
        $keyList = $this->connection
                ->execute("SELECT count(id) as count_keywords,modified from tbl_keyword_research where competitor_id = 0 AND location_id = " . $location_id)
                ->fetchAll('assoc');

        $modified = '';
        $count_keywords = 0;
        if (count($keyList) > 0) {
            $count_keywords = $keyList[0]['count_keywords'];
            $total_keywords += $count_keywords;
            $modified = $keyList[0]['modified'];
        }

        $client_details = array(
            "id" => 0,
            "url" => $location_url,
            "keywords_count" => intval($count_keywords),
            "run_date" => date("Y-m-d", strtotime($modified))
        );

        if (count($CompLists) > 0) {

            foreach ($CompLists as $index => $cmp) {
                $count_keywords = 0;
                $keywrdList = $this->connection
                        ->execute("SELECT count(id) as count_keywords from tbl_keyword_research where competitor_id = " . $cmp['id'] . " AND location_id = " . $location_id)
                        ->fetchAll('assoc');

                if (count($keywrdList) > 0) {
                    $count_keywords = $keywrdList[0]['count_keywords'];
                    $total_keywords += $count_keywords;
                }
                array_push($competitors_array, array(
                    "id" => $cmp['id'],
                    "url" => $cmp['website'],
                    "keywords_count" => intval($count_keywords),
                    "run_date" => date("Y-m-d", strtotime($cmp['modified']))
                ));
            }
        }

        return array(
            "total_keywords" => $total_keywords,
            "client" => $client_details,
            "competitors" => $competitors_array
        );
    }

    public function getRemovedCompetitorsKeyword($location_id, $app) {

        $competitors_array = array();
        $total_keywords = 0;
        $CompLists = $this->connection
                ->execute("SELECT  id,website,modified from tbl_compititors where location_id = " . $location_id)
                ->fetchAll('assoc');

        $location_url = $app->getLocationUrlById($location_id);
        $keyList = $this->connection
                ->execute("SELECT count(id) as count_keywords,modified from tbl_keyword_research where competitor_id = 0 AND status = 0 AND location_id = " . $location_id)
                ->fetchAll('assoc');

        $modified = '';
        $count_keywords = 0;
        if (count($keyList) > 0) {
            $count_keywords = $keyList[0]['count_keywords'];
            $total_keywords += $count_keywords;
            $modified = $keyList[0]['modified'];
        }

        $client_details = array(
            "id" => 0,
            "url" => $location_url,
            "keywords_count" => $count_keywords,
            "run_date" => date("Y-m-d", strtotime($modified))
        );

        if (count($CompLists) > 0) {

            foreach ($CompLists as $index => $cmp) {
                $count_keywords = 0;
                $keywrdList = $this->connection
                        ->execute("SELECT count(id) as count_keywords from tbl_keyword_research where competitor_id = " . $cmp['id'] . " AND status = 0 AND location_id = " . $location_id)
                        ->fetchAll('assoc');

                if (count($keywrdList) > 0) {
                    $count_keywords = $keywrdList[0]['count_keywords'];
                    $total_keywords += $count_keywords;
                }
                array_push($competitors_array, array(
                    "id" => $cmp['id'],
                    "url" => $cmp['website'],
                    "keywords_count" => $count_keywords,
                    "run_date" => date("Y-m-d", strtotime($cmp['modified']))
                ));
            }
        }

        return array(
            "total_keywords" => $total_keywords,
            "client" => $client_details,
            "competitors" => $competitors_array
        );
    }

}
