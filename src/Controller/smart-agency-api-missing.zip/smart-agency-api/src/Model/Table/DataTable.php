<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class DataTable extends Table {
    /* Default method to initialize */

    public function initialize(array $config) {
        parent::initialize($config);
    }

    public function countrylist() {

        try {

            $this->setTable('tbl_countries');

            $results = $this->find("all", [
                        'conditions' => ['status' => 1]
                    ])->all()->toArray();

            $countries_array = array();

            foreach ($results as $country):
                array_push($countries_array, array(
                    "id" => $country->id,
                    "code" => $country->code,
                    "name" => $country->country,
                    "phonecode" => $country->phonecode
                ));
            endforeach;

            return $countries_array;
        } catch (Exception $ex) {
            
        }
    }

    public function statelist() {

        try {

            $this->setTable('tbl_states');

            $results = $this->find("all")->all()->toArray();

            $states_array = array();

            foreach ($results as $states):
                array_push($states_array, array(
                    "id" => $states->id,
                    "country_id" => $states->country_id,
                    "name" => $states->name
                ));
            endforeach;

            return $states_array;
        } catch (Exception $ex) {
            
        }
    }

    public function citylist() {

        try {

            $this->setTable('tbl_cities');

            $results = $this->find("all")->all()->toArray();

            $cities_array = array();

            foreach ($results as $cities):
                array_push($cities_array, array(
                    "id" => $cities->id,
                    "state_id" => $cities->state_id,
                    "name" => $cities->name
                ));
            endforeach;

            return $cities_array;
        } catch (Exception $ex) {
            
        }
    }

    public function statesByCountryId($data = array()) {

        try {

            $this->setTable('tbl_states');
            $countryId = isset($data['country_id']) ? intval($data['country_id']) : 0;

            $results = $this->find("all", [
                        'conditions' => ['country_id' => $countryId]
                    ])->all()->toArray();

            $states_array = array();

            if (count($results) > 0):

                foreach ($results as $states):

                    array_push($states_array, array(
                        "id" => $states->id,
                        "country_id" => $states->country_id,
                        "name" => $states->name
                    ));

                endforeach;

            endif;

            return $states_array;
        } catch (Exception $ex) {
            
        }
    }

    public function citiesByStateId($data = array()) {

        try {

            $this->setTable('tbl_cities');
            $stateId = isset($data['state_id']) ? intval($data['state_id']) : 0;

            $results = $this->find("all", [
                        'conditions' => ['state_id' => $stateId]
                    ])->all()->toArray();

            $cities_array = array();

            if (count($results) > 0):

                foreach ($results as $city):

                    array_push($cities_array, array(
                        "id" => $city->id,
                        "state_id" => $city->state_id,
                        "name" => $city->name
                    ));

                endforeach;
            endif;

            return $cities_array;
        } catch (Exception $ex) {
            
        }
    }

}
?>

