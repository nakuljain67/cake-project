<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;

class CitationTable extends Table {
    /* Default method to initialize */

    public function initialize(array $config) {
        parent::initialize($config);
        $this->table('tbl_citations');
        $this->hasMany('Citationlist')->setForeignKey('citation_id');
	$this->belongsTo('City')->setForeignKey('city_id');
	$this->belongsTo('State')->setForeignKey('state_id');
        $this->belongsTo('Country')->setForeignKey('country_id');
    }

}

?>
