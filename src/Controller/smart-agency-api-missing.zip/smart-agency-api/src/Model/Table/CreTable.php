<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Datasource\ConnectionManager;

class CreTable extends Table {
    /* Default method to initialize */

    public function initialize(array $config) {
        parent::initialize($config);
        $this->connection = ConnectionManager::get('default');
    }

    public function alltargetpages($data = array(), $app) {

        $this->setTable('tbl_keygroup');

        $token = isset($data['token']) ? $data['token'] : 0;
        $user_id = 0;
        $location_id = 0;

        $target_pages = array();

        if (!empty($token)) {
            
            $tokendetail = $app->fetchTokenDetails($token);
            $user_id = $tokendetail['user_id'];
            $location_id = $tokendetail['location_id'];
                        
        } else {
            return $target_pages;
        }

        /* get all target pages */
        $results = $this->find("all", [
                    'conditions' => ['location_id' => $location_id, 'status' => 1]
                ])->all()->toArray();


        foreach ($results as $page):
            array_push($target_pages, $page->landing_page);
        endforeach;

        return $target_pages;
    }

    /* cre_queue entry */

    public function saveToCREQueue($data = array()) {

        $this->setTable('tbl_cre_queue');

        /* post variables */
        $type = isset($data['type']) ? trim($data['type']) : "targetpage";
        $location_id = isset($data['location_id']) ? trim($data['location_id']) : "";

        $query = $this->query();

        if ($query->insert(['type', 'location_id', 'next_index', 'current_last_id', 'created_dt'])
                        ->values(
                                [
                                    'type' => $type,
                                    'location_id' => $location_id,
                                    'next_index' => 0,
                                    'current_last_id' => 45,
                                    'created_dt' => date("Y-m-d H:i:s")
                                ]
                        )
                        ->execute()) {

            return true;
        }
        return false;
    }

    /* update cre_queue table */

    public function updateCREQueue($data = array()) {

        $location_id = isset($data['location_id']) ? intval($data['location_id']) : 0;
        $this->setTable('tbl_cre_queue');

        $results = $this->find("all", [
                    'conditions' => ['location_id' => $location_id]
                ])->all()->toArray();

        if (count($results) > 0):

            $query = $this->query();
            if ($query->update()
                            ->set(
                                    [
                                        'processed' => json_encode(array(1, 2, 3, 4, 5, 6, 7)),
                                        'next_index' => 8,
                                        'current_last_id' => 4,
                                        'updated_dt' => date("Y-m-d H:i:s")
                                    ]
                            )
                            ->where(['location_id' => $location_id])
                            ->execute()) {
                return true;
            } else {
                return false;
            }

        endif;
    }

    /* function to insert url to cre_urls */

    public function saveToCREUrls($data = array()) {

        $location_id = isset($data['location_id']) ? intval($data['location_id']) : 0;
        $url = isset($data['url']) ? trim($data['url']) : '';
        $created_by = isset($data['created_by']) ? intval($data['created_by']) : 0;

        $this->setTable('tbl_cre_urls');

        $query = $this->query();

        if ($query->insert(['url', 'location_id', 'is_running', 'rundate', 'created', 'created_by'])
                        ->values(
                                [
                                    'url' => $url,
                                    'location_id' => $location_id,
                                    'is_running' => 1,
                                    'rundate' => date("Y-m-d H:i:s"),
                                    'created' => date("Y-m-d H:i:s"),
                                    'created_by' => $created_by
                                ]
                        )
                        ->execute()) {

            return true;
        }
        return false;
    }

    /* function to get page limits */

    public function getPageURLLimits($location_id) {

        $this->setTable('tbl_cre_queue');

        $getLimits = $this->find("all", [
                    'conditions' => ['location_id' => $location_id]
                ])->all()->toArray();

        if (count($getLimits) > 0) {

            foreach ($getLimits as $index => $data) {

                return $data->next_index;
            }
        }

        return '';
    }

    /* fetch all cre_urls All pgaes */

    public function getCREUrlsOfLocation($data = array()) {

        $this->setTable('tbl_cre_urls');

        $limit = $data['limit'];

        $countTotalRowsFound = $this->find("all", [
                    'conditions' => ['location_id' => $data['location_id']]
                ])->all()->toArray();

        $results = $this->find("all", [
                    'conditions' => ['location_id' => $data['location_id']],
                    'limit' => $limit,
                    'offset' => $data['offset']
                ])->all()->toArray();

        $urls_array = array();

        if (count($results) > 0):

            foreach ($results as $index => $url):

                array_push($urls_array, array(
                    "page_id" => $url->id,
                    "page_url" => $url->url,
                    'ov' => isset($url->organic_visits) ? $url->organic_visits : 0,
                    'oc' => isset($url->organic_conv) ? $url->organic_conv : 0,
                    'tos' => isset($url->time_on_site) ? $url->time_on_site : 0,
                    'br' => isset($url->bounce_rate) ? $url->bounce_rate : 0,
                    'score' => isset($url->score) ? intval($url->score) : 0,
                    'issues' => isset($url->total_issues) ? $url->total_issues : 0,
                    'is_running' => $url->is_running
                ));
            endforeach;

        endif;
        return array("urls" => $urls_array, "count" => count($countTotalRowsFound));
    }

    /* function to get cre graph data */

    public function creGraphDataFinder($data = array()) {

        $this->setTable('tbl_cre_urls');

        $dashboard_data_array = array();

        $location_id = isset($data['location_id']) ? intval($data['location_id']) : 3;
        if ($location_id == 0) {
            return $dashboard_data_array;
        }
        $cre_running_status = 0;
        $is_cre_running = $this->find("all", [
                    'conditions' => ['location_id' => $location_id, "is_running" => 1]
                ])->all()->toArray();

        if (count($is_cre_running) > 0) {
            $cre_running_status = 1;
        }

        $query = $this->find();

        $result = $query
                ->select([
                    'total_issues' => $query->func()->sum('total_issues'),
                    'meta_issues' => $query->func()->sum('total_meta_issues'),
                    'title_issues' => $query->func()->sum('total_title_issues'),
                    'content_issues' => $query->func()->sum('total_content_issues'),
                    'heading_issues' => $query->func()->sum('total_heading_issues'),
                    'link_issues' => $query->func()->sum('total_link_issues'),
                    'image_issues' => $query->func()->sum('total_image_issues'),
                    'score' => $query->func()->avg('score'),
                    'pages' => $query->func()->count('id'),
                    "running_status" => $cre_running_status
                ])
                ->where(['location_id' => $location_id, 'is_running' => 0])
                ->toArray();

        return $result;
    }

    public function insertToTblCRE($location_id, $queryType, $dataF = array()) {

        $this->setTable('tbl_cre');

        $cre_data_array = array();

        $query = $this->query();

        if ($queryType == "insert") {

            // cre_cache tbl insert
            if ($query->insert(['type', 'location_id', 'trigger_report', 'rundate', 'created'])
                            ->values(
                                    [
                                        'type' => $dataF['type'],
                                        'location_id' => $dataF['location_id'],
                                        'trigger_report' => $dataF['trigger_report'],
                                        'rundate' => date("Y-m-d H:i:s"),
                                        'created' => date("Y-m-d H:i:s"),
                                    ]
                            )
                            ->execute()) {

                return true;
            }
            return false;
        } else if ($queryType == "update") {
            
        } else if ($queryType == "delete") {
            
        } else if ($queryType == "select") {
            
        }
    }

    public function operationForReverseSEO($location_id, $queryType, $dataF = array()) {

        $this->setTable("tbl_reverse_seo");
        $cre_seo_data_array = array();
        $query = $this->query();

        if ($queryType == "update") {
            // update query
            if ($query->update()
                            ->set(
                                    [
                                        'location_id' => $dataF['location_id'],
                                        'page_url' => $dataF['page_url'],
                                        'keyword' => $dataF['keyword'],
                                        'position' => $dataF['position'],
                                        'search_voulme' => $dataF['search_volume'],
                                        'cpc' => $dataF['CPC'],
                                        'competiton' => $dataF['competition'],
                                        'traffic_percent' => $dataF['traffic_percent'],
                                        'traffic_cost' => $dataF['traffic_cost'],
                                        'modified' => date("Y-m-d H:i:s")
                                    ]
                            )
                            ->where(['id' => $dataF['id']])
                            ->execute()) {
                return true;
            }
            return false;
        } else if ($queryType == "insert") {
            if ($query->insert(['location_id', 'page_url', 'keyword', 'position', 'search_voulme', 'cpc', 'competiton', 'traffic_percent', 'traffic_cost', 'created', 'created_by'])
                            ->values(
                                    [
                                        'location_id' => $dataF['location_id'],
                                        'page_url' => $dataF['page_url'],
                                        'keyword' => $dataF['keyword'],
                                        'position' => $dataF['position'],
                                        'search_voulme' => $dataF['search_volume'],
                                        'cpc' => $dataF['CPC'],
                                        'competiton' => $dataF['competition'],
                                        'traffic_percent' => $dataF['traffic_percent'],
                                        'traffic_cost' => $dataF['traffic_cost'],
                                        'created' => date("Y-m-d H:i:s"),
                                        'created_by' => $dataF['created_by'],
                                    ]
                            )
                            ->execute()) {

                return true;
            }
        } else if ($queryType == "select") {

            $last_modified_date = '';

            $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $dataF['url'])), "/");

            $results = $this->connection
                    ->execute("SELECT * FROM tbl_reverse_seo WHERE TRIM(BOTH  '/' FROM REPLACE(REPLACE(REPLACE (page_url, 'http://', ''),'https://',''),'www.','')) like '$trimurl' limit " . $dataF['offset'] . "," . $dataF['limit'])
                    ->fetchAll('assoc');

            $results_count = $this->connection
                    ->execute("SELECT count(id) as total FROM tbl_reverse_seo WHERE TRIM(BOTH  '/' FROM REPLACE(REPLACE(REPLACE (page_url, 'http://', ''),'https://',''),'www.','')) like '$trimurl'")
                    ->fetchAll('assoc');

            $find_seo = array();

            if (count($results) > 0) {

                foreach ($results as $index => $data) {

                    array_push($find_seo, array(
                        "page_url" => $data['page_url'],
                        "keyword" => $data['keyword'],
                        "position" => $data['position'],
                        "search_voulme" => $data['search_voulme'],
                        "cpc" => $data['cpc'],
                        "competiton" => $data['competiton'],
                        "traffic_percent" => $data['traffic_percent'],
                        "traffic_cost" => $data['traffic_cost'],
                        "created" => $data['created'],
                        "modified" => $data['modified']
                    ));

                    $last_modified_date = $data['modified'];
                }
            }

            return array("seo_data" => $find_seo, "last_date" => $last_modified_date, "total_count" => $results_count[0]['total']);
        }
    }

    public function updateCREQueueProccessedData($location_id, $queryType, $dataF = array()) {

        $this->setTable('tbl_cre_queue');

        $cre_data_array = array();
        $query = $this->query();

        if ($queryType == "insert") {
            // insert query
        } else if ($queryType == "updateProccess") {
            // update query
            if ($query->update()
                            ->set(
                                    [
                                        'processed' => $dataF['processed'],
                                        'updated_dt' => date("Y-m-d H:i:s")
                                    ]
                            )
                            ->where(['location_id' => $dataF['location_id']])
                            ->execute()) {
                return true;
            }
            return false;
        } else if ($queryType == "updateLastId") {
            // update query
            if ($query->update()
                            ->set(
                                    [
                                        'last_id' => $dataF['last_id'],
                                        'updated_dt' => date("Y-m-d H:i:s")
                                    ]
                            )
                            ->where(['location_id' => $dataF['location_id']])
                            ->execute()) {
                return true;
            }
            return false;
        } else if ($queryType == "updatePageIndex") {
            
        } else if ($queryType == "delete") {
            // delete query
        } else if ($queryType == "select") {
            // select query

            $crequeue_data_array = array();

            $results = $this->find("all", [
                        'conditions' => ['location_id' => $dataF['location_id']]
                    ])->all()->toArray();

            if (count($results) > 0) {

                foreach ($results as $index => $data) {

                    array_push($crequeue_data_array, array(
                        "processed" => json_decode($data->processed)
                    ));
                }
            }

            return $crequeue_data_array;
        }
    }

    public function operationOnCREUrlsTable($location_id, $queryType, $dataF = array()) {

        $this->setTable('tbl_cre_urls');

        $creurls_data_array = array();
        $query = $this->query();

        if ($queryType == "insert") {
            // insert query
        } else if ($queryType == "update") {
            // update data
        } else if ($queryType == "delete") {
            // delete query
            $total_rows = $this->find('all', [
                        'conditions' => ['location_id' => $location_id]
                    ])->count();

            if ($total_rows > 0) {
                $this->deleteAll(['location_id' => $location_id]);
                return true;
            }
            return false;
        } else if ($queryType == "select") {
            // select query
        }
    }

    public function operationOnUrlProfileNotes($location_id, $queryType, $dataF = array()) {

        $this->setTable('tbl_notes');

        $creurls_data_array = array();
        $query = $this->query();

        if ($queryType == "insert") {

            // cre_queue insert 
            if ($query->insert(['location_id', 'notes', 'url', 'keyword', 'created', 'created_by'])
                            ->values(
                                    [
                                        'location_id' => $dataF['location_id'],
                                        'notes' => $dataF['notes'],
                                        'url' => $dataF['url'],
                                        'keyword' => $dataF['keyword'],
                                        'created' => date("Y-m-d H:i:s"),
                                        "created_by" => $dataF['created_by']
                                    ]
                            )
                            ->execute()) {

                return true;
            }
            return false;
        } else if ($queryType == "update") {
            // update data
        } else if ($queryType == "delete") {
            // delete query
        } else if ($queryType == "select") {
            // select query
            $crenotes_data_array = array();

            $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $dataF['url'])), "/");

            $results = $this->connection
                    ->execute("SELECT * FROM tbl_notes WHERE location_id = " . $location_id . " and TRIM(BOTH  '/' FROM REPLACE(REPLACE(REPLACE (url, 'http://', ''),'https://',''),'www.','')) like '$trimurl' order by id desc limit " . $dataF['offset'] . "," . $dataF['limit'])
                    ->fetchAll('assoc');

            /* $results = $query->find('all', array('conditions' => array('location_id' => $location_id, 'url' => $dataF['url']),
              'limit' => $data['limit'],
              'offset' => $data['offset'], 'order' => array('id' => 'DESC'))); */

            if (count($results) > 0) {

                foreach ($results as $index => $data) {

                    array_push($crenotes_data_array, array(
                        "location_id" => $data['location_id'],
                        "notes" => $data['notes'],
                        "url" => $data['url'],
                        "keyword" => $data['keyword'],
                        "created_by" => $data['created_by'],
                        "created" => $data['created']
                    ));
                }
            }

            return $crenotes_data_array;
        }
    }

}

?>
