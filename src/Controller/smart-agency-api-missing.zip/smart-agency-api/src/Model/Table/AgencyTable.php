<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class AgencyTable extends Table {
    /* Default method to initialize */

    public function initialize(array $config) {
        parent::initialize($config);
        $this->setTable('tbl_agencies');
    }

    /* create agency */

    public function create($data = array()) {

        /*
         * Agency Prefix Should be unique 
         */
        try {

            $agency_type = isset($data['agency_type']) ? intval($data['agency_type']) : 1;
            $name = isset($data['name']) ? trim($data['name']) : "";
            $email = isset($data['email']) ? trim($data['email']) : "";
            $phone = isset($data['phone']) ? trim($data['phone']) : "";
            $prefix = isset($data['prefix']) ? trim($data['prefix']) : "";
            $url = isset($data['url']) ? trim($data['url']) : "";
            $white_lbl = isset($data['white_lbl']) ? trim($data['white_lbl']) : "";
            $logo = isset($data['logo']) ? trim($data['logo']) : "";
            $logo_pos = isset($data['logo_pos']) ? trim($data['logo_pos']) : "";
            $pdf_logo = isset($data['pdf_logo']) ? trim($data['pdf_logo']) : "";
            $about = isset($data['about']) ? trim($data['about']) : "";
            $country_id = isset($data['country_id']) ? intval($data['country_id']) : "";
            $state_id = isset($data['state_id']) ? intval($data['state_id']) : "";
            $city_id = isset($data['city_id']) ? intval($data['city_id']) : "";
            $address = isset($data['address']) ? trim($data['address']) : "";
            $zip_code = isset($data['zip_code']) ? trim($data['zip_code']) : "";
            $lang_code = isset($data['lang_code']) ? trim($data['lang_code']) : "";
            $currency_code = isset($data['currency_code']) ? trim($data['currency_code']) : "";
            $created_by = isset($data['created_by']) ? intval($data['created_by']) : "";
            $created = date("Y-m-d H:i:s");

            $query = $this->query();
            $success_array = array();

            if ($query->insert(['agency_type', 'name', 'email', 'phone', 'prefix', 'url', 'white_lbl', 'logo', 'logo_pos', 'pdf_logo', 'about', 'country_id', 'state_id', 'city_id', 'address', 'zip_code', 'lang_code', 'currency_code', 'status', 'created', 'created_by'])
                            ->values(
                                    [
                                        'agency_type' => $agency_type,
                                        'name' => $name,
                                        'email' => $email,
                                        'phone' => $phone,
                                        'prefix' => $prefix,
                                        'url' => $url,
                                        'white_lbl' => $white_lbl,
                                        'logo' => $logo,
                                        'logo_pos' => $logo_pos,
                                        'pdf_logo' => $pdf_logo,
                                        'about' => $about,
                                        'country_id' => $country_id,
                                        'state_id' => $state_id,
                                        'city_id' => $city_id,
                                        'address' => $address,
                                        'zip_code' => $zip_code,
                                        'lang_code' => $lang_code,
                                        'currency_code' => $currency_code,
                                        'status' => 1,
                                        'created' => $created,
                                        'created_by' => $created_by
                                    ]
                            )
                            ->execute()) {

                $result = $this->find('all', ['fields' => 'id'])->last();

                array_push($success_array, $result);
            }
            return $success_array;
        } catch (Exception $ex) {
            
        }
    }

    /* edit agency */

    public function edit($data = array()) {

        $agency_id = isset($data['agency_id']) ? intval($data['agency_id']) : 0;

        $agency_type = isset($data['agency_type']) ? intval($data['agency_type']) : 1;
        $name = isset($data['name']) ? trim($data['name']) : "";
        $email = isset($data['email']) ? trim($data['email']) : "";
        $phone = isset($data['phone']) ? trim($data['phone']) : "";
        $url = isset($data['url']) ? trim($data['url']) : "";
        $white_lbl = isset($data['white_lbl']) ? trim($data['white_lbl']) : "";
        $logo = isset($data['logo']) ? trim($data['logo']) : "";
        $logo_pos = isset($data['logo_pos']) ? trim($data['logo_pos']) : "";
        $pdf_logo = isset($data['pdf_logo']) ? trim($data['pdf_logo']) : "";
        $about = isset($data['about']) ? trim($data['about']) : "";
        $country_id = isset($data['country_id']) ? intval($data['country_id']) : "";
        $state_id = isset($data['state_id']) ? intval($data['state_id']) : "";
        $city_id = isset($data['city_id']) ? intval($data['city_id']) : "";
        $address = isset($data['address']) ? trim($data['address']) : "";
        $zip_code = isset($data['zip_code']) ? trim($data['zip_code']) : "";
        $lang_code = isset($data['lang_code']) ? trim($data['lang_code']) : "";
        $currency_code = isset($data['currency_code']) ? trim($data['currency_code']) : "";
        $modified = date("Y-m-d H:i:s");

        $results = $this->find("all", [
                    'conditions' => ['id' => $agency_id]
                ])->all()->toArray();

        if (count($results) > 0):

            $query = $this->query();
            if ($query->update()
                            ->set(
                                    [
                                        'agency_type' => $agency_type,
                                        'name' => $name,
                                        'email' => $email,
                                        'phone' => $phone,
                                        'url' => $url,
                                        'white_lbl' => $white_lbl,
                                        'logo' => $logo,
                                        'logo_pos' => $logo_pos,
                                        'pdf_logo' => $pdf_logo,
                                        'about' => $about,
                                        'country_id' => $country_id,
                                        'state_id' => $state_id,
                                        'city_id' => $city_id,
                                        'address' => $address,
                                        'zip_code' => $zip_code,
                                        'lang_code' => $lang_code,
                                        'currency_code' => $currency_code,
                                        'modified' => $modified
                                    ]
                            )
                            ->where(['id' => $agency_id])
                            ->execute()) {

                return true;
            } else {

                return false;
            }
        else:

            return false;
        endif;
    }

    /* remove agency */

    public function remove($data = array()) {

        try {

            $agency_id = isset($data['agency_id']) ? intval($data['agency_id']) : 0;

            $total_rows = $this->find('all', [
                        'conditions' => ['id' => $agency_id]
                    ])->count();

            if ($total_rows > 0):

                $query = $this->query();
                if ($query->delete()
                                ->where(['id' => $agency_id])
                                ->execute()) {
                    return true;
                }

                return false;
            endif;

            return false;
        } catch (Exception $ex) {
            
        }
    }

    /* update agency status */

    public function updateStatus($data = array()) {

        try {

            $agency_id = isset($data['agency_id']) ? intval($data['agency_id']) : 0;
            $status = isset($data['status']) ? intval($data['status']) : 1;

            $total_rows = $this->find('all', [
                        'conditions' => ['id' => $agency_id]
                    ])->count();

            if ($total_rows > 0):
                $query = $this->query();
                if ($query->update()
                                ->set(
                                        [
                                            'status' => $status
                                        ]
                                )
                                ->where(['id' => $agency_id])
                                ->execute()) {

                    return true;
                } else {

                    return false;
                }

            endif;

            return false;
        } catch (Exception $ex) {
            
        }
    }

    /* get agency list */

    public function getList($data = array(), $offset, $limit, $app) {

        try {

            $list = array();
            $limit = isset($data['limit']) ? $data['limit'] : $limit;
            $offset = isset($data['offset']) ? $data['offset'] : $offset;

            $results = $this->find("all", [
                        'conditions' => ['status' => 1],
                        'limit' => $limit,
                        'offset' => $offset
                    ])->all()->toArray();

            if (count($results) > 0):

                foreach ($results as $agency):

                    array_push($list, array(
                        "agency_id" => $agency->id,
                        "agency_type" => $app->getAgencyAccountType($agency->agency_type),
                        "name" => $agency->name,
                        "email" => $agency->email,
                        "phone" => $agency->phone,
                        "prefix" => $agency->prefix,
                        "url" => $agency->url,
                        "white_lbl" => $agency->white_lbl,
                        "logo" => $agency->logo,
                        "logo_pos" => $agency->logo_pos,
                        "pdf_logo" => $agency->pdf_logo,
                        "about" => $agency->about,
                        "country_details" => $app->getCountryDetailsById($agency->country_id),
                        "state_details" => $app->getStateDetailsById($agency->state_id),
                        "city_details" => $app->getCityDetailsById($agency->city_id),
                        "address" => $agency->address,
                        "zip_code" => $agency->zip_code,
                        "lang_code" => $agency->lang_code,
                        "currency_code" => $agency->currency_code,
                        "created" => $agency->created
                    ));
                endforeach;

            endif;

            return $list;
        } catch (Exception $ex) {
            
        }
    }

    /* get specific agency details */

    public function agencydetails($data = array(), $app) {

        try {

            $agency_id = isset($data['agency_id']) ? intval($data['agency_id']) : 0;
            $results = $this->find("all", [
                        'conditions' => ['id' => $agency_id]
                    ])->all()->toArray();

            $details = array();

            if (count($results) > 0) {

                foreach ($results as $agency):

                    array_push($details, array(
                        "agency_id" => $agency->id,
                        "agency_type" => $app->getAgencyAccountType($agency->agency_type),
                        "name" => $agency->name,
                        "email" => $agency->email,
                        "phone" => $agency->phone,
                        "prefix" => $agency->prefix,
                        "url" => $agency->url,
                        "white_lbl" => $agency->white_lbl,
                        "logo" => $agency->logo,
                        "logo_pos" => $agency->logo_pos,
                        "pdf_logo" => $agency->pdf_logo,
                        "about" => $agency->about,
                        "country_details" => $app->getCountryDetailsById($agency->country_id),
                        "state_details" => $app->getStateDetailsById($agency->state_id),
                        "city_details" => $app->getCityDetailsById($agency->city_id),
                        "address" => $agency->address,
                        "zip_code" => $agency->zip_code,
                        "lang_code" => $agency->lang_code,
                        "currency_code" => $agency->currency_code,
                        "created" => $agency->created
                    ));

                endforeach;
            }

            return $details;
        } catch (Exception $ex) {
            
        }
    }

    /* get all agency types */

    public function getagencytypes() {

        try {

            $this->setTable('tbl_agency_types');

            $results = $this->find("all")->all()->toArray();

            $types_array = array();

            foreach ($results as $type):
                array_push($types_array, array(
                    "id" => $type->id,
                    "type" => $type->type,
                ));
            endforeach;

            return $types_array;
        } catch (Exception $ex) {
            
        }
    }

    /* Check Agency Prefix Availability */

    public function is_prefix_available($prefix) {

        $results = $this->find("all", [
                    'conditions' => ['prefix' => $prefix]
                ])->all()->toArray();

        if (count($results) > 0) {

            return true;
        } else {

            return false;
        }
    }

    /* get Agency Status */

    public function getAgencyStatus($agencyId) {

        $results = $this->find("all", [
                    'conditions' => ['id' => $agencyId]
                        ], ['fields' => 'status'])->first();

        $agency_details = array();

        if (count($results) > 0) {

            $results = $results->toArray();

            return $results['status'];
        }

        return '';
    }

}

?>