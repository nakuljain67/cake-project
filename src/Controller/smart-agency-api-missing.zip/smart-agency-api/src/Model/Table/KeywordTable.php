<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Datasource\ConnectionManager;

class KeywordTable extends Table {
    /* Default method to initialize */

    public function initialize(array $config) {
        parent::initialize($config);
        $this->connection = ConnectionManager::get('default');
    }

    public function getLocationCampaignKeywords($data = array()) {

        $columns = "kw.keyword,kw.ranked_url,kw.rank,kw.maps_rank,kw.mobile_rank,kw.mobile_maps_rank,kw.bing_rank,kw.bing_maps_rank,kw.googleSearchVolume,kw.cpc,kw.difficulty,kw.isprimary,kg.is_target";

        $orderBy = '';
        $is_primary_conditions = '';
        $is_target_conditions = '';

        // Keyword is primary or not condition
        if ($data['is_primary'] == 1) {
            $is_primary_conditions = 'AND kw.isprimary = 1';
        }

        if ($data['is_target'] == 1) {
            $is_target_conditions = 'AND kg.is_target = 1';
        }

        // ORDER BY condition
        $order = $data['order'];
        if ($order == "sort_from_a_z") {
            $orderBy = "order by keyword ASC";
        } else if ($order == "sort_from_z_a") {
            $orderBy = "order by keyword DESC";
        } else if ($order == "created_date_asc") {
            $orderBy = "order by created ASC";
        } else if ($order == "created_date_desc") {
            $orderBy = "order by created DESC";
        } else if ($order == "updated_date_asc") {
            $orderBy = "order by modified ASC";
        } else if ($order == "updated_date_desc") {
            $orderBy = "order by modified DESC";
        }

        if (!isset($data['campaign_id'])) {

            $results = $this->connection
                    ->execute("SELECT $columns FROM tbl_keywords kw INNER JOIN tbl_keygroup kg ON kw.group_id = kg.id WHERE kw.location_id = " . $data['location_id'] . " $is_primary_conditions $is_target_conditions $orderBy")
                    ->fetchAll('assoc');
        } else {

            $results = $this->connection
                    ->execute("SELECT $columns FROM tbl_keywords kw INNER JOIN tbl_keygroup kg ON kw.group_id = kg.id WHERE kw.campaign_id = " . $data['campaign_id'] . " AND kw.location_id = " . $data['location_id'] . " $is_primary_conditions $is_target_conditions $orderBy")
                    ->fetchAll('assoc');
        }

        return $results;
    }

    /* Create Campain starts here */

    public function createLocationCampaign($data = array()) {

        $this->setTable('tbl_campaigns');

        $query = $this->query();

        if ($query->insert(['name', 'target_country', 'local_location', 'location_id', 'user_id', 'created', 'created_by'])
                        ->values(
                                [
                                    'name' => $data['name'],
                                    'target_country' => $data['country'],
                                    'local_location' => $data['google_location'],
                                    'location_id' => $data['location_id'],
                                    'user_id' => $data['user_id'],
                                    'created' => date("Y-m-d H:i:s"),
                                    'created_by' => $data['user_id'],
                                    'modified_by' => $data['user_id']
                                ]
                        )
                        ->execute()) {

            //$result = $this->find('all', ['fields' => 'id'])->last();
            //array_push($success_array, $result);
            return true;
        }
        //return $success_array;
        return false;
    }

    public function editLocationCampaign($data = array()) {

        $this->setTable('tbl_campaigns');

        $query = $this->query();

        if ($query->update()
                        ->set(
                                [
                                    'name' => $data['name'],
                                    'target_country' => $data['country'],
                                    'local_location' => $data['google_location'],
                                    'modified' => date("Y-m-d H:i:s"),
                                    'modified_by' => $data['user_id']
                                ]
                        )
                        ->where(['id' => $data['campaign_id'], "location_id" => $data['location_id']])
                        ->execute()) {

            return true;
        } else {

            return false;
        }
    }

    public function deleteLocationCampaign($data = array(), $app) {

        $campaign_id = $data['campaign_id'];

        $campaign = $this->connection
                ->execute("SELECT id, ranking_id FROM tbl_campaigns WHERE id = $campaign_id")
                ->fetchAll('assoc');

        if (empty($campaign)) {

            return array("status" => false, "message" => "invalid campaign id");
        }

        $ranking_id = $campaign[0]['ranking_id'];
        // still it is not working, so commented
        // $isdel = $app->delete_rank_report($ranking_id);
        $isdel = 1;
        if ($isdel == 1) {

            // delete keywords
            $this->connection
                    ->execute("DELETE FROM tbl_keywords WHERE campaign_id = $campaign_id AND location_id = " . $data['location_id']);

            // delete group
            $this->connection
                    ->execute("DELETE FROM tbl_keygroup WHERE campaign_id = $campaign_id AND location_id = " . $data['location_id']);

            // delete campaign
            $this->connection
                    ->execute("DELETE FROM tbl_campaigns WHERE id = $campaign_id AND location_id = " . $data['location_id']);

            return array("status" => true, "message" => "Campaign successfully deleted");
        }

        return array("status" => true, "message" => "Campaign is not deleted");
    }

    public function is_valid_campaign($campagin_id) {

        $this->setTable('tbl_campaigns');

        $results = $this->find("all", [
                    'conditions' => ['id' => $campagin_id]
                ])->all()->toArray();

        if (count($results) > 0):
            return true;
        endif;
        return false;
    }

    public function listLocationCampaign($data = array()) {

        $this->setTable('tbl_campaigns');
        try {
            $campaigns_array = array();
            $results = $this->find("all", [
                        'conditions' => ['location_id' => $data['location_id'], "status" => 1]
                    ])->order(['id' => 'DESC'])->all()->toArray();

            if (count($results) > 0):

                foreach ($results as $campaign):

                    $target = 'national';

                    if (!empty($campaign->local_location)) {
                        $target = "local";
                    }

                    $keywords = $this->connection
                            ->execute('SELECT count(id) as totalKeywords FROM tbl_keywords WHERE campaign_id = ' . $campaign->id . " AND location_id = " . $data['location_id'])
                            ->fetchAll('assoc');

                    array_push($campaigns_array, array(
                        "campaign_id" => $campaign->id,
                        "name" => $campaign->name,
                        "target" => $target,
                        "count_keywords" => intval($keywords[0]['totalKeywords']),
                        "country_id" => $campaign->target_country,
                        "google_location" => $campaign->local_location
                    ));

                endforeach;

            endif;

            return $campaigns_array;
        } catch (Exception $ex) {
            
        }
    }

    /* Keygroup Operations Starts */

    public function createLocationKeygroup($data = array()) {

        $this->setTable('tbl_keygroup');

        $query = $this->query();

        $success_array = array();

        if ($query->insert(['campaign_id', 'location_id', 'google_location', 'landing_page', 'live_date', 'home_page', 'resource_page', 'notes', 'is_target', 'user_id', 'status', 'created', 'created_by'])
                        ->values(
                                [
                                    'campaign_id' => $data['campaign_id'],
                                    'location_id' => $data['location_id'],
                                    'google_location' => $data['google_location'],
                                    'landing_page' => $data['landing_page'],
                                    "live_date" => $data['live_date'],
                                    "home_page" => $data['home_page'],
                                    "resource_page" => $data['resource_page'],
                                    'is_target' => $data['is_target'],
                                    "notes" => $data['notes'],
                                    'user_id' => $data['user_id'],
                                    "status" => $data['status'],
                                    'created' => date("Y-m-d H:i:s"),
                                    'created_by' => $data['user_id'],
                                    'modified_by' => $data['user_id']
                                ]
                        )
                        ->execute()) {

            $result = $query->find('all', ['fields' => 'id'])->last();
            array_push($success_array, $result);
            //return true;
        }
        return $success_array;
        //return false;
    }

    public function updateLocationKeygroup($data = array()) {

        $this->setTable('tbl_keygroup');

        $query = $this->query();

        if ($query->update()
                        ->set(
                                [
                                    'campaign_id' => $data['campaign_id'],
                                    'google_location' => $data['google_location'],
                                    'landing_page' => $data['landing_page'],
                                    "live_date" => $data['live_date'],
                                    "home_page" => $data['home_page'],
                                    "resource_page" => $data['resource_page'],
                                    'is_target' => $data['is_target'],
                                    "notes" => $data['notes'],
                                    'user_id' => $data['user_id'],
                                    "status" => $data['status'],
                                    'modified' => date("Y-m-d H:i:s"),
                                    'modified_by' => $data['user_id']
                                ]
                        )
                        ->where(['id' => $data['group_id'], "location_id" => $data['location_id']])
                        ->execute()) {

            return true;
        } else {

            return false;
        }
    }

    public function is_valid_keygroup($keygroup_id) {

        $this->setTable('tbl_keygroup');

        $results = $this->find("all", [
                    'conditions' => ['id' => $keygroup_id]
                ])->all()->toArray();

        return $results;
    }

    public function deleteLocationKeygroup($data = array()) {

        $this->setTable('tbl_keygroup');
        $keygroupTable = $this->query();

        $total_rows = $keygroupTable->find('all', [
                    'conditions' => ['id' => $data['keygroup_id']]
                ])->count();

        if ($total_rows > 0) {

            // delete keywords first
            $this->connection
                    ->execute("DELETE FROM tbl_keywords WHERE group_id = " . $data['keygroup_id'] . " AND location_id = " . $data['location_id']);

            // delete keygroup then
            $this->connection
                    ->execute("DELETE FROM tbl_keygroup WHERE id = " . $data['keygroup_id'] . " AND location_id = " . $data['location_id']);

            return true;
        } else {

            return false;
        }
    }

    public function listLocationKeygroups($data = array()) {

        $this->setTable('tbl_keygroup');

        try {
            $keygroups_array = array();

            $campaign_id = $data['campaign_id'];

            if ($campaign_id > 0) {

                $results = $this->connection
                        ->execute("SELECT group_id,keyword from tbl_keywords where location_id = " . $data['location_id'] . " AND campaign_id = " . $campaign_id . " and isprimary = 1 and group_id IN(select id from tbl_keygroup where campaign_id = " . $campaign_id . " and status = 1) order by id DESC")
                        ->fetchAll('assoc');
            } else {

                $results = $this->connection
                        ->execute("SELECT group_id,keyword from tbl_keywords where location_id = " . $data['location_id'] . " AND isprimary = 1 and group_id IN(select id from tbl_keygroup where status = 1) order by id DESC")
                        ->fetchAll('assoc');
            }

            if (count($results) > 0):

                foreach ($results as $keygroup):

                    array_push($keygroups_array, array(
                        "id" => $keygroup['group_id'],
                        "keyword" => $keygroup['keyword']
                    ));

                endforeach;

            endif;

            return $keygroups_array;
        } catch (Exception $ex) {
            
        }
    }

    public function createLocationKeyword($data = array()) {

        $this->setTable('tbl_keywords');

        $query = $this->query();

        $success_array = array();

        if ($query->insert(['campaign_id', 'group_id', 'location_id', 'keyword', 'isprimary', 'googleSearchVolume', 'cpc', 'difficulty', 'user_id', 'created', 'created_by'])
                        ->values(
                                [
                                    'campaign_id' => $data['campaign_id'],
                                    'group_id' => $data['group_id'],
                                    'location_id' => $data['location_id'],
                                    'keyword' => $data['keyword'],
                                    'isprimary' => isset($data['is_primary']) ? $data['is_primary'] : '',
                                    "googleSearchVolume" => isset($data['googleSearchVolume']) ? $data['googleSearchVolume'] : '',
                                    "cpc" => isset($data['cpc']) ? $data['cpc'] : '',
                                    "difficulty" => isset($data['difficulty']) ? $data['difficulty'] : '',
                                    'user_id' => $data['user_id'],
                                    'created' => date("Y-m-d H:i:s"),
                                    'created_by' => $data['user_id'],
                                    'modified_by' => $data['user_id']
                                ]
                        )
                        ->execute()) {

            $result = $this->find('all', ['fields' => 'id'])->last();
            array_push($success_array, $result);
            //return true;
        }
        return $success_array;
        //return false;
    }

    public function updateLocationKeyword($data = array()) {

        $this->setTable('tbl_keywords');

        $query = $this->query();

        $success_array = array();

        if ($query->update()
                        ->set(
                                [
                                    'campaign_id' => $data['campaign_id'],
                                    'location_id' => $data['location_id'],
                                    'keyword' => $data['keyword'],
                                    'isprimary' => isset($data['is_primary']) ? $data['is_primary'] : '',
                                    "googleSearchVolume" => isset($data['googleSearchVolume']) ? $data['googleSearchVolume'] : '',
                                    "cpc" => isset($data['cpc']) ? $data['cpc'] : '',
                                    "difficulty" => isset($data['difficulty']) ? $data['difficulty'] : '',
                                    'user_id' => $data['user_id'],
                                    'modified' => date("Y-m-d H:i:s"),
                                    'modified_by' => $data['user_id']
                                ]
                        )
                        ->where(['group_id' => $data['group_id'], "location_id" => $data['location_id'], "campaign_id" => $data['campaign_id']])
                        ->execute()) {

            return true;
        } else {

            return false;
        }
    }

    public function isGroupKeywordAvailable($data = array()) {

        $check_existing_key = $this->connection
                ->execute('SELECT * FROM tbl_keywords WHERE location_id = ' . $data['location_id'] . ' AND campaign_id = ' . $data['campaign_id'] . ' AND LOWER(TRIM(keyword)) = "' . strtolower(trim($data['keyword'])) . '"')
                ->fetchAll('assoc');

        if (count($check_existing_key) > 0) {

            return true;
        }
        return false;
    }

    public function isGroupKeywordAvailableExceptCurrentCampaign($data = array()) {

        $check_existing_key = $this->connection
                ->execute('SELECT * FROM tbl_keywords WHERE location_id = ' . $data['location_id'] . ' AND campaign_id = ' . $data['campaign_id'] . ' AND LOWER(TRIM(keyword)) = "' . strtolower(trim($data['keyword'])) . '"')
                ->fetchAll('assoc');

        if (count($check_existing_key) > 0) {

            return true;
        }
        return false;
    }

    public function moveKeywordToDeletedTable($data = array()) {

        $this->setTable('tbl_keywords_deleted');

        $queryToInsertDeletedTable = $this->query();

        $success_array = array();

        $campaignDetails = $this->connection
                ->execute("SELECT * FROM tbl_keywords WHERE location_id = " . $data['location_id'] . " AND campaign_id = " . $data['campaign_id'] . " AND keyword = '" . $data['keyword'] . "'")
                ->fetchAll('assoc');

        // making entry to tbl_keywords_deleted table
        if ($queryToInsertDeletedTable->insert(['campaign_id', 'group_id', 'location_id', 'keyword', 'isprimary', 'ranked_url', 'rank', 'rank_change', 'maps_rank', 'maps_rank_change', 'mobile_rank', 'mobile_rank_change', 'mobile_maps_rank', 'mobile_maps_rank_change', 'bing_rank', 'bing_rank_change', 'bing_maps_rank', 'bing_maps_rank_change', 'extra_data', 'dateOfRank', 'googleSearchVolume', 'cpc', 'difficulty', 'user_id', 'created', 'created_by'])
                        ->values(
                                [
                                    'campaign_id' => $campaignDetails[0]['campaign_id'],
                                    'group_id' => $campaignDetails[0]['group_id'],
                                    'location_id' => $campaignDetails[0]['location_id'],
                                    'keyword' => $campaignDetails[0]['keyword'],
                                    'isprimary' => $campaignDetails[0]['isprimary'],
                                    'ranked_url' => $campaignDetails[0]['ranked_url'],
                                    'rank' => $campaignDetails[0]['rank'],
                                    'rank_change' => $campaignDetails[0]['rank_change'],
                                    'maps_rank' => $campaignDetails[0]['maps_rank'],
                                    'maps_rank_change' => $campaignDetails[0]['maps_rank_change'],
                                    'mobile_rank' => $campaignDetails[0]['mobile_rank'],
                                    'mobile_rank_change' => $campaignDetails[0]['mobile_rank_change'],
                                    'mobile_maps_rank' => $campaignDetails[0]['mobile_maps_rank'],
                                    'mobile_maps_rank_change' => $campaignDetails[0]['mobile_maps_rank_change'],
                                    'bing_rank' => $campaignDetails[0]['bing_rank'],
                                    'bing_rank_change' => $campaignDetails[0]['bing_rank_change'],
                                    'bing_maps_rank' => $campaignDetails[0]['bing_maps_rank'],
                                    'bing_maps_rank_change' => $campaignDetails[0]['bing_maps_rank_change'],
                                    'extra_data' => $campaignDetails[0]['extra_data'],
                                    'dateOfRank' => $campaignDetails[0]['dateOfRank'],
                                    "googleSearchVolume" => $campaignDetails[0]['googleSearchVolume'],
                                    "cpc" => $campaignDetails[0]['cpc'],
                                    "difficulty" => $campaignDetails[0]['difficulty'],
                                    'user_id' => $campaignDetails[0]['user_id'],
                                    'created' => date("Y-m-d H:i:s"),
                                    'created_by' => $campaignDetails[0]['user_id']
                                ]
                        )
                        ->execute()) {

            // delete row of current keyword from tbl_keywords
            $this->connection
                    ->execute("DELETE from tbl_keywords WHERE location_id = " . $data['location_id'] . " AND campaign_id = " . $data['campaign_id'] . " AND keyword = '" . $data['keyword'] . "'");

            return true;
        }
        return false;
    }

    public function createConversionLandingPage($data = array()) {

        $this->setTable('tbl_conversion_pages');
        $query = $this->query();

        if ($data['type'] == "landing_page") {

            $results = $query->find("all", [
                        'conditions' => ['location_id' => $data['location_id']]
                    ])->toArray();

            $landing_urls = array();

            if (count($results) > 0) {

                foreach ($results as $key => $value) {
                    $landing_urls = json_decode($value->landing_urls);
                }
                if (count($landing_urls) > 0 && !empty($landing_urls)) {

                    if (in_array($data['page_url'], $landing_urls)) {
                        
                    } else {

                        $landing_urls[] = $data['page_url'];
                        $landing_urls = json_encode($landing_urls);
                        if ($query->update()
                                        ->set(
                                                [
                                                    'landing_urls' => $landing_urls,
                                                    'modified' => date("Y-m-d H:i:s"),
                                                    'modified_by' => $data['user_id']
                                                ]
                                        )
                                        ->where(['location_id' => $data['location_id']])
                                        ->execute()) {
                            return true;
                        } else {

                            return false;
                        }
                    }
                } else {

                    $landing_urls = json_encode(array($data['page_url']));
                    if ($query->update()
                                    ->set(
                                            [
                                                'landing_urls' => $landing_urls,
                                                'modified' => date("Y-m-d H:i:s"),
                                                'modified_by' => $data['user_id']
                                            ]
                                    )
                                    ->where(['location_id' => $data['location_id']])
                                    ->execute()) {
                        return true;
                    } else {

                        return false;
                    }
                }
            } else {

                $landing_urls = json_encode(array($data['page_url']));

                if ($query->insert(['location_id', 'type', 'landing_urls', 'created', 'created_by'])
                                ->values(
                                        [
                                            'location_id' => $data['location_id'],
                                            'type' => "two_step",
                                            'landing_urls' => $landing_urls,
                                            'created' => date("Y-m-d H:i:s"),
                                            'created_by' => $data['user_id'],
                                            'modified_by' => $data['user_id']
                                        ]
                                )
                                ->execute()) {

                    return true;
                }
                return false;
            }
        } else if ($data['type'] == "thankyou_page") {

            $results = $query->find("all", [
                        'conditions' => ['location_id' => $data['location_id']]
                    ])->toArray();

            $thank_urls = array();

            if (count($results) > 0) {

                foreach ($results as $key => $value) {
                    $thank_urls = json_decode($value->thank_urls);
                }

                if (count($thank_urls) > 0 && !empty($thank_urls)) {

                    if (in_array($data['page_url'], $thank_urls)) {
                        
                    } else {

                        $thank_urls[] = $data['page_url'];
                        $thank_urls = json_encode($thank_urls);

                        if ($query->update()
                                        ->set(
                                                [
                                                    'thank_urls' => $thank_urls,
                                                    'modified' => date("Y-m-d H:i:s"),
                                                    'modified_by' => $data['user_id']
                                                ]
                                        )
                                        ->where(['location_id' => $data['location_id']])
                                        ->execute()) {

                            return true;
                        } else {

                            return false;
                        }
                    }
                } else {

                    $thank_urls = json_encode(array($data['page_url']));
                    if ($query->update()
                                    ->set(
                                            [
                                                'thank_urls' => $thank_urls,
                                                'modified' => date("Y-m-d H:i:s"),
                                                'modified_by' => $data['user_id']
                                            ]
                                    )
                                    ->where(['location_id' => $data['location_id']])
                                    ->execute()) {

                        return true;
                    } else {

                        return false;
                    }
                }
            } else {
                $thank_urls = json_encode(array($data['page_url']));

                if ($query->insert(['location_id', 'type', 'thank_urls', 'created', 'created_by'])
                                ->values(
                                        [
                                            'location_id' => $data['location_id'],
                                            'type' => "two_step",
                                            'thank_urls' => $thank_urls,
                                            'created' => date("Y-m-d H:i:s"),
                                            'created_by' => $data['user_id'],
                                            'modified_by' => $data['user_id']
                                        ]
                                )
                                ->execute()) {

                    return true;
                }
                return false;
            }
        }
    }

    public function locationConversionPage($data = array()) {

        $operation = $data['operation'];
        $this->setTable('tbl_conversion_pages');
        $query = $this->query();

        if ($operation == "selectAll") {

            $slct_type = $data['type'];

            $results = $this->connection
                    ->execute("SELECT landing_urls,thank_urls FROM tbl_conversion_pages WHERE location_id = " . $data['location_id'])
                    ->fetchAll('assoc');

            $pages = array();

            if ($slct_type == "landing_page") {

                if (count($results) > 0) {
                    array_push($pages, $results[0]['landing_urls']);
                }
            } else if ($slct_type == "thankyou_page") {

                if (count($results) > 0) {
                    array_push($pages, $results[0]['thank_urls']);
                }
            }

            return $pages;
        } else if ($operation == "exists") {

            $slct_type = $data['type'];
            $page_url = $data['url'];

            $results = $this->connection
                    ->execute("SELECT landing_urls,thank_urls FROM tbl_conversion_pages WHERE location_id = " . $data['location_id'])
                    ->fetchAll('assoc');

            $pages = array();

            if ($slct_type == "landing_page") {

                if (count($results) > 0) {

                    $landing_urls = json_decode($results[0]['landing_urls']);

                    $data_urls = array();

                    foreach ($landing_urls as $urlf) {

                        $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $urlf)), "/");
                        array_push($data_urls, $trimurl);
                    }

                    if (in_array($page_url, $data_urls)) {
                        return array("status" => true, "type" => "Landing Page");
                    }
                    return array("status" => false, "type" => "Landing Page");
                }
            } else if ($slct_type == "thankyou_page") {

                if (count($results) > 0) {
                    $thankyou_urls = json_decode($results[0]['thank_urls']);

                    $data_urls = array();

                    foreach ($thankyou_urls as $urlf) {

                        $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $urlf)), "/");
                        array_push($data_urls, $trimurl);
                    }

                    if (in_array($page_url, $data_urls)) {
                        return array("status" => true, "type" => "Thank you page");
                    }
                    return array("status" => false, "type" => "Thank you page");
                }
            }
        } else if ($operation == "remove") {

            $slct_type = $data['type'];
            $page_url = $data['url'];

            $results = $this->connection
                    ->execute("SELECT landing_urls,thank_urls FROM tbl_conversion_pages WHERE location_id = " . $data['location_id'])
                    ->fetchAll('assoc');

            $pages = array();

            if ($slct_type == "landing_page") {

                if (count($results) > 0) {

                    $landing_urls = json_decode($results[0]['landing_urls']);

                    $data_urls = array();

                    foreach ($landing_urls as $urlf) {

                        $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $urlf)), "/");
                        if ($page_url == $trimurl) {
                            
                        } else {
                            array_push($data_urls, $urlf);
                        }
                    }

                    $landFound_urls = json_encode($data_urls);

                    if ($query->update()
                                    ->set(
                                            [
                                                'landing_urls' => $landFound_urls,
                                                'modified' => date("Y-m-d H:i:s")
                                            ]
                                    )
                                    ->where(['location_id' => $data['location_id']])
                                    ->execute()) {

                        return array("status" => 1, "urls" => $data_urls);
                    }

                    return array("status" => 0);
                }
            } else if ($slct_type == "thankyou_page") {

                if (count($results) > 0) {
                    $thankyou_urls = json_decode($results[0]['thank_urls']);

                    $data_urls = array();

                    foreach ($thankyou_urls as $urlf) {

                        $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $urlf)), "/");
                        if ($page_url == $trimurl) {
                            
                        } else {
                            array_push($data_urls, $urlf);
                        }
                    }

                    $thankyouFound_urls = json_encode($data_urls);

                    if ($query->update()
                                    ->set(
                                            [
                                                'thank_urls' => $thankyouFound_urls,
                                                'modified' => date("Y-m-d H:i:s")
                                            ]
                                    )
                                    ->where(['location_id' => $data['location_id']])
                                    ->execute()) {

                        return array("status" => 1, "urls" => $data_urls);
                    }

                    return array("status" => 0);
                }
            }
        }
    }

}

?>
