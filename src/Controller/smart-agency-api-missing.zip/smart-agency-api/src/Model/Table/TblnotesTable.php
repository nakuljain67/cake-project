<?php

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;

class TblnotesTable extends Table {
    
    /* Default method to initialize */

    public function initialize(array $config) {
        parent::initialize($config);
        
        $this->setTable('tbl_notes');
        $this->belongsTo('User')->setForeignKey('created_by')->setJoinType('INNER');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
    }

}

