<?php

namespace App\Shell;

use Cake\Console\Shell;
use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;
use PDO;

class MigrationShell extends Shell {

    private $app;
    private $conn;
    private $smart;
    private $smartdata;

    public function initialize() {
        parent::initialize();
        ini_set('max_execution_time', 90000000000);
        $this->app = new AppController();
        $this->loadModel('Apilocations');
        $this->conn = ConnectionManager::get('default');
        $this->smartdata = 'smart';
        $this->smart = ConnectionManager::get($this->smartdata);
    }

    /* default called method */

    public function main() {

        $this->autoRender = false;
        $this->app->json(1, array(
            "method" => "index",
            "messge" => "silence is golden"
        ));
    }

    public function migrateAgency() {
        $database = array('mcc_medstar', 'mcc_clixsy', 'mcc_reports', 'mcc_garynealon', 'mcc_ciriusmarket', 'mcc_joseponcejr', 'mcc_attwooddigit', 'mcc_njlocalseoex', 'mcc_fifthavenueb', 'mcc_mcc', 'mcc_pmishra');
        $smart = TableRegistry::get('tbl_agencies');
        $db = new PDO('mysql:dbname=enfusen_mcc_new;host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');
        $i = 1;
        foreach ($database as $new) {
            $result = $db->query("SELECT * from wp_setup_table WHERE db_name = '$new'");
            $data = $result->fetchAll();
            $logo = '';
            $pdf_logo = '';
            $path = $data[0]['white_lbl'] . '/wp-content/plugins/settings/uploads/pdf_logo.jpg';
            if ($this->checkRemoteFile($path)) {
                file_put_contents(WWW_ROOT . 'uploads/' . $i . '.jpg', file_get_contents($path));
                $pdf_logo = $i . '.jpg';
            }
            $logo_path = $data[0]['white_lbl'] . '/wp-content/plugins/settings/uploads/logo.png';
            if ($this->checkRemoteFile($logo_path)) {
                file_put_contents(WWW_ROOT . 'uploads/' . $i . '.png', file_get_contents($logo_path));
                $logo = $i . '.png';
            }
            $query = $smart->query();
            $result = $query->insert(['name', 'email', 'prefix', 'url', 'white_lbl', 'logo', 'pdf_logo', 'status', 'created', 'created_by', 'modified', 'modified_by', 'old_db'])
                    ->values(
                            [
                                'name' => $data[0]['name'],
                                'email' => $data[0]['email'],
                                'prefix' => $data[0]['prefix'],
                                'url' => $data[0]['url'],
                                'white_lbl' => $data[0]['white_lbl'],
                                'logo' => $logo,
                                'pdf_logo' => $pdf_logo,
                                'status' => $data[0]['status'],
                                'created' => $data[0]['created_dt'],
                                'created_by' => $data[0]['created_by'],
                                'modified' => $data[0]['updated_dt'],
                                'modified_by' => $data[0]['updated_by'],
                                'old_db' => $new
                            ]
                    )
                    ->execute();
            $i++;
        }
        echo "success";
        die;
    }

    public function checkRemoteFile($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        // don't download content
        curl_setopt($ch, CURLOPT_NOBODY, 1);
        curl_setopt($ch, CURLOPT_FAILONERROR, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        if (curl_exec($ch) !== FALSE) {
            return true;
        } else {
            return false;
        }
    }

    public function migrateLocation() {
        try {
            $agencies = TableRegistry::get('tbl_agencies');
            $database = $agencies->find('all')->select(['id', 'old_db'])->all();
            $smart = TableRegistry::get('tbl_locations');
            $temptable = TableRegistry::get('tbl_temp');

            $countrytable = TableRegistry::get('tbl_countries');
            $statetable = TableRegistry::get('tbl_states');
            $citytable = TableRegistry::get('tbl_cities');

            foreach ($database as $dbdata) {
                $new = $dbdata->old_db;

                $agency_id = $dbdata->id;
                $db = new PDO('mysql:dbname=' . $new . ';host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');

                $result = $db->query("SELECT MCCUserId, conv_verified FROM wp_client_location WHERE status = 1");
                if ($new == 'mcc_mcc') {
                    $res = $result->fetchAll();
                    $con1 = array("MCCUserId" => "652", "conv_verified" => 1);
                    $con2 = array("MCCUserId" => "1473", "conv_verified" => 0);
                    $con3 = array("MCCUserId" => "1529", "conv_verified" => 0);
                    $newar = array($con1, $con2, $con3);
                    $data = array_merge($res, $newar);
                } else {
                    $data = $result->fetchAll();
                }
                foreach ($data as $key) {
                    $user_id = $key['MCCUserId'];
                    $conv_verified = $key['conv_verified'];
                    $result = $db->query("SELECT * FROM `wp_usermeta` WHERE user_id = '$user_id'");
                    $new = $result->fetchAll();
                    $website = '';
                    $name = '';
                    $phone = '';
                    $country = '';
                    $state = '';
                    $city = '';
                    $address = '';
                    $zip_code = '';
                    foreach ($new as $ab) {
                        if ($ab['meta_key'] == 'website') {
                            $website = $ab['meta_value'];
                        }
                        if ($ab['meta_key'] == 'BRAND_NAME') {
                            $name = $ab['meta_value'];
                        }
                        if ($ab['meta_key'] == 'phonenumber') {
                            $phone = $ab['meta_value'];
                        }
                        if ($ab['meta_key'] == 'country') {
                            $country = 231;
                            $countrytxt = $ab['meta_value'];
                            if ($countrytxt != "") {
                                $res = $countrytable->find("all")->select(['id'])->where(['LOWER(country)' => strtolower($countrytxt)])->first();
                                if (!empty($res)) {
                                    $country = $res->id;
                                }
                            }
                        }
                        if ($ab['meta_key'] == 'state') {
                            $state = $ab['meta_value'];
                            if ($state != "") {
                                $res = $statetable->find("all")->select(['id'])->where(['LOWER(name)' => strtolower($state)])->first();
                                if (!empty($res)) {
                                    $state = $res->id;
                                }
                            }
                        }
                        if ($ab['meta_key'] == 'city') {
                            $city = $ab['meta_value'];
                            if ($city != "") {
                                $res = $citytable->find("all")->select(['id'])->where(['LOWER(name)' => strtolower($city)])->first();
                                if (!empty($res)) {
                                    $city = $res->id;
                                }
                            }
                        }
                        if ($ab['meta_key'] == 'streetaddress') {
                            $address = $ab['meta_value'];
                        }
                        if ($ab['meta_key'] == 'zip') {
                            $zip_code = $ab['meta_value'];
                        }
                    }
                    $info = $db->query("SELECT * FROM `wp_client_location` WHERE MCCUserId = '$user_id'");
                    $qa = $info->fetchAll();
                    $status = $qa[0]['status'];
                    $created_by = $qa[0]['created_by'];
                    $created = $qa[0]['created_dt'];
                    $modified = $qa[0]['updated_dt'];
                    $query = $smart->query();
                    $result = $query->insert(['agency_id', 'account_type', 'website', 'name', 'phone', 'country_id', 'state_id', 'city_id', 'address', 'zip_code', 'status', 'created', 'created_by', 'modified', 'conv_verified'])
                                    ->values(
                                            [
                                                'agency_id' => $agency_id,
                                                'account_type' => 'active_account',
                                                'website' => $website,
                                                'name' => $name,
                                                'phone' => $phone,
                                                'country_id' => $country,
                                                'state_id' => $state,
                                                'city_id' => $city,
                                                'address' => $address,
                                                'zip_code' => $zip_code,
                                                'status' => $status,
                                                'created' => $created,
                                                'created_by' => $created_by,
                                                'modified' => $modified,
                                                'conv_verified' => $conv_verified
                                            ]
                                    )->execute();

                    $lastrecord = $smart->find("all")->select(['id'])->order(['id' => 'desc'])->first();
                    $new_location_id = $lastrecord->id;
                    $temprec = $temptable->newEntity();
                    $temprec->loc_id = $new_location_id;
                    $temprec->agency_id = $agency_id;
                    $temprec->old_loc_id = $user_id;
                    $temprec->old_agency_db = $dbdata->old_db;
                    $temptable->save($temprec);
                }
            }
            echo "success";
            die;
        } catch (PDOException $ex) {
            echo 'Connection failed: ' . $ex->getMessage();
        }
    }

    public function migrateLocationMapping() {
        try {
            $database = array('mcc_medstar', 'mcc_clixsy', 'mcc_reports', 'mcc_garynealon', 'mcc_ciriusmarket', 'mcc_joseponcejr', 'mcc_attwooddigit', 'mcc_njlocalseoex', 'mcc_fifthavenueb', 'mcc_mcc', 'mcc_pmishra');
            foreach ($database as $new) {
                $db = new PDO('mysql:dbname=' . $new . ';host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');
                $result = $db->query("SELECT * FROM `wp_location_mapping` ");
                $data = $result->fetchAll();
                $smart = TableRegistry::get('tbl_location_mapping');
                foreach ($data as $new) {
                    $query = $smart->query();
                    $result = $query->insert(['location_id', 'user_id', 'created', 'modified'])
                            ->values(
                                    [
                                        'location_id' => $new['location_id'],
                                        'user_id' => $new['user_id'],
                                        'created' => $new['created_dt'],
                                        'modified' => $new['updated_dt'],
                                    ]
                            )
                            ->execute();
                }
            }
            echo "success";
            die;
        } catch (PDOException $ex) {
            echo 'Connection failed: ' . $ex->getMessage();
        }
    }

    public function migrateUser() {
        try {
            $database = array('mcc_medstar', 'mcc_clixsy', 'mcc_reports', 'mcc_garynealon', 'mcc_ciriusmarket', 'mcc_joseponcejr', 'mcc_attwooddigit', 'mcc_njlocalseoex', 'mcc_fifthavenueb', 'mcc_mcc', 'mcc_pmishra');
            foreach ($database as $new) {
                $db = new PDO('mysql:dbname=' . $new . ';host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');
                $name = $db->query("SELECT MCCUserId FROM `wp_client_location`");
                if ($new = 'mcc_mcc') {
                    $res = $name->fetchAll();
                    $con1 = array("MCCUserId" => "652");
                    $con2 = array("MCCUserId" => "1473");
                    $con3 = array("MCCUserId" => "1529");
                    $new = array("24" => $con1, "25" => $con2, "26" => $con3);
                    $user_id = array_merge($res, $new);
                } else {
                    $user_id = $name->fetchAll();
                }
                $uids = "";
                foreach ($user_id as $key) {
                    $uids .= $key['MCCUserId'] . ',';
                }
                if ($uids != "") {
                    $uids = substr($uids, 0, -1);
                } else {
                    continue;
                }

                $result = $db->query("SELECT * FROM `wp_users` WHERE ID NOT IN(" . $uids . ") AND deleted = 0");
                $data = $result->fetchAll();
                $smart = TableRegistry::get('tbl_users');
                foreach ($data as $new) {
                    $id = $new['id'];
                    $utype = 1;
                    $email = $new['user_login'];

                    $querychk = $smart->findByEmail($email)->count();
                    if ($querychk == 0) {

                        if ($email == "enfusenroger@gmail.com") {
                            $utype = 3;
                        } else {
                            $levelres = $db->query("SELECT meta_value FROM `wp_usermeta` WHERE user_id = $id")->fetch('obj');
                            if (!empty($levelres)) {
                                if ($levelres->meta_value == "level_5") {
                                    $utype = 2;
                                }
                            }
                        }

                        $query = $smart->query();
                        $result = $query->insert(['utype_id', 'email', 'password', 'fname', 'verify_code', 'status', 'created'])
                                        ->values(
                                                [
                                                    'utype_id' => $utype,
                                                    'email' => $new['user_login'],
                                                    'password' => $new['user_pass'],
                                                    'fname' => $new['display_name'],
                                                    'verify_code' => $new['user_activation_key'],
                                                    'status' => $new['user_status'],
                                                    'created' => $new['user_registered'],
                                                ]
                                        )->execute();
                    }
                }
            }
            echo "success";
            die;
        } catch (PDOException $ex) {
            echo 'Connection failed: ' . $ex->getMessage();
        }
    }

    public function migrateSiteAudit() {
        try {
            $agencies = TableRegistry::get('tbl_agencies');
            $database = $agencies->find('all')->select(['id', 'old_db'])->all();
            $temptable = TableRegistry::get('tbl_temp');
            $smart = TableRegistry::get('tbl_site_audit');
            foreach ($database as $dbdata) {
                $db_name = $dbdata->old_db;
                $db = new PDO('mysql:dbname=' . $db_name . ';host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');
                $result = $db->query("SELECT * FROM `wp_site_audit` ");
                $data = $result->fetchAll();
                foreach ($data as $new) {
                    $user_id = $new['user_id'];
                    $loc_data = $temptable->find("all")->where(['old_loc_id' => $user_id, 'old_agency_db' => $db_name])->first();
                    if (!empty($loc_data)) {
                        $location_id = $loc_data->loc_id;
                        $query = $smart->query();
                        $result = $query->insert(['location_id', 'campaign_id', 'snapshot_id', 'audit_status', 'all_info', 'error_name_list', 'rerun', 'last_audit'])
                                ->values(
                                        [
                                            'location_id' => $location_id,
                                            'user_id' => 2,
                                            'campaign_id' => $new['campaign_id'],
                                            'snapshot_id' => $new['snapshot_id'],
                                            'audit_status' => $new['audit_status'],
                                            'all_info' => $new['all_info'],
                                            'error_name_list' => $new['error_name_list'],
                                            'rerun' => $new['rerun'],
                                            'last_audit' => $new['last_audit'],
                                        ]
                                )
                                ->execute();
                        $this->conn->query("CREATE TABLE IF NOT EXISTS smartAgency.tbl_site_audit_error_page_list_$location_id SELECT * FROM $db_name.wp_site_audit_error_page_list_$user_id");
                    }
                }
            }
            echo "success";
            die;
        } catch (PDOException $ex) {
            echo 'Connection failed: ' . $ex->getMessage();
        }
    }





   // public function migrateCre(){
   //     try {
   //          $agencies = TableRegistry::get('tbl_agencies');
   //          $database = $agencies->find('all')->select(['id', 'old_db'])->all();
   //          $temptable = TableRegistry::get('tbl_temp');
   //          $smart = TableRegistry::get('tbl_cre');
   //          $history = TableRegistry::get('tbl_cre_history');
   //          $urls = TableRegistry::get('tbl_cre_urls');
   //          foreach ($database as $dbdata) {
   //              $db_name = $dbdata->old_db;
   //              $db = new PDO('mysql:dbname=' . $db_name . ';host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');
   //              $result = $db->query("SELECT * FROM `wp_content_recommend` ");
   //              $data = $result->fetchAll();
   //              $result = $db->query("SELECT * FROM `cre_history` ");
   //              $cre_history = $result->fetchAll();
   //              $result = $db->query("SELECT * FROM `cre_urls` ");
   //              $cre_urls = $result->fetchAll();
   //              foreach ($data as $new) {
   //                  $user_id = $new['user_id'];
   //                  $loc_data = $temptable->find("all")->where(['old_loc_id' => $user_id, 'old_agency_db' => $db_name])->first();
   //                  if (!empty($loc_data)) {
   //                  $location_id = $loc_data->loc_id;
   //                  $insert = $smart->newEntity();
   //                  $insert->type = $new['type'];
   //                  $insert->location_id = $location_id;
   //                  $insert->crawl_result = $new['crawl_result'];
   //                  $insert->trigger_report = $new['trigger_report'];
   //                  $insert->rundate = $new['rundate'];
   //                  $insert->created = $new['created_dt'];
   //                  $insert->modified = $new['updated_dt'];
   //                  $smart->save($insert);
   //                  die;
   //                  }
   //              }
   //              foreach ($cre_history as $new) {
   //                  $user_id = $new['user_id'];
   //                  $loc_data = $temptable->find("all")->where(['old_loc_id' => $user_id, 'old_agency_db' => $db_name])->first();
   //                  if (!empty($loc_data)) {
   //                  $location_id = $loc_data->loc_id;
   //                  $insert = $history->newEntity();
   //                  $insert->type = $new['type'];
   //                  $insert->location_id = $location_id;
   //                  $insert->totalurls = $new['totalurls'];
   //                  $insert->totalissues = $new['totalissues'];
   //                  $insert->issues_detail = $new['issues_detail'];
   //                  $insert->avg_score = $new['avg_score'];
   //                  $insert->rundate = $new['rundate'];
   //                  $insert->created = $new['created_dt'];
   //                  $history->save($insert);
   //                  }
   //              }
   //             foreach ($cre_urls as $new) {
   //                  $user_id = $new['user_id'];
   //                  $loc_data = $temptable->find("all")->where(['old_loc_id' => $user_id, 'old_agency_db' => $db_name])->first();
   //                  if (!empty($loc_data)) {
   //                  $location_id = $loc_data->loc_id;
   //                  $insert = $urls->newEntity();
   //                  $insert->location_id = $location_id;
   //                  $insert->url = $new['url'];
   //                  $insert->keyword = $new['keyword'];
   //                  $insert->is_running = $new['is_running'];
   //                  $insert->result = $new['result'];
   //                  $insert->total_issues = $new['total_issues'];
   //                  $insert->rundate = $new['rundate'];
   //                  $insert->created = $new['created_dt'];
   //                  $urls->save($insert);
   //                  }
   //              }
   //          }
   //           } catch (PDOException $ex) {
   //          echo 'Connection failed: ' . $ex->getMessage();
   //      }
   // }
  public function migrateCre(){
       try {
            $agencies = TableRegistry::get('tbl_agencies');
            $database = $agencies->find('all')->select(['id', 'old_db'])->all();
            $temptable = TableRegistry::get('tbl_temp');
            $smart = TableRegistry::get('tbl_cre');
            $history = TableRegistry::get('tbl_cre_history');
            $urls = TableRegistry::get('tbl_cre_urls');
            foreach ($database as $dbdata) {
                $db_name = $dbdata->old_db;
                $db = new PDO('mysql:dbname=' . $db_name . ';host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');
            //     try{
            //     $result = $db->query("SELECT * FROM `wp_content_recommend` ");
            //     $data = $result->fetchAll();
            //     } catch (\PDOException $ex) {
            //         @mail("nakul@rudrainnovatives.com","Error migration migrateCre",  json_encode($dbdata));    
            //         print_r($ex->getMessage());
            //     }
            //     $result = $db->query("SELECT * FROM `wp_content_recommend` ");
            //     $data = $result->fetchAll();
            //     foreach ($data as $new) {
            //         $user_id = $new['user_id'];
            //         $loc_data = $temptable->find("all")->where(['old_loc_id' => $user_id, 'old_agency_db' => $db_name])->first();
            //         if (!empty($loc_data)) {
            //         $location_id = $loc_data->loc_id;
            //         $insert = $smart->newEntity();
            //         $insert->type = $new['type'];
            //         $insert->location_id = $location_id;
            //         $insert->crawl_result = $new['crawl_result'];
            //         $insert->trigger_report = $new['trigger_report'];
            //         $insert->rundate = $new['rundate'];
            //         $insert->created = $new['created_dt'];
            //         $insert->modified = $new['updated_dt'];
            //         $smart->save($insert);
            //         }
            //     }
            //       echo "tbl_cre data import successfully for ".$db_name ;
            //     try{
            //     $result = $db->query("SELECT * FROM `cre_history` ");
            //     $cre_history = $result->fetchAll();
            //     } catch (\PDOException $ex) {
            //         @mail("nakul@rudrainnovatives.com","Error migration migrateCre",  json_encode($dbdata));    
            //         print_r($ex->getMessage());
            //     }
            //     foreach ($cre_history as $new) {
            //         $user_id = $new['user_id'];
            //         $loc_data = $temptable->find("all")->where(['old_loc_id' => $user_id, 'old_agency_db' => $db_name])->first();
            //         if (!empty($loc_data)) {
            //         $location_id = $loc_data->loc_id;
            //         $insert = $history->newEntity();
            //         $insert->type = $new['type'];
            //         $insert->location_id = $location_id;
            //         $insert->totalurls = $new['totalurls'];
            //         $insert->totalissues = $new['totalissues'];
            //         $insert->issues_detail = $new['issues_detail'];
            //         $insert->avg_score = $new['avg_score'];
            //         $insert->rundate = $new['rundate'];
            //         $insert->created = $new['created_dt'];
            //         $history->save($insert);
            //         }
            //     }
                echo "tbl_cre_history data import successfully for ".$db_name;
                try{
                $result = $db->query("SELECT result FROM `cre_urls` where id =1");
                $cre_urls = $result->fetchAll();
                } catch (\PDOException $ex) {
                    @mail("nakul@rudrainnovatives.com","Error migration migrateCre",  json_encode($dbdata));    
                    print_r($ex->getMessage());
                }
               foreach ($cre_urls as $new) {
                    $user_id = $new['user_id'];
                    $data = json_decode($new['result']);
                    $title_issues = $data['issues_count']['title_issues'];
                     $meta_issues = $data['issues_count']['meta_issues'];
                      $content_issues = $data['issues_count']['content_issues'];
                       $heading_issues = $data['issues_count']['heading_issues'];
                        $link_issues = $data['issues_count']['link_issues'];
                         $image_issues = $data['issues_count']['image_issues'];
                         $score = $data['score'];

                    pr($title_issues); die;
                    $loc_data = $temptable->find("all")->where(['old_loc_id' => $user_id, 'old_agency_db' => $db_name])->first();
                if (!empty($loc_data)) {
                    $location_id = $loc_data->loc_id;
                    $res = array();
                    $res['location_id'] = $location_id;
                    $res['url'] =  $new['url'];
                    $res['keyword'] = $new['keyword'];
                    $res['is_running'] = $new['is_running'];
                    $res['result'] = $new['result'];
                    $res['total_issues'] = $new['total_issues'];
                    $res['rundate'] = $new['rundate'];
                    $res['created'] = $new['created_dt'];
                    $results[] = $res;
                    }
                }
            $entities = $urls->newEntities($results);
            $lastres = $urls->saveMany($entities);   
            echo "tbl_cre_urls data import successfully for ".$db_name;
            die;
            }
            echo "success";
            die;
              } catch (PDOException $ex) {
            echo 'Connection failed: ' . $ex->getMessage();
        }
   }
    public function migrateCitation() {
        try {
            $agencies = TableRegistry::get('tbl_agencies');
            $database = $agencies->find('all')->select(['id', 'old_db'])->all();
            $temptable = TableRegistry::get('tbl_temp');
            $smart = TableRegistry::get('tbl_citations');
            $list = TableRegistry::get('tbl_citationlist');
            $competitor_table = TableRegistry::get('tbl_citation_competitor');
            $countrytable = TableRegistry::get('tbl_countries');
            $statetable = TableRegistry::get('tbl_states');
            $citytable = TableRegistry::get('tbl_cities');
            foreach ($database as $dbdata) {
                $db_name = $dbdata->old_db;
                $agency_id = $dbdata->id;
                $location_data = $temptable->find("all")->where(['old_agency_db' => $db_name])->toArray();
                $db = new PDO('mysql:dbname=' . $db_name . ';host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');
                foreach ($location_data as $loc_data) {
                    $location_id = $loc_data->old_loc_id;
                    $new_location_id = $loc_data->loc_id;
                    $result = $db->query("SELECT * FROM `wp_usermeta` WHERE user_id = $location_id");
                    $new = $result->fetchAll();
                    $website = '';
                    $name = '';
                    $phone = '';
                    $country = '';
                    $state = '';
                    $city = '';
                    $address = '';
                    $zip_code = '';
                    foreach ($new as $ab) {
                        if ($ab['meta_key'] == 'website') {
                            $website = $ab['meta_value'];
                        }
                        if ($ab['meta_key'] == 'phonenumber') {
                            $phone = $ab['meta_value'];
                        }
                        if ($ab['meta_key'] == 'city') {
                            $city = $ab['meta_value'];
                            if ($city != "") {
                                $res = $citytable->find("all")->select(['id'])->where(['LOWER(name)' => strtolower($city)])->first();
                                if (!empty($res)) {
                                    $city = $res->id;
                                }
                            }
                        }
                        if ($ab['meta_key'] == 'streetaddress') {
                            $address = $ab['meta_value'];
                        }
                        if ($ab['meta_key'] == 'zip') {
                            $zip_code = $ab['meta_value'];
                        }
                        if ($ab['meta_key'] == 'BRAND_NAME') {
                            $name = $ab['meta_value'];
                        }
                    }
                    $state_id = $citytable->find("all")->select(['state_id'])->where(['id' => $city])->first();
                    $state = $state_id->state_id;
                    $country_id = $statetable->find("all")->select(['country_id'])->where(['id' => $state])->first();
                    $country = $country_id->country_id;
                    $state = $state_id->state_id;
                    $insert = $smart->newEntity();
                    $insert->agency_id = $agency_id;
                    $insert->location_id = $new_location_id;
                    $insert->name = $name;
                    $insert->url = $website;
                    $insert->phone = $phone;
                    $insert->address = $address;
                    $insert->zip_code = $zip_code;
                    $insert->city_id = $city;
                    $insert->state_id = $state;
                    $insert->country_id = $country;
                    $insert->status = 1;
                    $smart->save($insert);
                    $lastrecord = $smart->find("all")->select(['id'])->order(['id' => 'desc'])->first();
                    $new_citation_id = $lastrecord->id;
                    $tracker = $db->query("SELECT * FROM `wp_citation_tracker` WHERE user_id = $location_id");
                    $tracker_data = $tracker->fetchAll();
                    if (!empty($tracker_data)) {
                        foreach ($tracker_data as $mobile) {
                            $insert = $list->newEntity();
                            $insert->location_id = $new_location_id;
                            $insert->citation_id = $new_citation_id;
                            $insert->reportId = $mobile['ReportId'];
                            $insert->status = $mobile['status'];
                            $insert->rerun = $mobile['rerun'];
                            $insert->basic_data = $mobile['basic_data'];
                            $insert->citations_data = $mobile['citations_data'];
                            $insert->competitive_citation = $mobile['competitive_citation'];
                            $insert->listing_reportId = $mobile['listing_reportId'];
                            $insert->listings_data = $mobile['listings_data'];
                            $insert->calculate_info = $mobile['calculate_info'];
                            $insert->last_run = $mobile['last_run'];
                            $list->save($insert);
                            $citation_tracker_id = $mobile['citation_tracker_id'];
                            $record = $list->find("all")->select(['id'])->order(['id' => 'desc'])->first();
                            $new_competitor_id = $record->id;
                            $competitor = $db->query("SELECT * FROM `wp_citation_competitor` WHERE citation_tracker_id = $citation_tracker_id");
                            $competitor_data = $competitor->fetchAll();
                            foreach ($competitor_data as $abc) {
                                $insert = $competitor_table->newEntity();
                                $insert->citation_tracker_id = $new_competitor_id;
                                $insert->citationReportCitationsId = $abc['CitationReportCitationsId'];
                                $insert->citations = $abc['citations'];
                                $competitor_table->save($insert);
                            }
                        }
                    }
                }
            }
            echo "success";
            die;
        } catch (\PDOException $ex) {
            echo 'Connection failed: ' . $ex->getMessage();
        }
    }
    public function migrateKeygroup() {
        try {
            $database = array('mcc_medstar', 'mcc_clixsy', 'mcc_reports', 'mcc_garynealon', 'mcc_ciriusmarket', 'mcc_joseponcejr', 'mcc_attwooddigit', 'mcc_njlocalseoex', 'mcc_fifthavenueb', 'mcc_mcc', 'mcc_pmishra');
            foreach ($database as $new) {
                $db = new PDO('mysql:dbname=' . $new . ';host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');
                $result = $db->query("SELECT * FROM `wp_keygroup` ");
                $data = $result->fetchAll();
                $smart = TableRegistry::get('tbl_keygroup');
                foreach ($data as $new) {
                    $query = $smart->query();
                    $result = $query->insert(['campaign_id', 'location_id', 'google_location', 'landing_page', 'live_date', 'home_page', 'resource_page', 'is_target', 'notes', 'user_id', 'status', 'created', 'modified'])
                            ->values(
                                    [
                                        'campaign_id' => $new['campaign_id'],
                                        'location_id' => $new['location_id'],
                                        'google_location' => $new['google_location'],
                                        'landing_page' => $new['landing_page'],
                                        'live_date' => $new['live_date'],
                                        'home_page' => $new['home_page'],
                                        'resource_page' => $new['resource_page'],
                                        'is_target' => $new['is_target'],
                                        'notes' => $new['notes'],
                                        'user_id' => $new['user_id'],
                                        'status' => $new['status'],
                                        'created' => $new['created_dt'],
                                        'modified' => $new['updated_dt'],
                                    ]
                            )
                            ->execute();
                }
            }
            echo "success";
            die;
        } catch (PDOException $ex) {
            echo 'Connection failed: ' . $ex->getMessage();
        }
    }

 public function migrateKeywordResearch(){
         try {
          $agencies = TableRegistry::get('tbl_agencies');            
          $database = $agencies->find('all')->select(['id','old_db'])->all();
          $temptable = TableRegistry::get('tbl_temp');    
          $smart = TableRegistry::get('tbl_keyword_research');
        foreach ($database as $dbdata){
        $db_name = $dbdata->old_db;
        $db = new PDO('mysql:dbname='.$db_name.';host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92'); 
        $result = $db->query("SELECT * FROM `keyword_opportunity`");
        $data = $result->fetchAll(); 
        foreach ($data as $new) {
            $user_id = $new['user_id'];
            $loc_data = $temptable->find("all")->where(['old_loc_id' => $user_id, 'old_agency_db' =>  $db_name])->first(); 
            if(!empty($loc_data)) {
            $location_id = $loc_data->loc_id;
            $query = $smart->query();
            $result = $query->insert(['location_id', 'keyword', 'position', 'prev_position', 'difference', 'search_volume', 'cpc', 'url', 'traffic_percent', 'traffic_cost', 'results', 'trends', 'status', 'modified'])
                    ->values(
                            [
                                'location_id' =>  $location_id,
                                'keyword' =>  $new['keyword'],
                                'position' =>  $new['position'],
                                'prev_position' =>  $new['prev_position'],
                                'difference' => $new['prev_position']-$new['position'],
                                'search_volume' =>  $new['search_volume'],
                                'cpc' =>  $new['CPC'],
                                'url' =>  $new['url'],
                                'traffic_percent' => $new['traffic'],
                                'traffic_cost' =>  $new['traffic_cost'],
                                'results' =>  $new['results'],
                                'trends' =>  $new['trends'],
                                'status' =>  $new['status'],
                                'modified' => $new['update_date'],
                            ]
                    )
                    ->execute();  
            }
        }
        }    
        echo "success";
        die;
        } catch (PDOException $ex) {
          echo 'Connection failed: ' . $ex->getMessage();
        }
  }
    public function migrateConvtracking() {
     try {
            $agencies = TableRegistry::get('tbl_agencies');
            $database = $agencies->find('all')->select(['id', 'old_db'])->all();
            $temptable = TableRegistry::get('tbl_temp');
            $con_main = new PDO('mysql:dbname=apiengine;host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');
            foreach ($database as $dbdata) {
                $db_name = $dbdata->old_db;
                if($db_name != 'mcc_mcc'){
                $ana_db = str_replace("mcc","analytic", $db_name);
                } else {
                    $ana_db = 'analytic_mcc';
                }
                $db = new PDO('mysql:dbname=' . $ana_db . ';host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');
                $location_data = $temptable->find("all")->where(['old_agency_db' => $db_name])->toArray();
                  foreach ($location_data as $loc_data) {
                        $location_id = $loc_data->old_loc_id;
                        $new_location_id = $loc_data->loc_id;
                        $table = 'conv_tracking_'.$location_id;
               if ($result =  $db->query("SHOW TABLES LIKE '".$table."'")) {
                  if($result->rowCount() >0) {
                $con_main->exec("CREATE TABLE IF NOT EXISTS `api_conv_tracking_$new_location_id` (
                  `id` bigint(50) unsigned NOT NULL AUTO_INCREMENT,
                  `location_id` int(50) NOT NULL,
                  `pageTitle` varchar(500) NOT NULL,
                  `currentPageURL` varchar(500) NOT NULL,
                  `previousPageURL` varchar(500) NOT NULL,
                  `dateTimeOfVisit` datetime NOT NULL,
                  `additionalParams` varchar(500) NOT NULL,
                  `sessionID` varchar(500) DEFAULT NULL,
                   PRIMARY KEY (`id`)
                ) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;");  
                    }
                  }
                }
              }
            echo "success";
            die;
        } catch (PDOException $ex) {
            echo 'Connection failed: ' . $ex->getMessage();
        } 
    }

public function migrateConversion(){
         try {
          $agencies = TableRegistry::get('tbl_agencies');            
          $database = $agencies->find('all')->select(['id','old_db'])->all();
          $temptable = TableRegistry::get('tbl_temp');    
         $smart = TableRegistry::get('tbl_conversions_data');
        $con_main = new PDO('mysql:dbname=apiengine;host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');
        foreach ($database as $dbdata){
            $db_name = $dbdata->old_db;
            if($db_name != 'mcc_mcc'){
            $ana_db = str_replace("mcc","analytic", $db_name);
            }else {
                $ana_db = 'analytic_mcc';
            }
        $db = new PDO('mysql:dbname='.$ana_db.';host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92'); 
        $result = $db->query("SELECT * FROM `all_conversions_data` ");
        $data = $result->fetchAll(); 
        foreach ($data as $new) {
            $user_id = $new['user_id'];
            $loc_data = $temptable->find("all")->where(['old_loc_id' => $user_id, 'old_agency_db' =>  $db_name])->first(); 
            if(!empty($loc_data))  {
            $location_id = $loc_data->loc_id;
            $query = $smart->query();
            $result = $query->insert(['location_id', 'date', 'url', 'organic', 'paid', 'referral', 'social', 'direct', 'total'])
                    ->values(
                            [
                                'location_id' =>  $location_id,
                                'date' =>  $new['date'],
                                'url' =>  $new['url'],
                                'organic' =>  $new['organic'],
                                'paid' => $new['paid'],
                                'referral' =>  $new['referral'],
                                'social' =>  $new['social'],
                                'direct' =>  $new['direct'],
                                'total' => $new['total'],
                            ]
                    )
                    ->execute();  
            }
          }
        }    
        echo "success";
        die;
        } catch (PDOException $ex) {
          echo 'Connection failed: ' . $ex->getMessage();
        }
  }
 
 public function migrateClient(){
       try {
          $agencies = TableRegistry::get('tbl_agencies');            
          $database = $agencies->find('all')->select(['id','old_db'])->all();
          $temptable = TableRegistry::get('tbl_temp');    
          $con_main = new PDO('mysql:dbname=apiengine;host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');
        foreach ($database as $dbdata){
            $db_name = $dbdata->old_db;
            if($db_name != 'mcc_mcc'){
            $ana_db = str_replace("mcc","analytic", $db_name);
            }else {
                $ana_db = 'analytic_mcc';
            }
        $db = new PDO('mysql:dbname='.$ana_db.';host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92'); 
        $result = $db->query("SELECT MCCUserID, AnalyticsToken, AnalyticsChildActId FROM `clients_table` ");
        $data = $result->fetchAll(); 
        foreach ($data as $new) {
            $user_id = $new['MCCUserID'];
            $client_token = $client_child = '';
            if(!empty($new['AnalyticsToken'])){
            $AnalyticsToken = json_decode($new['AnalyticsToken']);
            $token = [];
            $token['access_token'] = $AnalyticsToken->access_token;
            $token['token_type'] = $AnalyticsToken->token_type;
            $token['expires_in'] = $AnalyticsToken->expires_in;
            $token['refresh_token'] = $AnalyticsToken->refresh_token;
            $token['created'] = $AnalyticsToken->created;
            $client_token = json_encode($token);
           }
           if(!empty($new['AnalyticsChildActId'])){
            $AnalyticsChild = explode(',}/$^&', $new['AnalyticsChildActId']);
            $token = [];
            $token['account'] = $AnalyticsChild[0];
            $token['property'] = $AnalyticsChild[1];
            $token['profile'] = $AnalyticsChild[2];
            $token['account_name'] = '';
            $token['property_name'] = '';
            $token['profile_name'] = '';
            $client_child = json_encode($token);
          }
            $loc_data = $temptable->find("all")->where(['old_loc_id' => $user_id, 'old_agency_db' =>  $db_name])->first(); 
            if(!empty($loc_data))  {
             $location_id = $loc_data->loc_id;
            $sql = "INSERT INTO apiengine.api_locations (smart_location_id, google_token, analytics_child)
                    VALUES ('$location_id', '$client_token', '$client_child')";
             $con_main->exec($sql);
            }
          }
        }    
        echo "success";
        die;
        } catch (PDOException $ex) {
          echo 'Connection failed: ' . $ex->getMessage();
        } 
 }



 public function addcolumnother(){
            $agencies = TableRegistry::get('tbl_agencies');
            $database = $agencies->find('all')->select(['id', 'old_db'])->all();
            $temptable = TableRegistry::get('tbl_temp');
      foreach ($database as $dbdata) {
                $db_name = $dbdata->old_db;
                $ana_db = str_replace("mcc","analytic", $db_name);
                $db = new PDO('mysql:dbname=' . $ana_db . ';host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');
                  $location_data = $temptable->find("all")->where(['old_agency_db' => $db_name])->toArray();
                  foreach ($location_data as $loc_data) {
                        $location_id = $loc_data->old_loc_id;
                        $new_location_id = $loc_data->loc_id;
                        $table = 'short_analytics_'.$location_id;
                  if ($result =  $db->query("SHOW TABLES LIKE '".$table."'")) {
                  if($result->rowCount() >0) {
    $this->conn->query("ALTER TABLE smartAgency.api_short_analytics_$new_location_id ADD `other` INT NOT NULL DEFAULT '0' AFTER `email`");
  }
 }
}
}
}




}
