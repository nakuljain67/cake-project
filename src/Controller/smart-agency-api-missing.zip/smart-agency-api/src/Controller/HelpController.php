<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;
use PHPMailer;
use Cake\Mailer\Email;

class HelpController extends AppController {

    public $title;
    public $base_url;
    public $html_content;

    public function initialize() {
        parent::initialize();
        $this->viewBuilder()->layout('frontend');
        $this->base_url = \Cake\Routing\Router::url("/", true);
    }

    public function index($apiType = '') {

        $apiUrl = '';

        if (empty($apiType)) {
            $this->title = "About Smart Agency API Documentation";
            $this->html_content = "<br/><b>Description:</b><br/>All API's are building in Cake PHP. API's are used to Add / Edit / Delete / fetch the data so that user can see the proper information on UI. You can check the response of each API that means the outcome of any functionality.";
        } else if ($apiType == "locationwidgets") {

            $this->title = "Location Widgets";
            $apiUrl = $this->base_url . "dashboard/locationwidgets";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><b>Description:</b><br/>";
        } else if ($apiType == "createwidget") {

            $this->title = "Create Widget";
            $apiUrl = $this->base_url . "dashboard/createwidget";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "";
        } else if ($apiType == "login") {

            $this->title = "Login";
            $apiUrl = $this->base_url . "user/login";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to do user login to APP by the use of Email Addr and Password";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "client_id* (default hash value of 2nd agency), email(required), password(required), [extra parameter: login_type (portal (default), admin)] : paramter use for only superadmin : in case if superadmin want to login any agency value ='portal', otherwise value = 'admin'{open super admin view}   <br/>";
            $this->html_content .= "<br/><b>Note*: POST Password without any encryption, if parameter location_id = 0 in response, you need to redirect always on client dashboard page</b><br/>";
            $this->html_content .= "<br/><b>We will provide hash of different agencies</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"login successful","arr":[{"firstName":"Sanjay Kumar","lastName":"Singh","email":"sanjay@rudrainnovatives.com","dob":"1st June","phone":"984654412","about":"PHP Developer at Rudra Innovatives","country":"Afghanistan","state":"Andaman and Nicobar Islands","city":"Bombuflat","address":"Mohali Phase 5","zipcode":"160055","occupation":"Software Enginner","token" => “fdfdfd54354hghgfsofujhrj543sajdhfsdofjdfjsdk”,"user_id" => 1}]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"invalid login","arr":[]}</pre>';
        } else if ($apiType == "forgotpassword") {

            $this->title = "Forgot Password";
            $apiUrl = $this->base_url . "user/forgetpassword";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to send email to registered user by the use of Email Addr to do reset password";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "email(required), url(required)<br/>";
            $this->html_content .= "<br/><b>Note*: POST Email should be a valid email addr and url is the login screen link of App.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"mail sent"}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"failed to send mail"}<br/>{"sts":0,"msg":"empty fields found"}<br/>{"sts":0,"msg":"invalid email"}</pre><br/>Depends on Supplied conditions.';
        } else if ($apiType == "changepassword") {

            $this->title = "Change Password";
            $apiUrl = $this->base_url . "user/changepassword";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to reset password of user";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "token(required), confpassword(required), password(required), url(required)<br/>";
            $this->html_content .= "<br/><b>Note*: POST Password,Confirm Password without any encryption. Url is the link of login screen of App.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"password changed, please check mail","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"failed to send mail","arr":[]}<br/>{"sts":0,"msg":"invalid token","arr":[]}</pre><br/>Depends on supplied conditions.';
        } else if ($apiType == "logout") {

            $this->title = "Logout";
            $apiUrl = $this->base_url . "user/changepassword";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to do user logged out from App of current User session.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "token(required)<br/>";
            $this->html_content .= "<br/><b>Note*: token is generated once user logged in and after logout it destroys.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"user logged out successfully","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"failed to do user logout","arr":[]}</pre>';
        } else if ($apiType == "logoutallsessions") {

            $this->title = "Log out All Sessions";
            $apiUrl = $this->base_url . "user/logoutallsession";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API destroys all session of currently logged in user.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "token(required)<br/>";
            $this->html_content .= "<br/><b>Note*: token is generated once user logged in and after logout it destroys.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"User logged out successfully","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"failed to do user logout","arr":[]}</pre>';
        } else if ($apiType == "createlocation") {

            $this->title = "Create Location";
            $apiUrl = $this->base_url . "location/create";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to create Agency's Location.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>"
                    . "<b>Body</b> :  website(string)*, name(string)*, country_id(integer)*, state_id(integer)*, address(string)*, agency_id(integer), account_type(enum('active_account', 'demo_account')), services(string), target(enum('local', 'national')), status(integer), created_by(integer), email(string), phone(integer), about(string), city_id(integer), zip_code(integer).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"Location created successfully","arr":[{"id":2}]} </pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"Failed to create location","arr":[]}</pre>';
        } else if ($apiType == "upatelocation") {

            $this->title = "Update Location";
            $apiUrl = $this->base_url . "location/update";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to update information of Agency's Location.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>"
                    . "<b>Body</b> :  location_id(integer)*, name(string)*, country_id(integer)*, state_id(integer)*, address(string)*, agency_id(integer), account_type(enum('active_account', 'demo_account')), services(string), target(enum('local', 'national')), status(integer), created_by(integer), email(string), phone(integer), about(string), city_id(integer), zip_code(integer).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields, 'location_id' the that id which is retured to user when they create.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":1,"msg":"Location Updated successfully","arr":[]} </pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"Invalid Location Id","arr":[]}</pre>';
        } else if ($apiType == "listalllocation") {

            $this->title = "List All";
            $apiUrl = $this->base_url . "location/getUserLocations";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to list all Agency's Location.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST OR GET";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>"
                    . "<b>Body</b> : offset (Page number : 1 or 2 or 3 ), search_txt (optional), status (1 : active locations (default) or 0 : inactive locations)<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields, 'limit' and 'offset' are optional. These fields basically filters list upto limit else it lists 10 records order by ASC.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":1,"msg":"Locations Found","arr":[{'
                    . '"total_records": 36,
        "total_pages": 4,
        "current_page": 2,
        "data":{"id":3,"agency_id":5,"account_type":"","website":"https:\/\/rudrainnovatives.com","name":"Rudra Innovatives","services":"","email":"parambir@rudrainnovatives.com","phone":"987987787673","about":"TL","country_id":101,"state_id":32,"city_id":18,"address":"3b2","zip_code":"160054","conv_verified":0,"status":1,"created":"2017-05-17T10:28:43+00:00","created_by":56,"scores":{"mar_eff_score":"49.75","Keyword":"32.75","Content":"28.97","site_audit":1,"citation":0,"total_keywords":0,"target":"Armenia","google_analytics":1,"conversion_tracking_code":0,"keyword_campaign":1}}]}}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":1,"msg":"No Data Found","arr":[]}</pre>';
        } else if ($apiType == "locationdetail") {
            $this->title = "Get Location Detail";
            $apiUrl = $this->base_url . "location/locationDetail";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get location detail.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>"
                    . "<b>Body</b> : location_id*<br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":1,"msg":"Locations Found","arr":[{"id":3,"agency_id":5,"account_type":"","website":"https:\/\/rudrainnovatives.com","name":"Rudra Innovatives","services":"","email":"parambir@rudrainnovatives.com","phone":"987987787673","about":"TL","country_id":101,"state_id":32,"city_id":18,"address":"3b2","zip_code":"160054","conv_verified":0,"status":1,"created":"2017-05-17T10:28:43+00:00","created_by":56,"scores":{"mar_eff_score":"49.75","Keyword":"32.75","Content":"28.97","site_audit":1,"citation":0,"total_keywords":0,"target":"Armenia","google_analytics":1,"conversion_tracking_code":0,"keyword_campaign":1}}]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":1,"msg":"No Location Found","arr":[]}</pre>';
        } else if ($apiType == "deletelocation") {

            $this->title = "Delete Location";
            $apiUrl = $this->base_url . "location/delete";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to delete Location.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>"
                    . "<b>Body</b> : location_id*.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>  {"sts":1,"msg":"Location Deleted Successfully","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>  {"sts":0,"msg":"No Location Found","arr":[]}</pre>';
        }
        else if ($apiType == "changelocation") {

            $this->title = "Change Location";
            $apiUrl = $this->base_url . "location/changeLocation";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to change Location.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>"
                    . "<b>Body</b> : location_id*.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>  {"sts":1,"msg":"Location changed sucessfully","arr":[{"firstName":"Sanjay Kumar","lastName":"Singh","email":"sanjay@rudrainnovatives.com","dob":"1st June","phone":"984654412","about":"PHP Developer at Rudra Innovatives","country":"Afghanistan","state":"Andaman and Nicobar Islands","city":"Bombuflat","address":"Mohali Phase 5","zipcode":"160055","occupation":"Software Enginner","token" => “fdfdfd54354hghgfsofujhrj543sajdhfsdofjdfjsdk”,"user_id" => 1}]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>  {"sts":0,"msg":"Location is inactive","arr":[]}</pre>'
                    . '<pre>  {"sts":0,"msg":"Location is inactive","arr":[]}</pre>'
                    . '<pre>  {"sts":0,"msg":"Invalid Location","arr":[]}</pre>';
        }
        else if ($apiType == "addcompetitors") {

            $this->title = "Add Competitor";
            $apiUrl = $this->base_url . "Competitors/addCompetitors";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to add Competitors.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>"
                    . "<b>Body</b> : location_id*, websites*(comma seperated websites maximum 4 at a time).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1, "msg":"Competitors successfully added"} </pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"Failed to add competitors"}</pre>';
        } 
     else if ($apiType == "siteauditrun") {
            $this->title = "Site Audit Run";
            $apiUrl = $this->base_url . "SiteAudit/siteAuditRun";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Run Site Audit.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1, "msg":"Site audit successfully started in background."} </pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"invalid token"}</pre>';
        } 
         else if ($apiType == "siteauditdetail") {

            $this->title = "Site Audit Detail";
            $apiUrl = $this->base_url . "SiteAudit/siteAuditDetail";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Site Audit Detail.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>GET or POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1, "msg":"Site Audit Detail", , "arr": [data]} </pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"No Data Found"}</pre> <pre>{"sts":0,"msg":"Wait Site Audit is in Progress"}</pre>';
        } 
        else if ($apiType == "errorlist") {
            $this->title = "Site Audit Error List";
            $apiUrl = $this->base_url . "SiteAudit/errorList";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Site Audit Error List.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>"
                    . "<b>Body</b> : snapshot_id*, issue_id*.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1, "msg":"Site Audit Error List", , "arr": [data]} </pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"invalid token"}</pre>';
        } 
          else if ($apiType == "historysiteaudit") {
            $this->title = "Site Audit History.";
            $apiUrl = $this->base_url . "SiteAudit/historySiteAudit";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Site Audit History.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>GET or POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>"."<b>Body</b> : limit (By default 20), offset*, search_txt (search case).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1, "msg":"Site Audit History.", , "arr": [data]} </pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"No Audit History Found."}</pre>';
        } 
           else if ($apiType == "siteauditrerun") {
            $this->title = "Site Audit Rerun";
            $apiUrl = $this->base_url . "SiteAudit/siteAuditRerun";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Rerun Site Audit.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1, "msg":"Site audit successfully started in background."} </pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"invalid token"}</pre>';
        } 
         else if ($apiType == "allurlissue") {
            $this->title = "Site Audit All Url Issue";
            $apiUrl = $this->base_url . "SiteAudit/allUrlIssue";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get all Url Issue";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST or GET";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>"."<b>Body</b> : limit (By default 20), offset*, search_txt (search case)<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1, "msg":"All URL Issue", "arr": "data[]"} </pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"invalid token"}</pre> <pre>{"sts":0,"msg":"No data Found"}</pre>';
        } 
         else if ($apiType == "targeturl") {
            $this->title = "Site Audit Target URL";
            $apiUrl = $this->base_url . "SiteAudit/targetUrlIssue";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get target URL Issues.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST or GET";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1 , "msg":"Target URL Issue"} </pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"invalid token"}</pre>  <pre>{"sts":0,"msg":"No data Found"}</pre>';
        } 
        else if ($apiType == "downloadauditreport") {
            $this->title = "Site Audit Download Report";
            $apiUrl = $this->base_url . "SiteAudit/downloadAuditReport";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to download Site Audit Report.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST or GET";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>PDF Download Started</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"invalid token"}</pre> <pre>{"sts":0,"msg":"No data Found"}</pre>';
        } 
        else if ($apiType == "getkeywords") {
            $this->title = "Get Keywords";
            $apiUrl = $this->base_url . "location/getKeywords";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Get Keywords.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST or GET";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>"
                    . "<b>Body</b> : location_id*, country_id.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>  {"sts": 1, "msg": "Keywords Found", "arr": [ "list of web development companies in india", "software companies websites in india", "rudra"] }</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>  {"sts":1, "msg":"No Keyword Found", "arr":[]}</pre>';
        } else if ($apiType == "savekeywords") {

            $this->title = "Save Keywords";
            $apiUrl = $this->base_url . "location/saveKeywords";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Save Keywords.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST ";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>"
                    . "<b>Body</b> :  location_id*, keywords* (comma separated eg: web design, best app development, web development).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>  {"sts": 1, "msg": "campaign created", "arr": ["true" ]} </pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>  {"sts":0,"msg":"failed to create campaign","arr":[]}</pre>';
        } else if ($apiType == "run-audit") {
            $this->title = "Run Site Audit";
            $apiUrl = $this->base_url . "location/runAudit";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Run Site Audit.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST ";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>"
                    . "<b>Body</b> :  location_id*<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>  {"sts": 1, "msg": "Site audit successfully started in background.", "arr": []} </pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>  {"sts":0,"msg":"Site audit not started","arr":[]}</pre>';
        } else if ($apiType == "run-cre") {

            $this->title = "Run CRE";
            $apiUrl = $this->base_url . "location/runCre";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Run CRE.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST ";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header</b> : token* <br/>"
                    . "<b>Body</b> :  location_id*<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>  {"sts": 1, "msg": "CRE successfully started in background.", "arr": []} </pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>  {"sts":0,"msg":"Empty fields found","arr":[]}</pre>';
        } else if ($apiType == "listcountries") {

            $this->title = "List Countries";
            $apiUrl = $this->base_url . "data/countries";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to List all countries.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "No Parameters Needed.<br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"countries found","arr":[{"id":1,"code":"AF","name":"Afghanistan","phonecode":93},{"id":2,"code":"AL","name":"Albania","phonecode":355}]}</pre>';
        } else if ($apiType == "liststates") {

            $this->title = "List States";
            $apiUrl = $this->base_url . "data/states";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to List all states.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "No Parameters Needed.<br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"states found","arr":[{"id":1,"country_id":101,"name":"Andaman and Nicobar Islands"},{"id":2,"country_id":101,"name":"Andhra Pradesh"}]}</pre>';
        } else if ($apiType == "listcities") {

            $this->title = "List Cities";
            $apiUrl = $this->base_url . "data/cities";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to List all cities.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "No Parameters Needed.<br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":1,"msg":"cities found","arr":[{"id":1,"state_id":1,"name":"Bombuflat"},{"id":2,"state_id":1,"name":"Garacharma"},{"id":3,"state_id":1,"name":"Port Blair"}]}</pre>';
        } else if ($apiType == "statesbycountry") {

            $this->title = "List States by Country";
            $apiUrl = $this->base_url . "data/statesByCountryId";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to List all states by country id.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "country_id*.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"States found","arr":[{"id":1,"country_id":101,"name":"Andaman and Nicobar Islands"},{"id":2,"country_id":101,"name":"Andhra Pradesh"}]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"No States found","arr":[]}</pre>';
        } else if ($apiType == "citybystate") {

            $this->title = "List Cities by State";
            $apiUrl = $this->base_url . "data/citiesByStateId";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to List all city by state id.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "state_id*.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"Cities found","arr":[{"id":1273,"state_id":15,"name":"Achabal"},{"id":1274,"state_id":15,"name":"Akhnur"},{"id":1275,"state_id":15,"name":"Anantnag"}]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"No City found","arr":[]}</pre>';
        } else if ($apiType == "createagency") {

            $this->title = "Create Agency";
            $apiUrl = $this->base_url . "agency/create";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to create agency.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "agency_type*,name*,email*,phone*,prefix*,url*,white_lbl*,logo*,logo_pos*,pdf_logo*,about*,country_id*,state_id*,city_id*,address*,zip_code*,<br/>lang_code*,currency_code*, created_by*.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields. If Agency will be created successfully then automatically mail will go to Agency Owner's Mail Addr.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"Agency Created","arr":[{"id":7}]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"Agency Prefix already taken","arr":[]}<br/>{"sts":0,"msg":"Failed to create Agency","arr":[]}</pre>';
        } else if ($apiType == "listagency") {

            $this->title = "List Agencies";
            $apiUrl = $this->base_url . "agency/getList";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to List all Agencies of status 1.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "No Parameters Needed.<br/>";
            //$this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"Agency found","arr":[{"agency_id":2,"agency_type":"trial_active","name":"medstar","email":"sanjay@rudrainnovatives.com","phone":"","prefix":"medstar","url":"https:\/\/reports.medstarhealth.org","white_lbl":"","logo":"","logo_pos":"","pdf_logo":"","about":"","country_details":{"code":"IN","name":"India","phonecode":91,"status":1},"state_details":{"name":"Madhya Pradesh","country":"India"},"city_details":{"name":"Badvel","state":"Andhra Pradesh","country":"India"},"address":"","zip_code":"","lang_code":"","currency_code":"","created":"2017-05-22T11:03:38+00:00"},{"agency_id":7,"agency_type":"trial_active","name":"Parambir Singh","email":"","phone":"","prefix":"gaurav345","url":"http:\/\/pmishra.enfusen.com","white_lbl":"","logo":"","logo_pos":"","pdf_logo":"","about":"","country_details":[],"state_details":[],"city_details":[],"address":"","zip_code":"","lang_code":"","currency_code":"","created":"2017-05-23T13:47:15+00:00"}]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"No Agency found","arr":[]}</pre>';
        } else if ($apiType == "createcampaign") {

            $this->title = "Create Campaign";
            $apiUrl = $this->base_url . "keyword/createcampaign";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to create Keyword's Campaign.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "name*(string), target_country_id*(int), local_location(string), token*(string).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"campaign created","arr":[{"id":6}]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"Failed to create campaign","arr":[]}</pre>';
        } else if ($apiType == "editcampaign") {

            $this->title = "Edit Campaign";
            $apiUrl = $this->base_url . "keyword/editcampaign";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to update Keyword's Campaign information.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "campaign_id*(int), name*(string), target_country_id*(int), local_location(string), token*(string).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields, campaign_id is used as a unique id used to update data.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"campaign updated","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"Failed to update campaign","arr":[]}</pre>';
        } else if ($apiType == "deletecampaign") {

            $this->title = "Delete Campaign";
            $apiUrl = $this->base_url . "keyword/deletecampaign";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Delete Keyword's Campaign.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "campaign_id*(int), token*(string).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields, campaign_id is used as a unique id used to delete data of related user's token.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"campaign deleted","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"Failed to delete campaign","arr":[]}</pre>';
        } else if ($apiType == "listcampaign") {

            $this->title = "List All Campaign";
            $apiUrl = $this->base_url . "keyword/listcampaign";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to List all created Keyword's Campaign of specific location.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "token*(string).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields, token is used get data of all campaign's data.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":[{"id":3,"name":"Test Campaign","target_country":3,"local_location":"PTL Chouk, Fraco"},{"id":4,"name":"Test Campaign","target_country":3,"local_location":"PTL Chouk, Fraco"},{"id":5,"name":"Test Campaign","target_country":3,"local_location":"PTL Chouk, Fraco"},{"id":6,"name":"test","target_country":2,"local_location":""}],"arr":[]}</pre>';
        }  else if ($apiType == "downloadreport") {

            $this->title = "Download Report";
            $apiUrl = $this->base_url . "keyword/downloadReport";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Download all Report in PDF Format.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "token*(string), campaign_id*(int), sch_type*(0->keyword_report, 1->competitor_report, 2->rank_target_report, 3->executive_report),sch_report_type*(0->pdf, 1->csv), from_date(Default Yesterday), to_date(Default 1 month ago from today).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields, token is used get data of all campaign's data.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>PDF or CSV File Download Started</pre>';
            $this->html_content .= "If Failure<br/>";
            $this->html_content .= '<pre>{"sts":0,"msg":"invalid token"}</pre>';
        } else if ($apiType == "schedulereport") {

            $this->title = "Schedule E-Mail Report";
            $apiUrl = $this->base_url . "keyword/scheduleReport";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Schedule E-Mail Report.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "token*(string), campaign_id*(int), sch_type*(0->keyword_report, 1->competitor_report, 2->rank_target_report, 3->executive_report), sch_report_type*(0->pdf, 1->csv), email_info*(All 'Email' with 'Status' in JSON Object), sch_frequency*(0->weekly, 1->monthly), sch_reportVolume*(0->Last 7 Days, 1->Last 30 Days, 2->Last 90 Days) .<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields, token is used get data of all campaign's data.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1, "msg":"Email scheduler is successfully updated."}</pre>';
            $this->html_content .= "If Failure<br/>";
            $this->html_content .= '<pre>{"sts":0,"msg":"Invalid token"}</pre>';
        } else if ($apiType == "getschedulereport") {

            $this->title = "Get Schedule E-Mail Report";
            $apiUrl = $this->base_url . "keyword/getScheduleReport";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Get Schedule E-Mail Report.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "token*(string), campaign_id*(int) .<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields, token is used get data of all campaign's data.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1,
    "msg": "Info about Email scheduler Report.",
    "arr": {
        "sch_frequency": "Weekly",
        "sch_reportVolume": "Last 7 Days",
        "sch_type": "keyword_report",
        "report_type": "pdf",
        "email_info": [
            {
                "emailTo": "nakul@rudrainnovatives.com",
                "status": "1"
            },
            {
                "emailTo": "bablu@rudrainnovatives.com",
                "status": "1"
            }
        ]
    }}</pre>';
            $this->html_content .= "If Failure<br/>";
            $this->html_content .= '<pre>{"sts":0,"msg":"Invalid token"}</pre>
            <pre>{"sts":0,"msg":" No Data found."}</pre>';
        }
         else if ($apiType == "getgraphdata") {

            $this->title = "Get Graph Data";
            $apiUrl = $this->base_url . "cre/getgraphdata";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to to fetch the details of all issues of all running pages.It gives the detail of all issues type like meta, title, content, link, images etc";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "token*(string).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields. Token shold be sent in header of request.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{
                "sts": 1,
                "msg": "graph data found",
                "arr": {
                    "data": {
                        "cre_score": "72.62393162393163",
                        "issues": 2687,
                        "pages": 285,
                        "running_state": 0,
                        "gaconnected": 0
                    },
                    "description": [
                        {
                            "label": "Title Issues",
                            "data": 211,
                            "backgroundColor": "#2b94e1"
                        },
                        {
                            "label": "Meta Issues",
                            "data": 165,
                            "backgroundColor": "#bf9e6b"
                        },
                        {
                            "label": "Content Issues",
                            "data": 845,
                            "backgroundColor": "#ff7f00"
                        },
                        {
                            "label": "Heading Issues",
                            "data": 193,
                            "backgroundColor": "#a52600"
                        },
                        {
                            "label": "Link Issues",
                            "data": 712,
                            "backgroundColor": "#4fae33"
                        },
                        {
                            "label": "Image Issues",
                            "data": 561,
                            "backgroundColor": "#6666cc"
                        }
                    ]
                }
            }</pre>';
            $this->html_content .= "<br/>If Fails<br/>";
            $this->html_content .= '<pre>{
                "sts": 0,
                "msg": "invalid token",
                "arr": {
                    "token": "required"
                }
            }</pre>';
        } else if ($apiType == "getallpages") {

            $this->title = "List All Pages";
            $apiUrl = $this->base_url . "cre/getallpages";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to List all pages of cre either running or completed.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "token*(string).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{
                                    "sts": 1,
                                    "msg": "urls found",
                                    "arr": [
                                      {
                                        "page_id": 286,
                                        "page_url": "http://www.rawhide.org",
                                        "ov": 0,
                                        "oc": 0,
                                        "tos": 0,
                                        "br": 0,
                                        "score": 53,
                                        "issues": 9,
                                        "is_running": 0
                                      },
                                      {
                                        "page_id": 287,
                                        "page_url": "http://www.rawhide.org/blog/car-donation/rawhide-car-donations-good-bad-ugly/",
                                        "ov": 0,
                                        "oc": 0,
                                        "tos": 0,
                                        "br": 0,
                                        "score": 78,
                                        "issues": 14,
                                        "is_running": 0
                                      },
                                      {
                                        "page_id": 288,
                                        "page_url": "http://www.rawhide.org/blog/starr-academy/7-ways-rawhides-art-education-benefits-at-risk-youth/",
                                        "ov": 0,
                                        "oc": 0,
                                        "tos": 0,
                                        "br": 0,
                                        "score": 80,
                                        "issues": 11,
                                        "is_running": 0
                                      },...]
                                  }</pre>';
            $this->html_content .= "<br/>If Fails<br/>";
            $this->html_content .= '<pre>{
                "sts": 0,
                "msg": "invalid token",
                "arr": {
                    "token": "required"
                }
            }</pre>';
        } else if ($apiType == "gettargetpages") {

            $this->title = "List All Pages";
            $apiUrl = $this->base_url . "cre/getalltargetpages";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to List all target pages of cre either running or completed.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "token*(string).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{
                                "sts": 1,
                                "msg": "target urls found",
                                "arr": [
                                    {
                                        "page_id": 1258,
                                        "page_url": "https://www.enfusen.com/faq/clone-form-sharpspring/",
                                        "ov": 0,
                                        "oc": 0,
                                        "tos": 0,
                                        "br": 0,
                                        "score": 81,
                                        "issues": 9,
                                        "is_running": 0
                                    },
                                    {
                                        "page_id": 1267,
                                        "page_url": "https://www.enfusen.com/faq/video-add-new-users-enfusen-platform/",
                                        "ov": 0,
                                        "oc": 0,
                                        "tos": 0,
                                        "br": 0,
                                        "score": 53,
                                        "issues": 9,
                                        "is_running": 0
                                    },
                                    {
                                        "page_id": 1281,
                                        "page_url": "https://www.enfusen.com/faq/video-enfusen-artificial-intelligence-optimize-bot/",
                                        "ov": 0,
                                        "oc": 0,
                                        "tos": 0,
                                        "br": 0,
                                        "score": 79,
                                        "issues": 9,
                                        "is_running": 0
                                    },
                                    {
                                        "page_id": 1288,
                                        "page_url": "https://www.enfusen.com/videos/video/",
                                        "ov": 0,
                                        "oc": 0,
                                        "tos": 0,
                                        "br": 0,
                                        "score": 75,
                                        "issues": 11,
                                        "is_running": 0
                                    }
                                ]
                            }</pre>';
            $this->html_content .= "<br/>If Fails<br/>";
            $this->html_content .= '<pre>{
                "sts": 0,
                "msg": "invalid token",
                "arr": {
                    "token": "required"
                }
            }</pre>';
        } else if ($apiType == "runallpages") {

            $this->title = "Run All Campaign";
            $apiUrl = $this->base_url . "cre/runallpagecampaigncre";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to run all page of location at once.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "token*(string).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"campaign for all pages is inserted in cre queue","arr":[]}</pre>';
            $this->html_content .= "<br/>If Fails<br/>";
            $this->html_content .= '<pre>{"sts":0,"msg":"failed to make request for all pages to CRE"","arr":[]}</pre>';
            $this->html_content .= '<pre>{"sts":0,"msg":"invalid token"","arr":[]}</pre>';
        } else if ($apiType == "runsinglepage") {

            $this->title = "Run Single Page";
            $apiUrl = $this->base_url . "cre/triggersinglepagecre";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to run single page url.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "token*(string), id*(int).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields, id is the page id to which want to run.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"url started to run","arr":[]}</pre>';
            $this->html_content .= "<br/>If Fails<br/>";
            $this->html_content .= '<pre>{"sts":0,"msg":"invalid id"","arr":[]}</pre>';
            $this->html_content .= '<pre>{"sts":0,"msg":"invalid token"","arr":[]}</pre>';
        } else if ($apiType == "geturlprofile") {

            $this->title = "Get URL Profile";
            $apiUrl = $this->base_url . "cre/geturlprofiledata";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to to get All URL Profile Data.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "token*(string), url*(string).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields, url is the page url to on which we click.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{
                                    "sts": 1,
                                    "msg": "data found",
                                    "arr": {
                                        "top_section": {
                                            "cre_score": 0,
                                            "traffic_stats": [
                                                {
                                                    "name": "organic",
                                                    "visits": 0,
                                                    "conversions": 0,
                                                    "conversion_rate": 0
                                                },
                                                {
                                                    "name": "paid",
                                                    "visits": 0,
                                                    "conversions": 0,
                                                    "conversion_rate": 0
                                                },
                                                {
                                                    "name": "referral",
                                                    "visits": 0,
                                                    "conversions": 0,
                                                    "conversion_rate": 0
                                                },
                                                {
                                                    "name": "social",
                                                    "visits": 0,
                                                    "conversions": 0,
                                                    "conversion_rate": 0
                                                },
                                                {
                                                    "name": "direct",
                                                    "visits": 0,
                                                    "conversions": 0,
                                                    "conversion_rate": 0
                                                },
                                                {
                                                    "name": "total",
                                                    "visits": 1065,
                                                    "conversions": 20,
                                                    "conversion_rate": 30
                                                }
                                            ],
                                            "target_keywords": [],
                                            "seo_link_stats": [
                                                {
                                                    "title": "Exact Match",
                                                    "value": 0
                                                },
                                                {
                                                    "title": "Naked",
                                                    "value": 0
                                                },
                                                {
                                                    "title": "Syn Match",
                                                    "value": 0
                                                },
                                                {
                                                    "title": "Brand Match",
                                                    "value": 0
                                                },
                                                {
                                                    "title": "Generic",
                                                    "value": 0
                                                }
                                            ]
                                        },
                                        "middle_section": {
                                            "issues_count": {
                                                "title_issues": 0,
                                                "meta_issues": 0,
                                                "content_issues": 3,
                                                "heading_issues": 0,
                                                "link_issues": 2,
                                                "image_issues": 2
                                            },
                                            "performance_section": [
                                                {
                                                    "key": "Time on site",
                                                    "value": "0:00"
                                                },
                                                {
                                                    "key": "Bounce Rate",
                                                    "value": "0.00"
                                                },
                                                {
                                                    "key": "Click Through Rate",
                                                    "value": "0.00"
                                                },
                                                {
                                                    "key": "Age",
                                                    "value": "N/A"
                                                },
                                                {
                                                    "key": "Track",
                                                    "value": "Yes"
                                                },
                                                {
                                                    "key": "Indexed",
                                                    "value": "Yes"
                                                }
                                            ],
                                            "page_title": {
                                                "title": 1,
                                                "title_length": 68,
                                                "title_relevancy": 100
                                            },
                                            "meta_description": {
                                                "description": 1,
                                                "description_length": 152,
                                                "relevancy": 100,
                                                "robots_meta_tag": 1
                                            },
                                            "page_content": {
                                                "page_size": 54225,
                                                "total_words": 190,
                                                "load_time": 0,
                                                "seo_friendly_url": 1,
                                                "doctype_available": 1,
                                                "text_to_html_ratio": 11.2,
                                                "mobile_friendly": 1,
                                                "any_iframe": 0
                                            },
                                            "heading": {
                                                "heading_tags": 5,
                                                "h1_tags": 0,
                                                "h2_tags": 1,
                                                "h3_tags": 1,
                                                "h4_tags": 3,
                                                "h5_tags": 0,
                                                "h6_tags": 0
                                            },
                                            "links": {
                                                "count_internal_links": 16,
                                                "count_external_links": 9,
                                                "count_broken_links": 0,
                                                "links_without_title_attr": 25,
                                                "links_without_rel_attribute": 22
                                            },
                                            "images": {
                                                "count_images": 7,
                                                "fine_images": 5,
                                                "missing_alt_tag": 2
                                            },
                                            "primary_keyword": [],
                                            "discovered_keywords": [
                                                {
                                                    "keyword": "design web development",
                                                    "content": {
                                                        "content": 1,
                                                        "occurrence": 3,
                                                        "density": 0
                                                    },
                                                    "title": {
                                                        "title": 1,
                                                        "occurrence": 3,
                                                        "density": 0
                                                    },
                                                    "meta_description": {
                                                        "meta_description": 0,
                                                        "occurrence": 3,
                                                        "density": 0
                                                    },
                                                    "heading_tags": {
                                                        "heading_tags": 1,
                                                        "occurrence": 3,
                                                        "density": 0
                                                    },
                                                    "overall_density": {
                                                        "overall_density": 1,
                                                        "density": 0
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                }</pre>';
            $this->html_content .= "<br/>If Fails<br/>";
            $this->html_content .= '<pre>{
                                        "sts": 0,
                                        "msg": "url is empty",
                                        "arr": {
                                          "url": "required"
                                        }
                                      }</pre>';
            $this->html_content .= '<pre>{"sts":0,"msg":"invalid token"","arr":[]}</pre>';
        } else if ($apiType == "connectga") {

            $this->title = "Connect GA";
            $apiUrl = $this->base_url . "public/connectGA";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to connect google accounts. Ex (Google Adwords, Google Analytic, Google Search Console)";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>GET";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
	    $this->html_content .= "token * (base64 enocde - 2 times), redirect_uri (string)*, location_id, auth_type* Ex. (gaconnect, adwordconnect, consoleconnect)*<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= 'Redirect back to redirect_uri';
        } else if ($apiType == "getgadd") {
            $this->title = "Get GA Dropwdowns";
            $apiUrl = $this->base_url . "public/getGaDropDowns";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to save drop downs values of google analytic.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
	    $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> location_id *, 
req_type * (possible values :  normal, webproperties, webprofiles)
normal: in case, if no analytics_child iin our DB.
<br/>
On dropdown change
if account changed, 'webproperties' to get properties;
if property changed, 'webprofiles' to get profiles;

account
property
profile<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"Google analytic token saved successfully","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"Error to save data. please try again","arr":[]}</pre>';
        } else if ($apiType == "savegadd") {
            $this->title = "Save GA Dropwdowns";
            $apiUrl = $this->base_url . "public/saveDropDownsValues";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to save drop downs values of google analytic.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
	    $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b>account*, property*, profile*,account_name*, property_name*, profile_name*.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"campaign deleted","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"Failed to delete campaign","arr":[]}</pre>';
        } else if ($apiType == "saveprofilenotes") {

            $this->title = "Save CRE Notes for Specific page url";
            $apiUrl = $this->base_url . "cre/saveUrlProfileNotes";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to save the notes with specific url.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "header: token*<br/>body: url*(string), notes*(text), keyword*(string).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":1,"msg":"notes saved","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"invalid token","arr":[{"token":"required" }]}</pre>';
        } else if ($apiType == "getprofilenotes") {

            $this->title = "Fetch all notes of specific page.";
            $apiUrl = $this->base_url . "cre/getUrlProfileNotes";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get notes of any specific page via its url.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "header: token*<br/>body: url*(string), offset(text)[optional], limit(string)[optional].<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {
                                    "sts": 1,
                                    "msg": "notes found",
                                    "arr": [
                                        {
                                            "location_id": "3",
                                            "notes": "hello just testing message from this area.",
                                            "keyword": "",
                                            "created_by": "Sanjay Kumar",
                                            "created": "13th June 2017 10:59am"
                                        },
                                        {
                                            "location_id": "3",
                                            "notes": "sf",
                                            "keyword": "",
                                            "created_by": "Sanjay Kumar",
                                            "created": "12th June 2017 10:30am"
                                        },
                                        {
                                            "location_id": "3",
                                            "notes": "d",
                                            "keyword": "",
                                            "created_by": "Sanjay Kumar",
                                            "created": "12th June 2017 10:30am"
                                        },
                                        {
                                            "location_id": "3",
                                            "notes": "d",
                                            "keyword": "",
                                            "created_by": "Sanjay Kumar",
                                            "created": "12th June 2017 10:29am"
                                        }
                                    ]
                                }</pre>';
            $this->html_content .= '<br/><br/>If Records not found<br/><pre>{
                                    "sts": 0,
                                    "msg": "no notes available",
                                    "arr": []
                                }</pre>';
        } else if ($apiType == "createkeygroup") {

            $this->title = "Create Keygroup";
            $apiUrl = $this->base_url . "cre/createKeygroup";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to create Keygroup.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "header: token*<br/>body: campaign_id*(string), landing_url*(text), keyword*(string), google_location*(string), new_group*(int)[either 0 or 1], group_id(int)[optional].<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":1,"msg":"keyword created","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Keyword is already in that Campaign<br/><pre> {"sts":0,"msg":"keyword is already added","arr":[]}</pre><br/><br/>If Fails<br/><pre> {"sts":0,"msg":"failed to create keygroup keyword","arr":[]}</pre>';
        } else if ($apiType == "listkeygroup") {

            $this->title = "List all keygroups";
            $apiUrl = $this->base_url . "cre/saveUrlProfileNotes";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to show all keygroups.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "header: token*<br/>body: campaign_id*(int).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {
                                    "sts": 1,
                                    "msg": [
                                        {
                                            "id": 26,
                                            "campaign_id": 4,
                                            "google_location": "USA pensylvania",
                                            "landing_page": "https://www.enfusen.com/faq/video-setup-multi-location-keyword-campaigns-enfusen/",
                                            "home_page": null,
                                            "is_target": 1,
                                            "notes": null,
                                            "user_id": 1,
                                            "created": "2017-06-13T06:31:25+00:00"
                                        }
                                    ],
                                    "arr": []
                                }</pre>';
        } else if ($apiType == "triggerreverseseo") {

            $this->title = "Run Reverse SEO";
            $apiUrl = $this->base_url . "cre/triggerReverseSEO";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to run reverse seo.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "header: token*<br/>body: url*(string), country*(text), limit(int)[keyword limit].<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":1,"msg":"reverse data pulled","arr":[]}</pre><br/>If No Keywords found<br/>';
            $this->html_content .= '<pre> {"sts":0,"msg":"No keyword found for this page.","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"invalid token","arr":[{"token":"required" }]}</pre>';
        } else if ($apiType == "getreverseseodata") {

            $this->title = "Get Reverse SEO Data";
            $apiUrl = $this->base_url . "cre/getReverseSEOdata";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to save the notes with specific url.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{
                                    "sts": 1,
                                    "msg": "data found",
                                    "arr": [
                                        {
                                            "id": "1",
                                            "location_id": "3",
                                            "page_url": "https://www.rudrainnovatives.com/hire-developers/hire-web-designer/",
                                            "keyword": "hire web designer",
                                            "position": "68",
                                            "search_voulme": "880",
                                            "cpc": "15.12",
                                            "competiton": "0.71",
                                            "traffic_percent": "0.00",
                                            "traffic_cost": "0.00",
                                            "created": "2017-06-08 07:55:38",
                                            "created_by": null,
                                            "modified": "2017-06-08 08:09:40",
                                            "modified_by": null
                                        }
                                    ]
                                }</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"invalid token","arr":[{"token":"required" }]}</pre>';
        } else if ($apiType == "connect-adroll") {

            $this->title = "Connect AdRoll API";
            $apiUrl = $this->base_url . "public/connectAdroll";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to connect with AdRoll API with API engine House";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>header:</b> token*<br/><b>body:</b> api_key* (String), email* (String), password* (String), location_id (int).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"Successfully Connected with AdRoll API","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":"0","msg":"Provide all input fields","arr":[]}</pre> <br/>';
            $this->html_content .= '<pre>{"sts":0,"msg":"Invalid Header","arr":[]}</pre>';
        } else if ($apiType == "connect-twilio") {

            $this->title = "Connect Twilio API";
            $apiUrl = $this->base_url . "public/connectTwilio";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to connect with Twilio API with API engine House";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>header:</b> token*<br/><b>body:</b> api_key* (String), api_secret* (String), location_id (int).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"Successfully Connected with Twilio API","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":"0","msg":"Provide all input fields","arr":[]}</pre> <br/>';
            $this->html_content .= '<pre>{"sts":0,"msg":"Invalid Header","arr":[]}</pre>';

        } else if ($apiType == "connect-callrail") {

            $this->title = "Connect CallRail API";
            $apiUrl = $this->base_url . "public/connectCallrail";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to connect with Call Rail API with API engine House";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>header:</b> token*<br/><b>body:</b> api_key* (String), location_id (int).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"Successfully Connected with CallRail API","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":"0","msg":"Provide all input fields","arr":[]}</pre> <br/>';
            $this->html_content .= '<pre>{"sts":0,"msg":"Invalid Header","arr":[]}</pre>';
        } else if ($apiType == "disconnect-ga") {

            $this->title = "Disconnect GA account's";
            $apiUrl = $this->base_url . "public/disconnect";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to disconnect with all GA account's Ex.(Google Analytic, Google Adwords, Google Search)";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>header:</b> token*<br/><b>body:</b> location_id, type* Ex.(google_analytic, google_adwords, google_search).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"Google Adwords disconnected successfully.","arr":[]}</pre>';
	    $this->html_content .= '<pre> {"sts":"1","msg":"Google Analytic disconnected successfully.","arr":[]}</pre>';
	    $this->html_content .= '<pre> {"sts":"1","msg":"Google Search Console disconnected successfully.","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":"0","msg":"Invalid Request","arr":[]}</pre> <br/>';
            $this->html_content .= '<pre>{"sts":0,"msg":"Invalid Token","arr":[]}</pre>';
	} else if ($apiType == "connect-calltrackingmetrics") {

            $this->title = "Connect Call Tracking Metrics API";
            $apiUrl = $this->base_url . "public/connectCalltrackingmetrics";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to connect with Call Tracking Metrics API with API engine House";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>header:</b> token*<br/><b>body:</b> api_key* (String), api_secret* (String), location_id (int).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"Successfully Connected with Call Tracking Metrics API","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":"0","msg":"Provide all input fields","arr":[]}</pre> <br/>';
            $this->html_content .= '<pre>{"sts":0,"msg":"Invalid Header","arr":[]}</pre>';
        } else if ($apiType == "disconnect-adroll") {

            $this->title = "Disconnect AdRoll API";
            $apiUrl = $this->base_url . "public/disconnectAdroll";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to disconnect with AdRoll API ";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> location_id (int).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"Disconnected successfully","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"Invalid Header","arr":[]}</pre> <br/>';
        } else if ($apiType == "disconnect-twilio") {

            $this->title = "Disconnect Twilio API";
            $apiUrl = $this->base_url . "public/disconnectTwilio";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to disconnect with Twilio API ";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> location_id (int).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"Disconnected successfully","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"Invalid Header","arr":[]}</pre> <br/>';
        } else if ($apiType == "disconnect-callrail") {

            $this->title = "Disconnect Call Rail API";
            $apiUrl = $this->base_url . "public/disconnectCallrail";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to disconnect with Call Rail API ";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> location_id (int).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"Disconnected successfully","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"Invalid Header","arr":[]}</pre> <br/>';
        } else if ($apiType == "disconnect-calltrackingmetrics") {

            $this->title = "Disconnect Call Tracking Metrics API";
            $apiUrl = $this->base_url . "public/disconnectCalltrackingmetrics";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to disconnect with Call Tracking Metrics API ";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
	    $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> location_id (int).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"Disconnected successfully","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"Invalid Header","arr":[]}</pre> <br/>';

        } else if ($apiType == "disconnect-bing") {

            $this->title = "Disconnect Bingads API";
            $apiUrl = $this->base_url . "public/disconnectBing";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to disconnect with Bing API ";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
	    $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> location_id (int).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"Disconnected successfully","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"Invalid Header","arr":[]}</pre> <br/>';

        } else if ($apiType == "disconnect-facebook") {

            $this->title = "Disconnect Facebook API";
            $apiUrl = $this->base_url . "public/disconnectFb";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to disconnect with Facebook API ";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
	    $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> location_id (int).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"Disconnected successfully","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"Invalid Header","arr":[]}</pre> <br/>';

        }  else if ($apiType == "add-citation") {

            $this->title = "API for Add Citation";
            $apiUrl = $this->base_url . "citation/addCitation";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Add Citation.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
	    $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> location_id, name, url, country_id, state_id, city_id, city (in case if new city), services, phone, address, zip_code.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":1,"msg":"Citation successfully added","arr":{"citation_id":1}}</pre>';
	    $this->html_content .= '<pre> {"sts":1,"msg":"Citation successfully added","arr":{"citation_id":1,"new_city_id": 48923}} (in case of new city added)</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"Failed to add citation"}</pre> <br/>';

        } else if ($apiType == "update-citation") {

            $this->title = "API for Update Citation";
            $apiUrl = $this->base_url . "citation/updateCitation";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Update Citation.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
	    $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> citation_id, name, url, country_id, state_id, city_id, city (in case if new city), services, phone, address, zip_code<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":1,"msg":"Citation successfully updated","arr":{"citation_id":1}}</pre>';
	    $this->html_content .= '<pre> {"sts":1,"msg":"Citation successfully updated","arr":{"citation_id":1,"new_city_id": 48923}} (in case of new city added)</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"Failed to add citation"}</pre> <br/>';

        }else if ($apiType == "list-citation") {

            $this->title = "API for List All Citations";
            $apiUrl = $this->base_url . "citation/listCitations";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to List All citations.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
	    $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> offset <br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":1,"msg":"Citations Found","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"invalid token"}</pre> <br/>';

        }else if ($apiType == "details-citation") {

            $this->title = "API for Get Details of Citations";
            $apiUrl = $this->base_url . "citation/citationDetail";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Get Citation Details.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
	    $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> Id* <br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":1,"msg":"Data Found","arr":[]}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"You are not authorized to access this citation detail"}</pre> <br/>';

        }else if ($apiType == "report-citation") {

            $this->title = "API for Get Citation Report";
            $apiUrl = $this->base_url . "citation/citationReport";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Get Citation report.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
	    $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> Id* <br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":1,"msg":"Data Found","arr":[]}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"invalid token"}</pre> <br/>';

        }else if ($apiType == "delete-citation") {

            $this->title = "API for Delete Citation";
            $apiUrl = $this->base_url . "citation/deleteCitations";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used delete citation.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
	    $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> citation_id* <br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":1,"msg":"Citation Deleted successfully","arr":[]}</pre>';
	    $this->html_content .= '<pre> {"sts":1,"msg":"Citation deleted , but no citation list found","arr":[]}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre> {"sts":0,"msg":"invalid token"}</pre> <br/>';

        }else if ($apiType == "run-citation") {

            $this->title = "API for Run Citation";
            $apiUrl = $this->base_url . "citation/runCitation";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Run Citation.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> citation_id.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"Citation is runing successfully.","arr":[]}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"Failed to run citation"}</pre> <br/>';

        }else if ($apiType == "rerun-citation") {

            $this->title = "API for Re-Run Citation";
            $apiUrl = $this->base_url . "citation/reRunCitations";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Re-Run Citation.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> citation_id.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":1,"msg":"Citations Rerun Successfully"}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"Citations is already in progress."}</pre> <br/><pre>{"sts":0,"msg":"Rerun Process Failled."}</pre>';

        } else if ($apiType == "primary-citation") {

            $this->title = "API for Primary Citation";
            $apiUrl = $this->base_url . "citation/getPrimaryCitations";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to list Primary Citation.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> citation_id* , limit, offset, search_txt,sortby, orderby .<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {
    "sts": 1,
    "msg": "Primary Citations List",
    "arr": {
        "data": [
            {
                "logo": "http://enfusenstaging.com/api/logos/logo157.png",
                "webname": "b2byellowpages.com",
                "link": "",
                "score": "100",
                "nameColor": "",
                "name": "",
                "addressColor": "",
                "address": "",
                "zipColor": "",
                "zip": "",
                "phoneColor": "",
                "phone": "",
                "citation_list_id": 9
            },
            {
                "logo": "http://enfusenstaging.com/api/logos/logo59.png",
                "webname": "merchantcircle.com",
                "link": "",
                "score": "100",
                "nameColor": "",
                "name": "",
                "addressColor": "",
                "address": "",
                "zipColor": "",
                "zip": "",
                "phoneColor": "",
                "phone": "",
                "citation_list_id": 9
            },
            {
                "logo": "http://enfusenstaging.com/api/logos/logo63.png",
                "webname": "dexknows.com",
                "link": "",
                "score": "100",
                "nameColor": "",
                "name": "",
                "addressColor": "",
                "address": "",
                "zipColor": "",
                "zip": "",
                "phoneColor": "",
                "phone": "",
                "citation_list_id": 9
            },
            {
                "logo": "http://enfusenstaging.com/api/logos/logo101.png",
                "webname": "yellowpages.com",
                "link": "",
                "score": "100",
                "nameColor": "",
                "name": "",
                "addressColor": "",
                "address": "",
                "zipColor": "",
                "zip": "",
                "phoneColor": "",
                "phone": "",
                "citation_list_id": 9
            },
            {
                "logo": "http://enfusenstaging.com/api/logos/logo153.png",
                "webname": "yahoo.com",
                "link": "",
                "score": "100",
                "nameColor": "",
                "name": "",
                "addressColor": "",
                "address": "",
                "zipColor": "",
                "zip": "",
                "phoneColor": "",
                "phone": "",
                "citation_list_id": 9
            },
            {
                "logo": "http://enfusenstaging.com/api/logos/logo133.png",
                "webname": "bbb.org",
                "link": "",
                "score": "100",
                "nameColor": "",
                "name": "",
                "addressColor": "",
                "address": "",
                "zipColor": "",
                "zip": "",
                "phoneColor": "",
                "phone": "",
                "citation_list_id": 9
            },
            {
                "logo": "http://enfusenstaging.com/api/logos/logo55.png",
                "webname": "hotfrog.com",
                "link": "",
                "score": "100",
                "nameColor": "",
                "name": "",
                "addressColor": "",
                "address": "",
                "zipColor": "",
                "zip": "",
                "phoneColor": "",
                "phone": "",
                "citation_list_id": 9
            },
            {
                "logo": "http://enfusenstaging.com/api/logos/logo40.png",
                "webname": "yelp.com",
                "link": "",
                "score": "100",
                "nameColor": "",
                "name": "",
                "addressColor": "",
                "address": "",
                "zipColor": "",
                "zip": "",
                "phoneColor": "",
                "phone": "",
                "citation_list_id": 9
            },
            {
                "logo": "http://enfusenstaging.com/api/logos/logo340.png",
                "webname": "justdial.com",
                "link": "https://www.justdial.com/Chandigarh/Rudra-Innovative-Software-Pvt-Ltd/0172PX172-X172-140107154551-L3R9_BZDET?xid=Q2hhbmRpZ2FyaCBSdWRyYSBBc3RybyBTY2llbmNlIE1vaGFsaSBTYXMgTmFnYXI=",
                "score": "100",
                "nameColor": "#008000",
                "name": "Rudra innovative",
                "siteurlColor": "#FF0000",
                "siteurl": "https://www.rudrainnovatives.com/",
                "addressColor": "#008000",
                "address": "MOHALI",
                "zipColor": "#008000",
                "zip": "160059",
                "phoneColor": "#FF0000",
                "phone": "+91-172 4007010",
                "citation_list_id": 9
            },
            {
                "logo": "http://enfusenstaging.com/api/logos/logo18.png",
                "webname": "foursquare.com",
                "link": "https://foursquare.com/v/rudra-innovative-software-pvt-ltd/52d0e41d11d2ef090ab86789",
                "score": "100",
                "nameColor": "#008000",
                "name": "Rudra innovative",
                "siteurlColor": "#FF0000",
                "siteurl": "https://www.rudrainnovatives.com/",
                "addressColor": "#FF0000",
                "address": "MOHALI",
                "zipColor": "#008000",
                "zip": "160059",
                "phoneColor": "#FF0000",
                "phone": "+91-172 4007010",
                "citation_list_id": 9
            }
        ],
        "graph": {
            "correctBusignessName": 7,
            "errorBusignessName": 0,
            "correctAddress": 1,
            "errorAddress": 6,
            "corectUrl": 4,
            "errorUrl": 3,
            "correctPhone": 1,
            "errorPhone": 6,
            "correctZip": 5,
            "errorZip": 2,
            "topCitationAudit": 0,
            "topCitationAuditError": 7,
            "total_score": 0,
            "total_top_sites": 28,
            "top_citations": 7,
            "topPercent": 25
        },
        "total_records": 32,
        "total_pages": 4,
        "current_page": 1
    }
}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"No Additional Citations."}</pre> <br/><pre>{"sts":0,"msg":"Invalid Token."}</pre>';

        }else if ($apiType == "additional-citation") {

            $this->title = "API for Additional Citation";
            $apiUrl = $this->base_url . "citation/getAdditionsCitations";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Get Additional Citations Citation.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b>citation_id* , limit, offset, search_txt, sortby, orderby<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {
    "sts": 1,
    "msg": "Additional Citations List",
    "arr": {
        "data": [
            {
                "webname": "sulekha.com",
                "link": "https://www.sulekha.com/rudra-innovative-software-pvt-ltd-mohali-chandigarh-contact-address",
                "score": "",
                "nameColor": "#008000",
                "name": "Rudra innovative",
                "siteurlColor": "#008000",
                "siteurl": "https://www.rudrainnovatives.com/",
                "addressColor": "#008000",
                "address": "MOHALI",
                "zipColor": "#008000",
                "zip": "160059",
                "phoneColor": "#FF0000",
                "phone": "+91-172 4007010",
                "citation_list_id": 9
            },
            {
                "webname": "rudrainnovatives.wordpress.com",
                "link": "https://rudrainnovatives.wordpress.com/2016/09/30/top-best-15-web-development-website-designing-companies-in-india-oct-2016-report",
                "score": "",
                "nameColor": "#008000",
                "name": "Rudra innovative",
                "siteurlColor": "#008000",
                "siteurl": "https://www.rudrainnovatives.com/",
                "addressColor": "#008000",
                "address": "MOHALI",
                "zipColor": "#008000",
                "zip": "160059",
                "phoneColor": "#FF0000",
                "phone": "+91-172 4007010",
                "citation_list_id": 9
            },
            {
                "webname": "slideee.com",
                "link": "http://www.slideee.com/slide/best-web-development-company-india",
                "score": "",
                "nameColor": "#008000",
                "name": "Rudra innovative",
                "siteurlColor": "#008000",
                "siteurl": "https://www.rudrainnovatives.com/",
                "addressColor": "#FF0000",
                "address": "MOHALI",
                "zipColor": "#008000",
                "zip": "160059",
                "phoneColor": "#FF0000",
                "phone": "+91-172 4007010",
                "citation_list_id": 9
            },
            {
                "webname": "webdevelopmentcomapanylist.wordpress.com",
                "link": "https://webdevelopmentcomapanylist.wordpress.com",
                "score": "",
                "nameColor": "#008000",
                "name": "Rudra innovative",
                "siteurlColor": "#008000",
                "siteurl": "https://www.rudrainnovatives.com/",
                "addressColor": "#FF0000",
                "address": "MOHALI",
                "zipColor": "#FF0000",
                "zip": "160059",
                "phoneColor": "#008000",
                "phone": "+91-172 4007010",
                "citation_list_id": 9
            },
            {
                "webname": "companyinfoz.com",
                "link": "http://companyinfoz.com/company/rudra-innovative-software-private-limited",
                "score": "",
                "nameColor": "#008000",
                "name": "Rudra innovative",
                "siteurlColor": "#FF0000",
                "siteurl": "https://www.rudrainnovatives.com/",
                "addressColor": "#008000",
                "address": "MOHALI",
                "zipColor": "#008000",
                "zip": "160059",
                "phoneColor": "#FF0000",
                "phone": "+91-172 4007010",
                "citation_list_id": 9
            },
            {
                "webname": "appndeveloper.com",
                "link": "https://www.appndeveloper.com/india/sahibzada-ajit-singh-nagar/mobile-app-development-company/rudra-innovative-software-pvt-ltd",
                "score": "",
                "nameColor": "#008000",
                "name": "Rudra innovative",
                "siteurlColor": "#008000",
                "siteurl": "https://www.rudrainnovatives.com/",
                "addressColor": "#FF0000",
                "address": "MOHALI",
                "zipColor": "#008000",
                "zip": "160059",
                "phoneColor": "#FF0000",
                "phone": "+91-172 4007010",
                "citation_list_id": 9
            },
            {
                "webname": "asksuba.com",
                "link": "http://asksuba.com/address/rudra-infrastructure-building-consultants-contractors-ahmedabad",
                "score": "",
                "nameColor": "#008000",
                "name": "Rudra innovative",
                "siteurlColor": "#FF0000",
                "siteurl": "https://www.rudrainnovatives.com/",
                "addressColor": "#008000",
                "address": "MOHALI",
                "zipColor": "#008000",
                "zip": "160059",
                "phoneColor": "#FF0000",
                "phone": "+91-172 4007010",
                "citation_list_id": 9
            },
            {
                "webname": "statsinfinity.com",
                "link": "http://www.statsinfinity.com/domain/U2QzliVZbwHebiUo0SA3_Q.._info.html",
                "score": "",
                "nameColor": "#008000",
                "name": "Rudra innovative",
                "siteurlColor": "#FF0000",
                "siteurl": "https://www.rudrainnovatives.com/",
                "addressColor": "#FF0000",
                "address": "MOHALI",
                "zipColor": "#008000",
                "zip": "160059",
                "phoneColor": "#FF0000",
                "phone": "+91-172 4007010",
                "citation_list_id": 9
            },
            {
                "webname": "dealerbaba.com",
                "link": "https://www.dealerbaba.com/suppliers/information-technology/website-design-and-development/rudra-innovative-software-pvt-ltd.html",
                "score": "",
                "nameColor": "#008000",
                "name": "Rudra innovative",
                "siteurlColor": "#008000",
                "siteurl": "https://www.rudrainnovatives.com/",
                "addressColor": "#008000",
                "address": "MOHALI",
                "zipColor": "#008000",
                "zip": "160059",
                "phoneColor": "#FF0000",
                "phone": "+91-172 4007010",
                "citation_list_id": 9
            },
            {
                "webname": "grotal.com",
                "link": "https://www.grotal.com/Mohali/Rudra-Food-Junction-C2",
                "score": "",
                "nameColor": "#008000",
                "name": "Rudra innovative",
                "siteurlColor": "#FF0000",
                "siteurl": "https://www.rudrainnovatives.com/",
                "addressColor": "#008000",
                "address": "MOHALI",
                "zipColor": "#008000",
                "zip": "160059",
                "phoneColor": "#FF0000",
                "phone": "+91-172 4007010",
                "citation_list_id": 9
            }
        ],
        "total_records": 142,
        "total_pages": 15,
        "current_page": 1
    }
}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre></pre>';

        }  else if ($apiType == "competitor-citation") {

            $this->title = "API for Competitor Citation";
            $apiUrl = $this->base_url . "citation/getCompetitorCitations";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to list Competitor Citation.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> citation_id* , limit, offset, search_txt (by title), sortby, orderby.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {
    "sts": 1,
    "msg": "Competitor Citations List",
    "arr": {
        "data": [
            {
                "keyword": "Web Design",
                "googleLocation": "",
                "resultType": "MapsResult",
                "rank": 1,
                "title": "India Web Designs",
                "totalVerifiedCitations": 0,
                "mentions": 17,
                "averageDomainAuthority": "0.00",
                "averagePageAuthority": "0.00",
                "averageMozRank": "0.00",
                "averageLinks": "0.00",
                "citation_list_id": 2,
                "citation_report_id": "f7jLsSgWB06lFLlgGHaVjw"
            },
            {
                "keyword": "Web Design",
                "googleLocation": "",
                "resultType": "MapsResult",
                "rank": 4,
                "title": "Open Designs",
                "totalVerifiedCitations": 0,
                "mentions": 46,
                "averageDomainAuthority": "0.00",
                "averagePageAuthority": "0.00",
                "averageMozRank": "0.00",
                "averageLinks": "0.00",
                "citation_list_id": 2,
                "citation_report_id": "asbXHxGBx0KxZqrhU-oMWg"
            },
            {
                "keyword": "Web Design",
                "googleLocation": "",
                "resultType": "MapsResult",
                "rank": 3,
                "title": "Zinavo-Web Design Company in Bangalore",
                "totalVerifiedCitations": 0,
                "mentions": 169,
                "averageDomainAuthority": "0.00",
                "averagePageAuthority": "0.00",
                "averageMozRank": "0.00",
                "averageLinks": "0.00",
                "citation_list_id": 2,
                "citation_report_id": "AM45WQmO00miczYWH-_GHA"
            },
            {
                "keyword": "Web Design",
                "googleLocation": "",
                "resultType": "MapsResult",
                "rank": 2,
                "title": "Web Designing Web development in Hyderabad",
                "totalVerifiedCitations": 0,
                "mentions": 4,
                "averageDomainAuthority": "0.00",
                "averagePageAuthority": "0.00",
                "averageMozRank": "0.00",
                "averageLinks": "0.00",
                "citation_list_id": 2,
                "citation_report_id": "mKM1Yemfh0mtM0wWra9wHg"
            },
            {
                "keyword": "Web Design",
                "googleLocation": "",
                "resultType": "MapsResult",
                "rank": 5,
                "title": "Caba Innovatives: Web Designing Courses, Graphic Design Courses in Delhi",
                "totalVerifiedCitations": 0,
                "mentions": 28,
                "averageDomainAuthority": "0.00",
                "averagePageAuthority": "0.00",
                "averageMozRank": "0.00",
                "averageLinks": "0.00",
                "citation_list_id": 2,
                "citation_report_id": "iyqWxtDyikmagSf2gZakMg"
            },
            {
                "keyword": "Web Design",
                "googleLocation": "",
                "resultType": "MapsResult",
                "rank": 7,
                "title": "3KITS",
                "totalVerifiedCitations": 0,
                "mentions": 57,
                "averageDomainAuthority": "0.00",
                "averagePageAuthority": "0.00",
                "averageMozRank": "0.00",
                "averageLinks": "0.00",
                "citation_list_id": 2,
                "citation_report_id": "QQvAH7EkEEmm1pBmcW6X2g"
            },
            {
                "keyword": "Web Design",
                "googleLocation": "",
                "resultType": "MapsResult",
                "rank": 10,
                "title": "Softons Web Design Solutions",
                "totalVerifiedCitations": 0,
                "mentions": 6,
                "averageDomainAuthority": "0.00",
                "averagePageAuthority": "0.00",
                "averageMozRank": "0.00",
                "averageLinks": "0.00",
                "citation_list_id": 2,
                "citation_report_id": "R8SqaqfHc0q0Uf3MiN8Wcg"
            },
            {
                "keyword": "Web Design",
                "googleLocation": "",
                "resultType": "MapsResult",
                "rank": 10,
                "title": "I Knowledge Factory Pvt. Ltd",
                "totalVerifiedCitations": 0,
                "mentions": 89,
                "averageDomainAuthority": "0.00",
                "averagePageAuthority": "0.00",
                "averageMozRank": "0.00",
                "averageLinks": "0.00",
                "citation_list_id": 2,
                "citation_report_id": "j0hK0RwLzUiEsxR_0L3CAw"
            },
            {
                "keyword": "Web Design",
                "googleLocation": "",
                "resultType": "MapsResult",
                "rank": 9,
                "title": "Web Designer Agra, Website Designer Agra",
                "totalVerifiedCitations": 0,
                "mentions": 1,
                "averageDomainAuthority": "0.00",
                "averagePageAuthority": "0.00",
                "averageMozRank": "0.00",
                "averageLinks": "0.00",
                "citation_list_id": 2,
                "citation_report_id": "fzOgxbscn0eMlHG29Xz7qA"
            },
            {
                "keyword": "Web Design",
                "googleLocation": "",
                "resultType": "MapsResult",
                "rank": 8,
                "title": "Azasoft Solutions - Web Designing Company in Tirunelveli",
                "totalVerifiedCitations": 0,
                "mentions": 26,
                "averageDomainAuthority": "0.00",
                "averagePageAuthority": "0.00",
                "averageMozRank": "0.00",
                "averageLinks": "0.00",
                "citation_list_id": 2,
                "citation_report_id": "esKoIV5TuU-fKVc3JQ4xQg"
            }
        ],
        "total_records": 10,
        "total_pages": 1,
        "current_page": 1
    }
}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"No Additional Citations."}</pre> <br/><pre>{"sts":0,"msg":"Invalid Token."}</pre>';

        }else if ($apiType == "total-citation") {

            $this->title = "API for Get Total Citation";
            $apiUrl = $this->base_url . "citation/getTotal";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get total Citations Values.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> citation_id*.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {
    "sts": 1,
    "msg": "Total Data List",
    "arr": {
        "data": {
            "total_primary": 35,
            "total_additional": 142,
            "total_competitor": 10,
            "total_opportunities": 12
        }
    }
}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"No Data Found."}</pre> <br/><pre>{"sts":0,"msg":"Invalid Token."}</pre>';

        }   else if ($apiType == "opportunities -citation") {

            $this->title = "API for Opportunities Citation";
            $apiUrl = $this->base_url . "citation/getCitationsOpportunities";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to list Citation Opportunities.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> citation_id* , limit, offset, search_txt (by site), sortby, orderby.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{
    "sts": 1,
    "msg": "Citations Opportunoties data List",
    "arr": {
        "data": [
            {
                "site": "facebook.com",
                "link": "https://www.facebook.com/massoftind",
                "DA": -1,
                "num_competitor": 1,
                "mozRank": -1,
                "total_citaion": 0,
                "have_citation": "N",
                "citation_list_id": 9
            },
            {
                "site": "linkedin.com",
                "link": "https://www.linkedin.com/company/mass-software-solution-pvt-ltd.",
                "DA": -1,
                "num_competitor": 1,
                "mozRank": -1,
                "total_citaion": 0,
                "have_citation": "N",
                "citation_list_id": 9
            },
            {
                "site": "m.facebook.com",
                "link": "https://m.facebook.com/massoftind",
                "DA": -1,
                "num_competitor": 1,
                "mozRank": -1,
                "total_citaion": 0,
                "have_citation": "N",
                "citation_list_id": 9
            },
            {
                "site": "fr-fr.facebook.com",
                "link": "https://fr-fr.facebook.com/massoftind/posts/?ref=page_internal",
                "DA": -1,
                "num_competitor": 1,
                "mozRank": -1,
                "total_citaion": 0,
                "have_citation": "N",
                "citation_list_id": 9
            },
            {
                "site": "xn--telefonn-pedvolby-kvb86r.cybo.com",
                "link": "https://xn--telefonn-pedvolby-kvb86r.cybo.com/indie/33_kalkata/specializovan%C3%BD-design",
                "DA": -1,
                "num_competitor": 1,
                "mozRank": -1,
                "total_citaion": 0,
                "have_citation": "N",
                "citation_list_id": 9
            },
            {
                "site": "yellowpages-zh.cybo.com",
                "link": "https://yellowpages-zh.cybo.com/IN/%E6%9E%B6%E5%88%A9%E5%90%89%E6%89%93/%E5%B0%88%E6%A5%AD%E8%A8%AD%E8%A8%88/?",
                "DA": -1,
                "num_competitor": 1,
                "mozRank": -1,
                "total_citaion": 0,
                "have_citation": "N",
                "citation_list_id": 9
            },
            {
                "site": "slideshare.net",
                "link": "https://www.slideshare.net/MassSoftwareSolutions/mass-software-solutions-pvt-ltd",
                "DA": -1,
                "num_competitor": 1,
                "mozRank": -1,
                "total_citaion": 0,
                "have_citation": "N",
                "citation_list_id": 9
            },
            {
                "site": "massoftind.com.ourssite.com",
                "link": "http://massoftind.com.ourssite.com",
                "DA": -1,
                "num_competitor": 1,
                "mozRank": -1,
                "total_citaion": 0,
                "have_citation": "N",
                "citation_list_id": 9
            },
            {
                "site": "prefikset-telefon.cybo.com",
                "link": "https://prefikset-telefon.cybo.com/india/33_kalkuta/dizajn-i-specializuar-",
                "DA": -1,
                "num_competitor": 1,
                "mozRank": -1,
                "total_citaion": 0,
                "have_citation": "N",
                "citation_list_id": 9
            },
            {
                "site": "retningsnumre.cybo.com",
                "link": "https://retningsnumre.cybo.com/india/33_kolkata/spesialisert-design",
                "DA": -1,
                "num_competitor": 1,
                "mozRank": -1,
                "total_citaion": 0,
                "have_citation": "N",
                "citation_list_id": 9
            }
        ],
        "total_records": 10,
        "total_pages": 1,
        "current_page": 1
    }
}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"No Additional Citations."}</pre> <br/><pre>{"sts":0,"msg":"Invalid Token."}</pre>';

        }  else if ($apiType == "site-report") {

            $this->title = "API for get Citation Site Report";
            $apiUrl = $this->base_url . "citation/getSiteReport";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get site reporting data.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> citation_list_id*, site*, offset, limit, search_txt, site, sortby, orderby.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{
    "sts": 1,
    "msg": "Citations Sites report data List",
    "arr": {
        "data": [
            {
                "domain": "facebook.com",
                "verified": "N",
                "name": "Y",
                "address": "N",
                "phone": "Y",
                "siteurl": "Y",
                "street_adress": "Y",
                "city": "N",
                "state": "N/A",
                "zip": "Y",
                "da": -1,
                "pa": -1,
                "mozrank": -1
            },
            {
                "domain": "facebook.com",
                "verified": "N",
                "name": "Y",
                "address": "N",
                "phone": "N",
                "siteurl": "Y",
                "street_adress": "Y",
                "city": "N",
                "state": "N/A",
                "zip": "Y",
                "da": -1,
                "pa": -1,
                "mozrank": -1
            },
            {
                "domain": "facebook.com",
                "verified": "N",
                "name": "N",
                "address": "N",
                "phone": "Y",
                "siteurl": "Y",
                "street_adress": "Y",
                "city": "N",
                "state": "N/A",
                "zip": "N",
                "da": -1,
                "pa": -1,
                "mozrank": -1
            }
        ],
        "final_calculation": {
            "status": "None",
            "citation_site": "facebook.com",
            "have_citation": "N",
            "num_competitor": 12,
            "total_citations": 3,
            "da": -3,
            "domain_mozrank": -3,
            "instructions": "Instructions from Facebook : https://www.facebook.com/business/help/720478807965744",
            "login_url": "https://www.facebook.com/login/"
        },
        "notes": "",
        "logindata": {
            "citation_list_id": 2,
            "site_url": "facebook.com",
            "password": "123456"
        },
        "total_records": 3,
        "total_pages": 1,
        "current_page": 1
    }
}</pre>';

        }else if ($apiType == "notes-citation") {

            $this->title = "API for Save Citation Notes";
            $apiUrl = $this->base_url . "citation/saveCitationNotes";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to save citation notes.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> citation_list_id*, site, notes, location_id.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":1, "msg":"Notes Added Into Database", "arr":[]}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"No Data Found."}</pre> <br/><pre>{"sts":0,"msg":"Invalid Token."}</pre>';

        } else if ($apiType == "credential-citation") {

            $this->title = "API for Save Citation site login credentials";
            $apiUrl = $this->base_url . "citation/saveLogin";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to save site login credentials .";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> citation_list_id*, site, username, password <br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{
    "sts": 1,
    "msg": "User Details Save Into Database",
    "arr": []
}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"No Data Found."}</pre> <br/><pre>{"sts":0,"msg":"Invalid Token."}</pre>';

        }  else if ($apiType == "competetivereport-citation") {

            $this->title = "API for Get Competetive report Citation";
            $apiUrl = $this->base_url . "citation/getCompetitiveReport";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Get citation competetive report.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> citation_report_id* ex('R8SqaqfHc0q0Uf3MiN8Wcg'), offset, limit, sortby, orderby, search_txt <br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{
    "sts": 1,
    "msg": "Citations Competetive Report Data List",
    "arr": {
        "data": [
            {
                "site": "yellowpages.cybo.com",
                "verified": "N",
                "name": "Y",
                "fa": "N",
                "phone": "Y",
                "url": "Y",
                "sa": "Y",
                "city": "N",
                "state": "N/A",
                "zip": "N",
                "pa": -1,
                "da": -1,
                "link": "https://yellowpages.cybo.com/IN/krishnagiri/specialized-design"
            },
            {
                "site": "postal-codes.cybo.com",
                "verified": "N",
                "name": "Y",
                "fa": "N",
                "phone": "Y",
                "url": "Y",
                "sa": "Y",
                "city": "N",
                "state": "N/A",
                "zip": "N",
                "pa": -1,
                "da": -1,
                "link": "https://postal-codes.cybo.com/india/635109_hosur/interior-decorations"
            }
        ],
        "total_records": 6,
        "total_pages": 3,
        "current_page": 2
    }
}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"No Data Found."}</pre> <br/><pre>{"sts":0,"msg":"Invalid Token."}</pre>';

        } else if ($apiType == "delete-notes") {

            $this->title = "API for Delete Citation Notes";
            $apiUrl = $this->base_url . "citation/deleteNotes";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used delete citation Notes.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> notes_id*<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1, "msg": "Notes Deleted sucessfully"}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"No Data Found."}</pre> <br/><pre>{"sts":0,"msg":"Invalid Token."}</pre>';

        } else if ($apiType == "download-report") {

            $this->title = "API for Download Citation Report";
            $apiUrl = $this->base_url . "citation/downloadPDF";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to download Citation PDF Report.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>GET";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>GET </b>token (2 times base64_encode)*, citation_id*<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre></pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"Please Provide Citation Id."}</pre> <br/>';

        } else if ($apiType == "history-citation") {

            $this->title = "API for History Citation";
            $apiUrl = $this->base_url . "citation/getCitationsHistory";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Citations History.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> citation_id*, offset.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {
    "sts": 1,
    "msg": "Citations History data List",
    "arr": {
        "data": [
            {
                "run_date": "04 Jul 2017 12:21 PM",
                "total_primary": 34,
                "total_additional": 170,
                "total_competitor": 10,
                "total_opportunities": 12,
                "verified": 2,
                "not_verified": 175,
                "total": 177,
                "total_score": 1.13,
                "need_attention": 177
            },
            {
                "run_date": "03 Jul 2017 2:44 PM",
                "total_primary": 68,
                "total_additional": 312,
                "total_competitor": 10,
                "total_opportunities": 12,
                "verified": 2,
                "not_verified": 324,
                "total": 326,
                "total_score": 0.61,
                "need_attention": 326
            }
        ],
        "total_records": 2,
        "total_pages": 1,
        "current_page": 1
    }
}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"No Data Found."}</pre> <br/><pre>{"sts":0,"msg":"Invalid Token."}</pre>';

        }  else if ($apiType == "all-connection") {

            $this->title = "Get All Connections";
            $apiUrl = $this->base_url . "public/getConnections";
            $this->html_content = "<b>API Url: </b><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get all connections.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b> token*<br><b>Body :</b> location_id.<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {
    "sts": 1,
    "msg": "Connections detail",
    "arr": {
        "google_token": "",
        "analytics_child": "",
        "adword_token": "",
        "google_search_token": "",
        "bing_token": "",
        "fb_token": "",
        "adroll_info": {
            "apikey": "123testing",
            "email": "aman@gmail.com",
            "password": "123rudra"
        },
        "calltracking_info": {
            "apikey": "123testing",
            "apisecret": "sakjdfhkkasdjfh"
        },
        "callrail_info": {
            "apikey": "123testing"
        },
        "twilio_info": {
            "apikey": "123testing",
            "apisecret": "aman1as2d1"
        }
    }
}</pre>';
	    $this->html_content .= '<br/><br/>If Fails<br/><pre>"sts":0,"msg":"No Connection Found"}</pre> <br/>';
        }else if ($apiType == "bing-connect") {
            $this->title = "Bing Ads Connect API";
            $apiUrl = $this->base_url . "public/connectBing";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Connect with Bing Ads services.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>GET";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>GET (method)</b>token* (base64 enocde - 2 times), location_id*, redirect_uri*";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>  </pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Missing parameters .","arr":[]}</pre>';
            
        }else if ($apiType == "fb-connect") {
            $this->title = "Facebook Connect API";
            $apiUrl = $this->base_url . "public/fbConnect";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Connect with Facebook API.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>GET";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>GET (method)</b>token* (base64 enocde - 2 times), location_id*, redirect_uri*";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>  </pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Missing parameters .","arr":[]}</pre>';
            
        } else if ($apiType == "admin-add-citation") {
            $this->title = "Admin Add Citations";
            $apiUrl = $this->base_url . "AdminCitation/addCitation";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Add Citations  by Admin from dashboard.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b>token*</br><b>Body :</b> domain_name, da, login_url, instruction, status, score, is_top_hunderd";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"0","msg":"New Citations Data Added into database","arr":[]} </pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Invalid Token","arr":[]}</pre> </br> <pre>{"sts":"0","msg":"Token Not Found","arr":[]}</pre>';
            
        }  else if ($apiType == "admin-edit-citation") {
            $this->title = "Admin Edit Citations";
            $apiUrl = $this->base_url . "AdminCitation/editCitation";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Edit Citations by Admin from dashboard.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b>token*</br><b>Body :</b> id";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{
    "sts": 1,
    "msg": "Citation Data",
    "arr": {
        "id": 2,
        "domain_name": "http://www.example.com",
        "login_url": "http://www.example.com/login",
        "instruction": "",
        "status": "Primary",
        "score": "50",
        "is_top_hunderd": 0
    }
} </pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Invalid Token","arr":[]}</pre> </br> <pre>{"sts":"0","msg":"Token Not Found","arr":[]}</pre>';
            
        } else if ($apiType == "admin-update-citation") {
            $this->title = "Admin Update Citations";
            $apiUrl = $this->base_url . "AdminCitation/updateCitations";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Update Citations  by Admin from dashboard.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b>token*</br><b>Body :</b>id*, domain_name, da, login_url, instruction, status, score, is_top_hunderd";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"0","msg":"Citation Updated successfully","arr":[]} </pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Invalid Token","arr":[]}</pre> </br> <pre>{"sts":"0","msg":"Token Not Found","arr":[]}</pre>';
            
        } else if ($apiType == "admin-all-citation") {
            $this->title = "Admin Get All Citations";
            $apiUrl = $this->base_url . "AdminCitation/getallCitations";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Get All Citations.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b>token*</br><b>Body :</b>offset (Page number), limit, status";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {
    "sts": 1,
    "msg": "Citation Data",
    "arr": {
        "citation": [
            {
                "id": null,
                "domain_name": "facebook.com",
                "da": "100",
                "login_url": "https://www.facebook.com/login/",
                "instruction": "Instructions from Facebook : https://www.facebook.com/business/help/720478807965744",
                "status": "Primary",
                "is_top_hunderd": 1
            },
            {
                "id": null,
                "domain_name": "http://www.example.com",
                "da": "98.99",
                "login_url": "http://www.example.com/login",
                "instruction": "",
                "status": "Primary",
                "is_top_hunderd": 0
            }
        ],
        "total_page": 5,
        "page": 1
    }
} </pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Invalid Token","arr":[]}</pre> </br> <pre>{"sts":"0","msg":"Token Not Found","arr":[]}</pre>';
            
        } else if ($apiType == "admin-top-citation") {
            $this->title = "Admin Get All Top Citations";
            $apiUrl = $this->base_url . "AdminCitation/gettopCitations";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Get Top Citations .";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b>token*</br><b>Body :</b>offset (Page number), Limit";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {
    "sts": 1,
    "msg": "Citation Top Data",
    "arr": {
        "citation": [
            {
                "id": null,
                "domain_name": "facebook.com",
                "da": "100",
                "login_url": "https://www.facebook.com/login/",
                "instruction": "Instructions from Facebook : https://www.facebook.com/business/help/720478807965744",
                "status": "Primary",
                "is_top_hunderd": 1
            },
            {
                "id": null,
                "domain_name": "linkedin.com",
                "da": "100",
                "login_url": null,
                "instruction": null,
                "status": null,
                "is_top_hunderd": 1
            }
        ],
        "total_page": 3,
        "page": 1
    }
} </pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Invalid Token","arr":[]}</pre> </br> <pre>{"sts":"0","msg":"Token Not Found","arr":[]}</pre>';
            
        }else if ($apiType == "multi-top-citation") {
            $this->title = "Admin Add Multiple/Single Top Citations";
            $apiUrl = $this->base_url . "AdminCitation/addTopCitations";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Add Multiple top Citations  by Admin from dashboard.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b>token*</br><b>Body :</b>{'ids': '2,3,4,7,8,9,5,6'}";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"0","msg":"Top users updated successfully","arr":[]} </pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Invalid Token","arr":[]}</pre> </br> <pre>{"sts":"0","msg":"Token Not Found","arr":[]}</pre>';
            
        } else if ($apiType == "remove-top-citation") {
            $this->title = "Admin Remove Multiple/Single Top Citations";
            $apiUrl = $this->base_url . "AdminCitation/removeTopCitations";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Remove Multiple top Citations  by Admin from dashboard.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b>token*</br><b>Body :</b>{'ids': '2,3,4,7,8,9,5,6'}";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"0","msg":"Top users Removed successfully","arr":[]} </pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Invalid Token","arr":[]}</pre> </br> <pre>{"sts":"0","msg":"Token Not Found","arr":[]}</pre>';
            
        } else if ($apiType == "upload-logo") {
            $this->title = "Admin Upload Top Citations logo";
            $apiUrl = $this->base_url . "AdminCitation/removeTopCitations";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to upload top citation logo.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "<b>Header :</b>token*</br><b>Body :</b>id*, image (base64 encode)";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"0","msg":"Logo Uploaded","arr":[]} </pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Invalid Token","arr":[]}</pre> </br> <pre>{"sts":"0","msg":"Token Not Found","arr":[]}</pre>';
            
        } else if ($apiType == "update-score") {
            $this->title = "Admin Update multiple scores";
            $apiUrl = $this->base_url . "AdminCitation/updateScore";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Update multiple score at same time.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= '<b>Header :</b>token*</br><b>Body :</b>{"data":[{"id":1,"score":50},{"id":2,"score":80}]}' ;
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"0","msg":"Citations Scores are updated successfully","arr":[]} </pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Invalid Token","arr":[]}</pre> </br> <pre>{"sts":"0","msg":"Token Not Found","arr":[]}</pre>';
            
        } 



        $this->set("apiType", $this->title);
        $this->set("content", $this->html_content);
    }

    public function apiEngine($apiType = '') {
        $base_url = 'http://enfusenstaging.com/apiengine/api/';
        $base_url2 = "http://localhost/cakeApi/enfusenApp/bingApi/";
        $base_url3 = "http://localhost/cakeApi/enfusenApp/AdwordApi/";
        $apiUrl = '';
        if (empty($apiType)) {
            $this->title = "About API Engine Documentation - Only accessible from main server";
            $this->html_content = "<br/><b>Description:</b><br/>All API engine related outbound API and cron information will be listed here.";
        } else if ($apiType == "getgatoken") {

            $this->title = "Get Google Analytic Token";
            $apiUrl = $base_url . "getgatoken";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get saved user google access token from database.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"Google token found","arr":[{"access_token":"ya29.sfsfds-NQZRcl4ffOc5iawah_Z-fsdfsdfsfdfgdgf_fHuwTU2MEYY7kS1pyNgQLJU","token_type":"Bearer","expires_in":3600,"refresh_token":"ffpZm0jwPB1birpNOOBX5LI_uIQ359nrsdPc_FOsPytE","id_token":"lkljklwrewrwr.gdgd_rv2oRqmgjg10n7vz3_wy_84f04xWt02meP6-VwJ9ts8ijK7DvN3Kq5lr6_AHlNY4LL5Sg8_kjh-hjkhk_INqo13kZlpf5-jlljlk-vcnUgUc_H2_ghfghfh-1agFLRMMPV14twBUtPNL28NlEYlLi6Lfb_zaHHiG8nFepiHv05tMTzGRVbz7vi6Wr0ktMhiZx3j2rdV1wtoH0w","created":1496660867}]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"No connected with google yet","arr":[]}</pre>';
        } else if ($apiType == "savegatoken") {

            $this->title = "Save Google Analytic Token - Only accessible from main server";
            $apiUrl = $base_url . "savegaaccount";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to save user google access token in database.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header), token* (json object of google token - collection of acces, refresh, token type etc).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"Google analytic token saved successfully","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"Error to save data. please try again","arr":[]}</pre>';
        } else if ($apiType == "savegaaccount") {

            $this->title = "Save Google Analytic Account and websites - Only accessible from main server";
            $apiUrl = $base_url . "savegatoken";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to save google analytics drop downs values. Like accounjt, property and profile of GA";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header), account*, property*, profile* <br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"Google analytics child accounts saved successfully","arr":[]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"Google analytics child accounts not saved","arr":[]}</pre>
<pre>{"sts":0,"msg":"You need to connect with Google analytics for this step","arr":[]}';
        } else if ($apiType == "getgatoken") {

            $this->title = "Get Google Analytic Token";
            $apiUrl = $base_url . "getgatoken";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get saved user google access token from database.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{"sts":1,"msg":"Google token found","arr":[{"access_token":"ya29.sfsfds-NQZRcl4ffOc5iawah_Z-fsdfsdfsfdfgdgf_fHuwTU2MEYY7kS1pyNgQLJU","token_type":"Bearer","expires_in":3600,"refresh_token":"ffpZm0jwPB1birpNOOBX5LI_uIQ359nrsdPc_FOsPytE","id_token":"lkljklwrewrwr.gdgd_rv2oRqmgjg10n7vz3_wy_84f04xWt02meP6-VwJ9ts8ijK7DvN3Kq5lr6_AHlNY4LL5Sg8_kjh-hjkhk_INqo13kZlpf5-jlljlk-vcnUgUc_H2_ghfghfh-1agFLRMMPV14twBUtPNL28NlEYlLi6Lfb_zaHHiG8nFepiHv05tMTzGRVbz7vi6Wr0ktMhiZx3j2rdV1wtoH0w","created":1496660867}]}</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts":0,"msg":"No connected with google yet","arr":[]}</pre>';
        } else if ($apiType == "fbcampaign") {

            $this->title = "Facebook Api Campaign Detail - Only accessible from main server";
            $apiUrl = $base_url . "facebookcampaign";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Facebook Campaigns Detail from database.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header), offset , limit (Number of record send in api call).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Facebook Campaign Details", "arr": [data] }</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts": 0, "msg": "offset is missing", "arr": [] }</pre>';
        } else if ($apiType == "fbadset") {

            $this->title = "Facebook Api AdSet Detail - Only accessible from main server";
            $apiUrl = $base_url . "facebookadset";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Facebook  AdSets Detail from database.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header), offset , limit (Number of record send in api call).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Facebook Ad Sets Detail", "arr": [data] }</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts": 0, "msg": "offset is missing", "arr": [] }</pre>';
        } else if ($apiType == "fbad") {
            $this->title = "Facebook Api Ads Detail - Only accessible from main server";
            $apiUrl = $base_url . "facebookad";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Facebook Ads Detail from database.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header), offset , limit (Number of record send in api call).<br/>";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Facebook Ads Detail", "arr": [data] }</pre>';
            $this->html_content .= '<br/><br/>If Fails<br/><pre>{"sts": 0, "msg": "offset is missing", "arr": [] }</pre>';
        } else if ($apiType == "calldetail") {
            $this->title = "Call Tracking Metrics Call Detail - Only accessible from main server";
            $apiUrl = $base_url . "calltrackingdetail";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Calls Detail from Call Tracking Metrics.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header), offset , limit (Number of record send in api call).<br/>";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "CallTrackingMetrics Call Detail", "arr": [data] }</pre>';
            $this->html_content .= '<br/><br/> If Fails<br/><pre>{"sts": 0, "msg": "offset is missing", "arr": [] }</pre>';
        }
//////////////////////////////// change//////////////////////
        else if ($apiType == "arcampaign") {

            $this->title = "AddRoll Api Campaign Detail - Only accessible from main server";
            $apiUrl = $base_url . "addrollcampaigndata";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get AddRoll Campaigns Detail from database.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header), offset , limit (Number of record send in api call).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Adroll Campaign Data", "arr": [data] }</pre>';
        } else if ($apiType == "arreport") {
            $this->title = " AddRoll Api AdSet Detail - Only accessible from main server";
            $apiUrl = $base_url . "addrollcampaignreport";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get AddRoll Campaigns Report Detail from database.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header), offset , limit (Number of record send in api call).<br/>";
            $this->html_content .= "<br/><b>Note: * are required fields.</b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Adroll Campaign Report", "arr": [data] }</pre>';
        } else if ($apiType == "arad") {
            $this->title = "AddRoll Api Ads Detail - Only accessible from main server";
            $apiUrl = $base_url . "addrollads";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get AddRoll Ads Detail from database.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header), offset , limit (Number of record send in api call).<br/>";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Adroll Camapign Ads Data", "arr": [data] }</pre>';
        } else if ($apiType == "twiliocalldetail") {
            $this->title = "Twilio Call Detail - Only accessible from main server";
            $apiUrl = $base_url . "twiliocalldetail";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Calls Detail from Twilio.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header), offset , limit (Number of record send in api call).<br/>";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Twilio Call Detail", "arr": [data] }</pre>';
        } else if ($apiType == "callraildetail") {
            $this->title = "Call Tracking Metrics Call Detail - Only accessible from main server";
            $apiUrl = $base_url . "callraildetail";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Calls Detail from Call Rail.";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header), offset , limit (Number of record send in api call).<br/>";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "CallRail Call Detail", "arr": [data] }</pre>';
        }
        /////////////////////end change///////////////////
        //########### @aman :- 19-june-17 ###################### //
        else if ($apiType == "bing-sub-accounts") {
            $this->title = "Bing Ads Out-Bond Api - Only accessible from main server";
            $apiUrl = $base_url2 . "getSubaccounts";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Bing sub-accounts related to location id";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header),limit (Number of record send in api call), offset (integer).<br/>";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Bing Subaccount list", "arr": [data] }</pre>';
            $this->html_content .= "If Error (Invalid location id)<br/>";
            $this->html_content .= '<pre>{ "sts": 0, "msg": "Invalid location id", "arr": [] }</pre>';
        } else if ($apiType == "bing-campaigns") {
            $this->title = "Bing Ads Out-Bond Api - Only accessible from main server";
            $apiUrl = $base_url2 . "getCampaigns";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Bing Ads Campaings related to location id or Sub-account id";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header),limit (Number of record send in api call), offset (integer), start_date (date), end_date (date).<br/>";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Bing Campaign list", "arr": [data] }</pre>';
            $this->html_content .= "If Error (Parent sub-account error / empty)<br/>";
            $this->html_content .= '<pre>{ "sts": 0, "msg": "No campaigns found", "arr": [] }</pre>';
        } else if ($apiType == "bing-adgroups") {
            $this->title = "Bing Ads Out-Bond Api - Only accessible from main server";
            $apiUrl = $base_url2 . "getAdgroups";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Bing Ads Ad-groups related to location id or campaign id";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header),limit (Number of record send in api call), offset (integer), start_date (date), end_date (date).<br/>";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Bing Adgroups list", "arr": [data] }</pre>';
            $this->html_content .= "If Error (Parent campaign id error / empty)<br/>";
            $this->html_content .= '<pre>{ "sts": 0, "msg": "No Adgroups found", "arr": [] }</pre>';
        } else if ($apiType == "bing-keywords") {
            $this->title = "Bing Ads Out-Bond Api - Only accessible from main server";
            $apiUrl = $base_url2 . "getKeyword";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Bing Ads Keywords related to location id or Ad-groups id";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header),limit (Number of record send in api call), offset (integer), start_date (date), end_date (date).<br/>";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Bing Keyword list", "arr": [data] }</pre>';
            $this->html_content .= "If Error (Parent adgroup id error / empty)<br/>";
            $this->html_content .= '<pre>{ "sts": 0, "msg": "No Keyword found", "arr": [] }</pre>';
        } else if ($apiType == "bing-ads") {
            $this->title = "Bing Ads Out-Bond Api - Only accessible from main server";
            $apiUrl = $base_url2 . "getAds";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Bing Ads Ads related to location id or Ad-groups id";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header),limit (Number of record send in api call), offset (integer), start_date (date), end_date (date).<br/>";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Bing Ads list", "arr": [data] }</pre>';
            $this->html_content .= "If Error (Parent adgroup id error / empty)<br/>";
            $this->html_content .= '<pre>{ "sts": 0, "msg": "No Ads found", "arr": [] }</pre>';
        } else if ($apiType == "adwords-subaccount") {
            $this->title = "Google Adwords Out-Bond Api - Only accessible from main server";
            $apiUrl = $base_url3 . "getSubaccounts";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Adwords sub-account according to location id";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header),limit (Number of record send in api call), offset (integer).<br/>";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Adwords Sub-Account List", "arr": [data] }</pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{ "sts": 0, "msg": "No Sub-Accounts found", "arr": [] }</pre>';

        } else if ($apiType == "adwords-campaigns") {

            $this->title = "Google Adwords Out-Bond Api - Only accessible from main server";
            $apiUrl = $base_url3 . "getCampaigns";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Adwords Campaigns according to location id or parent sub account id ";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header),limit (Number of record send in api call), offset (integer), start_date(date), end_date (date).<br/>";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Adwords Campaign List", "arr": [data] }</pre>';
            $this->html_content .= "If Error (Parent adgroup id error / empty)<br/>";
            $this->html_content .= '<pre>{ "sts": 0, "msg": "No campaign found", "arr": [] }</pre>';

        } else if ($apiType == "adwords-adgroups") {

            $this->title = "Google Adwords Out-Bond Api - Only accessible from main server";
            $apiUrl = $base_url3 . "getAdgroups";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Adwords Adgroups according to location id or parent campaigns id ";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header),limit (Number of record send in api call), offset (integer), start_date(date), end_date (date).<br/>";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Adwords Adgroups List", "arr": [data] }</pre>';
            $this->html_content .= "If Error (Parent adgroup id error / empty)<br/>";
            $this->html_content .= '<pre>{ "sts": 0, "msg": "No Adgroups found", "arr": [] }</pre>';

        } else if ($apiType == "adwords-keywords") {

            $this->title = "Google Adwords Out-Bond Api - Only accessible from main server";
            $apiUrl = $base_url3 . "getKeywords";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Adwords Keywords according to location id or parent adgroups id ";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header),limit (Number of record send in api call), offset (integer), start_date(date), end_date (date).<br/>";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Adwords Keywords List", "arr": [data] }</pre>';
            $this->html_content .= "If Error (Parent adgroup id error / empty)<br/>";
            $this->html_content .= '<pre>{ "sts": 0, "msg": "No Keywords found", "arr": [] }</pre>';

        } else if ($apiType == "adwords-ads") {

            $this->title = "Google Adwords Out-Bond Api - Only accessible from main server";
            $apiUrl = $base_url3 . "getAds";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to get Adwords Ads according to location id or parent adgroups id ";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header),limit (Number of record send in api call), offset (integer), start_date(date), end_date (date).<br/>";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre>{ "sts": 1, "msg": "Adwords Ads List", "arr": [data] }</pre>';
            $this->html_content .= "If Error (Parent adgroup id error / empty)<br/>";
            $this->html_content .= '<pre>{ "sts": 0, "msg": "No Ads found", "arr": [] }</pre>';

        } else if ($apiType == "add-locations") {

            $this->title = "Add new Location Api - Only accessible from main server";
            $apiUrl = $base_url . "addLocation";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to add new API location id into database ";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header)";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"New Location Added into database .","arr":[]}</pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Location Error , Invalid Location id.","arr":[]}</pre></br>';
            $this->html_content .= '<pre>{"sts":"0","msg":"Location Already in database .","arr":[]}</pre>';

        } else if ($apiType == "delete-locations") {

            $this->title = "Delete selected Location id using Api - Only accessible from main server";
            $apiUrl = $base_url . "deleteLocation";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to Delete location from database ";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header)";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"Location deleted sucessfully from database","arr":[]}</pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Unknown Location Id","arr":[]}</pre></br>';
            $this->html_content .= '<pre>{"sts":"0","msg":"Location not deleted, Database Error occured","arr":[]}</pre>';

        } else if ($apiType == "save-adroll-credentials") {

            $this->title = "Api for save AdRoll api credentials - Only accessible from main server";
            $apiUrl = $base_url . "saveAdrollCredentials";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to save AdRoll api credentials into database";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header), api_key, email, password";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"Adroll Credentials sucessfully Updated into datebase","arr":[]} </pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Provide all input fields .","arr":[]}</pre></br>';
            $this->html_content .= '<pre>{"sts":"0","msg":"Unknown location id .","arr":[]}</pre>';

        } else if ($apiType == "save-twilio-credentials") {

            $this->title = "Api for save Twilio api credentials - Only accessible from main server";
            $apiUrl = $base_url . "saveTwilioCredentials";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to save Twilio api credentials into database";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header), api_key, api_secret ";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"Twilio Credentials sucessfully Updated into database","arr":[]} </pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Provide all input fields .","arr":[]}</pre></br>';
            $this->html_content .= '<pre>{"sts":"0","msg":"Unknown location id .","arr":[]}</pre>';

        } else if ($apiType == "save-callrail-credentials") {

            $this->title = "Api for save Call Rail api credentials - Only accessible from main server";
            $apiUrl = $base_url . "saveCallrailCredentials";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to save Call rail api credentials into database";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header), api_key ";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"Callrail Credentials sucessfully Updated into database","arr":[]} </pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Provide all input fields .","arr":[]}</pre></br>';
            $this->html_content .= '<pre>{"sts":"0","msg":"Unknown location id .","arr":[]}</pre>';

        } else if ($apiType == "save-calltrackingmetrics-credentials") {
            $this->title = "Api for save Call Tracking Metrics api credentials - Only accessible from main server";
            $apiUrl = $base_url . "saveCalltrackingmetricsCredentials";
            $this->html_content = "<b>API Url: </b><br/><br/>" . $apiUrl;
            $this->html_content .= "<br/><br/><b>Description:</b><br/>";
            $this->html_content .= "This API is used to save Call Tracking Metrics api credentials into database";
            $this->html_content .= "<br/><br/><b>Method:</b><br/>POST";
            $this->html_content .= "<br/><br/><b>Parameters:</b><br/>";
            $this->html_content .= "location_id*(integer - in header), api_key, api_secret";
            $this->html_content .= "<br/><b> Note: * are required fields. </b><br/>";
            $this->html_content .= "<br/><b>Response:</b><br/>";
            $this->html_content .= "If Success<br/>";
            $this->html_content .= '<pre> {"sts":"1","msg":"CallTrackingMetrics Credentials sucessfully Updated into database","arr":[]} </pre>';
            $this->html_content .= "If Error <br/>";
            $this->html_content .= '<pre>{"sts":"0","msg":"Provide all input fields .","arr":[]}</pre></br>';
            $this->html_content .= '<pre>{"sts":"0","msg":"Unknown location id .","arr":[]}</pre>';

        } 




        $this->set("apiType", $this->title);
        $this->set("content", $this->html_content);
    }

}

