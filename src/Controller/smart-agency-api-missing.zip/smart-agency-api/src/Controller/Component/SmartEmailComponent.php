<?php

namespace App\Controller\Component;

use Cake\Controller\Component;
use PHPMailer;
use SmartEmailTemplates;
use App\Controller\AppController;

class SmartEmailComponent extends Component {

    public $body;
    public $appController;

    public function __construct() {
        $this->appController = new AppController();
    }

    /* Send Mail according to its Type */

    public function SendMail($to, $from, $link, $type) {

        try {

            $token = '';
            require_once($this->appController->getVendorPath("PHPMailer") . 'class.phpmailer.php');
            /* including forgot password template here */
            require_once($this->appController->getVendorPath("EmailTemplates") . 'class.templates.php');

            $email = new PHPMailer();
            $fromName = 'Enfusen Notification';
            $email->From = $from;
            $email->FromName = $fromName;
            $email->IsHTML(true);
            $email->setFrom($from, $fromName);
            $email->addReplyTo($from, $fromName);
            $email->addAddress($to, '');
            //$email->AddAddress('sanjay@rudrainnovatives.com', 'Aman Kumar');
            //$email->AddAddress(ADMIN_EMAIL, 'Roger Bryan');

            $templates = new SmartEmailTemplates();

            if ($type == "forgot_password") {

                $token = $this->getGuid();
                $email->Subject = "Password Reset";
                $this->body = str_replace('~~EMAIL_HOLDER_NAME~~', $to, $templates->forgetPasswordTemplate());
                $this->body = str_replace('~~FORGOT_PASSWORD_LINK~~', $link . "/" . $token, $this->body);
            } else if ($type == "reset_password") {

                $content = '';
                $token = '';
                if (!empty($link) && $link != "") {
                    $content = '<a href="' . $link . '" target="_blank">Click here to login</a>.';
                }

                $email->Subject = "Password Changed";

                $this->body = str_replace('~~EMAIL_HOLDER_NAME~~', $to, $templates->passwordChangedTemplate());
                $this->body = str_replace('~~CONTENT~~', $content, $this->body);
            } else if ($type == "create_agency") {

                $email->Subject = "Agency Setup Notification";

                $this->body = str_replace('~~AGENCY_HOLDER_NAME~~', $link['name'], $templates->createAgencyTemplate());
                $this->body = str_replace('~~AGENCY_URL~~', $link['url'], $this->body);
                $this->body = str_replace('~~AGENCY_USERNAME~~', $link['username'], $this->body);
                $this->body = str_replace('~~AGENCY_PASSWORD~~', $link['password'], $this->body);
            }  else if ($type == "schedule_report") {
                $email->Subject = "Scheduled Email Report";
                pr(WWW_ROOT.'pdf/'.$link['report_name']); die;
                $email->AddAttachment( WWW_ROOT.'pdf/'.$link['report_name'], $link['report_name']);
                $this->body = str_replace('~~FREQUENCY~~', $link['frequency'], $templates->scheduleReportTemplate());
                $this->body = str_replace('~~Date~~', $link['date'], $this->body);
                $this->body = str_replace('~~TYPE_NAME~~', $link['type_name'], $this->body);
                // $this->body = str_replace('~~AGENCY_PASSWORD~~', $link['password'], $this->body);
            }

            $email->MsgHTML($this->body);

            $email->AltBody = "test smart Agency";

            if ($email->Send()) {

                return array("status" => 1, "token" => $token);
            } else {

                return array("status" => 0, "token" => $token);
            }
        } catch (Exception $ex) {
            
        }
    }

    /* generates 40 char random string  */

    public function getGuid() {

        return sha1($this->appController->generateRandomString());
    }

}

?>
