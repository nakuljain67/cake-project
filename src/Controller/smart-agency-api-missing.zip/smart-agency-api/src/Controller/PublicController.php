<?php

namespace App\Controller;

use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;

require_once(ROOT . DS . 'vendor' . DS . "gaconnect" . DS . "vendor" . DS . "autoload.php");

/* for facebook only */
require_once(ROOT . DS . 'vendor' . DS . "facebook_ads" . DS . "vendor" . DS . "autoload.php");
require_once(ROOT . DS . 'vendor' . DS . "facebook" . DS . "vendor" . DS . "autoload.php");

use FacebookAds\Api;
use FacebookAds\Object\User;
use FacebookAds\Object\AdAccount;
use FacebookAds\Object\AdAccountUser;
use FacebookAds\Object\Fields\AdAccountFields;

/* -- BING ADS -- */
require_once(ROOT . DS . 'vendor' . DS . "bingAds" . DS . "vendor" . DS . "autoload.php");
use Microsoft\BingAds\Auth\AuthorizationData;
use Microsoft\BingAds\Auth\OAuthTokenRequestException;
use Microsoft\BingAds\Auth\OAuthWebAuthCodeGrant;
use Microsoft\BingAds\Samples\WebAuthHelper;

class PublicController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->autoRender = false;
	session_start();
    }

    public function index() {
        $this->autoRender = false;
        $this->json(1, array(
            "method" => "index",
            "messge" => "silence is golden"
        ));
    }

  

    private function googleclient() {
        $client = new \Google_Client();
        $client->setAccessType('offline');
        $client->setClientId(GA_CLIENTID);
        $client->setClientSecret(GA_CLIENT_SECRET);
        $client->setRedirectUri(GA_REDIRECT_URI);
        $client->setApprovalPrompt('force');
        return $client;
    }

    public function connectGA() {

        $this->autoRender = false;
        // cookie used to connect google analytic from server
        if (!isset($_GET['code'])) {
            unset($_COOKIE['location_id']);
        }

        if (!isset($_COOKIE['location_id'])) {
            $tokenencoded = isset($_GET['token']) ? trim($_GET['token']) : '';
            $token = base64_decode(base64_decode($tokenencoded));
            $check = $this->is_token_valid($token); // check token is valid or not  
            if($check == true) {

                $res = $this->fetchTokenDetails($token);

            } else {

                $this->json(0, 'Invalid Token');
            }
            
            $location_id = isset($_GET["location_id"]) ? intval($_GET["location_id"]) : intval($res['location_id']); // @updated 23-june-17

            $redirecturi = isset($_GET['redirect_uri']) ? $_GET['redirect_uri'] : '';
            $auth_type = isset($_GET['auth_type']) ? trim(htmlspecialchars($_GET['auth_type'])) : 'gaconnect';
            //$location_id = 1;            
            setcookie("location_id", $location_id, time() + (86400 * 30), "/");
            setcookie("redirect_uri_to_app", $redirecturi, time() + (86400 * 30), "/");
            setcookie("auth_type", $auth_type, time() + (86400 * 30), "/");
        } else {
            $location_id = $_COOKIE['location_id'];
            $redirecturi = $_COOKIE['redirect_uri_to_app'];
            $auth_type = $_COOKIE['auth_type'];
        }

        try {
            $client = $this->googleclient();
            if ($auth_type == "adwordconnect") {
                $client->setScopes(GAW_SCOPES);
            } else if ($auth_type == "consoleconnect") {
                $client->setScopes(GASEACH_SCOPES);
            } else {
                $client->setScopes(GA_SCOPES);
            }

            if (!isset($_GET['code'])) {
                $url = $client->createAuthUrl();
                header('Location: ' . $url);
                exit;
            } else {
                $authToken = $client->authenticate($_GET['code']);
                $authToken = json_encode($authToken);
                $data_string = "token=" . $authToken;
                                                
                if ($auth_type == "adwordconnect") {
                    $rs = $this->pc_post("", "", API_ENGINE_URI, "/savegadwtoken", $data_string, array('location_id' => $location_id));                    
                } else if ($auth_type == "consoleconnect") {
                    $rs = $this->pc_post("", "", API_ENGINE_URI, "/savegconsoletoken", $data_string, array('location_id' => $location_id));
                } else {
                    $rs = $this->pc_post("", "", API_ENGINE_URI, "/savegatoken", $data_string, array('location_id' => $location_id));
                }
                
                if (isset($redirecturi) && $redirecturi != '') {
                    $reduri = $redirecturi;
                    setcookie("redirect_uri_to_app", "", time() + (86400 * 30), "/");
                    setcookie("location_id", "", time() + (86400 * 30), "/");
                    unset($_COOKIE['redirect_uri_to_app']);
                    unset($_COOKIE['location_id']);
                    echo "<script>location.href = '" . $reduri . "'</script>";
                }
            }
        } catch (\Exception $ex) {
            
        }
    }


    public function saveDropDownsValues() {
        try {
            $this->autoRender = false;
            $arvalidation = array();
            $token = $this->request->header('token');
            $check = $this->is_token_valid($token); // check token is valid or not 

            if($check == true) {

                $res = $this->fetchTokenDetails($token);
                $req_data = json_decode(file_get_contents('php://input'));
                $location_id = isset($req_data->location_id) ? intval($req_data->location_id) : intval($res['location_id']); // @updated 23-june-17
                $account = isset($req_data->account) && trim($req_data->account) != '' ? $req_data->account : '';
                $property = isset($req_data->property) && trim($req_data->property) != '' ? $req_data->property : '';
                $profile = isset($req_data->profile) && trim($req_data->profile) != '' ? $req_data->profile : '';

                $account_name = isset($req_data->account_name) && trim($req_data->account_name) != '' ? $req_data->account_name : '';
                $property_name = isset($req_data->property_name) && trim($req_data->property_name) != '' ? $req_data->property_name : '';
                $profile_name = isset($req_data->profile_name) && trim($req_data->profile_name) != '' ? $req_data->profile_name : '';
                            
                if ($account == "") {
                    $arvalidation['account'] = "Please provide account id";
                }
                if ($property == "") {
                    $arvalidation['property'] = "Please provide property id";
                }
                if ($profile == "") {
                    $arvalidation['profile'] = "Please provide profile id";
                }

                if (!empty($arvalidation)) {
                    $this->json(0, "Empty fields found", $arvalidation);
                }

                $data_string = "account=" . $account . "&property=" . $property . "&profile=" . $profile .
                        "&account_name=" . $account_name . "&property_name=" . $property_name . "&profile_name=" . $profile_name;

                $response = $this->pc_post("", "", API_ENGINE_URI, "/savegaaccount", $data_string, array('location_id' => $location_id));
                $response = json_decode($response);

            } else {
                $this->json("0", "Invalid Token");
            }

            $this->json($response->sts, $response->msg, $response->arr);
        } catch (\Exception $ex) {
            
        }
    }

    public function getConnections() {
        $this->autoRender = false;
        $token = $this->request->header('token');
        $check = $this->is_token_valid($token); // check token is valid or not 
        if($check == true) {
            $res = $this->fetchTokenDetails($token);
            $data = json_decode(file_get_contents('php://input'));
            $location_id = isset($data->location_id) ? intval($data->location_id) : intval($res["location_id"]);
            $response = $this->pc_post("", "", API_ENGINE_URI, "/getallconnections", "", array('location_id' => $location_id));
            $response = json_decode($response);
            //print_r($response); die;
            if (isset($response->sts) && $response->sts == 1) {
                $this->json(1, 'Connections found', $response->arr);
            }
            $this->json(0, 'No Connection Found', $response->sts);
        } else {
            $this->json(0, 'Invalid Token');
        }
        
    }

    public function disconnect() {
        try {
            $this->autoRender = false;
            $token = $this->request->header('token');
            $check = $this->is_token_valid($token);
            if($check == true) {
                $res = $this->fetchTokenDetails($token);
                $data = json_decode(file_get_contents('php://input'));
                $location_id = isset($data->location_id) ? intval($data->location_id) : intval($res["location_id"]);
                $type = isset($data->type) ? $data->type : "";
                $datastring = "type=" . $type;
                $response = $this->pc_post("", "", API_ENGINE_URI, "/disconnectconn", $datastring, array('location_id' => $location_id));
                $response = json_decode($response);
                $this->json($response->sts, $response->msg);
            } else {
                $this->json(0, 'Invalid Token');
            }
            
        } catch (\Exception $ex) {
            
        }
    }

    public function getGaDropDowns() {
        try {
            $this->autoRender = false;
            $token = $this->request->header('token');
            $check = $this->is_token_valid($token);
            if($check == true) {
                $res = $this->fetchTokenDetails($token);
                $data = json_decode(file_get_contents('php://input'));
                $location_id = isset($data->location_id) ? intval($data->location_id) : intval($res["location_id"]);
                $req_type = isset($data->req_type) ? trim($data->req_type) : 'normal';

                $account_num = isset($data->account) ? trim($data->account) : '';

                $web_prop = isset($data->property) ? trim($data->property) : '';
                $prof_id = isset($data->profile) ? trim($data->profile) : '';

                $response = $this->pc_post("", "", API_ENGINE_URI, "/getgatoken", "", array('location_id' => $location_id));
                $response = json_decode($response);

                if (isset($response->sts) && $response->sts == 1) {
                    if (isset($response->arr->google_token) && $response->arr->google_token != '') {
                        $tokendetail = json_decode($response->arr->google_token);
                        $client = $this->googleclient();
                        $client->setScopes(GA_SCOPES);
                        $client->fetchAccessTokenWithRefreshToken($tokendetail->refresh_token);
                        $analytics = new \Google_Service_Analytics($client);                                
                        $analytics_child = $response->arr->analytics_child;
                                                                        
                        $accounts = $webproperties = array();
                        if ($req_type == 'normal') {
                            $accounts = $records = $this->getAccounts_Ids($analytics);
                            if ($account_num == '') {
                                if (!empty($records)) {
                                    $account_num = $records[0][0];
                                }
                            }
                        }

                        if ($req_type == 'normal' || $req_type == 'webproperties') {
                            $webproperties = $records = $this->getWebProperties_Ids($analytics, $account_num);
                            if ($web_prop == '') {
                                if (!empty($records)) {
                                    $web_prop = $records[0][0];
                                }
                            }
                        }

                        $profiles = $records = $this->getProfiles_Ids($analytics, $account_num, $web_prop);
                        if ($prof_id == '') {
                            $prof_id = $records[0][0];
                        }

                        $arr = array(
                            'accounts' => $accounts,
                            'account_num' => $account_num,
                            'webproperties' => $webproperties,
                            'web_prop' => $web_prop,
                            'profiles' => $profiles,
                            'prof_id' => $prof_id
                        );

                        $this->json(1, 'Google Analytics Dropdowns', $arr);
                    }
                    $this->json(0, 'Google token not found');
                } else {
                    $this->json(0, 'Google Analytic is not connected');
                }
            } else {
                $this->json(0, 'Invalid Token');
            }
            
        } catch (\Exception $ex) {
            
        }
    }

    private function getAccounts_Ids($analytics) {

        $AccountIds = array();
        try{            
              $accountsItems = $analytics->management_accounts->listManagementAccounts()->getItems();              
        }
        catch (\Exception $ex){
            $dataerros = json_decode($ex->getMessage());
            $this->json(0, $dataerros->error->message, $dataerros);
        }
        
        if (count($accountsItems) > 0)
            foreach ($accountsItems as $curAccountItem)
                $AccountIds[] = array($curAccountItem->getId(), $curAccountItem->name);

        return $AccountIds;
    }

    private function getWebProperties_Ids($analytics, $AccountNum) {

        $WebPropertiesIds = array();

        if (!empty($AccountNum)) {
            
            try{
                $webpropertiesItems = $analytics->management_webproperties->listManagementWebproperties($AccountNum)->getItems();
            }
            catch (\Exception $ex){
                $dataerros = json_decode($ex->getMessage());
                $this->json(0, $dataerros->error->message, $dataerros);
            }            

            if (count($webpropertiesItems) > 0)
                foreach ($webpropertiesItems as $curWebpropertiesItem)
                    $WebPropertiesIds[] = array($curWebpropertiesItem->getId(), $curWebpropertiesItem->name);
        }

        return $WebPropertiesIds;
    }

    private function getProfiles_Ids($analytics, $AccountNum, $WebPropNum) {

        $PprofilesIds = array();

        if (!empty($AccountNum) && !empty($WebPropNum)) {
            
            try{
                $profilesItems = $analytics->management_profiles->listManagementProfiles($AccountNum, $WebPropNum)->getItems();
            }
            catch (\Exception $ex){
                $dataerros = json_decode($ex->getMessage());
                $this->json(0, $dataerros->error->message, $dataerros);
            }             

            if (count($profilesItems) > 0)
                foreach ($profilesItems as $curProfilesItem)
                    $PprofilesIds[] = array($curProfilesItem->getId(), $curProfilesItem->name);
        }

        return $PprofilesIds;
    }

    public function PullSearchConsoleMetrics($data = array()) {

        $this->autoRender = false;

        $results = array();

        try {

            if (!empty($data["location_url"]) && !empty($data["refressToken"])) {

                $client = $this->googleclient();
                $client->fetchAccessTokenWithRefreshToken($data["refressToken"]);
                //$client->fetchAccessTokenWithRefreshToken("1/zJjWcAubp21S_xtRgh_4VNSx7G1S1X16Gv3SW1eXfQk");

                $service = new \Google_Service_Webmasters($client);

                $q = new \Google_Service_Webmasters_SearchAnalyticsQueryRequest();

                $startDate = $data["start_date"];
                $endDate = $data["end_date"];
                $url = $data["location_url"];

                $q->setStartDate($startDate);
                $q->setEndDate($endDate);
                $q->setDimensions(['page', 'query']);
                $q->setSearchType('web');
                $q->setRowLimit('2'); // Maximum 1000 keywords can fetch from webmaster
                $q->setStartRow('0');
                try{
                    $u = $service->searchanalytics->query($url, $q);
                } catch (\Exception $e) {
                    $u = "";
                }

                if(!empty($u)) {
                    $searchConsoleArray = array();

                    for ($i = 0; $i < count($u->rows); $i++) {

                        $res = array();
                        $res['url'] = $u->rows[$i]->keys[0];
                        $res['start_date'] = $startDate;
                        $res['end_date'] = $endDate;
                        $res['keyword'] = $u->rows[$i]->keys[1];
                        $res['clicks'] = $u->rows[$i]->clicks;
                        $res['impressions'] = $u->rows[$i]->impressions;
                        $res['ctr'] = $u->rows[$i]->ctr;
                        $res['position'] = $u->rows[$i]->position;
                        $res['created'] = date("Y-m-d H");
                        $results[] = $res;
                    }
                }
                
            }
        } catch (\Exception $ex) {
            
        }

        return $results;
    }
    /*
    public function getSearchConsoleUrls() {

        // this method is not in use so far.
        $this->autoRender = false;
        $location_id = 3;
        $SearchData = $this->getAllSearchURLs($location_id);
        if (count($SearchData)) {

            foreach ($SearchData as $index => $value) {

                $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $value['url'])), "/");

                $jsonData = json_encode($value);

                $results = $this->connection
                        ->execute("UPDATE tbl_cre_urls SET `ctr` = '" . $value['ctr'] . "', `search_console_data` = '" . $jsonData . "' WHERE `location_id` = " . $location_id . " AND TRIM(BOTH  '/' FROM REPLACE(REPLACE(REPLACE (url, 'http://', ''),'https://',''),'www.','')) like '$trimurl'")
                        ->fetchAll('assoc');
            }
        }
    }
    */
    public function getAllSearchURLs($location_id) {

        // this method is not in use so far.
        $console_data = $this->connection
                ->execute('SELECT * FROM api_search_console WHERE location_id = ' . $location_id)
                ->fetchAll('assoc');

        return $console_data;
    }

    /* ----------------- Connection API date :- 21-june-17 -------------------------- */

    /**
     * Date :- 21-june-17 
     * Function disc :- function for hit request using cURL to call API (API ENGINE HOUSE)
     * Parameters :- url , function, location, postData 
     * @RudrainnovativePvtLtd
     */
    private function hitRequest($url, $function, $location_id, $postData) {
        try {
            if (!empty($url) && !empty($function) && !empty($postData)) {

                $complete_url = $url . $function;
                $curl = curl_init();
                $headers =  array("Content-Length: " . strlen($postData), "location_id: " . $location_id);
                curl_setopt($curl, CURLOPT_URL, $complete_url);
                curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($curl, CURLOPT_POST, true);
                curl_setopt($curl, CURLOPT_POSTFIELDS, $postData);
                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);

                $result = curl_exec($curl);                
                return $result;
            } else {
                $this->json("0", "Provide all input fields");
            }
        } catch (\Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 21-june-17 
     * Function disc :- Function for disconnect  
     * Parameter :- location_id
     * @RudrainnovativePvtLtd
     */
    private function disconnectConnection($location_id, $field) {
        try {

            $url = API_ENGINE_URI;
            $function = "/deleteCredentials";

            $postArray = "field=".$field;
            $result = $this->hitRequest($url, $function, $location_id, $postArray); // calling function for second api call to api engine house            
        } catch (\Exception $ex) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 21-june-17 
     * Function disc :- Function for connect with AdRoll (save data in database)
     * Parameter :- token (header), api_key, email, password, location_id 
     * @RudrainnovativePvtLtd
     */
    public function connectAdroll() {
        try {
            $token = $this->request->header('token');
            $check = $this->is_token_valid($token); // checking token is valid or not 
            if($check == true) {
                $res = $this->fetchTokenDetails($token);
                $req_data = json_decode(file_get_contents('php://input')); // getting input from body 
                $location_id = $location_id = isset($req_data->location_id) ? intval($req_data->location_id) : intval($res['location_id']);
                $api_key = isset($req_data->api_key) ? $req_data->api_key : "";
                $email = isset($req_data->email) ? $req_data->email : "";
                $pass = isset($req_data->password) ? $req_data->password : "";
                $url = API_ENGINE_URI; // constant define in bootstrap.php 
                $function = "/saveAdrollCredentials"; // function which we call via api

                /* Array for storing all the post data for send to save into database */
                $postArray = "api_key=".$api_key."&email=".$email."&password=".$pass;

                $result = $this->hitRequest($url, $function, $location_id, $postArray); // calling function for second api call to api engine house
                print($result);
            } else {
                $this->json(0, 'Invalid Token');
            }
            
        } catch (\Exception $e) {
            echo "Exception :" . $e->getMessage();
        }
    }

    /**
     * Date :- 21-june-17 
     * Function disc :- Function for disconnect AdRoll connection 
     * Parameter :- token (header), location_id
     * @RudrainnovativePvtLtd
     */
    public function disconnectAdroll() {
        $token = $this->request->header('token');
        $check = $this->is_token_valid($token); // checking token is valid or not 
        if($check == true) {
            $res = $this->fetchTokenDetails($token);
            $req_data = json_decode(file_get_contents('php://input')); // getting input from body 
            $location_id = isset($req_data->location_id) ? intval($req_data->location_id) : intval($res['location_id']); // getting location id from token
            $field = "adroll_info";
            $this->disconnectConnection($location_id, $field); // calling function to disconnect Adroll
        } else {
            $this->json(0, 'Invalid Token');
        }
        
    }

    /**
     * Date :- 21-june-17 
     * Function disc :- Function for Connect with twilio API 
     * Parameter :- token (header), api_key, api_secret, location_id
     * @RudrainnovativePvtLtd
     */
    public function connectTwilio() {
        $token = $this->request->header('token');
        $check = $this->is_token_valid($token); // checking token is valid or not 
        if($check == true) {
            $res = $this->fetchTokenDetails($token);
            $req_data = json_decode(file_get_contents('php://input')); // getting input from body 
            $location_id = isset($req_data->location_id) ? intval($req_data->location_id) : intval($res['location_id']); // getting location id from token 
            $apikey = isset($req_data->api_key) ? $req_data->api_key : "";
            $apisecret = isset($req_data->api_secret) ? $req_data->api_secret : "";

            $url = API_ENGINE_URI;
            $function = "/saveTwilioCredentials";

            $postArray = "api_key=".$apikey."&api_secret=".$apisecret;
            $result = $this->hitRequest($url, $function, $location_id, $postArray); // calling function for second api call to api engine house
            print($result);
        } else {
            $this->json(0, 'Invalid Token');
        }
        
    }

    /**
     * Date :- 21-june-17 
     * Function disc :- Function for disconnect with Twilio connection 
     * Parameter :-  token (header), location_id
     * @RudrainnovativePvtLtd
     */
    public function disconnectTwilio() {
        $token = $this->request->header('token');
        $check = $this->is_token_valid($token); // checking token is valid or not 
        if($check == true) {
            $res = $this->fetchTokenDetails($token);
            $req_data = json_decode(file_get_contents('php://input')); // getting input from body 
            $location_id = isset($req_data->location_id) ? intval($req_data->location_id) : intval($res['location_id']); // getting location id from token
            $field = "twilio_info";

            $this->disconnectConnection($location_id, $field); // calling function to disconnect twilio 
        } else {
            $this->json(0, 'Invalid Token');
        }
        
    }

    /**
     * Date :- 21-june-17 
     * Function disc :- Function for Connect with twilio API 
     * Parameter :- token (header), api_key, location_id
     * @RudrainnovativePvtLtd
     */
    public function connectCallrail() {
        $token = $this->request->header('token');
        $check = $this->is_token_valid($token); // checking token is valid or not 
        if($check == true) {
            $res = $this->fetchTokenDetails($token);
            $req_data = json_decode(file_get_contents('php://input')); // getting input from body 
            $location_id = isset($req_data->location_id) ? intval($req_data->location_id) : intval($res['location_id']); // getting location id from token 
            $apikey = isset($req_data->api_key) ? $req_data->api_key : "";

            $url = API_ENGINE_URI;
            $function = "/saveCallrailCredentials";

            $postArray = "api_key=".$apikey;
            $result = $this->hitRequest($url, $function, $location_id, $postArray); // calling function for second api call to api engine house
            print($result);
        } else {
            $this->json(0, 'Invalid Token');
        }
    }

    /**
     * Date :- 21-june-17 
     * Function disc :- Function for disconnect with CallRail connection 
     * Parameter :-  token (header), location_id
     * @RudrainnovativePvtLtd
     */
    public function disconnectCallrail() {
        $token = $this->request->header('token');
        $check = $this->is_token_valid($token); // checking token is valid or not 
        if($check == true) {
            $res = $this->fetchTokenDetails($token);
            $req_data = json_decode(file_get_contents('php://input')); // getting input from body 
            $location_id = isset($req_data->location_id) ? intval($req_data->location_id) : intval($res['location_id']); // getting location id from token
            $field = "callrail_info";

            $this->disconnectConnection($location_id, $field); // calling function to disconnect callrail 
        } else {
            $this->json(0, 'Invalid Token');
        }
        
    }

    /**
     * Date :- 21-june-17 
     * Function disc :- Function for Connect CallTrackingMetrics 
     * Parameter :- token (header), api_key_, api_secret, location_id
     * @RudrainnovativePvtLtd
     */
    public function connectCalltrackingmetrics() {
        $token = $this->request->header('token');
        $check = $this->is_token_valid($token); // checking token is valid or not 
        if($check == true) {
            $res = $this->fetchTokenDetails($token);
            $req_data = json_decode(file_get_contents('php://input')); // getting input from body 
            $location_id = isset($req_data->location_id) ? intval($req_data->location_id) : intval($res['location_id']); // getting location id from token
            $apikey = isset($req_data->api_key) ? $req_data->api_key : "";
            $apisecret = isset($req_data->api_secret) ? $req_data->api_secret : "";

            $url = API_ENGINE_URI;
            $function = "/saveCalltrackingmetricsCredentials";
            $postArray = "api_key=".$apikey."&api_secret=".$apisecret;
            $result = $this->hitRequest($url, $function, $location_id, $postArray); // calling function for second api call to api engine house
            print($result);
        } else {
             $this->json(0, 'Invalid Token');
        }
        
    }

    /**
     * Date :- 21-june-17 
     * Function disc :- Function for disconnect with CallTrackingMetrics
     * Parameter :- token (header), location_id
     * @RudrainnovativePvtLtd
     */
    public function disconnectCalltrackingmetrics() {
        $token = $this->request->header('token');
        $check = $this->is_token_valid($token); // checking token is valid or not 
        if($check == true) {
            $res = $this->fetchTokenDetails($token);
            $req_data = json_decode(file_get_contents('php://input')); // getting input from body 
            $location_id = isset($req_data->location_id) ? intval($req_data->location_id) : intval($res['location_id']); // getting location id from token
            $field = "calltracking_info";

            $this->disconnectConnection($location_id, $field); // calling function to disconnect call tracking metrics 
        } else {
            $this->json(0, 'Invalid Token');
        }
        
    }

   /**
     * Date :- 22-june-17 
     * Function disc :- Function for check `google_search_token` credentials a/c to location id & return credentials 
     * Parameters :- location_id *
     * @RudrainnovativePvtLtd
     */
    public function getSearchToken($location_id) {

        if (!empty($location_id)) {
            $url = API_ENGINE_URI;
            $function = "/getToken";
            $field = "google_search_token"; // pass table field you want to get 

            $postArray = "field=".$field;
            $result = $this->hitRequest($url, $function, $location_id, $postArray);
            $data = json_decode($result);            
            if (!empty($data->arr) && $data->arr != null) {
                return $data->arr;
            }
        }
    }


   /* ------------ Connection code :- 24-june-17 ------------------ */
    /**
     * Date :- 23-june-17 
     * Updated :- 24-june-17
     * Function disc :- function for connect with facebook save data into database  
     * Parameter :- location_id(header), redirect_uri (POST)
     * @RudrainnovativePvtLtd
     */
    
    public function fbConnect() {
       
       /* Token verification */
       $tokenencoded = isset($_GET['token']) ? trim($_GET['token']) : '';; // 2 times base64_encode token
        
        if(!empty(trim($tokenencoded))) {

            $token = base64_decode(base64_decode($tokenencoded));
            $check = $this->is_token_valid($token); // check token is valid or not  
            if($check == true) {

                $res = $this->fetchTokenDetails($token);

            } else {

                $this->json(0, 'Invalid Token');
            }
        } else {
            $this->json(0, 'Token Not Found.');
        }
        
	 /* get data from get method */
        $location_id = isset($_GET["location_id"]) ?  intval($_GET["location_id"]) : intval($res['location_id']);
        $redirect_uri = isset($_GET["redirect_uri"]) ? $_GET["redirect_uri"] : ""; // getting redirect uri from post  
        
        if(!empty($location_id) && !empty($redirect_uri)) {
            $clientId = FB_CLIENT_ID;
            $secret = FB_CLIENT_SECRET;
            
            $redirect = FB_API_URI; //  set redirect uri 
            
            $provider = new \League\OAuth2\Client\Provider\Facebook([
                'clientId' => $clientId,
                'clientSecret' => $secret,
                'redirectUri' => $redirect,
                'graphApiVersion' => 'v2.9',
            ]);
            $authUrl = $provider->getAuthorizationUrl([
                'scope' => ['email', 'user_friends'],
            ]);
            $_SESSION['oauth2state'] = $provider->getState();

            /* Seting location id and redirect uri into cookie */
            $_SESSION['fb_location_id'] = $location_id;
            $_SESSION['fb_redirect_uri'] = $redirect_uri;            
            header("Location:".$authUrl);
            exit;
        } else {
            $this->json(0, 'location_id and redirect_uri are required parameters');
        }
                   
    }
    
    /**
     * Date :- 23-june-17 
     * Updated :- 24-june-17
     * Function disc :- function for connect with facebook save data into database  
     * Parameter :- location_id(header), redirect_uri (POST)
     * @RudrainnovativePvtLtd
     */
    
    public function saveFbCredentials() {
        
        if (!empty($_GET['code']) && !empty($_GET['state'])) {
            
            $clientId = FB_CLIENT_ID;
            $secret = FB_CLIENT_SECRET;
            $redirect = FB_API_URI;
            $provider = new \League\OAuth2\Client\Provider\Facebook([
                'clientId' => $clientId,
                'clientSecret' => $secret,
                'redirectUri' => $redirect,
                'graphApiVersion' => 'v2.9',
                'scopes' => 'ads_read,ads_management'
            ]);
            $token = $provider->getAccessToken('authorization_code', [
                'code' => $_GET['code']
            ]);
            $today = date('d-m-Y');
            $expires_in = date('d-m-Y', strtotime($today . ' + 30 days'));
            $new = [];
            $new['token'] = $token;
            $new['expires_in'] = $expires_in;

            $location_id =  $_SESSION['fb_location_id'];
            $redirect_uri =  $_SESSION['fb_redirect_uri'];
            
            $report = $this->saveFb($location_id, json_encode($new)); // calling function for save data into database 
            
            if($report == true) {
               echo "<script>location.href='".$redirect_uri."'</script>";
            } else {
                echo "<script>location.href='".$redirect_uri."'</script>";
            }
            
            
        } elseif (empty($_GET['state']) || ($_GET['state'] !== $_SESSION['oauth2state'])) {
            unset($_SESSION['oauth2state']);
            echo 'Invalid state.';
            exit;
        }

    }

    /* Function for send fb token into database date:-24-june-17 */

    public function saveFb($location_id, $credentials) {
         if (!empty($location_id)) {
            $url = API_ENGINE_URI;
            $function = "/saveFacebookCredentials";            
            $postArray = "credential=".$credentials;
            $result = $this->hitRequest($url, $function, $location_id, $postArray);            
            $data = json_decode($result);
            
            if($data->sts == 1) {
                return true;
            } else {
                return false;
            }
        }
    }
	
   /* -------------- BING CONNECTION date:- 24-june-17------------------------ */
    
    /* Function for connect with Bing ads api */
    public function connectBing()
    {
        
        /* Token verification */
        $tokenencoded = isset($_GET['token']) ? trim($_GET['token']) : '';// getting token from get method 
        
        if(!empty($tokenencoded)) {

            $token = base64_decode(base64_decode($tokenencoded));
            $check = $this->is_token_valid($token); // check token is valid or not  
            if($check == true) {

                $res = $this->fetchTokenDetails($token);

            } else {

                $this->json(0, 'Invalid Token');
            }
        } else {
            $this->json(0, 'Token Not Found.');
        }

	$location_id = isset($_GET['location_id']) ? intval($_GET['location_id']) : intval($res['location_id']); // location id 
        $redirect_uri = isset($_GET["redirect_uri"]) ? $_GET["redirect_uri"] : ""; // getting redirect uri from post 


        if(!empty($location_id) && !empty($redirect_uri)) {

            setcookie('redirect_uri_bing', $redirect_uri, time() + (86400 * 30), "/");
            setcookie('location_id', $location_id, time() + (86400 * 30), "/");
                 
            echo "<script> location.href='".$this->redirectUri()."'</script>";

        } else {
            $this->json(0, 'Missing parameters');
        }
    }
    
    /* Function for geting oauthcallback after account authentication */

    public function oauth2Callback() {
        try {
            
            if (!isset($_SESSION['AuthorizationData']) || !isset($_SESSION['AuthorizationData']->Authentication)) {
                $authentication = (new OAuthWebAuthCodeGrant())
                        ->withClientId(BING_CLIENT_ID)
                        ->withClientSecret(BING_CLIENT_SECRET)
                        ->withRedirectUri('https://' . $_SERVER['HTTP_HOST'] . $this->redirectUri())
                        ->withState('45415'); //rand(0, 999999999)


                $_SESSION['AuthorizationData'] = (new AuthorizationData())
                        ->withAuthentication($authentication)
                        ->withDeveloperToken(BING_DEVELOPER_TOKEN);

                $_SESSION['state'] = $_SESSION['AuthorizationData']->Authentication->State;


                header('Location: ' . $_SESSION['AuthorizationData']->Authentication->GetAuthorizationEndpoint());
            }

            if ($_GET['code'] != null) {

                $_SESSION['AuthorizationData']->Authentication->RequestOAuthTokensByResponseUri($_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);

                $this->callBingAdsServices(); //callint callBingAdsServices 
            }
        } catch (\Exception $e) {
            echo 'Message: ' . $e->getMessage();
        }
    }
    
    /* Function for set redirect uri for bing ads */

    public function redirectUri() {
        $link = 'https://login.live.com/oauth20_authorize.srf?client_id=' .BING_CLIENT_ID. '&scope=bingads.manage&response_type=code&redirect_uri=' .BING_API_REDIRECT. '&grant_type=authorization_code&state=45415';

        return $link;
    }
    
    public function callBingAdsServices() {
        if (!isset($_SESSION['AuthorizationData']) ||
                !isset($_SESSION['AuthorizationData']->Authentication) ||
                !isset($_SESSION['AuthorizationData']->Authentication->OAuthTokens)
        ) {
            $this->json(0, 'Authorization failled');
        } else {

            /* save authentications into database */
            if (isset($_SESSION['AuthorizationData']) && !empty($_SESSION['AuthorizationData'])) {
                $bingTokens = []; // array for store bing tokens

                /* Getting Tokens after oauth verification */
                $bingTokens['accesstoken'] = $_SESSION['AuthorizationData']->Authentication->OAuthTokens->AccessToken;
                $bingTokens['refreshtoken'] = $_SESSION['AuthorizationData']->Authentication->OAuthTokens->RefreshToken;
                $bingTokens['expiry'] = $_SESSION['AuthorizationData']->Authentication->OAuthTokens->AccessTokenExpiresInSeconds;
                $bingTokens['state'] = $_SESSION['AuthorizationData']->Authentication->State;

                $tokens = json_encode($bingTokens);

                $redirect_uri = $_COOKIE['redirect_uri_bing'];
                $location_id = $_COOKIE['location_id'];

                if(!empty($redirect_uri) && !empty($location_id)) {
                    $out = $this->saveBingCredentials($location_id, $tokens);
                    if($out == true) {
                        echo "<script> location.href='".$redirect_uri."'</script>";
                    }
                } else {
                    $this->json(0, 'Redirect uri or location id not fount');
                }
            }
        }
    }

    /* function for save bing credentials (API engine hosuse database) */


    private function saveBingCredentials($location_id, $credentials) 
    {
        if(!empty($location_id) && !empty($credentials)) {
            $url = API_ENGINE_URI;
            $function = "/saveBingCredentials";
            $postArray = "credential=".$credentials;
            $result = $this->hitRequest($url, $function, $location_id, $postArray);
            $data = json_decode($result);

            if($data->sts == 1) {
                return true;
            } else {
                return false;
            }
        }
    }

    /* Function for disconnect bingAds 25-june-17 */

    public function disconnectBing() {
        $token = $this->request->header('token');
        $check = $this->is_token_valid($token); // checking token is valid or not 
        if($check == true) {
            $res = $this->fetchTokenDetails($token);
            $req_data = json_decode(file_get_contents('php://input')); // getting input from body 
            $location_id = isset($req_data->location_id) ? intval($req_data->location_id) : intval($res['location_id']); // getting location id from token
            $field = "bing_token";

            $this->disconnectConnection($location_id, $field); // calling function to disconnect call tracking metrics 
        } else {
            $this->json(0, 'Invalid Token');
        }
    }

    /* Function for disconnect facebook ads 25-june-17 */

    public function disconnectFb() {
        $token = $this->request->header('token');
        $check = $this->is_token_valid($token); // checking token is valid or not 
        if($check == true) {
            $res = $this->fetchTokenDetails($token);
            $req_data = json_decode(file_get_contents('php://input')); // getting input from body 
            $location_id = isset($req_data->location_id) ? intval($req_data->location_id) : intval($res['location_id']); // getting location id from token
            $field = "fb_token";

            $this->disconnectConnection($location_id, $field); // calling function to disconnect call tracking metrics 
        } else {
            $this->json(0, 'Invalid Token');
        }
    }


}

