<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;

class AdminCitationController extends AppController {

    public function initialize() {
        $this->autoRender = false;
    }

    /**
     * Date :- 25-june-17
     * Function Disc :- Function for add new entry in citation manager table 
     * Parameter :- token (header), domain_name, da, login_url, instruction, status, score, is_top_hundred
     */
    public function addCitation() {

        $token = $this->request->header('token');
        if (!empty(trim($token))) {

            $check = $this->is_token_valid($token); // check token is valid or not  

            /* Condition if token is correct */
            if ($check == true) {
                $req_data = json_decode(file_get_contents('php://input')); // getting input from body
                $domainName = isset($req_data->domain_name) ? $req_data->domain_name : "";
                $da = isset($req_data->da) ? $req_data->da : "";
                $loginUrl = isset($req_data->login_url) ? $req_data->login_url : "";
                $instruction = isset($req_data->instruction) ? $req_data->instruction : "";
                $status = isset($req_data->status) ? $req_data->status : "";
                $score = isset($req_data->score) ? $req_data->score : "";
                $is_top = isset($req_data->is_top_hundred) ? $req_data->is_top_hundred : "";

                /* Insert data into database */
                $table = $this->loadModel('citationManager'); // loading Model 
                $insert = $table->newEntity();
                $insert->domain_name = $domainName;
                $insert->da = $da;
                $insert->login_url = $loginUrl;
                $insert->instruction = $instruction;
                $insert->status = $status;
                $insert->score = $score;
                $insert->is_top_hundred = $is_top;
                $insert->created = date('Y-m-d h:i:s');

                if ($table->save($insert)) {
                    $this->json(1, "New Citations Data Added into database");
                } else {
                    $this->json(0, "Citations insertion failled");
                }
            } else {
                $this->json(0, 'Invalid Token');
            }
        } else {
            $this->json(0, 'Token Not Found.');
        }
    }

    /**
     * Date :- 25-june-17
     * Function Disc :- Function for edit citations accoring to id 
     * Parameter :- token (header), id (int)
     */
    public function editCitation() {
        $return = []; // blank array for store data comes from database 
        $token = $this->request->header('token');
        if (!empty(trim($token))) {

            $check = $this->is_token_valid($token); // check token is valid or not  

            /* Condition if token is correct */
            if ($check == true) {
                $req_data = json_decode(file_get_contents('php://input')); // getting input from body
                $citationsId = isset($req_data->id) ? $req_data->id : "";
                if (!empty($citationsId)) {
                    $table = $this->loadModel("citationManager"); // loading model
                    $citationData = $table->find('all')->where(["id" => $citationsId])->toArray();
                    if (!empty($citationData)) {
                        $return["id"] = $citationData[0]->id;
                        $return["domain_name"] = $citationData[0]->domain_name;
                        $return["login_url"] = $citationData[0]->login_url;
                        $return["instruction"] = $citationData[0]->instruction;
                        $return["status"] = $citationData[0]->status;
                        $return["score"] = $citationData[0]->score;
                        $return["is_top_hundred"] = $citationData[0]->is_top_hundred;

                        $this->json(1, 'Citation Data', $return);
                    } else {
                        $this->json(0, 'No Citation Data Found');
                    }
                } else {
                    $this->json(0, 'Citations Id not found');
                }
            } else {
                $this->json(0, 'Invalid Token');
            }
        } else {

            $this->json(0, 'Token Not Found.');
        }
    }

    /**
     * Date :- 25-june-17
     * Function Disc :- Function for update citations (tbl_citations_manager table)
     * Parameters :- token(header), id, domain_name, da, login_url, instruction, status, score, is_top_hundred
     */
    public function updateCitations() {

        $token = $this->request->header('token');
        if (!empty(trim($token))) {

            $check = $this->is_token_valid($token); // check token is valid or not  

            /* Condition if token is correct */
            if ($check == true) {

                $res = $this->fetchTokenDetails($token);
                $req_data = json_decode(file_get_contents('php://input')); // getting input from body
                $citationsId = isset($req_data->id) ? intval($req_data->id) : "";
                $domainName = isset($req_data->domain_name) ? $req_data->domain_name : "";
                $da = isset($req_data->da) ? $req_data->da : "";
                $loginUrl = isset($req_data->login_url) ? $req_data->login_url : "";
                $instruction = isset($req_data->instruction) ? $req_data->instruction : "";
                $status = isset($req_data->status) ? $req_data->status : "";
                $score = isset($req_data->score) ? $req_data->score : "";
                $is_top = isset($req_data->is_top_hundred) ? $req_data->is_top_hundred : "";

                $table = $this->loadModel('citationManager');
                $update = array(
                    "domain_name" => $domainName,
                    "da" => $da,
                    "login_url" => $loginUrl,
                    "instruction" => $instruction,
                    "status" => $status,
                    "score" => $score,
                    "is_top_hundred" => $is_top
                );

                $query = $table->query();

                if ($query->update()->set($update)->where(["id" => $citationsId])->execute()) {
                    $this->json(1, "Citation Updated successfully");
                } else {
                    $this->json(0, 'Updation Failled, Error occured');
                }
            } else {

                $this->json(0, 'Invalid Token');
            }
        } else {
            $this->json(0, 'Token Not Found.');
        }
    }

    /**
     * Date :- 25-june-17
     * Function Disc :- Function for fetch all citations (tbl_citations_manager table)
     * Parameter :- Offset (Page number), Limit, Token (header)
     */
    public function getallCitations() {
        $limit = 10; // fixed until value not sent by admin 
        $offset = 1; // fixed until value not sent by admin 
        $return = []; // blank array for store citation report 
        $token = $this->request->header('token');
        if (!empty(trim($token))) {

            $check = $this->is_token_valid($token); // check token is valid or not  

            /* Condition if token is correct */
            if ($check == true) {
                $data = []; // blank array to store database data 
                $req_data = json_decode(file_get_contents('php://input')); // getting input from body
                $limit = isset($req_data->limit) ? intval($req_data->limit) : $limit;
                $offset = isset($req_data->offset) && $req_data->offset != 0 ? intval($req_data->offset) : $offset;
                $status = isset($req_data->status) ? $req_data->status : ""; 

                $table = $this->loadModel('citationManager');
                $query = $table->find();
                if(empty($status)){
                	$count = $query->select(['count' => $query->func()->count('*')])->toArray(); // count all citations data
                }else {
                	$count = $query->select(['count' => $query->func()->count('*')])->where(["status" => $status])->toArray(); // count all citations data
                }

                $total = $count[0]->count;

                if ($total > 0) {

                	if(!empty($status)){
                		$data = $table->find('all')->select(['domain_name', 'da', 'login_url', 'instruction', 'status', 'score', 'is_top_hundred'])->limit($limit)->toArray();
                	} else {
                		$data = $table->find('all')->select(['domain_name', 'da', 'login_url', 'instruction', 'status', 'score', 'is_top_hundred'])->where(["status" => $status])->limit($limit)->toArray();
                	}
                    

                    $totalPage = $total / $limit; // total page value 

                    if ($total <= $limit) {

                        $loopCount = count($data); // count data for loop 

                        for ($i = 0; $i < $loopCount; $i++) {
                            $return["citation"][$i]['id'] = $data[$i]->id;
                            $return["citation"][$i]['domain_name'] = $data[$i]->domain_name;
                            $return["citation"][$i]['da'] = $data[$i]->da;
                            $return["citation"][$i]['login_url'] = $data[$i]->login_url;
                            $return["citation"][$i]['instruction'] = $data[$i]->instruction;
                            $return["citation"][$i]['status'] = $data[$i]->status;
                            $return["citation"][$i]['status'] = $data[$i]->status;
                            $return["citation"][$i]['is_top_hundred'] = $data[$i]->is_top_hundred; // if 1 then yes 
                        }

                        $return["total_page"] = 1;
                        $return["page"] = 1;
                    } else {

                    	if(!empty($stauts)) {
                    		$data = $table->find('all')->select(['domain_name', 'da', 'login_url', 'instruction', 'status', 'score', 'is_top_hundred'])->limit($limit)->page($offset)->toArray();
                    	} else {
                    		$data = $table->find('all')->select(['domain_name', 'da', 'login_url', 'instruction', 'status', 'score', 'is_top_hundred'])->where(["status" => $status])->limit($limit)->page($offset)->toArray();
                    	}
                        

                        $loopCount = count($data); // count data for loop 

                        for ($i = 0; $i < $loopCount; $i++) {
                            $return["citation"][$i]['id'] = $data[$i]->id;
                            $return["citation"][$i]['domain_name'] = $data[$i]->domain_name;
                            $return["citation"][$i]['da'] = $data[$i]->da;
                            $return["citation"][$i]['login_url'] = $data[$i]->login_url;
                            $return["citation"][$i]['instruction'] = $data[$i]->instruction;
                            $return["citation"][$i]['status'] = $data[$i]->status;
                            $return["citation"][$i]['status'] = $data[$i]->status;
                            $return["citation"][$i]['is_top_hundred'] = $data[$i]->is_top_hundred; // if 1 then yes 
                        }

                        $return["total_page"] = round($totalPage);
                        $return["page"] = $offset;
                    }
                    $this->json(1, 'Citation Data', $return);
                } else {
                    $this->json(0, 'No Citation Data found');
                }
            } else {
                $this->json(0, 'Invalid Token');
            }
        } else {
            $this->json(0, 'Token Not Found.');
        }
    }

    /**
     * Date :- 25-june-17
     * Function Disc :- Function for filter top 100 results 
     * Parameter :- token, limit, offset
     */
    public function gettopCitations() {
        $limit = 10; // fixed until value not sent by admin 
        $offset = 1; // fixed until value not sent by admin 
        $return = []; // blank array for store citation report 
        $token = $this->request->header('token');
        if (!empty(trim($token))) {

            $check = $this->is_token_valid($token); // check token is valid or not  

            /* Condition if token is correct */
            if ($check == true) {
                $data = []; // blank array to store database data 
                $req_data = json_decode(file_get_contents('php://input')); // getting input from body
                $limit = isset($req_data->limit) ? intval($req_data->limit) : $limit;
                $offset = isset($req_data->offset) && $req_data->offset != 0 ? intval($req_data->offset) : $offset;

                $table = $this->loadModel('citationManager');
                $query = $table->find();
                $count = $query->select(['count' => $query->func()->count('*')])->where(["is_top_hundred" => 1])->toArray(); // count all citations data
                $total = $count[0]->count;

                if ($total > 0) {

                    $data = $table->find('all')->select(['domain_name', 'da', 'login_url', 'instruction', 'status', 'score', 'is_top_hundred'])->where(["is_top_hundred" => 1])->limit($limit)->toArray();

                    $totalPage = $total / $limit; // total page value 

                    if ($total <= $limit) {

                        $loopCount = count($data); // count data for loop 

                        for ($i = 0; $i < $loopCount; $i++) {
                            $return["citation"][$i]['id'] = $data[$i]->id;
                            $return["citation"][$i]['domain_name'] = $data[$i]->domain_name;
                            $return["citation"][$i]['da'] = $data[$i]->da;
                            $return["citation"][$i]['login_url'] = $data[$i]->login_url;
                            $return["citation"][$i]['instruction'] = $data[$i]->instruction;
                            $return["citation"][$i]['status'] = $data[$i]->status;
                            $return["citation"][$i]['status'] = $data[$i]->status;
                            $return["citation"][$i]['is_top_hundred'] = $data[$i]->is_top_hundred; // if 1 then yes 
                        }

                        $return["total_page"] = 1;
                        $return["page"] = 1;
                    } else {

                        $data = $table->find('all')->select(['domain_name', 'da', 'login_url', 'instruction', 'status', 'score', 'is_top_hundred'])->where(["is_top_hundred" => 1])->limit($limit)->page($offset)->toArray();

                        $loopCount = count($data); // count data for loop 

                        for ($i = 0; $i < $loopCount; $i++) {
                            $return["citation"][$i]['id'] = $data[$i]->id;
                            $return["citation"][$i]['domain_name'] = $data[$i]->domain_name;
                            $return["citation"][$i]['da'] = $data[$i]->da;
                            $return["citation"][$i]['login_url'] = $data[$i]->login_url;
                            $return["citation"][$i]['instruction'] = $data[$i]->instruction;
                            $return["citation"][$i]['status'] = $data[$i]->status;
                            $return["citation"][$i]['status'] = $data[$i]->status;
                            $return["citation"][$i]['is_top_hundred'] = $data[$i]->is_top_hundred; // if 1 then yes 
                        }

                        $return["total_page"] = round($totalPage);
                        $return["page"] = $offset;
                    }
                    $this->json(1, 'Citation Top Data', $return);
                } else {
                    $this->json(0, 'No Citation Data found');
                }
            } else {
                $this->json(0, 'Invalid Token');
            }
        } else {
            $this->json(0, 'Token Not Found.');
        }
    }
    
    
    /**
     * Date :- 28-june-17
     * Function Disc :- Function for add top citations 
     * Parameter :- {"ids": "2,3,4,7,8,9,5,6"}
     */
    
    public function addTopCitations() {
        $token = $this->request->header('token');
        $table = $this->loadModel('citationManager');
        if (!empty(trim($token))) {

            $check = $this->is_token_valid($token); // check token is valid or not  

            /* Condition if token is correct */
            if ($check == true) {
                $req_data = json_decode(file_get_contents('php://input'));
                $ids = isset($req_data->ids) ? $req_data->ids : ""; 
                 
                if(!empty($ids)) {
                    $parsedIds = explode(",", $ids);
                    $total = count($parsedIds);
                    if($total > 0 && $total != 0){
                        $query = $table->query();
                        if($query->update()->set(["is_top_hundred" => 1, "score" => 100])->where(["id IN" => $parsedIds])->execute()) {
                            $this->json(1, "Top users updated successfully");
                        } else {
                            $this->json(0, "Top users updation failled.");
                        }
                    } else {
                        $this->json(0, "Id's not found");
                    }
                } else {
                    $this->json(0, "Id's not found");
                }
            }else {
                $this->json(0, 'Invalid Token');
            }
            
        } else {
            $this->json(0, 'Token Not Found.');
        }
    }
    
    /**
     * Date :- 28-june-17
     * Function Disc :- Function for remove top citations 
     * Parameter :- {"ids": "2,3,4,7,8,9,5,6"}
     */
    public function removeTopCitations() {
        $token = $this->request->header('token');
        $table = $this->loadModel('citationManager');
        if (!empty(trim($token))) {

            $check = $this->is_token_valid($token); // check token is valid or not  

            /* Condition if token is correct */
            if ($check == true) {
                $req_data = json_decode(file_get_contents('php://input'));
                $ids = isset($req_data->ids) ? $req_data->ids : ""; 
                
                if(!empty($ids)) {
                    $parsedIds = explode(",", $ids);
                    $total = count($parsedIds);
                    if($total > 0 && $total != 0){
                        $query = $table->query();
                        if($query->update()->set(["is_top_hundred" => 0, "score" => null])->where(["id IN" => $parsedIds])->execute()) {
                            $this->json(1, "Top users Removed successfully");
                        } else {
                            $this->json(0, "Top users updation failled.");
                        }
                    } else {
                        $this->json(0, "Id's not found");
                    }
                } else {
                    $this->json(0, "Id's not found");
                }
            }else {
                $this->json(0, 'Invalid Token');
            }
            
        } else {
            $this->json(0, 'Token Not Found.');
        }
    }
    
    /**
     * Date :- 28-june-17
     * Function Disc :- Function for upload base64 encoded image according to id into database 
     * Parameter :- image(base64_encode)
     */
    
    public function uploadLogo() {
        $token = $this->request->header('token');
        $dir_to_save = __DIR__."/../../webroot/logos";
        
        if (!empty(trim($token))) {

            $check = $this->is_token_valid($token); // check token is valid or not 
           
            $table = $this->loadModel('citationManager');

            /* Condition if token is correct */
            if ($check == true) {
                
                $req_data = json_decode(file_get_contents('php://input'));
                
                $img = isset($req_data->image) ? $req_data->image : ""; 
                $id = isset($req_data->id) ? intval($req_data->id) : "";
                
                if(empty($id)) {
                    $this->json(0, "Id required");
                }
                
                if(empty($img)) {
                    $this->json(0, "base64 encoded image required");
                } else {
                    $img = str_replace('data:image/png;base64,', "", $img);
                }
               
                if (!is_dir($dir_to_save)) {
                    mkdir($dir_to_save);
                }
                $file_name = "logo".$id.".png";
                if(file_put_contents($dir_to_save."/".$file_name, base64_decode($img))) {
                    
                    chmod($dir_to_save."/".$file_name, 0777); // set 777 permission
                    
                    /* update logo name into database a/c to id */
                    $query = $table->query();
                    $query->update()->set(["logo" => $file_name])->where(["id" => $id])->execute();
                    $this->json(1, "Logo Uploaded");
                } else {
                    $this->json(0, "Logo upload failled");
                }
                
            } else {
                $this->json(0, 'Invalid Token');
            }
        } else {
            $this->json(0, 'Token Not Found.');
        }
        
        
    }
    
    /**
     * Date :- 3-july-17
     * Function Disc :- Function for update multiple score
     * Parameter :- {"score":[{"id":1,"score":50},{"id":2,"score":80}]} 
     */
    public function updateScore() {
        $token = $this->request->header('token');
        $table = $this->loadModel('citationManager');
        if (!empty(trim($token))) {

            $check = $this->is_token_valid($token); // check token is valid or not  

            /* Condition if token is correct */
            if ($check == true) {
                $req_data = json_decode(file_get_contents('php://input'));
                $score = isset($req_data->data) ? $req_data->data : "";
                
                if(!empty($score)) {
                    
                    $total = count($score);
                    
                    if($total > 0 && $total != 0){
                        
                        foreach($score as $val):
                            $query = $table->query();
                            $query->update()->set(["score" => $val->score])->where(["id" => $val->id])->execute();
                        endforeach;
                        $this->json(1, "Citations Scores are updated successfully");
                    } else {
                        $this->json(0, "Empty Please set values");
                    }
                } else {
                    $this->json(0, "Id's not found");
                }
            }else {
                $this->json(0, 'Invalid Token');
            }
            
        } else {
            $this->json(0, 'Token Not Found.');
        }
    }
    
    

}

