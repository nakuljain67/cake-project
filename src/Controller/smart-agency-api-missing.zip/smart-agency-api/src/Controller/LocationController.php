<?php

namespace App\Controller;

use App\Controller\AppController;
use App\Controller\SiteAuditController;
use App\Controller\CreController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;
use PDO;

class LocationController extends AppController {

    public $siteAudit; public $cre;

    public function initialize() {
        parent::initialize();
        $this->loadModel("Keygroups");
        $this->siteAudit = new SiteAuditController();
        $this->cre = new CreController();
        $this->conn = ConnectionManager::get('default');
    }

    /* default method called */

    public function index() {

        $this->autoRender = false;

        $this->json(1, array(
            "method" => "index",
            "messge" => "silence is golden"
        ));
    }

    /* create agency location */

    public function create() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                /* save details to tbl_locations table */

                $token = $this->request->header('token');
                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));
                    $website = isset($data['website']) && trim($data['website']) != '' ? $data['website'] : '';
                    $name = isset($data['name']) && trim($data['name']) != '' ? $data['name'] : '';
                    $country_id = isset($data['country_id']) && trim($data['country_id']) != '' ? $data['country_id'] : '';
                    $state_id = isset($data['state_id']) && trim($data['state_id']) != '' ? $data['state_id'] : '';
                    $address = isset($data['address']) && trim($data['address']) != '' ? $data['address'] : '';
                    $target = isset($data['target']) && trim($data['target']) != '' ? $data['target'] : '';

                    $arvalidation = array();
                    if ($website == "") {
                        $arvalidation['website'] = "Please provide website";
                    }
                    if ($name == "") {
                        $arvalidation['name'] = "Please provide name";
                    }
                    if ($country_id == "") {
                        $arvalidation['country_id'] = "Please provide country_id";
                    }
                    if ($state_id == "") {
                        $arvalidation['state_id'] = "Please provide state_id";
                    }
                    if ($address == "") {
                        $arvalidation['address'] = "Please provide address";
                    }
//                    if ($target == "") {
//                        $arvalidation['target'] = "Please provide target";
//                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }
                    $res = $this->fetchTokenDetails($token);
                    $userType = $res['code'];
                    if($userType != 'ADM' && $userType != 'SADM'){
                        $this->json(0, "You are not authorized to create clients");
                    }
                    
                    $data['agency_id'] = $res['agency_id'];
                    $data['user_id'] = $res['user_id'];
                    $infoStatus = $this->Location->create($data, new AppController());

                    /* ------- Function calling for add location into api_location table into API Engine House --- */
                    $this->addLocation($infoStatus[0]->location_id);
                    /* ------- END ---------- */

                    if ($infoStatus == "-1") {
                        $this->json(1, "City already exist for this state");
                    }
                    if (count($infoStatus) > 0) {
                        $this->json(1, "Location created successfully", $infoStatus);
                    } else {
                        $this->json(0, "Failed to create location", $infoStatus);
                    }
                } else {
                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (\Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* update agency location */

    public function update() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {
                /* post variables */
                $token = $this->request->header('token');
                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));
                    $location_id = isset($data['location_id']) && trim($data['location_id']) != '' ? $data['location_id'] : '';
                    
                    $canupdate = 1;
                    $location = $this->Location->findById($location_id)->select(['id','created','modified'])->first();
                    if(empty($location)){
                        $this->json(0, "Invalid location");
                    }
                    $now = time();                       
                    $createddt = strtotime($location->created);                     
                    $diff = floor(($now - $createddt) / 60);
                    if($diff > location_url_update_time){
                        $canupdate = 0;
                    }                    
                    
                    if($canupdate == 1){
                        $website = isset($data['website']) && trim($data['website']) != '' ? $data['website'] : '';                    
                    }
                    $name = isset($data['name']) && trim($data['name']) != '' ? $data['name'] : '';
                    $country_id = isset($data['country_id']) && trim($data['country_id']) != '' ? $data['country_id'] : '';
                    $state_id = isset($data['state_id']) && trim($data['state_id']) != '' ? $data['state_id'] : '';
                    $address = isset($data['address']) && trim($data['address']) != '' ? $data['address'] : '';
                    $target = isset($data['target']) && trim($data['target']) != '' ? $data['target'] : '';

                    $arvalidation = array();
                    if ($location_id == "") {
                        $arvalidation['location_id'] = "Please provide location_id";
                    }
                    if($canupdate == 1){
                        if ($website == "") {
                            $arvalidation['website'] = "Please provide website";
                        }
                    }
                    if ($name == "") {
                        $arvalidation['name'] = "Please provide name";
                    }
                    if ($country_id == "") {
                        $arvalidation['country_id'] = "Please provide country_id";
                    }
                    if ($state_id == "") {
                        $arvalidation['state_id'] = "Please provide state_id";
                    }
                    if ($address == "") {
                        $arvalidation['address'] = "Please provide address";
                    }
//                  if ($target == "") {
//                      $arvalidation['target'] = "Please provide target";
//                  }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }
                    
                    $status = isset($data['status']) ? intval($data['status']) : "";
                    $res = $this->fetchTokenDetails($token);
                    $userType = $res['code'];
                    if($userType != 'ADM' && $userType != 'SADM'){
                            $uid = $res['user_id'];                            
                                                        
                            $this->loadModel('LocationMap');
                            $conditions = array(
                                'AND' => array(
                                    array("location_id" => $location_id),
                                    array("user_id" => $uid)
                            ));
                            
                            $mappeddata = $this->LocationMap->find()->where($conditions)->count();
                            if($mappeddata == 0){
                                $this->json(0, "You are not authorized to update this location");
                            }
                    }
                    
                    $data['agency_id'] = $res['agency_id'];
                    if ($this->Location->edit($data, $canupdate)) {
                        /* Update Status ON API Engine */
                        $this->updateLocation($location_id, $status);
                        $this->json(1, "Location Updated successfully");
                    } else {

                        $this->json(0, "Invalid Location Id");
                    }
                } else {
                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (\Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* get locations by agency id */

    public function getUserLocations() {

        $this->autoRender = false;
        $this->limit = 12;
        try {
            $token = $this->request->header('token');
            if ($this->is_token_valid()) {
                $data = (array) json_decode(file_get_contents('php://input'));
                $offset = isset($data['offset']) ? $data['offset'] : $this->start;

                if ($offset <= 0) {
                    $offset = 0;
                    $page = $offset + 1;
                } else {
                    $page = $offset;
                }
                                                
                $res = $this->fetchTokenDetails($token);                
                $data['agency_id'] = $res['agency_id'];
                $search_txt = isset($data['search_txt']) ? htmlspecialchars(trim($data['search_txt'])) : "";                
                $status = isset($data['status']) ? intval($data['status']) : 1;
                $locations_array = $this->Location->getlist($data, $this->start, $this->limit);
                
                if ($search_txt == '') {
                    $total_locations = $this->Location->find('all', [
                                'conditions' => ['agency_id' => $data['agency_id'], 'status' => 1]
                            ])->count();
                } else {
                    $total_locations = $this->Location->find('all', [
                                'conditions' => ['OR' => [
                                        ['agency_id' => $data['agency_id'], 'status' => $status, 'Location.name like' => '%' . $search_txt . '%'],
                                        ['agency_id' => $data['agency_id'], 'status' => $status, 'Location.website like' => '%' . $search_txt . '%']
                                    ]
                                ]
                            ])->count();
                }

                $remining_records = ($total_locations % $this->limit);
                $total_pages = floor(($total_locations / $this->limit));
                if ($remining_records > 0) {
                    $total_pages = $total_pages + 1;
                }

                if (count($locations_array) > 0) {
                    $final_array['total_records'] = $total_locations;
                    $final_array['total_pages'] = $total_pages;
                    $final_array['current_page'] = $page;
                    $final_array['data'] = $locations_array;
                    $this->json(1, "Locations Found", $final_array);
                } else {

                    $this->json(0, "No Data Found", $locations_array);
                }
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        } catch (\Exception $ex) {
            
        }
    }

    /* Get Location Detail */

    public function locationDetail() {
        $this->autoRender = false;
        try {
            $token = $this->request->header('token');
            if ($this->is_token_valid()) {
                $data = (array) json_decode(file_get_contents('php://input'));
                $id = isset($data['location_id']) ? intval($data['location_id']) : 0;
                $arvalidation = array();
                if ($id == "" || $id == 0) {
                    $arvalidation['location_id'] = "Please provide location_id";
                }

                if (!empty($arvalidation)) {
                    $this->json(0, "Empty fields found", $arvalidation);
                }

                $res = $this->fetchTokenDetails($token);
                $agency_id = $res['agency_id'];

                $dataexists = $this->Location->findById($id);
                $location = $dataexists->first();
                if (!empty($location)) {
                    if ($location->agency_id == $agency_id) {
                        $this->json(1, "Location Found", $location);
                    } else {
                        $this->json(1, "You are not authorized to access this location");
                    }
                } else {
                    $this->json(1, "Invalid Location ID");
                }
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        } catch (\Exception $ex) {
            
        }
    }

    /* delete agency location */

    public function delete() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                // delete location
                $token = $this->request->header('token');
                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));
                    $arvalidation = array();
                    if (!isset($data['location_id']) || $data['location_id'] == "") {
                        $arvalidation['location_id'] = "Please provide location_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    $res = $this->fetchTokenDetails($token);
                    $data['agency_id'] = $res['agency_id'];
                    if ($this->Location->remove($data)) {

                        /* ----------- Calling function for delete location id from database (API Engine House) ---- */
                        $this->deleteLocation($data['location_id']);
                        $this->deleteDynamicTables($data['location_id']);
                        /* ---- END ------ */

                        $this->json(1, "Location Deleted Successfully");
                    } else {

                        $this->json(0, "No Location Found");
                    }
                } else {
                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (\Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }
    
    private function deleteDynamicTables($location_id){
        try{
            $con = new ConnectionManager;
            $cn = $con->get('default');
            // delete GA data table
            $shortanalytcs = "api_short_analytics_".$location_id;
            $sql = "DROP TABLE ".$shortanalytcs;
            $cn->execute($sql);
            
            // delete site audit error list
            $siteauditerrorlist = "tbl_site_audit_error_page_list_".$location_id;
            $sql = "DROP TABLE ".$siteauditerrorlist;
            $cn->execute($sql);
            
        } catch (\Exception $ex) {

        } catch (\Exception $ex) {

        }
    }
    
    public function getKeywords() {
        try {
            $this->autoRender = false;
            $token = $this->request->header('token');
            if ($this->is_token_valid()) {
                $res = $this->fetchTokenDetails($token);
                $data = (array) json_decode(file_get_contents('php://input'));
                $location_id = isset($data['location_id']) ? intval($data['location_id']) : 0;
                $arvalidation = array();
                if ($location_id == 0) {
                    $arvalidation['location_id'] = "Please provide location_id";
                }

                if (!empty($arvalidation)) {
                    $this->json(0, "Empty fields found", $arvalidation);
                }

                $website = $this->getLocationUrlById($location_id);

                $country_id = isset($data['country_id']) ? trim($data['country_id']) : 0;
                $countriestbl = TableRegistry::get('tbl_countries');
                $country = $countriestbl->findById($country_id)->first();
                if (empty($country)) {
                    $this->json(0, "Invalid Country");
                }
                $country = $country->code;

                if (trim($website) != '') {
                    $this->autoRender = false;
                    $sem = $this->semrush_api_info();
                    $semrush_main_api_url = $sem['main_api_url'];
                    $key = $sem['key'];
                    $display_limit = $this->semrush_limit();
                    $curl_url = "?type=domain_organic&key=" . $key . "&export_columns=Ph,Po,Pp,Pd,Nq,Cp,Ur,Tr,Tc,Co,Nr,Td&domain=" . $website . "&database=" . strtolower($country) . "&display_sort=tr_desc&display_limit=" . $display_limit; //&display_limit=50
                    $resultdata = $this->pc_get("", "", $semrush_main_api_url, $curl_url);

                    if (strpos($resultdata, 'ERROR') !== false) {
                        $this->json(1, "No Keyword Found");
                    } else if (strpos($resultdata, 'ERROR 50') !== false) {
                        $this->json(1, "No Keyword Found");
                    }

                    $dataarr = array();
                    $competitor_key = explode(PHP_EOL, $resultdata);
                    foreach ($competitor_key as $com_index => $row_data) {
                        if ($com_index > 0) {
                            $line = explode(';', $row_data);
                            // pending work : save keywords in keyword research
                            $dataarr[] = $line[0];
                        }
                    }
                    if (!empty($dataarr)) {
                        $this->json(1, "Keywords Found", $dataarr);
                    } else {
                        $this->json(1, "No Keyword Found");
                    }
                } else {
                    $this->json(0, "Invalid Location");
                }
            } else {
                $this->json(0, "invalid_token", array("token" => "required"));
            }
        } catch (\Exception $ex) {
            
        }
    }

    public function saveKeywords() {
        
        try {

            $this->autoRender = false;
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));

                    $arvalidation = array();
                    if (!isset($data['location_id']) || $data['location_id'] == "") {
                        $arvalidation['location_id'] = "Please provide location_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    $location_id = $data['location_id'];
                    $keywords = trim($data['keywords']); // comma seprated string
                    $allkeywords = explode(",", $keywords);
                    if ($keywords == '' || count($allkeywords) == 0) {
                        $this->json(0, "Please send keywords");
                    }

                    $token = $this->request->header("token");
                    $tokenDetails = $this->fetchTokenDetails($token);

                    $results = $this->Location->find("all", [
                                'conditions' => ['Location.id' => $location_id],
                                'fields' => ['name', 'website', 'target', 'country_id', 'City.name'],
                                'contain' => ['City']
                            ])->first();
                    $cityname = isset($results->city) ? $results->city->name : '';

                    $name = $results->name;
                    $target_country = $results->country_id;
                    $target = $results->target == 'local' ? 'local' : 'national';
                    $google_location = 'local';
                    if ($target == "") {
                        $google_location = $cityname;
                    }

                    $user_id = $tokenDetails['user_id'];
                    $campaigntbl = TableRegistry::get('tbl_campaigns');
                    $keywordtbl = TableRegistry::get('tbl_keywords');
                    $keygroup = TableRegistry::get('tbl_keygroup');
                    $this->loadModel("Keyword");

                    // Start Delete camapign, keygroups and keywords, in case of back and update
                    $keywordtbl->deleteAll(['location_id' => $location_id]);
                    $keygroup->deleteAll(['location_id' => $location_id]);
                    $campaigntbl->deleteAll(['location_id' => $location_id]);
                    // End Delete camapign, keygroups and keywords, in case of back and update
                    // create campaign
                    $capmarrr = array("location_id" => $location_id, "name" => $name, "country" => $target_country, "target" => $target, "google_location" => $google_location, "user_id" => $user_id);
                    $campentity = $campaigntbl->newEntity($capmarrr);

                    if ($campaigntbl->save($campentity)) {
                        $campaign_id = $campentity->id;
                        $results = array();

                        foreach ($allkeywords as $keyword) {
                            $res = array();
                            $res['campaign_id'] = $campaign_id;
                            $res['location_id'] = $location_id;
                            $res['google_location'] = $google_location;
                            $res['user_id'] = $user_id;
                            $res['created'] = date("Y-m-d H:i:s");
                            $res['created_by'] = $user_id;
                            $res['modified_by'] = $user_id;

                            // create keygroup
                            $entity = $keygroup->newEntity($res);
                            $keygroup->save($entity);
                            $group_id = $entity->id;

                            $res = array();
                            $res['campaign_id'] = $campaign_id;
                            $res['location_id'] = $location_id;
                            $res['group_id'] = $group_id;
                            $res['keyword'] = $keyword;
                            $res['isprimary'] = 1;
                            $res['user_id'] = $user_id;
                            $res['created'] = date("Y-m-d H:i:s");
                            $res['created_by'] = $user_id;
                            $res['modified_by'] = $user_id;
                            
                            // create primary keyword
                            $entity = $keywordtbl->newEntity($res);
                            $keywordtbl->save($entity);
                        }
                        $this->json(1, "Keywords sucessully added");
                    } else {

                        $this->json(0, "Failed to add keywords");
                    }
                }
            }
            else{
                $this->json(0, "Silence is golden");
            }
        } catch (\Exception $ex) {
            $this->json(0, "Exception", $ex->getMessage());
        }
    }

    // run background service
    public function runAudit() {
        try {

            $this->autoRender = false;
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));

                    $arvalidation = array();
                    if (!isset($data['location_id']) || $data['location_id'] == "") {
                        $arvalidation['location_id'] = "Please provide location_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }
                    $token = $this->request->header('token');
                    
                    $tokenDetails = $this->fetchTokenDetails($token);
                    $user_id = $tokenDetails['user_id'];
                    
                    $location_id = $data['location_id'];
                    $this->loadModel("Location");
                    
                    $location = $this->Location->findById($location_id)->select(['website', 'name'])->first(); 
                    if(empty($location)){
                        $this->json(0, "Invalid Location");
                    }                          
                    $website = $this->fully_trim($location->website);
                    // TEMP Dsiable, to test location add functionality
                    if(TEMPDISABLED == 0){
                        $rs = $this->siteAudit->runsiteaudit($location_id, $location->name, $website, $user_id);
                    }                    
                    if ($rs == 1) {
                        $this->json(1, "Site audit successfully started");
                    } else if ($rs == -1) {
                        $this->json(0, "Site audit is already in progress");
                    } 
                    else {
                        $this->json(0, "Something going wrong to run Site Audit. Please try to run again");
                    }                    
                    
                }
                else{
                    $this->json(0, "invalid token");
                }
            }
            else{
                $this->json(0, "Silence is golden");
            }
        } catch (\Exception $ex) {
            $this->json(0, "Exception", $ex->getMessage());
        }
    }
    
    public function changeLocation() {
        try {

            $this->autoRender = false;
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {                    
                    $data = (array) json_decode(file_get_contents('php://input'));
                    $arvalidation = array();                    
                    if (!isset($data['location_id']) || $data['location_id'] == "") {
                        $arvalidation['location_id'] = "Please provide location_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }
                    
                    $location_id = $data['location_id'];   
                                        
                    $detail = $this->fetchTokenDetails();
                    if(empty($detail)){
                        $this->json(0, "Invalid Token");
                    }
                    
                    if($detail['location_id'] == 0){
                        $this->json(0, "Please create/enable at least one location");
                    }
                    
                    $agency_id = $detail['agency_id'];
                    $res = $this->Location->findById($location_id)->first();
                    
                    if(empty($res)){
                        $this->json(0, "Invalid Location");
                    }
                    
                    if($res->agency_id != $agency_id){
                        $this->json(0, "You are not authorized to access this location");
                    }
                    if($res->status == 0){
                        $this->json(0, "Location is inactive");
                    }
                    
                    if ($detail['code'] != 'ADM' && $detail['code'] != 'SADM') {
                        // check for except admin and superadmin
                        $this->loadModel('LocationMap');
                        $rs = $this->LocationMap->findByLocation_id($location_id)->count();
                        if($rs == 0){
                            $this->json(0, "You are not authorized to access this location");
                        }
                    }                    
                    $user_details = array();
                    $usr_token_tbl = TableRegistry::get('tbl_userlive_tokens');                    
                    $user_tkn = $usr_token_tbl->newEntity();                                        
                    $user_tkn->location_id = $location_id;
                    $user_tkn->id = $detail['token_id'];
                    if($usr_token_tbl->save($user_tkn)){
                        
                        array_push($user_details, array(
                            "firstName" => $detail['fname'],
                            "lastName" => $detail['lname'],
                            "email" => $detail['email'],
                            "usertype" => $detail['usertype'],
                            "token" => $detail['token'],                        
                            "location_id" => $res->id,
                            "website" => $res->website,
                            "name" => $res->name
                        ));
                        
                        $this->json(1, "Location changed sucessfully", $user_details);
                    }
                    else{
                        $this->json(0, "Some error occurred to change location. please try again");
                    }                    
                }
            }
            else{
                $this->json(0, "Silence is golden");
            }
        } catch (\Exception $ex) {
            $this->json(0, "Exception", $ex->getMessage());
        }
    }

    // run background service
    public function runCre() {
        try {

            $this->autoRender = false;
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {                    
                    $data = (array) json_decode(file_get_contents('php://input'));

                    $arvalidation = array();
                    if (!isset($data['location_id']) || $data['location_id'] == "") {
                        $arvalidation['location_id'] = "Please provide location_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }
                    $token = $this->request->header('token');
                    
                    $tokenDetails = $this->fetchTokenDetails($token);
                    $user_id = $tokenDetails['user_id'];
                    
                    $location_id = $data['location_id'];
                    $this->loadModel("Location");
                    
                    $location = $this->Location->findById($location_id)->select(['website', 'name'])->first(); 
                    if(empty($location)){
                        $this->json(0, "Invalid Location");
                    }                          
                    $website = $location->website;
                    // TEMP Dsiable, to test location add functionality
                    if(TEMPDISABLED == 0){
                        $rs = $this->cre->crefullscan($user_id, $location_id, $website, $token);                    
                    }
                    $this->json(1, "CRE is successfully statrted for full website");
                }
            }
        } catch (\Exception $ex) {
            $this->json(0, "Exception", $ex->getMessage());
        }
    }
                
    /* Function create / add new location into API engine house database */

    public function addLocation() {
        try {
            $location_id = 1993;
            $this->autoRender = false;
            if (!empty($location_id)) {
                // $result = $this->pc_post("", "", API_ENGINE_URI, "/addLocation", "", array('location_id' => $location_id));
        $this->conn->query("CREATE TABLE IF NOT EXISTS api_short_analytics_$location_id (
              `id` int(13) PRIMARY KEY AUTO_INCREMENT,
              `location_id` int(50),
              `dateOfVisit` varchar(20),
              `pageURL` varchar(300),
              `keyword` varchar(100),
              `currentRank` int(5),
              `organic` int(5),
              `social` int(5),
              `referral` int(5),
              `none` int(5),
              `cpc` int(5),
              `email` int(5),
              `other` int(10),
              `total` int(10),
              `timeOnSite` varchar(10),
              `bounceRate` varchar(10),
              `url_type` varchar(32),
              `created` timestamp NOT NULL
            ) ENGINE=InnoDB;");
        $con_main = new PDO('mysql:dbname=apiengine;host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');
         $con_main->exec("CREATE TABLE IF NOT EXISTS apiengine.api_main_analytics_$location_id (
              `id` bigint(200) PRIMARY KEY AUTO_INCREMENT,
              `location_id` int(50),
              `tableId` varchar(200),
              `pageURL` varchar(500),
              `visits` int(11),
              `timeOnSite` float,
              `bounceRate` float,
              `dateOfVisit` date,
              `timeOfVisit` time,  
              `source` VARCHAR(100),
              `medium` VARCHAR(100),
              `created` timestamp not null
            ) ENGINE=InnoDB;");
             $con_main->exec("CREATE TABLE IF NOT EXISTS apiengine.api_conv_tracking_$location_id (
              `id` bigint(50) unsigned NOT NULL AUTO_INCREMENT,
              `location_id` int(50) NOT NULL,
              `pageTitle` varchar(500) NOT NULL,
              `currentPageURL` varchar(500) NOT NULL,
              `previousPageURL` varchar(500) NOT NULL,
              `dateTimeOfVisit` datetime NOT NULL,
              `additionalParams` varchar(500) NOT NULL,
              `sessionID` varchar(500) DEFAULT NULL,
              PRIMARY KEY (`Id`),
              UNIQUE KEY `Id_UNIQUE` (`Id`)
            ) ENGINE=InnoDB;");
            } else {
                $this->json("0", "Please provide location id");
            }
        } catch (\Exception $e) {
            
        }
    }
    
    private function updateLocation($location_id, $status) {
        try {
            $this->autoRender = false;
            if (!empty($location_id)) {
                $data_string = "status=".$status;
                $result = $this->pc_post("", "", API_ENGINE_URI, "/updateLocation", $data_string, array('location_id' => $location_id));
            } else {
                $this->json("0", "Please provide location id");
            }
        } catch (\Exception $e) {   
        }
    }

    /* Function for delete Location from database (API Engine House) */
    private function deleteLocation($location_id) {
        try {
            $this->autoRender = false;
            if (!empty($location_id)) {
                $result = $this->pc_post("", "", API_ENGINE_URI, "/deleteLocation", "", array('location_id' => $location_id));
        $this->conn->query("DROP TABLE IF EXISTS api_short_analytics_$location_id");
         $con_main = new PDO('mysql:dbname=apiengine;host=enfusen.c22tracmla9w.us-west-2.rds.amazonaws.com', 'enfusen_master', '25beerisgood4u!92');
          $con_main->exec("DROP TABLE IF EXISTS api_main_analytics_$location_id");
          $con_main->exec("DROP TABLE IF EXISTS api_conv_tracking_$location_id");
            }
        } catch (\Exception $e) {

        }
    }
        

}
