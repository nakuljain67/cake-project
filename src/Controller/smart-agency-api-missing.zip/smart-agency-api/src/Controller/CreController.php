<?php

namespace App\Controller;

use App\Controller\AppController;
use App\Controller\KeywordController;
use App\Controller\PublicController;
use \DomDocument;
use \stdClass;
use DateTime;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;
use Cake\Routing\Router;

class CreController extends AppController {

    private $connection;
    private $keyword;
    public $public;

    public function initialize() {
        parent::initialize();
        $this->connection = ConnectionManager::get('default');
        $this->keyword = new KeywordController();
        $this->public = new PublicController();
    }

    /* default method called */

    public function index() {

        $this->autoRender = false;

        $this->json(1, array(
            "method" => "index",
            "messge" => "silence is golden"
        ));
    }

    public function getUrlGaData($page_url, $location_id, $type = '') {

        $this->autoRender = false;

        $results = array();

        try {
            $from_date = date("Y-m-d", strtotime("-31 days")); // 31 means 30 days from to_date
            $to_date = date("Y-m-d", strtotime("-1 days"));

            $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $page_url)), "/");

            if ($type == "front") {

                $results = $this->connection
                        ->execute("SELECT sum(timeOnSite) as time_on_site, sum(total) as total_visit,sum(bounceRate) as total_BounceRate, sum(organic) as total_organic,sum(cpc) as total_cpc,sum(referral) as total_referral,sum(social) as total_social, sum(none) as total_direct FROM api_short_analytics_$location_id WHERE location_id = " . $location_id . " AND `DateOfVisit` >= '$from_date' and `DateOfVisit` <= '$to_date' order by DateOfVisit desc")
                        ->fetchAll('assoc');
            } else {

                $results = $this->connection
                        ->execute("SELECT sum(timeOnSite) as time_on_site, sum(total) as total_visit,sum(bounceRate) as total_BounceRate, sum(organic) as total_organic,sum(cpc) as total_cpc,sum(referral) as total_referral,sum(social) as total_social, sum(none) as total_direct FROM api_short_analytics_$location_id WHERE location_id = " . $location_id . " AND TRIM(BOTH  '/' FROM REPLACE(REPLACE(REPLACE (pageURL, 'http://', ''),'https://',''),'www.','')) like '$trimurl' AND `DateOfVisit` >= '$from_date' and `DateOfVisit` <= '$to_date' order by DateOfVisit desc")
                        ->fetchAll('assoc');
            }
        } catch (\Exception $ex) {
            
        } catch (\PDOException $ex) {
            
        }

        return $results;
    }
    
    //================== Main Functions =================================================

    /* function to get value of Graphs */

    public function getGraphData() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');

            if ($this->is_token_valid()) {

                if (!empty($token)) {
                    $tokendetail = $this->fetchTokenDetails($token);
                    $user_id = $tokendetail['user_id'];
                    $location_id = $tokendetail['location_id'];
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }

                // updated this code on 20JUN2017
                $last_run_date = '';
                $tblCREData = $this->connection
                        ->execute("SELECT modified FROM tbl_cre where location_id = " . $location_id)
                        ->fetchAll('assoc');
                $last_run_date = '';
                if (count($tblCREData) > 0) {

                    $last_run_date = $tblCREData[0]['modified'];
                }

                $data_found = $this->Cre->creGraphDataFinder(array("location_id" => $location_id));

                $graph_data = array(
                    "last_run_date" => $last_run_date,
                    "data" => array(
                        "cre_score" => isset($data_found[0]['score']) ? $data_found[0]['score'] : 0,
                        "issues" => $data_found[0]['total_issues'],
                        "pages" => $data_found[0]['pages'],
                        "running_state" => intval($this->tableCREOperation($location_id, "selectStatus", array("location_id" => $location_id))[0]['trigger_report']),
                        "gaconnected" => $this->checkgaconnect($location_id),
                        "is_singlepage_running" => count($this->countURLsRunningPages($location_id)) > 0 ? 1 : 0
                    ),
                    "description" => array(
                        array(
                            "label" => 'Title Issues',
                            "data" => $data_found[0]['title_issues'],
                            "backgroundColor" => '#2b94e1'
                        ),
                        array(""
                            . "label" => 'Meta Issues',
                            "data" => $data_found[0]['meta_issues'],
                            "backgroundColor" => '#bf9e6b'
                        ),
                        array(
                            "label" => 'Content Issues',
                            "data" => $data_found[0]['content_issues'],
                            "backgroundColor" => '#ff7f00'
                        ),
                        array(
                            "label" => 'Heading Issues',
                            "data" => $data_found[0]['heading_issues'],
                            "backgroundColor" => '#a52600'
                        ),
                        array(
                            "label" => 'Link Issues',
                            "data" => $data_found[0]['link_issues'],
                            "backgroundColor" => '#4fae33'
                        ),
                        array(
                            "label" => 'Image Issues',
                            "data" => $data_found[0]['image_issues'],
                            "backgroundColor" => '#6666cc'
                        )
                    )
                );
                $this->json(1, "graph data found", $graph_data);
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* function to get all running pages by token */

    public function getAllPages() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "GET") {

            $token = $this->request->header('token');
            //$data = json_decode(file_get_contents('php://input'));
            //$offset = isset($data->offset) ? trim($data->offset) : 0;
            //$limit = isset($data->limit) ? trim($data->limit) : $this->limit;
            $offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
            $limit = isset($_GET['limit']) ? trim($_GET['limit']) : $this->limit;
            if ($this->is_token_valid()) {

                $user_id = 0;
                $location_id = 0;

                if (!empty($token)) {
                    $tokendetail = $this->fetchTokenDetails($token);
                    $user_id = $tokendetail['user_id'];
                    $location_id = $tokendetail['location_id'];
                }

                $PagesArray = $this->Cre->getCREUrlsOfLocation(array("location_id" => $location_id, "offset" => $offset, "limit" => $limit), new AppController());
                $UpdateValueArray = array();
                foreach ($PagesArray['urls'] as $key => $value) {
                    $page_url = $value['page_url'];
                    $dataArray = array();
                    if (count($this->getUrlGaData($page_url, $location_id)) > 0) {

                        $dataArray = $this->getUrlGaData($page_url, $location_id)[0];
                    }

                    array_push($UpdateValueArray, array(
                        "page_id" => $value['page_id'],
                        "page_url" => $page_url,
                        "ov" => empty($dataArray['total_organic']) ? 0 : intval($dataArray['total_organic']),
                        "oc" => 0,
                        "tos" => empty($dataArray['time_on_site']) ? 0 : $this->PerSentFormat(($dataArray['time_on_site'] / $dataArray['total_visit'])),
                        "br" => empty($dataArray['total_BounceRate']) ? 0 : $this->PerSentFormat(($dataArray['total_BounceRate'] / $dataArray['total_visit']) * 100),
                        "score" => $value['score'],
                        "issues" => $value['issues'],
                        "is_running" => $value['is_running']
                    ));
                }

                $this->json(1, array("message" => "urls found", "total_rows" => $PagesArray['count']), $UpdateValueArray);
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* get all target pages */

    public function getAllTargetPages() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');

            if ($this->is_token_valid()) {

                $targetPagesList = $this->getTargetPages($token);

                $usr_urls_tbl = TableRegistry::get('tbl_cre_urls');
                $user_id = 0;
                $location_id = 0;

                if (!empty($token)) {
                    $tokendetail = $this->fetchTokenDetails($token);
                    $user_id = $tokendetail['user_id'];
                    $location_id = $tokendetail['location_id'];
                }

                $total_rows = $usr_urls_tbl->find('all', [
                            'conditions' => ['location_id' => $location_id]
                        ])->all()->toArray();

                $targetPagesArray = array();

                if (count($total_rows) > 0) {

                    foreach ($total_rows as $index => $url):

                        if (in_array($url->url, $targetPagesList)):

                            array_push($targetPagesArray, array(
                                "page_id" => $url->id,
                                "page_url" => $url->url,
                                'ov' => isset($url->organic_visits) ? $url->organic_visits : 0,
                                'oc' => isset($url->organic_conv) ? $url->organic_conv : 0,
                                'tos' => isset($url->time_on_site) ? $url->time_on_site : 0,
                                'br' => isset($url->bounce_rate) ? $url->bounce_rate : 0,
                                'score' => isset($url->score) ? intval($url->score) : 0,
                                'issues' => isset($url->total_issues) ? $url->total_issues : 0,
                                'is_running' => $url->is_running
                            ));
                        else:
                            continue;
                        endif;
                    endforeach;
                }

                $this->json(1, "target urls found", $targetPagesArray);
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* function to analyse full website */

    public function runAllPageCampaignCRE() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');

            if ($this->is_token_valid()) {

                $tokendetail = $this->fetchTokenDetails($token);
                $user_id = $tokendetail['user_id'];
                $location_id = $tokendetail['location_id'];
                $url = $tokendetail['website'];

                if (empty($location_id)) {

                    $this->json(0, "location_id is empty", array("location_id" => "required"));
                }

                $this->crefullscan($user_id, $location_id, $url, $token);
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function crefullscan($user_id, $location_id, $url, $token) {
        try {
            $cre_queue = TableRegistry::get('tbl_cre_queue');
            $total_rows = $cre_queue->find('all', [
                        'conditions' => ['location_id' => $location_id]
                    ])->all()->toArray();
            if (count($total_rows) > 0) {

                $this->json(0, "CRE is already running", array("campaign" => "in running state"));
            }

            // check dynamically created favicon            
            if (!empty($url)) {

                $url = $this->appendhttp($url);
                $parseurl = parse_url($url);
                $baseurl = $parseurl['host'];
                $serviceurl = 'http://icons.better-idea.org/allicons.json';
                $returndata = @file_get_contents($serviceurl . '?' . 'url=' . $baseurl);
                $returndata = json_decode($returndata);
                $faviconurl = 0;
                if (isset($returndata->icons[0]->url) && $returndata->icons[0]->url != '') {
                    $faviconurl = $returndata->icons[0]->url;
                }

                $hasfavicon = $this->get_user_meta($location_id, 'webfavicon');

                if (empty($hasfavicon)) {

                    $this->add_user_meta($location_id, 'webfavicon', $faviconurl);
                } else {

                    $this->update_user_meta($location_id, 'webfavicon', $faviconurl);
                }
            }

            // adding favicon ends

            if ($this->tableCREOperation($location_id, "countTriggerRow", array("location_id" => $location_id))) {

                $this->tableCREOperation($location_id, "updateTrigger", array("trigger_report" => 1, "modified" => date("Y-m-d H:i:s"), "location_id" => $location_id));
                // row updated
            } else {
                if ($this->Cre->insertToTblCRE($location_id, "insert", array("type" => "allpage", "location_id" => $location_id, "trigger_report" => 1))) {
                    // value inserted
                }
            }

            if ($this->are_cre_urls_exists($location_id)) {

                // make cre past history- entry to cre_history table
                if ($this->makeCREHistory($location_id, "allpage")) {
                    // history upto date
                }
            }
            
            /* entry to cre_queue */
            if ($this->Cre->saveToCREQueue(array("type" => "allpage", "token" => $token, "location_id" => $location_id))) {

                /* starting background process */
                $this->silent_post(array(
                    "location_id" => $location_id,
                    'created_by' => $user_id,
                    'type' => 'allpage'
                    ), $this->getSilentPostPath() . "cre/findAllPageLinksOfWebsite");
                                                
                $this->json(1, "CRE is successfully statrted for full website");
            } else {

                $this->json(0, "Failed to make request for all pages to CRE");
            }
        } catch (Exception $ex) {
            
        }
    }

    // CRE method for target page analysis 
    public function runTargetPageCRE() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');

            if ($this->is_token_valid()) {

                $tokendetail = $this->fetchTokenDetails($token);
                $user_id = $tokendetail['user_id'];
                $location_id = $tokendetail['location_id'];

                if (empty($location_id)) {

                    $this->json(0, "location_id is empty", array("location_id" => "required"));
                }

                if ($this->Cre->insertToTblCRE($location_id, "insert", array("type" => "targetpage", "location_id" => $location_id, "trigger_report" => 1))) {
                    // value inserted
                }

                if ($this->are_cre_urls_exists($location_id)) {
                    // make cre past history- entry to cre_history table
                    if ($this->makeCREHistory($location_id, "targetpage")) {
                        // history upto date
                    }
                }

                /* entry to cre_queue */
                if ($this->Cre->saveToCREQueue(array("type" => "targetpage", "token" => $token, "location_id" => $location_id))) {

                    if ($this->updateCREUrlsTable($location_id)) {

                        $this->json(1, "CRE for target pages is inserted in cre queue");
                    } else {

                        $this->json(0, "Failed to run CRE for target pages");
                    }
                } else {

                    $this->json(0, "Failed to make request for all pages to CRE");
                }
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* function to parse all page urls */

    public function findAllPageLinksOfWebsite() {

        $this->autoRender = false;

        //if ($_SERVER['REQUEST_METHOD'] == "POST") {

        $location_id = isset($_REQUEST['location_id']) ? intval($_REQUEST['location_id']) : 0;
        $created_by = isset($_REQUEST['created_by']) ? intval($_REQUEST['created_by']) : 0;
        $type = isset($_REQUEST['type']) ? trim($_REQUEST['type']) : 'allpage';
        $token = '';
        $website = $this->getLocationUrlById($location_id);

        if (empty($website)) {
            exit();
        }

        // delete from cre_urls
        if ($this->Cre->operationOnCREUrlsTable($location_id, "delete")) {
            // successfully deleted all location urls
        }
        
        $crawled_page = $this->crawl_page($token, $website, $location_id, "fullweb");
        if(empty($crawled_page['urls'])){
            $cre = TableRegistry::get('tbl_cre');
            $cre->updateAll(['trigger_report' => 0], ['location_id' => $location_id]);                    
            $cre_queue = TableRegistry::get('tbl_cre_queue');
            $cre_queue->deleteAll(['location_id' => $location_id]);            
            @mail(ADMIN_EMAIL.',parambir@rudrainnovatives.com','CRE failed to crawl on Smart Agency',  json_encode($crawled_page));
            $this->logSmartError(array(
                    "location_id" => 3,
                    "error_type" => "CRE",
                    "file" => "CreController/findAllPageLinksOfWebsite",
                    "url" => $this->getSilentPostPath() . "cre/",
                    "function" => "findAllPageLinksOfWebsite",
                    "message" => "CRE failed to crawl website",
                    "full_exception" => "message is to added just for dummy now",
                    "browser" => "chrome",
                    "os" => "Ubuntu 14.01"
                        )
                ); 
            die;
        }

        if (is_array($crawled_page)) {

            if (empty($crawled_page['sitemapurl'])) {

                $this->logSmartError(array(
                    "location_id" => 3,
                    "error_type" => "CRE",
                    "file" => "CreController/index",
                    "url" => $this->getSilentPostPath() . "cre/",
                    "function" => "index",
                    "message" => "Sitemap file missing",
                    "full_exception" => "message is to added just for dummy now",
                    "browser" => "chrome",
                    "os" => "Ubuntu 14.01"
                        )
                );
            } else if (empty($crawled_page['urls'])) {

                $this->logSmartError(array(
                    "location_id" => 3,
                    "error_type" => "CRE",
                    "file" => "CreController/findAllPageLinksOfWebsite",
                    "url" => $this->getSilentPostPath() . "cre/findAllPageLinksOfWebsite",
                    "function" => "findAllPageLinksOfWebsite",
                    "message" => "No URLs foound",
                    "full_exception" => "no urls found from sitemap",
                    "browser" => "chrome",
                    "os" => "Ubuntu 14.01"
                        )
                );
            } else {

                foreach ($crawled_page['urls'] as $index => $url) {

                    $url = $url->{0};
                    $data = array(
                        "location_id" => $location_id,
                        "url" => $url,
                        'created_by' => $created_by
                    );
                    /* save to cre urls */
                    if ($this->Cre->saveToCREUrls($data)) {
                        // inserted to cre_urls
                    }
                }
                if ($this->Cre->updateCREQueueProccessedData($location_id, "updateLastId", array("location_id" => $location_id, "last_id" => $this->getlastIdOfCREUrls($location_id)))) {
                    // cre queue updated
                    $this->logSmartError(array(
                        "location_id" => 3,
                        "error_type" => "CRE",
                        "file" => "CreController/findAllPageLinksOfWebsite",
                        "url" => $this->getSilentPostPath() . "cre/findAllPageLinksOfWebsite",
                        "function" => "findAllPageLinksOfWebsite",
                        "message" => "updateCREQueueProccessedData last id updated",
                        "full_exception" => "",
                        "browser" => "chrome",
                        "os" => "Ubuntu 14.01"
                            )
                    );
                }
            }
        } else {

            $this->logSmartError(array(
                "location_id" => 3,
                "error_type" => "CRE",
                "file" => "CreController/findAllPageLinksOfWebsite",
                "url" => $this->getSilentPostPath() . "cre/findAllPageLinksOfWebsite",
                "function" => "findAllPageLinksOfWebsite",
                "message" => "CRE Failed to Crawl page",
                "full_exception" => "message is to added just for dummy now",
                "browser" => "chrome",
                "os" => "Ubuntu 14.01"
                    )
            );
        }
        /* } else {

          } */
    }
            
    public function triggerReverseSEO() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            //$pageId = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;
            $data = json_decode(file_get_contents('php://input'));
            $url = isset($data->url) ? trim($data->url) : '';
            $country = isset($data->country) ? trim($data->country) : 'us';
            $limit = isset($data->limit) ? intval($data->limit) : 50;

            if ($this->is_token_valid()) {

                $tokendetail = $this->fetchTokenDetails($token);
                $user_id = $tokendetail['user_id'];
                $location_id = $tokendetail['location_id'];

                if (empty($location_id)) {

                    $this->json(0, "location_id is empty", array("valid token" => "required"));
                }
                /* $url = '';
                  if (count($this->findPageURLByPageIdCRE($pageId, $location_id)) > 0) {
                  $url = $this->findPageURLByPageIdCRE($pageId, $location_id)[0]['page_url'];
                  } */
                if (empty($url)) {
                    $this->json(0, "invalid url", array("url" => "required"));
                }

                $row_c_url = $urlpage = rtrim(trim($url), "/");
                $semrush = $this->semrush_api_info();
                $semrush_main_api_url = $semrush['main_api_url'];
                $key = $semrush['key'];
                $display_limit = $limit;
                $username = '';
                $password = '';
                $status = 0;
                $urlchk = trim(str_replace(array("https://", "http://", "www."), array("", "", ""), trim($row_c_url)), "/");
                $curl_url = "?type=url_organic&key=" . $key . "&export_columns=Ph,Po,Pp,Nq,Kd,Cp,Ur,Tr,Tc,Co,Nr,Td,Ts&url=" . $row_c_url . "&database=" . strtolower($country) . "&display_sort=nq_desc&display_limit=" . $display_limit; //&display_limit=50
                $resultdata = $this->pc_get($username, $password, $semrush_main_api_url, $curl_url);

                if (strpos($resultdata, 'ERROR 50') !== false) {

                    $row_c_url .= "/";
                    $curl_url = "?type=url_organic&key=" . $key . "&export_columns=Ph,Po,Pp,Nq,Kd,Cp,Ur,Tr,Tc,Co,Nr,Td,Ts&url=" . $row_c_url . "&database=" . strtolower($country) . "&display_sort=nq_desc&display_limit=" . $display_limit; //&display_limit=50
                    $resultdata = $this->pc_get($username, $password, $semrush_main_api_url, $curl_url);
                    if (strpos($resultdata, 'ERROR 50') !== false) {

                        $this->json(0, "No keyword found for this page.");
                    }
                    //$this->json(0, "No keyword found for this page.");
                }

                $competitor_key = explode(PHP_EOL, $resultdata);
                $location_id = 3;
                $total = 0;

                foreach ($competitor_key as $com_index => $row_data) {
                    if ($com_index > 0) {
                        $line = explode(';', $row_data);
                        $keyword = $line[0];

                        $check_existing_key = $this->connection
                                ->execute('SELECT * FROM tbl_reverse_seo WHERE location_id = ' . $location_id . ' AND TRIM(BOTH  "/" FROM REPLACE(REPLACE(REPLACE (page_url, "http://", ""),"https://",""),"www.","")) like "' . $urlchk . '" AND LOWER(TRIM(keyword)) = "' . strtolower(trim($keyword)) . '"')
                                ->fetchAll('assoc');

                        if (!empty($check_existing_key)) {

                            $update_key['page_url'] = $urlpage;
                            $update_key['location_id'] = $location_id;
                            $update_key['keyword'] = $line[0];
                            $update_key['position'] = $line[1];
                            $update_key['search_volume'] = $line[3];
                            $update_key['CPC'] = $line[5];
                            $update_key['competition'] = $line[9];
                            $update_key['traffic_percent'] = $line[7];
                            $update_key['traffic_cost'] = $line[8];
                            $update_key['created_by'] = $user_id;
                            $update_key['id'] = $check_existing_key[0]['id'];
                            if ($this->Cre->operationForReverseSEO($location_id, 'update', $update_key)) {
                                
                            }
                        } else {

                            $insert_opp['location_id'] = $location_id;
                            $insert_opp['page_url'] = $urlpage;
                            $insert_opp['keyword'] = $line[0];
                            $insert_opp['position'] = $line[1];
                            $insert_opp['search_volume'] = $line[3];
                            $insert_opp['CPC'] = $line[5];
                            $insert_opp['competition'] = $line[9];
                            $insert_opp['traffic_percent'] = $line[7];
                            $insert_opp['traffic_cost'] = $line[8];
                            $insert_opp['created_by'] = $user_id;
                            if ($this->Cre->operationForReverseSEO($location_id, 'insert', $insert_opp)) {
                                
                            }
                        }
                    }
                }

                $this->json(1, "reverse data pulled");
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function getReverseSEOdata() {
        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $data = json_decode(file_get_contents('php://input'));
            $url = isset($data->url) ? trim($data->url) : '';
            $offset = isset($data->offset) ? intval($data->offset) : 0;
            $limit = isset($data->limit) ? intval($data->limit) : $this->limit;

            if ($this->is_token_valid()) {
                $tokendetail = $this->fetchTokenDetails($token);
                $user_id = $tokendetail['user_id'];
                $location_id = $tokendetail['location_id'];

                if (empty($location_id)) {

                    $this->json(0, "location_id is empty", array("valid token" => "required"));
                }

                $seoData = $this->Cre->operationForReverseSEO($location_id, "select", array("url" => $url, "location_id" => $location_id, "offset" => $offset, "limit" => $limit));

                if (count($seoData) > 0) {

                    $this->json(1, array("last_date" => $seoData['last_date'], "total_count" => $seoData['total_count']), $seoData['seo_data']);
                } else {

                    $this->json(0, "no data found with this url");
                }
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        }
    }

    /* function which is used to start CRE for all/target campaign auto via cron */

    public function autoRunCREQueuePages() {

        /* This file is actually used to Start CRE Urls from cre_urls by limit */
        
        $this->autoRender = false;        
        $cre_queue = TableRegistry::get('tbl_cre_queue');

        $cre_cache = TableRegistry::get('tbl_cre_cache');

        $total_rows = $cre_queue->find('all', ['limit' => 8])->all()->toArray();        
        
        if (count($total_rows) > 0) {

            foreach ($total_rows as $index => $data) {

                $location_id = $data->location_id;

                $updated_dt = strtotime($data->updated_dt); // converting into timestamp - updated_dt
                $current_dt = time();  // converting into timestamp - current datetime
                $totalMinsGap = round(($current_dt - $updated_dt) / 60);
                
                if ($totalMinsGap > Cre_Mins_Gap) { // comparing time diff in mins
                    if ($this->Cre->updateCREQueueProccessedData($location_id, "updateProccess", array("processed" => '', "location_id" => $location_id))) {
                        // update to cre_queue to process data
                    }
                    continue;
                }
                 
                if (intval($data->current_last_id) == intval($data->last_id)) {
                    /* do cre_queue empty */
                    $cre_queue->deleteAll(['location_id' => $location_id]);
                    /* do cre_cache empty */
                    $cre_cache->deleteAll(['location_id' => $location_id]);
                    
                    $this->tableCREOperation($location_id, "updateTrigger", array("trigger_report" => 0, "modified" => date("Y-m-d H:i:s"), "location_id" => $location_id));

                    continue;
                } else if (!empty(trim($data->processed, "[]"))) {
                    // checking here is data->processed is empty or not
                    // if yes(empty) then it fires for next pages
                    continue;
                }

                $targetPagesArray = array();

                $pageLimit = $this->Cre->getPageURLLimits($location_id); 
                                
                $dt = $this->getCREPageUrls($location_id, $pageLimit);
                $pageUrls = $dt['urls'];
                $pageIds = $dt['pageIds'];

                if ($this->Cre->updateCREQueueProccessedData($location_id, "updateProccess", array("processed" => json_encode($pageIds), "location_id" => $location_id))) {
                    // saved to cre_queue to process data
                }
                
                $runningPageIds = array();                
                foreach ($pageUrls as $singleUrl) {

                    $this->silent_post(array(
                        "location_id" => $location_id,
                        "page_url" => $singleUrl['page_url'],
                        "page_id" => $singleUrl['page_id'],
                        "type" => "fullweb"
                            ), $this->getSilentPostPath() . "cre/runSinglePageCRE"
                    );
                    sleep(2); // 2 seconds interval between requests
                }
            }
        } else {
            /* Running single page CRE not by all campaign click */
            $running_pages = $this->countURLsRunningPages();

            if (count($running_pages) > 0) {
                foreach ($running_pages as $index => $data) {
                    $url = $data->url;
                    $location_id = $data->location_id;
                    $pageId = $data->id;

                    $updated_dt = strtotime($data->modified); // converting into timestamp - updated_dt
                    $current_dt = time();  // converting into timestamp - current datetime

                    $totalMinsGap = round(($current_dt - $updated_dt) / 60);
                    if ($totalMinsGap > Cre_Mins_Gap) { // comparing time diff in mins
                        $this->silent_post(array(
                            "location_id" => $location_id,
                            "page_url" => $url,
                            "page_id" => $pageId,
                            "type" => "fullweb"
                            ), $this->getSilentPostPath() . "cre/runSinglePageCRE"
                        );
                        sleep(2); // 2 seconds interval between requests
                    }
                }
            }
        }
    }

    public function saveUrlProfileNotes() {

        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header("token");
            //$pageId = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;
            $data = json_decode(file_get_contents('php://input'));
            $url = isset($data->url) ? trim($data->url) : '';
            $notes = isset($data->notes) ? trim($data->notes) : '';
            $keyword = isset($data->keyword) ? trim($data->keyword) : '';

            if ($this->is_token_valid()) {

                $tokendetail = $this->fetchTokenDetails($token);
                $user_id = $tokendetail['user_id'];
                $location_id = $tokendetail['location_id'];

                if ($location_id > 0) {
                    /* $url = '';
                      if (count($this->findPageURLByPageIdCRE($pageId, $location_id)) > 0) {
                      $url = $this->findPageURLByPageIdCRE($pageId, $location_id)[0]['page_url'];
                      } */
                    if ($this->Cre->operationOnUrlProfileNotes($location_id, "insert", array(
                                "location_id" => $location_id,
                                "notes" => $notes,
                                "url" => $url,
                                "keyword" => $keyword,
                                "created_by" => $user_id
                                    )
                            )
                    ) {

                        $this->json(1, "notes saved");
                    } else {

                        $this->json(0, "failed to save notes");
                    }
                } else {

                    $this->json(0, "invalid token", array("valid token" => "required"));
                }
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function getUrlProfileNotes() {

        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header("token");
            //$pageId = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;
            $data = json_decode(file_get_contents('php://input'));
            $url = isset($data->url) ? trim($data->url) : '';
            $offset = isset($data->offset) ? trim($data->offset) : 0;
            $limit = isset($data->limit) ? trim($data->limit) : $this->limit;
            if ($this->is_token_valid()) {

                $tokendetail = $this->fetchTokenDetails($token);
                $user_id = $tokendetail['user_id'];
                $location_id = $tokendetail['location_id'];

                if ($location_id > 0) {
                    /* $url = '';
                      if (count($this->findPageURLByPageIdCRE($pageId, $location_id)) > 0) {
                      $url = $this->findPageURLByPageIdCRE($pageId, $location_id)[0]['page_url'];
                      } */
                    $notes_array = $this->Cre->operationOnUrlProfileNotes($location_id, "select", array("url" => $url, "offset" => $offset, "limit" => $limit));
                    if (count($notes_array) > 0) {
                        $NotesDataArray = array();
                        foreach ($notes_array as $index => $value) {

                            $userProfile = $this->getUserDetails(intval($value['created_by']))[0];
                            $date = date_create($value['created']);
                            array_push($NotesDataArray, array(
                                "location_id" => $value['location_id'],
                                "notes" => $value['notes'],
                                "keyword" => $value['keyword'],
                                "created_by" => $userProfile['fname'] . " " . $userProfile['lname'],
                                "created" => date_format($date, 'jS F Y g:ia')
                            ));
                        }

                        $this->json(1, "notes found", $NotesDataArray);
                    } else {
                        $this->json(0, "no notes available");
                    }
                } else {

                    $this->json(0, "invalid token", array("valid token" => "required"));
                }
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* function to start CRE Target Pages */

    public function startTargetPagesCRE() {

        $this->autoRender = false;
        $this->json(1, $this->getTargetPages(''));
    }

    // CRE method for single page analysis 
    public function runSinglePageCRE() {

        $this->autoRender = false;

        $url = isset($_REQUEST['page_url']) ? trim($_REQUEST['page_url']) : "";

        if (!empty($url)) {

            $location_id = isset($_REQUEST['location_id']) ? intval($_REQUEST['location_id']) : 0;
            $webType = isset($_REQUEST['type']) ? trim($_REQUEST['type']) : "fullweb";

            $page_id = isset($_REQUEST['page_id']) ? intval($_REQUEST['page_id']) : 0;

            if ($location_id > 0 && $page_id > 0) {

                $analysedData = $this->startPageAnalysis($url, $location_id, $webType);
                
                if ($this->updateCREUrls($analysedData, $location_id, $page_id)) {

                    $this->notifyamin("Page Run Test", "Page run successfully with url '" . $url . "'");
                }
            }
        }
    }

    // get CRE History
    public function getCREHistoryData() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
            $limit = isset($_GET['limit']) ? trim($_GET['limit']) : $this->limit;

            if ($this->is_token_valid()) {

                $tokendetail = $this->fetchTokenDetails($token);
                $user_id = $tokendetail['user_id'];
                $location_id = $tokendetail['location_id'];

                if (empty($location_id)) {

                    $this->json(0, "location_id is empty", array("location_id" => "required"));
                }

                $this->json(1, "history found", $this->getCREHistory($location_id, $limit, $offset));
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* trigger single page cre to run */

    public function triggerSinglePageCRE() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $pageId = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;
            $token = $this->request->header("token");

            if (!empty($token)) {

                if ($this->is_token_valid()) {

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];
                    $url = '';
                    /* limiting condition to run maximum of 10 pages */
                    if (count($this->countURLsRunningPages($location_id)) > CRE_SINGLE_MAX_RUN) {
                        $this->json(0, "maximum 10 pages run at a time", array("page limit exceeded"));
                    }

                    if (count($this->findPageURLByPageIdCRE($pageId, $location_id)) > 0) {
                        $url = $this->findPageURLByPageIdCRE($pageId, $location_id)[0]['page_url'];
                    }
                    if (!empty($url)) {

                        // check dynamically created favicon            
                        $url_website = $this->getLocationUrlById($location_id);

                        if (!empty($url_website)) {

                            $url_website = $this->appendhttp($url_website);
                            $parseurl = parse_url($url_website);
                            $baseurl = $parseurl['host'];
                            $serviceurl = 'http://icons.better-idea.org/allicons.json';
                            $returndata = @file_get_contents($serviceurl . '?' . 'url=' . $baseurl);
                            $returndata = json_decode($returndata);
                            $faviconurl = 0;
                            if (isset($returndata->icons[0]->url) && $returndata->icons[0]->url != '') {
                                $faviconurl = $returndata->icons[0]->url;
                            }

                            $hasfavicon = $this->get_user_meta($location_id, 'webfavicon');

                            if (empty($hasfavicon)) {

                                $this->add_user_meta($location_id, 'webfavicon', $faviconurl);
                            } else {

                                $this->update_user_meta($location_id, 'webfavicon', $faviconurl);
                            }
                        }

                        $this->notifyamin("Single Page Run Test", "Page Started to run of url '" . $url . "'");
                        // firing single page run by silent post
                        $this->silent_post(array(
                            "location_id" => $location_id,
                            "page_url" => $url,
                            "page_id" => $pageId,
                            "type" => "fullweb"
                                ), $this->getSilentPostPath() . "cre/runSinglePageCRE"
                        );
                        $this->json(1, "url started to run");
                    } else {

                        $this->json(0, "invalid id", array("id" => "required"));
                    }
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* cre home page search console data */

    public function showLocationConsoleScore() {

        $this->autoRender = false;
        $token = $this->request->header("token");

        if (!empty($token)) {

            if ($this->is_token_valid()) {

                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];

                $data = json_decode(file_get_contents('php://input'));

                $url_website = $this->getLocationUrlById($location_id);

                $search_urls = $this->calculateSearchConsoleMetrics($location_id, "front_page", '', $url_website);

                $urlGaData = $this->getUrlGaData($url_website, $location_id, "front")[0];

                $search_values = array();
                $total_clicks = 0;
                $total_impressions = 0;
                $final_ctr = 0;
                $keywords = array();
                if (count($search_urls) > 0) {

                    foreach ($search_urls as $index => $value) {

                        $total_clicks += $value->clicks;
                        $total_impressions = $value->impressions;
                    }

                    if ($total_impressions > 0) {

                        $final_ctr = round(($total_clicks / $total_impressions) / 100, 2);
                    }
                }

                $this->json(1, "search console data", array(
                    "total_ctr" => $final_ctr . "%",
                    "time_on_site" => isset($urlGaData['time_on_site']) ? $this->convertMinutuesSecondsFormat($urlGaData['time_on_site']) : 0,
                    "bounce_rate" => isset($urlGaData['total_BounceRate']) ? $this->PerSentFormat(($urlGaData['total_BounceRate'] / $urlGaData['total_visit']) * 100) . "%" : '0%'
                ));
            }
        }
    }

    public function calculateSearchConsoleMetrics($location_id, $type, $url, $location_url = '', $limit = 20, $offset = 0) {

        $this->autoRender = false;

        // search in tbl_options table

        if (!empty($this->get_user_meta($location_id, "search_console_data"))) {
            //print_r($this->get_user_meta($location_id, "search_console_data")); die;
            $results = $this->connection
                    ->execute("SELECT updated FROM tbl_options WHERE location_id = " . $location_id . " and option_key = 'search_console_data'")
                    ->fetchAll('assoc');

            $curTimestamp = date("Y-m-d");
            $lastTimestamp = date("Y-m-d", strtotime($results[0]['updated']));

            if ($lastTimestamp == $curTimestamp) {
                $search_urls = json_decode($this->get_user_meta($location_id, "search_console_data"));
            } else {

                $credentials = $this->public->getSearchToken($location_id);
                if (!empty($credentials) && count((array) $credentials) > 0) {
                    $search_urls = $this->public->PullSearchConsoleMetrics(array("location_url" => $location_url, "start_date" => date("Y-m-d", strtotime("-31 days")), "end_date" => date("Y-m-d", strtotime("-1 days")), "limit" => $limit, "offset" => $offset, "refressToken" => $credentials->refresh_token));
                    $this->update_user_meta($location_id, "search_console_data", json_encode($search_urls));
                }
            }
        } else {
            $credentials = $this->public->getSearchToken($location_id);
            if (!empty($credentials) && count((array) $credentials) > 0) {

                $search_urls = $this->public->PullSearchConsoleMetrics(array("location_url" => $location_url, "start_date" => date("Y-m-d", strtotime("-31 days")), "end_date" => date("Y-m-d", strtotime("-1 days")), "limit" => $limit, "offset" => $offset, "refressToken" => $credentials->refresh_token));

                $this->add_user_meta($location_id, "search_console_data", json_encode($search_urls));
            }
        }

        if ($type == "front_page") {
            return $search_urls;
        }

        // search ends here!

        $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $url)), "/");
        $search_values = array();
        $total_clicks = 0;
        $total_impressions = 0;
        $final_ctr = 0;
        $keywords = array();
        if (count($search_urls) > 0) {

            foreach ($search_urls as $index => $value) {

                $sTrim = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $value->url)), "/");

                if (strtolower($sTrim) == strtolower($trimurl)) {

                    array_push($keywords, $value->keyword);

                    array_push($search_values, array(
                        "keyword" => $value->keyword,
                        "clicks" => $value->clicks,
                        "impressions" => $value->impressions,
                        "position" => $value->position,
                        "ctr" => $value->ctr
                    ));

                    $total_clicks += $value->clicks;
                    $total_impressions = $value->impressions;
                }
            }
        }

        if ($total_impressions > 0) {

            $final_ctr = round(($total_clicks / $total_impressions) / 100, 2);
        }


        return array("keywords" => $keywords, "console_data" => $search_values, "ctr" => $final_ctr);
    }

    /* URL Profile Data of CRE */

    public function getURLProfileData() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');

            if ($this->is_token_valid()) {

                $location_id = 0;
                $user_id = 0;

                $data = json_decode(file_get_contents('php://input'));

                $url = isset($data->url) ? trim($data->url) : '';

                $fetch_token = $this->fetchTokenDetails($token);

                $user_id = $fetch_token['user_id'];
                $location_id = $fetch_token['location_id'];

                if ($user_id == 0 && $location_id == 0) {

                    $this->json(0, "invalid token", array("token" => "required"));
                }

                if (empty($url)) {

                    $this->json(0, "invalid url", array("url" => "required"));
                } else {
                    $location_url = $this->getLocationUrlById($location_id);

                    $search_console = $this->calculateSearchConsoleMetrics($location_id, "single_page", $url, $location_url);

                    $search_keywords = $search_console['keywords'];
                    $search_ctr = $search_console['ctr'];
                    $console_data = $search_console['console_data'];

                    $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $url)), "/");
                    $results = $this->connection
                            ->execute("SELECT id,is_running,result,score,modified FROM tbl_cre_urls WHERE created_by = " . $user_id . " AND TRIM(BOTH  '/' FROM REPLACE(REPLACE(REPLACE (url, 'http://', ''),'https://',''),'www.','')) like '$trimurl'")
                            ->fetchAll('assoc');
                    //$this->pr(json_decode($results[0]['result']));

                    $urlGaData = $this->getUrlGaData($url, $location_id)[0];


                    $cre_score = 0;
                    $ov = empty($urlGaData['total_organic']) ? 0 : intval($urlGaData['total_organic']);
                    $oc = 0;
                    $ocon = 0;
                    $pv = empty($urlGaData['total_cpc']) ? 0 : intval($urlGaData['total_cpc']);
                    $pc = 0;
                    $pcon = 0;
                    $rv = empty($urlGaData['total_referral']) ? 0 : intval($urlGaData['total_referral']);
                    $rc = 0;
                    $rcon = 0;
                    $sv = empty($urlGaData['total_social']) ? 0 : intval($urlGaData['total_social']);
                    $sc = 0;
                    $scon = 0;
                    $dv = empty($urlGaData['total_direct']) ? 0 : intval($urlGaData['total_direct']);
                    $dc = 0;
                    $dcon = 0;
                    $tv = empty($urlGaData['total_visit']) ? 0 : intval($urlGaData['total_visit']);
                    $tc = 0;
                    $last_run_date = '';
                    $tcon = 0;
                    $title_issues = 0;
                    $meta_issues = 0;
                    $content_issues = 0;
                    $heading_issues = 0;
                    $link_issues = 0;
                    $image_issues = 0;
                    $page_title = 0;
                    $page_length = 0;
                    $title_relevancy = 0;
                    $meta_title = 0;
                    $meta_length = 0;
                    $meta_relevancy = 0;
                    $meta_tag = 0;
                    $page_size = 0;
                    $total_words = 0;
                    $load_time = 0;
                    $seo_friendly_url = 0;
                    $doctype_available = 0;
                    $text_to_html_ratio = 0;
                    $mobile_friendly = 0;
                    $any_iframe = 0;
                    $canonical_check = 0;
                    $h1 = 0;
                    $h1c = array();
                    $h1_notes_array = '';
                    $h1f = array();
                    $h2 = 0;
                    $h2c = array();
                    $h2_notes_array = '';
                    $h2f = array();
                    $h3 = 0;
                    $h3c = array();
                    $h3_notes_array = '';
                    $h3f = array();
                    $h4 = 0;
                    $h4c = array();
                    $h4_notes_array = '';
                    $h4f = array();
                    $h5 = 0;
                    $h5c = array();
                    $h5_notes_array = '';
                    $h5f = array();
                    $h6 = 0;
                    $h6c = array();
                    $h6_notes_array = '';
                    $h6f = array();
                    $count_headings = 0;
                    $count_internal_links = 0;
                    $count_external_links = 0;
                    $count_broken_links = 0;
                    $links_without_title_attr = 0;
                    $links_without_rel_attribute = 0;
                    $count_images = 0;
                    $fineImages = 0;
                    $missing_alt_tag = 0;
                    $content_occ = 0;
                    $title_occ = 0;
                    $meta_occ = 0;
                    $heading_occ = 0;
                    $overall_density = 0;
                    $all_external_links = array();
                    $all_internal_links = array();
                    $all_broken_links = array();
                    $links_without_title_attr_array = array();
                    $links_without_rel_attribute_array = array();
                    $total_images_array = array();
                    $missing_alt_tag_array = array();
                    $exceed_external_links = 0;
                    $page_breakdown = array();
                    $is_running = 0;
                    $page_id = 0;
                    $missing_alt_tag_data = '';
                    $favicon_icon = '';
                    $favicon_status = 0;

                    $algoValueCalculate = $this->alogoCRErules("select")[0];

                    if (count($results)) {
                        $is_running = $results[0]['is_running'];
                        $page_id = $results[0]['id'];
                        $cre_score = intval($results[0]['score']);
                        $profile = json_decode($results[0]['result']);
                        $last_run_date = $results[0]['modified'];
                        if (!empty($profile)) {

                            $favicon_icon = $profile->favicon_img;
                            $favicon_status = $profile->favicon;

                            if (!empty($profile->issues_count)) {
                                $title_issues = $profile->issues_count->title_issues;
                                $meta_issues = $profile->issues_count->meta_issues;
                                $content_issues = $profile->issues_count->content_issues;
                                $heading_issues = $profile->issues_count->heading_issues;
                                $link_issues = $profile->issues_count->link_issues;
                                $image_issues = $profile->issues_count->image_issues;
                            }
                            if (!empty($profile->title)) {

                                $page_title = $profile->title->title_tag;
                                $page_length = $profile->title->title_length;
                                $title_relevancy = $profile->title->title_relevancy;
                            }
                            if (!empty($profile->desc)) {

                                $meta_title = $profile->desc->is_meta_desc;
                                $meta_length = $profile->desc->desc_length;
                                $meta_relevancy = $profile->desc->desc_relevancy;
                                $meta_tag = $profile->desc->robots_meta_tag;
                            }

                            $page_size = $profile->totalpagesize;
                            $total_words = $profile->content->total_words;
                            $load_time = $profile->validloadtime;
                            $seo_friendly_url = $profile->seo_friendly;
                            $doctype_available = $profile->doctpye;
                            $text_to_html_ratio = $profile->text_ratio;
                            $mobile_friendly = $profile->mobile_friendly;
                            $any_iframe = $profile->iframe;
                            $canonical_check = $profile->canonical_tag;

                            if (!empty($profile->headings)) {

                                $count_headings = $profile->headings->totalheadtags;

                                $h1 = $profile->headings->totalh1;

                                if (isset($profile->headings->h1f)) {
                                    $h1f = $profile->headings->h1f;
                                    $h1_notes_array .= "<span class='sphead'>Below list of H1 tags</span><hr/>";
                                    foreach ($profile->headings->h1f as $h1a) {
                                        $h1_notes_array .= "<div class='htagp'>" . htmlentities("<h1>" . $h1a . "</h1>  Length : " . strlen($h1a) . " characters.") . "</div>";
                                    }
                                }
                                if (isset($profile->headings->h1)) {
                                    $h1c = $profile->headings->h1;
                                    $h1_notes_array .= "<span class='sphead'>Below H1 tags are too long/short. Recommended Length Should between " . $algoValueCalculate['HEADING_LENGTH'] . " characters.</span><hr/>";
                                    foreach ($profile->headings->h1 as $h1t) {
                                        $h1_notes_array .= "<div style='color: red;' class='htagp headrd'>" . htmlentities("<h1>" . $h1t . "</h1>") . "  Length : " . strlen($h1t) . " characters.</div>";
                                    }
                                }

                                $h2 = $profile->headings->totalh2;

                                if (isset($profile->headings->h2f)) {
                                    $h2f = $profile->headings->h2f;
                                    $h2_notes_array .= "<span class='sphead'>Below list of H2 tags</span><hr/>";
                                    foreach ($profile->headings->h2f as $h2a) {
                                        $h2_notes_array .= "<div class='htagp'>" . htmlentities("<h2>" . $h2a . "</h2>") . "  Length : " . strlen($h2a) . " characters.</div>";
                                    }
                                }
                                if (isset($profile->headings->h2)) {
                                    $h2c = $profile->headings->h2;
                                    $h2_notes_array .= "<span class='sphead'>Below H2 tags are too long/short. Recommended Length Should between " . $algoValueCalculate['HEADING_LENGTH'] . " characters.</span><hr/>";
                                    foreach ($profile->headings->h2 as $h2t) {
                                        $h2_notes_array .= "<div style='color: red;' class='htagp headrd'>" . htmlentities("<h2>" . $h2t . "</h2>") . "  Length : " . strlen($h2t) . " characters.</div>";
                                    }
                                }

                                $h3 = $profile->headings->totalh3;
                                if (isset($profile->headings->h3f)) {
                                    $h3_notes_array .= "<span class='sphead'>Below list of H3 tags</span><hr/>";
                                    $h3f = $profile->headings->h3f;
                                    foreach ($profile->headings->h3f as $h3a) {
                                        $h3_notes_array .= "<div class='htagp'>" . htmlentities("<h3>" . $h3a . "</h3>") . "  Length : " . strlen($h3a) . " characters.</div>";
                                    }
                                }
                                if (isset($profile->headings->h3)) {
                                    $h3c = $profile->headings->h3;
                                    $h3_notes_array .= "<span class='sphead'>Below H3 tags are too long/short. Recommended Length Should between " . $algoValueCalculate['HEADING_LENGTH'] . " characters.</span><hr/>";
                                    foreach ($profile->headings->h3 as $h3t) {
                                        $h3_notes_array .= "<div style='color: red;' class='htagp headrd'>" . htmlentities("<h3>" . $h3t . "</h3>") . "  Length : " . strlen($h3t) . " characters.</div>";
                                    }
                                }

                                $h4 = $profile->headings->totalh4;
                                if (isset($profile->headings->h4f)) {
                                    $h4f = $profile->headings->h4f;
                                    $h4_notes_array .= "<span class='sphead'>Below list of H4 tags</span><hr/>";
                                    foreach ($profile->headings->h4f as $h4a) {
                                        $h4_notes_array .= "<div class='htagp'>" . htmlentities("<h4>" . $h4a . "</h4>") . "  Length : " . strlen($h4a) . " characters.</div>";
                                    }
                                }
                                if (isset($profile->headings->h4)) {
                                    $h4c = $profile->headings->h4;
                                    $h4_notes_array .= "<span class='sphead'>Below H4 tags are too long/short. Recommended Length Should between " . $algoValueCalculate['HEADING_LENGTH'] . " characters.</span><hr/>";
                                    foreach ($profile->headings->h4 as $h4t) {
                                        $h4_notes_array .= "<div style='color: red;' class='htagp headrd'>" . htmlentities("<h4>" . $h4t . "</h4>") . "  Length : " . strlen($h4t) . " characters.</div>";
                                    }
                                }

                                $h5 = $profile->headings->totalh5;
                                if (isset($profile->headings->h5f)) {
                                    $h5f = $profile->headings->h5f;
                                    $h5_notes_array .= "<span class='sphead'>Below list of H5 tags.</span><hr/>";
                                    foreach ($profile->headings->h5f as $h5a) {
                                        $h5_notes_array .= "<div class='htagp'>" . htmlentities("<h5>" . $h5a . "</h5>") . "  Length : " . strlen($h5a) . " characters.</div>";
                                    }
                                }
                                if (isset($profile->headings->h5)) {
                                    $h5c = $profile->headings->h5;
                                    $h5_notes_array .= "<span class='sphead'>Below H5 tags are too long/short. Recommended Length Should between " . $algoValueCalculate['HEADING_LENGTH'] . " characters.</span><hr/>";
                                    foreach ($profile->headings->h5 as $h5t) {
                                        $h5_notes_array .= "<div style='color: red;' class='htagp headrd'><h5>" . $h5t . "</h5>  Length : " . strlen($h5t) . " characters.</div>";
                                    }
                                }

                                $h6 = $profile->headings->totalh6;
                                if (isset($profile->headings->h6f)) {
                                    $h6f = $profile->headings->h6f;
                                    $h6_notes_array .= "<span class='sphead'>Below list of H6 tags.</span><hr/>";
                                    foreach ($profile->headings->h6f as $h6a) {
                                        $h6_notes_array .= "<div class='htagp'><h6>" . $h6a . "</h6>  Length : " . strlen($h6a) . " characters.</div>";
                                    }
                                }
                                if (isset($profile->headings->h6)) {
                                    $h6c = $profile->headings->h6;
                                    $h6_notes_array .= "<span class='sphead'>Below H6 tags are too long/short. Recommended Length Should between " . $algoValueCalculate['HEADING_LENGTH'] . " characters.</span><hr/>";
                                    foreach ($profile->headings->h6 as $h6t) {
                                        $h6_notes_array .= "<div style='color: red;' class='htagp headrd'><h6 style='color:red;'>" . $h6t . "</h6>  Length : " . strlen($h6t) . " characters.</div>";
                                    }
                                }
                            }

                            if (!empty($profile->links)) {

                                $count_external_links = count((array) $profile->links->external_links);
                                if (count($profile->links->external_links) > 0) {
                                    foreach ($profile->links->external_links as $ext) {
                                        array_push($all_external_links, $ext);
                                    }
                                }
                                //$all_external_links = $profile->links->external_links;
                                $count_internal_links = count((array) $profile->links->internal_links);
                                if (count($profile->links->internal_links) > 0) {
                                    foreach ($profile->links->internal_links as $ext) {
                                        array_push($all_internal_links, $ext);
                                    }
                                }
                                $count_broken_links = count((array) $profile->links->broken_links);
                                if (count($profile->links->broken_links) > 0) {
                                    foreach ($profile->links->broken_links as $ext) {
                                        array_push($all_broken_links, $ext);
                                    }
                                }
                                $links_without_rel_attribute = count((array) $profile->links->no_rel);
                                if (count($profile->links->no_rel) > 0) {
                                    foreach ($profile->links->no_rel as $ext) {
                                        array_push($links_without_rel_attribute_array, $ext);
                                    }
                                }
                                $links_without_title_attr = count((array) $profile->links->no_title);
                                if (count($profile->links->no_title) > 0) {
                                    foreach ($profile->links->no_title as $ext) {
                                        array_push($links_without_title_attr_array, $ext);
                                    }
                                }
                                $exceed_external_links = $profile->links->exceed_external_links;
                            }

                            if (!empty($profile->images)) {

                                $count_images = $profile->images->total_images;
                                $total_images_array = $profile->images->all_images;
                                $fineImages = intval($profile->images->total_images - count((array) $profile->images->alt_miss));
                                $missing_alt_tag = count((array) $profile->images->alt_miss);
                                if ($missing_alt_tag > 0) {
                                    $missing_alt_tag_data .= "Below " . $missing_alt_tag . " image(s) found with missing alt tag";
                                    foreach ($profile->images->alt_miss as $image) {
                                        $missing_alt_tag_data .= "<br/><a target='_blank' href='$image'>$image</a>";
                                    }
                                }
                                $missing_alt_tag_array = $profile->images->alt_miss;
                            }

                            $page_breakdown = array("html" => $profile->page_size, "css" => $profile->arcss->css_size, "js" => $profile->js->js_size, "image" => $profile->images->img_size);
                        }
                    }


                    //array("key" => "low","value" => 10, "color" => "");

                    $MAX_HEADING_TAGS = 30;
                    $MAX_H1_TAGS = 1;
                    $algorules = $this->alogoCRErules("select")[0];
                    if (count($algorules) > 0) {
                        $MAX_HEADING_TAGS = $algorules['MAX_HEADING_TAGS'];
                        $MAX_H1_TAGS = $algorules['MAX_H1_TAGS'];
                    }


                    $bouncerate = 0;
                    if (isset($urlGaData['total_visit']) && $urlGaData['total_visit'] > 0) {
                        $bouncerate = (($urlGaData['total_BounceRate'] / $urlGaData['total_visit']) * 100);
                    }

                    $urlProfileData = array(
                        "page_id" => intval($page_id),
                        "url" => $url,
                        "page_run" => $last_run_date,
                        "is_running" => intval($is_running),
                        "search_keywords" => $search_keywords,
                        "total_ctr" => $search_ctr,
                        "search_data" => $console_data,
                        "top_section" => array(
                            "cre_score" => $cre_score,
                            "traffic_stats" => array(
                                array(
                                    "name" => "organic",
                                    "visits" => $ov,
                                    "conversions" => $oc,
                                    "conversion_rate" => $ocon
                                ),
                                array(
                                    "name" => "paid",
                                    "visits" => $pv,
                                    "conversions" => $pc,
                                    "conversion_rate" => $pcon
                                ),
                                array(
                                    "name" => "referral",
                                    "visits" => $rv,
                                    "conversions" => $rc,
                                    "conversion_rate" => $rcon
                                ),
                                array(
                                    "name" => "social",
                                    "visits" => $sv,
                                    "conversions" => $sc,
                                    "conversion_rate" => $scon
                                ),
                                array(
                                    "name" => "direct",
                                    "visits" => $dv,
                                    "conversions" => $dc,
                                    "conversion_rate" => $dcon
                                ),
                                array(
                                    "name" => "total",
                                    "visits" => $tv,
                                    "conversions" => 0,
                                    "conversion_rate" => 0
                                )
                            ),
                            "target_keywords" => $this->keyword->getTargetKeywords(array("location_id" => $location_id, "landing_page" => $url)),
                            "seo_link_stats" => array(
                                array("title" => "Exact Match", "value" => 0),
                                array("title" => "Naked", "value" => 0),
                                array("title" => "Syn Match", "value" => 0),
                                array("title" => "Brand Match", "value" => 0),
                                array("title" => "Generic", "value" => 0)
                            )
                        ),
                        "middle_section" => array(
                            "issues_count" => array(
                                "title_issues" => $title_issues,
                                "meta_issues" => $meta_issues,
                                "content_issues" => $content_issues,
                                "heading_issues" => $heading_issues,
                                "link_issues" => $link_issues,
                                "image_issues" => $image_issues
                            ),
                            "performance_section" => array(
                                array("key" => "Time on site", "value" => isset($urlGaData['time_on_site']) ? $this->convertMinutuesSecondsFormat($urlGaData['time_on_site']) : 0, "data_point" => $this->provideSortedDataPoint(2, array("low" => 18, "avg" => 122, "high" => 270, "you" => $urlGaData['time_on_site'])), "notes" => "Time on site is a type of visitor report that provides data on the amount of time (in minutes or seconds) visitors have spent on your website."),
                                array("key" => "Bounce Rate", "value" => isset($urlGaData['total_BounceRate']) && isset($urlGaData['total_visit']) ? $this->PerSentFormat($bouncerate) . "%" : '0%', "data_point" => $this->provideSortedDataPoint(1, array("low" => 25, "avg" => 59, "high" => 89, "you" => $this->PerSentFormat($bouncerate))), "notes" => "A website's bounce rate is perhaps one of the most undervalued metrics of a successful SEO campaign. In general, a bounce rate is the amount of visitors to any given website who navigate off of the site after viewing only one page, typically expressed as a percentage."),
                                array("key" => "Click Through Rate", "value" => $search_ctr . "%", "data_point" => $this->provideSortedDataPoint(1, array("low" => 10, "avg" => 45, "high" => 90, "you" => $search_ctr)), "notes" => "Click-through rate (CTR) is the ratio of users who click on a specific link to the number of total users who view a page, email, or advertisement. It is commonly used to measure the success of an online advertising campaign for a particular website.")
                            ),
                            "page_title" => array(
                                "title" => $page_title,
                                "title_check" => $page_title != '' ? 1 : 0,
                                "title_notes" => "The title is an important factor in the on-site search engine optimization. Not only uses the search engines the title for the keywords, the title is also used for display in the SERP (Search Engine Result Page). For best practice make use of your main keywords in the title.",
                                "title_length" => $page_length,
                                "title_length_check" => isset($profile->title->title_valid) ? $profile->title->title_valid : 0,
                                "title_length_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 8, "avg" => 50, "high" => 74, "you" => $page_length)),
                                    "notes" => "The <TITLE> element provides a short piece of text describing the document. The title is very important as it shows in the window title bars, bookmarks and search results. Title should be between " . $algoValueCalculate['PAGE_TITLE_RANGE'] . "  characters long."
                                ),
                                "title_relevancy" => $title_relevancy,
                                "title_relevancy_check" => isset($profile->title->title_relevant) ? $profile->title->title_relevant : 0,
                                "title_relevancy_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(1, array("low" => 5, "avg" => 86, "high" => 100, "you" => $title_relevancy)),
                                    "notes" => "The title of page should match with content on webpage. Relevancy should minimum " . $algoValueCalculate['TITLE_RELEVANCY'] . " %"
                                )
                            ),
                            "meta_description" => array(
                                "description" => $meta_title,
                                "desc_check" => $meta_title != '' ? 1 : 0,
                                "meta_notes" => "The meta description is an factor in the on-site search engine optimization. Not only uses the search engines the description for the keywords, the description is used frequently for display in the SERP (Search Engine Result Page). For best practice describe where your webpage is about in the description.",
                                "description_length" => $meta_length,
                                "desc_length_check" => isset($profile->desc->desc_valid) ? $profile->desc->desc_valid : 0,
                                "description_length_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 4, "avg" => 119, "high" => 157, "you" => $meta_length)),
                                    "notes" => "Meta Description should between " . $algoValueCalculate['PAGE_DESC_RANGE'] . " characters"
                                ),
                                "relevancy" => $meta_relevancy,
                                "desc_relevancy_check" => isset($profile->desc->desc_relevant) ? $profile->desc->desc_relevant : 0,
                                "relevancy_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(1, array("low" => 2, "avg" => 72, "high" => 100, "you" => $meta_relevancy)),
                                    "notes" => "Description of page should match with content on webpage. Relevancy should minimum " . $algoValueCalculate['DESC_RELEVANCY'] . " %."
                                ),
                                "robots_meta_tag" => $meta_tag,
                                "robots_meta_tag_data" => array(
                                    "notes" => "Spider robots are not allowed to display a title and description from the Open Directory Project in the search results."
                                )
                            ),
                            "page_content" => array(
                                "page_size" => $page_size,
                                "pagesize_check" => isset($profile->pagesizevalid) ? $profile->pagesizevalid : 0,
                                "pagesize_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 22083, "avg" => 1554453, "high" => 2616904, "you" => $total_words)),
                                ),
                                "page_size_notes" => "Page size should in between " . $algoValueCalculate['AVG_PAGE_SIZE'] . " bytes (" . ($algoValueCalculate['AVG_PAGE_SIZE'] / 1024 * 1024) . " MB)",
                                "total_words" => $total_words,
                                "total_words_check" => isset($profile->content->content_valid) ? $profile->content->content_valid : 0,
                                "total_words_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 44, "avg" => 832, "high" => 1902, "you" => $total_words)),
                                    "total_words_notes" => "A webpage must contain at least " . $algoValueCalculate['PAGE_CONTENT_RANGE'] . " words",
                                ),
                                "load_time" => $load_time,
                                "validloadtime_check" => isset($profile->validloadtime) ? $profile->validloadtime : 0,
                                "load_time_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => "0.01", "avg" => 2, "high" => "11.19", "you" => $load_time)),
                                    "load_time_notes" => "Content loading time should between " . $algoValueCalculate['AVG_LOADING_TIME'] . " seconds",
                                ),
                                "seo_friendly_url" => $seo_friendly_url,
                                "seo_friendly_url_notes" => "SEO Friendly URLs are easy to read and understand for crawlers",
                                "doctype_available" => $doctype_available,
                                "doctype_available_notes" => "The <!DOCTYPE> declaration tells the web browser about what version of HTML the page is written in. It is good practice to always add the declaration to the HTML documents, so that the browser knows what type of document to expect.",
                                "text_to_html_ratio" => $text_to_html_ratio,
                                "text_to_html_ratio_check" => isset($profile->valid_ratio) ? $profile->valid_ratio : 0,
                                "text_to_html_ratio_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(1, array("low" => "2.78", "avg" => "28", "high" => "49.24", "you" => $text_to_html_ratio)),
                                    "text_to_html_ration_notes" => "Low Text to HTML ratio indicates little content for search engines to index. We consider it to be good practice to have a Text to HTML ratio of between " . $algoValueCalculate['TEXT_RATIO'] . " %",
                                ),
                                "mobile_friendly" => $mobile_friendly,
                                "mobile_friendly_data" => array(
                                    "mobile_friendly_notes" => "We found META viewport tag on page. this tag control how a webpage is displayed on a mobile device",
                                ),
                                "any_iframe" => $any_iframe == 1 ? 'Iframe found' : 'No Iframe found',
                                "any_iframe_check" => $any_iframe == 1 ? 0 : 1,
                                "any_iframe_data" => array(
                                    "any_iframe_notes" => " It is not recommended to use frames or iframes because they can cause problems for search engines. It is best to avoid frames and inline frames whenever possible."
                                ),
                                "favicon_check" => $favicon_status,
                                "favicon_img" => $favicon_icon,
                                "favicon_data" => array(
                                    "favicon_notes" => "The Favicon is a small icon associated with a website. The Favicon is important because it is displayed next to the website's URL in the address bar of the browser as well as in bookmarks and shortcuts."
                                ),
                                "canonical_check" => $canonical_check,
                                "canonical_data" => array(
                                    "canonical_notes" => "Canonical tag help web-masters to prevent duplicate content issues on page."
                                )
                            ),
                            "page_breakdown" => $page_breakdown,
                            "heading" => array(
                                "heading_tags" => $count_headings,
                                "heading_tags_check" => $count_headings > 0 && $count_headings <= $MAX_HEADING_TAGS ? 1 : 0,
                                "heading_tags_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 1, "avg" => 12, "high" => 25, "you" => $count_headings)),
                                    "h1_tags_notes" => $h1_notes_array
                                ),
                                "heading_tags_notes" => "The search engines uses the heading tags for the keywords. Each page should have at least " . $algoValueCalculate['MAX_H1_TAGS'] . " heading tag. For best practice try not to use more than " . $algoValueCalculate['MAX_HEADING_TAGS'] . " heading tags on a webpage.",
                                "h1_tags" => $h1,
                                "h1_tags_check" => $h1 > 0 && $h1 <= $MAX_HEADING_TAGS ? 1 : 0,
                                "h1_tags_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 1, "avg" => 2, "high" => 3, "you" => $h1)),
                                    "h1_tags_notes" => $h1_notes_array
                                ),
                                "h1" => $h1c,
                                "h1f" => $h1f,
                                "h2_tags" => $h2,
                                "h2_tags_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 1, "avg" => 3, "high" => 9, "you" => $h2)),
                                    "h2_tags_notes" => $h2_notes_array
                                ),
                                "h2" => $h2c,
                                "h2f" => $h2f,
                                "h3_tags" => $h3,
                                "h3_tags_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 1, "avg" => 5, "high" => 11, "you" => $h3)),
                                    "h3_tags_notes" => $h3_notes_array
                                ),
                                "h3" => $h3c,
                                "h3f" => $h3f,
                                "h4_tags" => $h4,
                                "h4_tags_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 1, "avg" => 2, "high" => 5, "you" => $h4)),
                                    "h4_tags_notes" => $h4_notes_array
                                ),
                                "h4" => $h4c,
                                "h4f" => $h4f,
                                "h5_tags" => $h5,
                                "h5_tags_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 1, "avg" => 3, "high" => 9, "you" => $h5)),
                                    "h5_tags_notes" => $h5_notes_array,
                                ),
                                "h5" => $h5c,
                                "h5f" => $h5f,
                                "h6_tags" => $h6,
                                "h6_tags_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 1, "avg" => 5, "high" => 10, "you" => $h6)),
                                    "h6_tag_notes" => $h6_notes_array,
                                ),
                                "h6" => $h6c,
                                "h6f" => $h6f
                            ),
                            "algo_rules" => count($algorules) > 0 ? $algorules : array(),
                            "links" => array(
                                "count_internal_links" => $count_internal_links,
                                "all_external_links" => $all_external_links,
                                "external_links_check" => isset($profile->links->exceed_external_links) ? $profile->links->exceed_external_links : 0,
                                "all_external_links_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => intval(explode("-", $algoValueCalculate['EXTRANL_LINKS'])[0]), "avg" => 15, "high" => intval(explode("-", $algoValueCalculate['EXTRANL_LINKS'])[1]), "you" => $count_external_links)),
                                    "external_link_notes" => " According to seo, we can not define more than " . $algoValueCalculate['EXTRANL_LINKS'] . " external links",
                                ),
                                "all_internal_links_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 7, "avg" => 15, "high" => 30, "you" => $count_internal_links)),
                                    "internal_link_notes" => "",
                                ),
                                "all_internal_links" => $all_internal_links,
                                "all_broken_links" => $all_broken_links,
                                "broken_links_check" => $count_broken_links > 0 ? 0 : 1,
                                "all_broken_links_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 7, "avg" => 15, "high" => 30, "you" => $count_broken_links)),
                                    "broken_link_notes" => "Broken Links may have a negative effect on seo. Please fix or remove these links",
                                ),
                                "links_without_title_attr_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 7, "avg" => 15, "high" => 30, "you" => $links_without_title_attr)),
                                    "links_without_title_attr_notes" => "Title attribute does not have direct impact on ranking. But is can influence click behavior for users, which can indirectly affect SEO",
                                ),
                                "links_without_title_check" => isset($profile->links->no_title) && count((array) ($profile->links->no_title)) <= 0 ? 1 : 0,
                                "links_without_rel_attribute_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 7, "avg" => 15, "high" => 30, "you" => $links_without_rel_attribute)),
                                    "links_without_rel_attr_notes" => "The REL no-follow attribute helps with SEO position because it tells search engines not to conflict multiple links coming from the same site with organic linking.",
                                ),
                                "links_without_rel_check" => isset($profile->links->no_rel) && count((array) ($profile->links->no_rel)) <= 0 ? 1 : 0,
                                "count_broken_links" => $count_broken_links,
                                "links_without_title_attr_array" => $links_without_title_attr_array,
                                "links_without_rel_attr_array" => $links_without_rel_attribute_array,
                                "links_without_title_attr" => $links_without_title_attr,
                                "links_without_rel_attribute" => $links_without_rel_attribute,
                                "exceed_external_links" => $exceed_external_links
                            ),
                            "images" => array(
                                "count_images" => $count_images,
                                "images_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 7, "avg" => 15, "high" => 30, "you" => $count_images)),
                                    "image_notes" => "The 'alt' attribute provides a text equivalent for the image. If the browser cannot display an image the alt description will be given in its place. Furthermore, some visitors cannot see images as they might be blind in which the alt tag provides a valuable image description. Finally, search engines utilize the alt attribute for image search indexing.",
                                ),
                                "all_images" => $total_images_array,
                                "total_imges_check" => $fineImages > 0 ? 1 : 0,
                                "fine_images" => $fineImages,
                                "missing_alt_tag" => $missing_alt_tag,
                                "alt_imges_check" => $missing_alt_tag == 0 ? 1 : 0,
                                "missing_alt_tag_data" => array(
                                    "data_point" => $this->provideSortedDataPoint(0, array("low" => 7, "avg" => 15, "high" => 30, "you" => $missing_alt_tag)),
                                    "missing_alt_tag_notes" => $missing_alt_tag_data,
                                ),
                                "missing_alt_tag_array" => $missing_alt_tag_array,
                            ),
                            "primary_keyword" => array(),
                            "discovered_keywords" => array(
                                array(
                                    "keyword" => "design web development",
                                    "content" => array(
                                        "content" => 1,
                                        "occurrence" => 3,
                                        "density" => 0
                                    ),
                                    "title" => array(
                                        "title" => 1,
                                        "occurrence" => 3,
                                        "density" => 0
                                    ),
                                    "meta_description" => array(
                                        "meta_description" => 0,
                                        "occurrence" => 3,
                                        "density" => 0
                                    ),
                                    "heading_tags" => array(
                                        "heading_tags" => 1,
                                        "occurrence" => 3,
                                        "density" => 0
                                    ),
                                    "overall_density" => array(
                                        "overall_density" => 1,
                                        "density" => 0
                                    )
                                )
                            )
                        )
                    );

                    $this->json(1, "data found", $urlProfileData);
                }
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* function to save algo for cre */

    public function alogoCRErules($type) {

        $this->autoRender = false;
        $cre_algo_tbl = TableRegistry::get('tbl_cre_algovals');
        $query = $cre_algo_tbl->query();

        if ($type == "insert") {

            $credata = array(
                "PAGE_TITLE_RANGE" => "60 - 70",
                "KEYWORD_TITLE_DENSITY" => "2 - 3",
                "PAGE_DESC_RANGE" => "150 - 160",
                'KEYWORD_DESC_DENSITY' => '2 - 3',
                'HEADING_LENGTH' => '1 - 50',
                'PAGE_CONTENT_RANGE' => '500',
                'KEYWORD_CONTENT_DENSITY' => '2 - 3',
                'EXTRANL_LINKS' => '1 - 6',
                'AVG_PAGE_SIZE' => '1 - 1048576',
                'AVG_LOADING_TIME' => '0 - 2',
                'TITLE_RELEVANCY' => 1,
                'DESC_RELEVANCY' => 1,
                'TEXT_RATIO' => "10 - 20",
                'IDCRE' => 0,
                'OVERALL_KEY_DENSITY' => 3,
                'OVERALL_PRIMARY_DENSITY' => 5,
                'MAX_HEADING_TAGS' => 30,
                'MAX_H1_TAGS' => 1
            );

            if ($query->insert(['version_no', 'credata', 'created', 'created_by'])
                            ->values(
                                    [
                                        'version_no' => 1,
                                        'credata' => json_encode($credata),
                                        'created' => date("Y-m-d H:i:s"),
                                        'created_by' => 1
                                    ]
                            )
                            ->execute()) {
                return true;
            }
            return false;
        } else if ($type == "select") {

            $crealgo_data_array = array();

            $results = $query->find('all', array('order' => array('id' => 'DESC')))->toArray();

            if (count($results) > 0) {

                foreach ($results as $index => $data) {
                    $algoValues = json_decode($data->credata);
                    array_push($crealgo_data_array, array(
                        "PAGE_TITLE_RANGE" => $algoValues->PAGE_TITLE_RANGE,
                        "KEYWORD_TITLE_DENSITY" => $algoValues->KEYWORD_TITLE_DENSITY,
                        "PAGE_DESC_RANGE" => $algoValues->PAGE_DESC_RANGE,
                        "KEYWORD_DESC_DENSITY" => $algoValues->KEYWORD_DESC_DENSITY,
                        "HEADING_LENGTH" => $algoValues->HEADING_LENGTH,
                        "PAGE_CONTENT_RANGE" => $algoValues->PAGE_CONTENT_RANGE,
                        "KEYWORD_CONTENT_DENSITY" => $algoValues->KEYWORD_CONTENT_DENSITY,
                        "EXTRANL_LINKS" => $algoValues->EXTRANL_LINKS,
                        "AVG_PAGE_SIZE" => $algoValues->AVG_PAGE_SIZE,
                        "AVG_LOADING_TIME" => $algoValues->AVG_LOADING_TIME,
                        "TITLE_RELEVANCY" => $algoValues->TITLE_RELEVANCY,
                        "DESC_RELEVANCY" => $algoValues->DESC_RELEVANCY,
                        "TEXT_RATIO" => $algoValues->TEXT_RATIO,
                        "IDCRE" => $algoValues->IDCRE,
                        "OVERALL_KEY_DENSITY" => $algoValues->OVERALL_KEY_DENSITY,
                        "OVERALL_PRIMARY_DENSITY" => $algoValues->OVERALL_PRIMARY_DENSITY,
                        "MAX_HEADING_TAGS" => $algoValues->MAX_HEADING_TAGS,
                        "MAX_H1_TAGS" => $algoValues->MAX_H1_TAGS
                    ));
                }
            }

            return $crealgo_data_array;
        }
    }

    //================== Supportive Functions =================================================

    /* Save target urls to cre_urls table */

    /* function to update cre_urls table */

    public function updateCREUrls($data = array(), $location_id, $pageId) {

        $creUrls = TableRegistry::get('tbl_cre_urls');

        $results = $creUrls->find("all", [
                    'conditions' => ['location_id' => $location_id, 'is_running' => 1, 'id' => $pageId]
                ])->all()->toArray();

        if (count($results) > 0):

            $query = $creUrls->query();
            if ($query->update()
                            ->set(
                                    [
                                        'result' => json_encode($data),
                                        'total_issues' => $data['total_issues'],
                                        'total_title_issues' => $data['issues_count']['title_issues'],
                                        'total_meta_issues' => $data['issues_count']['meta_issues'],
                                        'total_content_issues' => $data['issues_count']['content_issues'],
                                        'total_heading_issues' => $data['issues_count']['heading_issues'],
                                        'total_link_issues' => $data['issues_count']['link_issues'],
                                        'total_image_issues' => $data['issues_count']['image_issues'],
                                        'is_running' => 0,
                                        'score' => $data['score'],
                                        'modified' => date("Y-m-d H:i:s")
                                    ]
                            )
                            ->where(['location_id' => $location_id, 'id' => $pageId])
                            ->execute()) {

                $this->updateQueueProcessedStatus($location_id, $pageId);

                return true;
            } else {
                return false;
            }

        endif;
    }

    public function updateQueueProcessedStatus($location_id = 0, $page_id = 0) {

        $processData = $this->updateCREQueueProccessed($location_id, "select", array("location_id" => $location_id));
        $pageIds = array();
        $pgeId = $page_id;

        foreach ($processData[0]['processed'] as $index => $data) {
            if ($data != $pgeId) {
                array_push($pageIds, $data);
            }
        }

        if ($this->updateCREQueueProccessed($location_id, "updateProccess", array("processed" => json_encode($pageIds), "location_id" => $location_id))) {
            // saved to cre_queue to process data
            @mail("sanjay@rudrainnovatives.com", "Page Id Removed from cre_queue", "Page Id :" . json_encode($pgeId) . " Updated Data Array: " . json_encode($pageIds));
        }
    }

    public function tableCREOperation($location_id, $queryType, $dataF = array()) {

        $creUrls = TableRegistry::get('tbl_cre');

        $query = $creUrls->query();

        $cre_data_array = array();

        if ($queryType == "updateTrigger") {
            // update query
            if ($query->update()
                            ->set(
                                    [
                                        'trigger_report' => $dataF['trigger_report'],
                                        'modified' => $dataF['modified']
                                    ]
                            )
                            ->where(['location_id' => $dataF['location_id']])
                            ->execute()) {
                return true;
            }
            return false;
        } else if ($queryType == "selectStatus") {
            // select query

            $crequeue_data_array = array();

            $results = $creUrls->find("all", [
                        'conditions' => ['location_id' => $dataF['location_id']]
                    ])->all()->toArray();

            if (count($results) > 0) {

                foreach ($results as $index => $data) {

                    array_push($crequeue_data_array, array(
                        "trigger_report" => $data->trigger_report
                    ));
                }
            }

            return $crequeue_data_array;
        } else if ($queryType == "countTriggerRow") {
            // select query

            $crequeue_data_array = array();

            $results = $creUrls->find("all", [
                        'conditions' => ['location_id' => $dataF['location_id']]
                    ])->all()->toArray();

            if (count($results) > 0) {
                return true;
            }
            return false;
        } else if ($queryType == "insertTrigger") {

            $query->insert(['type', 'location_id', 'crawl_result', 'trigger_report', 'rundate', 'created', 'created_by'])
                    ->values(
                            [
                                'type' => $dataF['type'],
                                'location_id' => $dataF['location_id'],
                                'crawl_result' => $dataF['crawl_result'],
                                'trigger_report' => $dataF['trigger_report'],
                                'rundate' => date("Y-m-d H:i:s"),
                                'created' => date("Y-m-d H:i:s"),
                                'created_by' => $dataF['created_by']
                            ]
                    )
                    ->execute();
            return true;
        }
    }

    public function updateCREQueueProccessed($location_id, $queryType, $dataF = array()) {

        $creUrls = TableRegistry::get('tbl_cre_queue');

        $cre_data_array = array();

        if ($queryType == "updateProccess") {
            // update query

            $query = $creUrls->query();

            if ($query->update()
                            ->set(
                                    [
                                        'processed' => $dataF['processed']
                                    ]
                            )
                            ->where(['location_id' => $dataF['location_id']])
                            ->execute()) {
                return true;
            }
            return false;
        } else if ($queryType == "select") {
            // select query

            $crequeue_data_array = array();

            $results = $creUrls->find("all", [
                        'conditions' => ['location_id' => $dataF['location_id']]
                    ])->all()->toArray();

            if (count($results) > 0) {

                foreach ($results as $index => $data) {

                    array_push($crequeue_data_array, array(
                        "processed" => json_decode($data->processed)
                    ));
                }
            }

            return $crequeue_data_array;
        }
    }

    public function updateCREUrlsTable($location_id) {

        $targetPagesArray = $this->getKeygroupLandingPages($location_id);

        if ($this->SaveTargetPagesToCREUrls($targetPagesArray, $location_id)) {

            return true;
        } else {

            return false;
        }
    }

    public function getKeygroupLandingPages($location_id) {

        $targetPages = TableRegistry::get('tbl_keygroup');

        $results = $targetPages->find("all", [
                    'conditions' => ['location_id' => $location_id, 'status' => 1]
                ])->all()->toArray();
        $targetPagesArray = array();

        foreach ($results as $page):

            array_push($targetPagesArray, $page->landing_page);

        endforeach;

        return $targetPagesArray;
    }

    public function SaveTargetPagesToCREUrls($targetPagesArray = array(), $location_id) {

        $CREUrlsPages = TableRegistry::get('tbl_cre_urls');

        foreach ($targetPagesArray as $pageUrl) {

            $query = $CREUrlsPages->query();

            $results = $CREUrlsPages->find("all", [
                        'conditions' => ['location_id' => $location_id, 'url' => $pageUrl]
                    ])->all()->toArray();

            if (count($results) > 0):

                $query->update()
                        ->set(
                                [
                                    'is_running' => 1,
                                    'created' => date("Y-m-d H:i:s"),
                                    'modified' => date("Y-m-d H:i:s")
                                ]
                        )
                        ->where(['location_id' => $location_id, 'url' => $pageUrl])
                        ->execute();

            else:

                $query->insert(['url', 'location_id', 'is_running', 'rundate', 'created'])
                        ->values(
                                [
                                    'url' => $pageUrl,
                                    'location_id' => $location_id,
                                    'is_running' => 1,
                                    'rundate' => date("Y-m-d H:i:s"),
                                    'created' => date("Y-m-d H:i:s")
                                ]
                        )
                        ->execute();
            endif;
        }
        return true;
    }

    public function updateCREQueueLastRunningPageIndex($location_id, $current_last_id, $next_index) {

        $this->autoRender = false;
        $CREUrlQueue = TableRegistry::get('tbl_cre_queue');

        $results = $CREUrlQueue->find("all", [
                    'conditions' => ['location_id' => $location_id]
                ])->all()->toArray();
        if (count($results) > 0) {

            $query = $CREUrlQueue->query();

            $query->update()
                    ->set(
                            [
                                'next_index' => $next_index,
                                'current_last_id' => $current_last_id,
                                'updated_dt' => date("Y-m-d H:i:s")
                            ]
                    )
                    ->where(['location_id' => $location_id])
                    ->execute();

            return true;
        }
        return false;
    }

    public function are_cre_urls_exists($location_id) {

        $CREUrlsPages = TableRegistry::get('tbl_cre_urls');

        $results = $CREUrlsPages->find("all", [
                    'conditions' => ['location_id' => $location_id]
                ])->all()->toArray();

        if (count($results) > 0):
            return true;
        else:
            return false;
        endif;
    }

    public function makeCREHistory($location_id, $type) {

        $this->autoRender = false;

        $totalurls = 0;
        $totalurlissue = 0;
        $total_score_val = 0;
        $title = 0;
        $meta = 0;
        $content = 0;
        $heading = 0;
        $link = 0;
        $image = 0;
        $rundate = date("Y-m-d H:i:s");
        $user_trigger = 1;
        $avgscore = 0;

        $CREUrlsPages = TableRegistry::get('tbl_cre_urls');

        $results = $CREUrlsPages->find("all", [
                    'conditions' => ['location_id' => $location_id, 'is_running' => 0, 'total_issues IS NOT' => null]
                ])->all()->toArray();

        $targetPages = $this->getKeygroupLandingPages($location_id);
        $issues = "";
        
        if (count($results) > 0) {

            foreach ($results as $index => $rowvaldata) {

                $key = $rowvaldata->id;

                if (in_array($rowvaldata->url, $targetPages) && $type == "allpage") {
                    continue;
                } else if (!in_array($rowvaldata->url, $targetPages) && $type == "targetpage") {
                    continue;
                }

                $row = json_decode($rowvaldata->result);

                if (count($row) > 0) {

                    $title = $title + $row->issues_count->title_issues;
                    $meta = $meta + $row->issues_count->meta_issues;
                    $content = $content + $row->issues_count->content_issues;
                    $heading = $heading + $row->issues_count->heading_issues;
                    $link = $link + $row->issues_count->link_issues;
                    $image = $image + $row->issues_count->image_issues;
                    $totalurlissue += $row->issues_count->title_issues + $row->issues_count->meta_issues +
                            $row->issues_count->content_issues + $row->issues_count->heading_issues +
                            $row->issues_count->link_issues + $row->issues_count->image_issues;


                    $total_score_val = $total_score_val + $row->score;
                }

                $totalurls++;
            }
            
            $issues = array();
            $issues['title'] = $title;
            $issues['meta'] = $meta;
            $issues['content'] = $content;
            $issues['heading'] = $heading;
            $issues['link'] = $link;
            $issues['image'] = $image;
            $issues = json_encode($issues);
            if ($totalurls != 0) {
                $avgscore = round(($total_score_val / $totalurls), 2);
            }
        }        

        $CREUrlsPages = TableRegistry::get('tbl_cre_history');

        $query = $CREUrlsPages->query();

        $query->insert(['type', 'location_id', 'totalurls', 'totalissues', 'issues_detail', 'avg_score', 'rundate', 'created'])
                ->values(
                        [
                            'type' => $type,
                            'location_id' => $location_id,
                            'totalurls' => $totalurls,
                            'totalissues' => $totalurlissue,
                            'issues_detail' => $issues,
                            'avg_score' => $avgscore,
                            'rundate' => date("Y-m-d H:i:s"),
                            'created' => date("Y-m-d H:i:s")
                        ]
                )
                ->execute();

        return true;
    }

    public function getCREHistory($location_id, $limit, $offset) {

        $CREUrlsPages = TableRegistry::get('tbl_cre_history');

        $results = $CREUrlsPages->find("all", [
                    'conditions' => ['location_id' => $location_id],
                    'limit' => $limit,
                    'offset' => $offset
                ])->all()->toArray();

        $row_count = $CREUrlsPages->find("all", [
                    'conditions' => ['location_id' => $location_id]
                ])->all()->toArray();

        $creHistory = array();

        if (count($results) > 0) {

            foreach ($results as $index => $history) {
                array_push($creHistory, array(
                    "history_id" => $history->id,
                    "type" => $history->type,
                    "totalurls" => $history->totalurls,
                    "totalissues" => $history->totalissues,
                    "issues_detail" => json_decode($history->issues_detail),
                    "avg_score" => $history->avg_score,
                    "rundate" => $history->rundate,
                    "created" => $history->created
                ));
            }
        }
        return array("total_count" => count($row_count), "history_data" => $creHistory);
    }

    // function gives all target pages based on logged in user_id 
    public function getTargetPages($token) {

        $this->autoRender = false;

        $target_pages = $this->Cre->alltargetpages(array("token" => $token), new AppController());

        return $target_pages;
    }
    
    public function user_agent(){
        $agents = array(        
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.7; rv:7.0.1) Gecko/20100101 Firefox/7.0.1',
            'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.1.9) Gecko/20100508 SeaMonkey/2.0.4',
            'Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; en-US)',
            'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; da-dk) AppleWebKit/533.21.1 (KHTML, like Gecko) Version/5.0.5 Safari/533.21.1'

        );
        return $agents[array_rand($agents)];
    }
    public function startPageAnalysis($url, $location_id, $runtype) {

        $this->autoRender = false;

        $analysis_array = array();

        if (empty($url))
            return $analysis_array;

        $url = $this->appendhttp($url);

        $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $url)), "/");

        if ($runtype == 'fullweb') {

            $dataFound = $this->getCRECacheData($location_id, $url, "select");
            if (!empty($dataFound)) {
                if (!empty($dataFound[0]['data_array'])) {
                    $dataFound = $dataFound[0]['data_array'];
                    return $dataFound;
                }
            }
        }

        $partsurl = parse_url($url);
        $baseurl = '';
        if (isset($partsurl['scheme']) && isset($partsurl['host'])) {
            $baseurl = $partsurl['scheme'] . '://' . $partsurl['host'];
        }

        $score = 0;
        $pagespreed = 0;
        $step = 0;
        $stepass = 0;
        $mobile = 0;
        $text_ratio = 0;
        $title_issues = 0;
        $meta_issues = 0;
        $content_issues = 0;
        $heading_issues = 0;
        $link_issues = 0;
        $image_issues = 0;
        $totalpagesize = 0;
        $total_issues = 0;
        $keyword = '';
        $site_url = $url;
        $timeload = 0;
        
        $opts = [
            "http" => [
                "method" => "GET",
                "header" => "Accept-language: en\r\n" .
                    "Referer: http://www.enfusen.com\r\n".
                    "User-Agent: ".$this->user_agent()."\r\n"
                ]
        ];

        $context = stream_context_create($opts);
        
        $time1 = microtime(true);
        $html = file_get_contents($url, false, $context);
        $time2 = microtime(true);

        $onlybody = new DOMDocument();
        $mockbody = new DOMDocument;
        $mockbody->preserveWhiteSpace = false;

        $onlybody->loadHTML($html);
        $bodydata = $onlybody->getElementsByTagName('body');
        $bodydata = $bodydata->item(0);
        foreach ($bodydata->childNodes as $child) {
            $mockbody->appendChild($mockbody->importNode($child, true));
        }

        $this->removeElementsByTagName('script', $mockbody);
        $this->removeElementsByTagName('style', $mockbody);
        $this->removeElementsByTagName('noscript', $mockbody);
        $this->removeElementsByTagName('header', $mockbody);
        $this->removeElementsByTagName('footer', $mockbody);

        $onlybodyhtml = $mockbody->saveHTML();
        $onlybodyhtml = $this->remove_html_comments($onlybodyhtml);

        $totalstrlength = strlen($onlybodyhtml);
        $remintext = $this->strip_html_tags($onlybodyhtml);
        $remintextlength = strlen($remintext);
        $text_ratio = round(( $remintextlength / $totalstrlength ) * 100, 2);

        $rang = explode("-", TEXT_RATIO);
        $min = isset($rang[0]) ? trim($rang[0]) : 10; // %
        $max = isset($rang[1]) ? trim($rang[1]) : 20; // %
        $valid_ratio = 0;
        if ($text_ratio >= $min && $text_ratio <= $max) {
            $valid_ratio = 1;
            $stepass++;
        } else {
            $total_issues++;
            $content_issues++;
        }
        $step++;

        $pagesize = $this->get_remote_size($location_id, $url, $runtype);
        $pagestatus = $this->get_remote_status($location_id, $url, $runtype);
        $fulltimeload = $time2 - $time1; // in seconds    
        $timeload = $fulltimeload;

        $validloadtime = 0;
        if ($pagespreed > 0) {
            $timeload = $pagespreed;
        }

        $lotime = floatval($timeload);

        $rang = explode("-", AVG_LOADING_TIME);
        $min = isset($rang[0]) ? trim($rang[0]) : 0; // words
        $max = isset($rang[1]) ? trim($rang[1]) : 5; // words
        if ($lotime >= $min && $lotime <= $max) {
            $validloadtime = 1;
            $stepass++;
        } else {
            $total_issues++;
            $content_issues++;
        }
        $step++;

        $dom = new DOMDocument;
        $dom->loadHTML($html);
        $dom->preserveWhiteSpace = false;
        $arr = array(
            'keyword' => $keyword,
            'url' => $url,
            'base_url' => $baseurl,
            'validloadtime' => $validloadtime,
            'text_ratio' => $text_ratio,
            'valid_ratio' => $valid_ratio,
            'pagestatus' => $pagestatus,
            'idrcre' => IDCRE
        );

        $arphrase = array();
        $keywords = array();
        $contentdata = array();
        $onlycontentwords = '';
        if ($keyword == '') {
            $bodydom = new DOMDocument();
            $bodydom->loadHTML($html);

            $this->removeElementsByTagName('script', $bodydom);
            $this->removeElementsByTagName('noscript', $bodydom);
            $this->removeElementsByTagName('style', $bodydom);
            $this->removeElementsByTagName('head', $bodydom);
            $fullbodyhtml = $bodydom->saveHtml(); // old $databodyhtml = $bodydom->saveHtml();         
            $databodyhtml = $onlybodyhtml;

            $encoding = $this->get_header_encoding($location_id, $url, $runtype);

            $bodaydata = iconv($encoding, "utf-8", $databodyhtml);

            $bodaydata = $onlycontentwords = $this->strip_html_tags($bodaydata);
            $bodaydata = htmlentities($bodaydata, ENT_QUOTES, "UTF-8");
            $datatargetkeywords = array();
        }

        $arr['page_speed'] = $timeload; // in micro seconds

        $arr['page_size'] = $totalpagesize = $pagesize; // size in bytes        

        if (isset($partsurl['query']) && $partsurl['query'] != '') {
            $arr['seo_friendly'] = 0;
            $total_issues++;
            $content_issues++;
        } else {
            $arr['seo_friendly'] = 1;
            $stepass++;
        }
        $step++;

        // check doc type
        $arr['doctpye'] = 0;
        $doctype = '<!DOCTYPE';
        if (strpos(strtolower($html), strtolower($doctype)) !== false) {
            $arr['doctpye'] = 1;
            $stepass++;
        } else {
            $total_issues++;
            $content_issues++;
        }
        $step++;

        // check if body data calcluateed or not
        if (isset($bodaydata) && trim($bodaydata) != '') {

            $bodydom = new DOMDocument;
            $bodydom->loadHTML($html);

            $this->removeElementsByTagName('script', $bodydom);
            $this->removeElementsByTagName('noscript', $bodydom);
            $this->removeElementsByTagName('style', $bodydom);
            $this->removeElementsByTagName('head', $bodydom);
            $fullbodyhtml = $databodyhtml = $bodydom->saveHtml();

            $encoding = $this->get_header_encoding($location_id, $url, $runtype);
            $bodaydata = iconv($encoding, "utf-8", $databodyhtml);

            $bodaydata = $onlycontentwords = $this->strip_html_tags($bodaydata);
            $bodaydata = htmlentities($bodaydata, ENT_QUOTES, "UTF-8");
        }

        $totalwords = str_word_count($bodaydata);

        $arcontent = array(
            'total_words' => $totalwords
        );

        // check iframe
        $iframe = '<iframe';
        $arr['iframe'] = 0;
        if (strpos(strtolower($fullbodyhtml), strtolower($iframe)) !== false) {
            $arr['iframe'] = 1;
            $total_issues++;
            $content_issues++;
        } else {
            $stepass++;
        }
        $step++;

        $arcontent['content_valid'] = 0;
        if ($totalwords >= PAGE_CONTENT_RANGE) {
            $arcontent['content_valid'] = 1;
            $stepass++;
        } else {
            $total_issues++;
            $content_issues++;
        }
        $step++;
        if ($keyword != '') {
            $resocuur = $this->fnd_pos(strtolower($keyword), strtolower($bodaydata));
            $total_occr = $Nkr = count($resocuur);
            $arcontent['keyword_available_content'] = $total_occr;
        }

        if ($keyword != '') {
            $Tkn = str_word_count(strtolower($bodaydata));
            $Density = ($Nkr / $Tkn) * 100;

            $rang = explode("-", $KEYWORD_CONTENT_DENSITY);
            $min = isset($rang[0]) ? trim($rang[0]) : 2; // %
            $max = isset($rang[1]) ? trim($rang[1]) : 3; // %

            if ($Density < $min || $Density > $max) {
                $total_issues++;
                $content_issues++;
            } else {
                $stepass++;
            }
            $step++;
            $arcontent['content_key_density'] = round($Density, 2) . '%';
        }

        $arr['content'] = $arcontent;

        $artitle = array();
        $title = $dom->getElementsByTagName('title');
        $artitle['title_tag'] = 0;

        if ($title->length > 0) {

            $artitle['title_tag'] = 1;
            $title = trim($title->item(0)->nodeValue);
            $artitle['title'] = $title;
            $rang = explode("-", PAGE_TITLE_RANGE);
            $min = isset($rang[0]) ? trim($rang[0]) : 1;
            $max = isset($rang[1]) ? trim($rang[1]) : 70;
            $titlelen = strlen($title);
            $artitle['title_valid'] = 0;
            $artitle['title_length'] = $titlelen;
            if ($titlelen >= $min && $titlelen <= $max) {
                $artitle['title_valid'] = 1;
                $stepass++;
            } else {
                $total_issues++;
                $title_issues++;
            }
            $step++;
            $artitle['title_relevant'] = 0;

            // relevancy new code        
            $titlewords = $this->getLongTailKeywords($title, 1, 0);
            $totaltitlewords = count($titlewords);
            $matchtitlecont = 0;
            foreach ($titlewords as $key => $a) {
                $foundtitlekey = $this->fnd_pos(strtolower($key), strtolower($onlycontentwords));
                if (!empty($foundtitlekey)) {
                    $matchtitlecont++;
                }
            }
            $percent = (($matchtitlecont / $totaltitlewords) * 100);
            $percent = round($percent, 2);
            // relevancy new code                

            $artitle['title_relevancy'] = $percent;
            // relevancy fine if grater than 50%
            if ($percent >= TITLE_RELEVANCY) {
                $artitle['title_relevant'] = 1;
                $stepass++;
            } else {
                $total_issues++;
                $title_issues++;
            }
            $step++;
            $artitle['title_key_density'] = "0";

            $rang = explode("-", KEYWORD_TITLE_DENSITY);
            $min = isset($rang[0]) ? trim($rang[0]) : 2; // %
            $max = isset($rang[1]) ? trim($rang[1]) : 3; // %  

            $Tkn = str_word_count(strtolower($title));

            if (strpos(strtolower($title), strtolower($keyword)) !== false) {

                $resocuur = $this->fnd_pos(strtolower($keyword), strtolower($title));
                $total_occr = $Nkr = count($resocuur);
                $artitle['keyword_available_title'] = $total_occr;

                if ($keyword != '') {
                    $Density = ($Nkr / $Tkn) * 100;
                    if ($Density < $min || $Density > $max) {
                        $total_issues++;
                        $title_issues++;
                    } else {
                        $stepass++;
                    }
                    $step++;
                    $artitle['title_key_density'] = round($Density, 2) . '%';
                }
            }

            if ($keyword == '') {
                $newar = array();
                foreach ($keywords as $key => $keyw) {
                    $resocuur = $this->fnd_pos(strtolower($key), strtolower($title));
                    $Nkr = count($resocuur);
                    $Density = ($Nkr / $Tkn) * 100;
                    $density = round($Density, 2) . '%';
                    $add_total_issue = 0;
                    $add_content_issue = 0;
                    if ($Density < $min || $Density > $max) {
                        $add_total_issue = 1;
                        $add_content_issue = 1;
                    }
                    $keywords["$key"]['title'] = array('occurence' => $Nkr, 'density' => $density, 'Nkr' => $Nkr, 'Tkn' => $Tkn,
                        'add_total_issue' => $add_total_issue, 'add_content_issue' => $add_content_issue);
                }
            }
        }
        $arr['title'] = $artitle;
        $ardesc = array();

        $ardesc['is_meta_desc'] = 0;
        $description = '';
        $ardesc['robots_meta_tag'] = 0;
        $duplicatemetadesc = 0;
        $metas = $dom->getElementsByTagName('meta');

        for ($i = 0; $i < $metas->length; $i++) {

            $meta = $metas->item($i);

            if ($meta->getAttribute('name') == 'description') {
                $ardesc['is_meta_desc'] = 1;
                $description = $meta->getAttribute('content');
                $rang = explode("-", PAGE_DESC_RANGE);
                $min = isset($rang[0]) ? trim($rang[0]) : 150;
                $max = isset($rang[1]) ? trim($rang[1]) : 160;
                $ardesc['desc_valid'] = 0;
                $desclen = strlen($description);
                $ardesc['desc_length'] = $desclen;
                if ($desclen >= $min && $desclen <= $max) {
                    $ardesc['desc_valid'] = 1;
                    $stepass++;
                } else {
                    $total_issues++;
                    $meta_issues++;
                }
                $step++;
                $ardesc['desc_relevant'] = 0;
                $percent = 0;
                $descwords = $this->getLongTailKeywords($description, 1, 0);
                $totaldescwords = count($descwords);
                $matchdesccont = 0;
                foreach ($descwords as $key => $a) {
                    $founddesckey = $this->fnd_pos(strtolower($key), strtolower($onlycontentwords));
                    if (!empty($founddesckey)) {
                        $matchdesccont++;
                    }
                }
                $percent = (($matchdesccont / $totaldescwords) * 100);
                $percent = round($percent, 2);

                $ardesc['desc_relevancy'] = $percent;
                // relevancy fine if grater than 50%
                if ($percent >= DESC_RELEVANCY) {
                    $ardesc['desc_relevant'] = 1;
                    $stepass++;
                } else {
                    $total_issues++;
                    $meta_issues++;
                }
                $step++;
                $ardesc['desc_key_density'] = "0";
                $Tkn = str_word_count(strtolower($description));
                $rang = explode("-", KEYWORD_DESC_DENSITY);
                $min = isset($rang[0]) ? trim($rang[0]) : 2; // %
                $max = isset($rang[1]) ? trim($rang[1]) : 3; // %

                if (strpos(strtolower($description), strtolower($keyword)) !== false) {

                    $resocuur = $this->fnd_pos(strtolower($keyword), strtolower($description));
                    $total_occr = $Nkr = count($resocuur);
                    $ardesc['keyword_available_desc'] = $total_occr;

                    if ($keyword != '') {
                        $Density = ($Nkr / $Tkn) * 100;
                        if ($Density < $min || $Density > $max) {
                            $total_issues++;
                            $meta_issues++;
                        } else {
                            $stepass++;
                        }
                        $step++;
                        $ardesc['desc_key_density'] = round($Density, 2) . '%';
                    }
                }

                if ($keyword == '') {
                    $newar = array();
                    foreach ($keywords as $key => $keyw) {
                        $resocuur = $this->fnd_pos(strtolower($key), strtolower($description));
                        $Nkr = count($resocuur);
                        $Density = ($Nkr / $Tkn) * 100;
                        $density = round($Density, 2) . '%';
                        $add_total_issue = 0;
                        $add_content_issue = 0;
                        if ($Density < $min || $Density > $max) {
                            $add_total_issue = 1;
                            $add_content_issue = 1;
                        }
                        $keywords["$key"]['desc'] = array('occurence' => $Nkr, 'density' => $density, 'Nkr' => $Nkr, 'Tkn' => $Tkn,
                            'add_total_issue' => $add_total_issue, 'add_content_issue' => $add_content_issue);
                    }
                }

                $duplicatemetadesc++;
            }

            // in case description empty
            foreach ($keywords as $key => $keyw) {
                if ($description == '') {
                    $keywords["$key"]['desc'] = array('occurence' => 0);
                }
            }

            if ($meta->getAttribute('name') == 'robots') {
                $ardesc['robots_meta_tag'] = 1;
            }

            if ($meta->getAttribute('name') == 'viewport') {
                $mobile = 1;
            }
        }

        $arr['mobile_friendly'] = 1;
        if ($mobile == 0) {
            $ardesc['mobile_friendly'] = 0;
            $total_issues++;
            $content_issues++;
        } else {
            $stepass++;
        }
        $step++;

        if ($duplicatemetadesc >= 2) {
            $ardesc['duplicate_meta_desc'] = 1;
            $total_issues++;
            $meta_issues++;
        } else {
            $ardesc['duplicate_meta_desc'] = 0;
            $stepass++;
        }
        $step++;

        if ($ardesc['robots_meta_tag'] == 0) {
            $total_issues++;
            $meta_issues++;
        } else {
            $stepass++;
        }
        $step++;

        $ardesc['meta_desc'] = $description;

        $arr['desc'] = $ardesc;

        $rang = explode("-", HEADING_LENGTH);
        $min = isset($rang[0]) ? trim($rang[0]) : 1;
        $max = isset($rang[1]) ? trim($rang[1]) : 120;
        $keyexistheader = 0;
        $arrheadings = array();

        $h1s = $mockbody->getElementsByTagName('h1');
        $arrheadings['totalh1'] = $h1s->length;
        $newar = array();
        $headingocuur = array();
        for ($i = 0; $i < $h1s->length; $i++) {
            $htext = $h1s->item($i)->nodeValue;
            if (strpos(strtolower($htext), strtolower($keyword)) !== false) {
                $arrheadings['h1_keyword'][] = $htext;
                $keyexistheader++;
            }
            $lenstr = strlen($htext);
            if ($lenstr < $min || $lenstr > $max) {
                $arrheadings['h1'][] = $htext;
                $heading_issues++;
                $total_issues++;
            } else {
                $arrheadings['h1f'][] = $htext;
                $stepass++;
            }
            $step++;
            $headingocuur[] = $htext;
        }

        $h2s = $mockbody->getElementsByTagName('h2');
        $arrheadings['totalh2'] = $h2s->length;
        for ($i = 0; $i < $h2s->length; $i++) {
            $htext = $h2s->item($i)->nodeValue;
            $lenstr = strlen($htext);

            if (strpos(strtolower($htext), strtolower($keyword)) !== false) {
                $arrheadings['h2_keyword'][] = $htext;
                $keyexistheader++;
            }

            if ($lenstr < $min || $lenstr > $max) {
                $arrheadings['h2'][] = $htext;
                $heading_issues++;
                $total_issues++;
            } else {
                $arrheadings['h2f'][] = $htext;
                $stepass++;
            }
            $step++;

            $headingocuur[] = $htext;
        }

        $h3s = $mockbody->getElementsByTagName('h3');
        $arrheadings['totalh3'] = $h3s->length;

        for ($i = 0; $i < $h3s->length; $i++) {
            $htext = $h3s->item($i)->nodeValue;
            $lenstr = strlen($htext);
            if (strpos(strtolower($htext), strtolower($keyword)) !== false) {
                $arrheadings['h3_keyword'][] = $htext;
                $keyexistheader++;
            }
            if ($lenstr < $min || $lenstr > $max) {
                $arrheadings['h3'][] = $htext;
                $heading_issues++;
                $total_issues++;
            } else {
                $arrheadings['h3f'][] = $htext;
                $stepass++;
            }
            $step++;
            $headingocuur[] = $htext;
        }

        $h4s = $mockbody->getElementsByTagName('h4');
        $arrheadings['totalh4'] = $h4s->length;

        for ($i = 0; $i < $h4s->length; $i++) {
            $htext = $h4s->item($i)->nodeValue;
            $lenstr = strlen($htext);
            if (strpos(strtolower($htext), strtolower($keyword)) !== false) {
                $arrheadings['h4_keyword'][] = $htext;
                $keyexistheader++;
            }
            if ($lenstr < $min || $lenstr > $max) {
                $arrheadings['h4'][] = $htext;
                $heading_issues++;
                $total_issues++;
            } else {
                $arrheadings['h4f'][] = $htext;
                $stepass++;
            }
            $step++;
            $headingocuur[] = $htext;
        }

        $h5s = $mockbody->getElementsByTagName('h5');
        $arrheadings['totalh5'] = $h5s->length;

        for ($i = 0; $i < $h5s->length; $i++) {
            $htext = $h5s->item($i)->nodeValue;
            $lenstr = strlen($htext);
            if (strpos(strtolower($htext), strtolower($keyword)) !== false) {
                $arrheadings['h5_keyword'][] = $htext;
                $keyexistheader++;
            }
            if ($lenstr < $min || $lenstr > $max) {
                $arrheadings['h5'][] = $htext;
                $heading_issues++;
                $total_issues++;
            } else {
                $arrheadings['h5f'][] = $htext;
                $stepass++;
            }
            $step++;
            $headingocuur[] = $htext;
        }

        $h6s = $mockbody->getElementsByTagName('h6');
        $arrheadings['totalh6'] = $h6s->length;

        for ($i = 0; $i < $h6s->length; $i++) {
            $htext = $h6s->item($i)->nodeValue;
            $lenstr = strlen($htext);
            if (strpos(strtolower($htext), strtolower($keyword)) !== false) {
                $arrheadings['h6_keyword'][] = $htext;
                $keyexistheader++;
            }
            if ($lenstr < $min || $lenstr > $max) {
                $arrheadings['h6'][] = $htext;
                $heading_issues++;
                $total_issues++;
            } else {
                $arrheadings['h6f'][] = $htext;
                $stepass++;
            }
            $step++;
            $headingocuur[] = $htext;
        }

        $step++;
        if ($arrheadings['totalh1'] > MAX_H1_TAGS) {
            $heading_issues++;
            $total_issues++;
        } else {
            $stepass++;
        }


        //$MAX_HEADING_TAGS    
        $totalheadtags = $arrheadings['totalh1'] + $arrheadings['totalh2'] + $arrheadings['totalh3'] + $arrheadings['totalh4'] +
                $arrheadings['totalh5'] + $arrheadings['totalh6'];

        $step++;
        $arrheadings['totalheadtags'] = $totalheadtags;
        if ($totalheadtags > MAX_HEADING_TAGS) {
            $heading_issues++;
            $total_issues++;
        } else {
            $stepass++;
        }

        if ($keyword == '') {

            foreach ($keywords as $key => $keyw) {
                $totalheadingocuur = 0;
                foreach ($headingocuur as $headi) {

                    $resocuur = $this->fnd_pos(strtolower($key), strtolower($headi));

                    $cntNkr = count($resocuur);
                    if ($cntNkr > 0) {
                        $totalheadingocuur++;
                    }
                }

                $keywords["$key"]['headings'] = array('occurence' => $totalheadingocuur);
            }
            $arr['keywords'] = $keywords;
        } else {
            $arrheadings['keyword_in_headings'] = $keyexistheader;
            if ($keyexistheader <= 0) {
                $total_issues++;
                $heading_issues++;
            } else {
                $stepass++;
            }
            $step++;
        }

        $arr['headings'] = $arrheadings;

        $arr['canonical_tag'] = 0;
        $arr['favicon'] = 0;
        $arcss = array();
        $css_size = 0;
        $canonicaltag = $dom->getElementsByTagName('link'); // rel canonical tag available in only full html

        for ($i = 0; $i < $canonicaltag->length; $i++) {

            $canonical_tag = $canonicaltag->item($i);
            if ($canonical_tag->getAttribute('rel') == 'canonical') {
                $arr['canonical_tag'] = 1;
            }
            if ($canonical_tag->getAttribute('type') == 'text/css' || $canonical_tag->getAttribute('rel') == 'stylesheet') {
                $csslink = $canonical_tag->getAttribute('href');
                if ($baseurl != '') {
                    $csslink = $this->reltoabs($csslink, $baseurl);
                }
                $time1 = microtime(true);
                $cssize = $this->get_remote_size($location_id, $csslink, $runtype);
                $time2 = microtime(true);
                $fulltimeload = $fulltimeload + ($time2 - $time1);

                $css_size = $css_size + $cssize;
                $arcss[] = $csslink;
            }
            if ($canonical_tag->getAttribute('rel') == 'shortcut' || $canonical_tag->getAttribute('rel') == 'shortcut icon' || $canonical_tag->getAttribute('rel') == 'icon') {
                if ($arr['favicon'] != 1) {
                    $arr['favicon'] = 1;
                    $arr['favicon_img'] = $baseurl != "" ? $this->reltoabs($canonical_tag->getAttribute('href'), $baseurl) : $canonical_tag->getAttribute('href');
                }
            }
        }

        if ($arr['favicon'] == 0) {
            $favicon = $this->get_user_meta($location_id, 'webfavicon');
            if ($favicon != '' && $favicon != 0) {
                $arr['favicon'] = 1;
                $arr['favicon_img'] = $favicon;
            }
        }

        if ($arr['favicon'] == 0) {
            $faiconurl = $baseurl . '/favicon.ico';
            $faiconexisst = $this->urlexist($faiconurl);
            if ($faiconexisst == 1) {
                $arr['favicon'] = 1;
                $arr['favicon_img'] = $faiconurl;
            }
        }

        if ($arr['canonical_tag'] == 0) {
            $total_issues++;
            $content_issues++;
        } else {
            $stepass++;
        }
        $step++;
        if ($arr['favicon'] == 0) {
            $total_issues++;
            $content_issues++;
        } else {
            $stepass++;
        }
        $step++;

        // internal css
        $arintenalcss = array();
        $internalcss = $dom->getElementsByTagName('style');

        for ($i = 0; $i < $internalcss->length; $i++) {
            $internalcsstag = $internalcss->item($i);
            //$arintenalcss[] =  $internalcsstag->nodeValue;
            $cssize = mb_strlen($internalcsstag->nodeValue, '8bit');
            $css_size = $css_size + $cssize;
        }

        $arcss['css_size'] = $css_size;
        $arcss['internal_css'] = $arintenalcss;
        $totalpagesize = $totalpagesize + $css_size;
        $arr['arcss'] = $arcss;

        // check js
        $js = $dom->getElementsByTagName('script');
        $arexternaljs = array();
        $arinlinejs = array();
        $js_size = 0;
        for ($i = 0; $i < $js->length; $i++) {
            $js_tag = $js->item($i);
            if ($js_tag->getAttribute('src') != '') {
                $jslink = $js_tag->getAttribute('src');
                if ($baseurl != '') {
                    $jslink = $this->reltoabs($jslink, $baseurl);
                }
                $time1 = microtime(true);
                $jsize = $this->get_remote_size($location_id, $jslink, $runtype);
                $time2 = microtime(true);
                $fulltimeload = $fulltimeload + ($time2 - $time1);

                $js_size = $js_size + $jsize;
                $arexternaljs[] = $jslink;
            } else {
                //$arinlinejs[] =  $js_tag->nodeValue;
                $jsize = mb_strlen($js_tag->nodeValue, '8bit');
                $js_size = $js_size + $jsize;
            }
        }
        $totalpagesize = $totalpagesize + $js_size;

        $arpagejs = array(
            'external_js' => $arexternaljs,
            'inline_js' => $arinlinejs,
            'js_size' => $js_size
        );

        $arr['js'] = $arpagejs;

        // check img alt tag

        $imgtag = $mockbody->getElementsByTagName('img'); // images check from only body (excluding header and footer)
        $arimg = array(
            'total_images' => $imgtag->length
        );

        $emptysrc = 0;
        $img_sz = 0;

        for ($i = 0; $i < $imgtag->length; $i++) {

            $img_tag = $imgtag->item($i);
            if ($img_tag->getAttribute('src') != '') {
                $imgsrc = $img_tag->getAttribute('src');
                if ($baseurl != '') {
                    $imgsrc = $this->reltoabs($imgsrc, $baseurl);
                }
                $time1 = microtime(true);
                $imgsize = $this->get_remote_size($location_id, $imgsrc, $runtype);
                $time2 = microtime(true);
                $fulltimeload = $fulltimeload + ($time2 - $time1);

                $img_sz = $img_sz + $imgsize;
                $arimg['all_images'][] = $imgsrc;
                $stepass++;
            } else if ($img_tag->getAttribute('src') == '') {
                $emptysrc++;
                $total_issues++;
                $image_issues++;
            }
            $step++;

            if ($img_tag->getAttribute('alt') == '') {
                $src = $img_tag->getAttribute('src');
                $arurls1 = parse_url(strtolower($src));
                if (!isset($arurls1['host'])) {
                    $arurls = parse_url(strtolower($site_url));
                    if ($arurls1['path'] != '') {
                        $src = $arurls['host'] . $src;
                        $src = $this->appendhttp($src);
                    }
                }

                $arimg['alt_miss'][] = $src;
                $total_issues++;
                $image_issues++;
            } else {
                $stepass++;
            }
            $step++;
        }

        // if no image found
        if ($arimg['total_images'] == 0) {
            $total_issues++;
            $image_issues++;
        } else {
            $stepass++;
        }
        $step++;
        // if no image found

        $totalpagesize = $totalpagesize + $img_sz;
        $arimg['empty_src'] = $emptysrc;
        $arimg['img_size'] = $img_sz;
        $arr['images'] = $arimg;

        // check anchors, external links, anchors

        $atag = $mockbody->getElementsByTagName('a');
        $ancar = array();

        for ($i = 0; $i < $atag->length; $i++) {
            $anc_ar = $atag->item($i);
            if ($anc_ar->getAttribute('href') == '') {
                $ancar['empty_links'][] = '';
            } else {
                // rel and title tag

                if ($anc_ar->getAttribute('title') == '') {
                    $ancar['no_title'][] = $baseurl != '' ? $this->reltoabs($anc_ar->getAttribute('href'), $baseurl) : $anc_ar->getAttribute('href');
                }

                if ($anc_ar->getAttribute('rel') == '') {
                    $ancar['no_rel'][] = $baseurl != '' ? $this->reltoabs($anc_ar->getAttribute('href'), $baseurl) : $anc_ar->getAttribute('href');
                }
                $arurls = parse_url(strtolower($site_url));

                $href = $baseurl != '' ? $this->reltoabs($anc_ar->getAttribute('href'), $baseurl) : $anc_ar->getAttribute('href');
                $hashhref = explode("#", $href);
                if (count($hashhref) > 1) {
                    $href = $hashhref[0];
                }
                $arurls1 = parse_url(strtolower($href));
                $relativepath = 0;
                if (!isset($arurls1['host'])) {
                    // if path is relative
                    if ($arurls1['path'] != '') {
                        $relativepath = 1;
                        $arurls1['host'] = $arurls['host'];
                    }
                }

                if (isset($arurls['host']) && isset($arurls1['host'])) {

                    $url1 = str_replace(array("http://", "https://"), array("", ""), $arurls['host']);
                    $url1 = str_replace("www.", " ", $url1);
                    $url2 = str_replace(array("http://", "https://"), array("", ""), $arurls1['host']);
                    $url2 = str_replace("www.", " ", $url2);
                    if ($url1 != $url2) {
                        $ancar['external_links'][] = $baseurl != '' ? $this->reltoabs($href, $baseurl) : $href;
                    } else {
                        if ($relativepath == 1) {

                            $proto = isset($arurls['scheme']) ? trim($arurls['scheme']) : '';
                            if ($proto == '') {
                                $proto = 'http';
                            }
                            $href = $proto . '://' . $arurls['host'] . $arurls1['path'];
                        }
                        $ancar['internal_links'][] = $href;
                    }

                    //Broken Links Code - Temp disabled
                    $sts = $this->get_remote_status($location_id, $href, $runtype); //urlbroken($href);
                    if ($sts == 404) {
                        $ancar['broken_links'][] = $href;
                    }
                }
            }
        }

        $ancar['external_links'] = array_unique($ancar['external_links']);
        $ancar['internal_links'] = array_unique($ancar['internal_links']);

        if (isset($ancar['external_links']) && count($ancar['external_links']) > 0) {
            //CHECK $EXTRANL_LINKS        
            $rang = explode("-", EXTRANL_LINKS);
            $min = isset($rang[0]) ? trim($rang[0]) : 1;
            $max = isset($rang[1]) ? trim($rang[1]) : 6;
            $total_exlinks = count($ancar['external_links']);
            if ($total_exlinks < $min || $total_exlinks > $max) {
                $ancar['exceed_external_links'] = 1;
                $stepass++;
            } else {
                $ancar['exceed_external_links'] = 0;
                $total_issues++;
                $link_issues++;
            }
            $step++;
        }

        $ancar['no_title'] = array_unique($ancar['no_title']);
        $ancar['no_rel'] = array_unique($ancar['no_rel']);
        $ancar['empty_links'] = array_unique($ancar['empty_links']);
        $ancar['broken_links'] = array_unique($ancar['broken_links']);

        $ancar['no_title'] = array_unique($ancar['no_title']);
        if (isset($ancar['no_title']) && !empty($ancar['no_title'])) {
            $total_issues++;
            $link_issues++;
        } else {
            $stepass++;
        }
        $step++;
        $ancar['no_rel'] = array_unique($ancar['no_rel']);
        if (isset($ancar['no_rel']) && !empty($ancar['no_rel'])) {
            $total_issues++;
            $link_issues++;
        } else {
            $stepass++;
        }
        $step++;
        if (isset($ancar['empty_links']) && !empty($ancar['empty_links'])) {
            $total_issues++;
            $link_issues++;
        } else {
            $stepass++;
        }
        $step++;
        if (isset($ancar['broken_links']) && !empty($ancar['broken_links'])) {
            $total_issues++;
            $link_issues++;
        } else {
            $stepass++;
        }
        $step++;
        $arr['links'] = $ancar;
        $arr['totalpagesize'] = $totalpagesize;
        $arr['pagesizevalid'] = 0;
        $rang = explode("-", AVG_PAGE_SIZE);
        $min = isset($rang[0]) ? trim($rang[0]) : 1; // 1 byte
        $max = isset($rang[1]) ? trim($rang[1]) : 1048576; // 1 mb
        if ($totalpagesize >= $min && $totalpagesize <= $max) {
            $arr['pagesizevalid'] = 1;
            $stepass++;
        } else {
            $total_issues++;
            $content_issues++;
        }
        $step++;
        $arr['total_issues'] = $total_issues;
        $arr['fulltimeload'] = $fulltimeload;

        $arrissuecount = array(
            'title_issues' => $title_issues,
            'meta_issues' => $meta_issues,
            'content_issues' => $content_issues,
            'heading_issues' => $heading_issues,
            'link_issues' => $link_issues,
            'image_issues' => $image_issues
        );

        $arr['issues_count'] = $arrissuecount;
        $arr['step'] = $step;
        $arr['stepass'] = $stepass;

        if ($score == 0) {
            $score = round(($stepass / $step) * 100);
        }

        // miniumu score
        if ($score < 50) {
            $score = 50;
        }

        $arr['score'] = $score;

        // if not exist add in db cache

        if ($runtype == 'fullweb') {

            $dataFound = $this->getCRECacheData($location_id, $url, "select");

            if (!empty($dataFound)) {
                // update
                $dataArray = $dataFound[0]['data_array'];
                $id = $dataFound[0]['data_id'];

                $this->getCRECacheData($location_id, $url, "update", array("result" => serialize($arr), "id" => $id));
            } else {

                // insert
                $this->getCRECacheData($location_id, $url, "insert", array("url" => $trimurl, "result" => serialize($arr), "location_id" => $location_id));
            }
        }

        $this->notifyamin("CRE urls", "single page analysis " . json_encode($arr));

        return $arr;

        // if not exist add in db cache
        /* } else {
          $this->json(0, "silence is golden");
          } */
    }

    public function reltoabs($rel, $base) {
        //check if https
        $basehttp = explode("https", $base);
        $ishttps = 0;
        if (count($basehttp) > 1) {
            $ishttps = 1;
        }
        if (strpos(strtolower($rel), strtolower("www.")) !== false) {
            if (parse_url($rel, PHP_URL_SCHEME) == '') {
                $rel = $this->appendhttp($rel);
            }
            return $rel;
        }
        /* return if already absolute URL */

        if (parse_url($rel, PHP_URL_SCHEME) != '')
            return $rel;

        /* queries and anchors */
        if ($rel[0] == '#' || $rel[0] == '?')
            return $base . $rel;

        /* parse base URL and convert to local variables:
          $scheme, $host, $path */
        $path = parse_url($base);
        if ($ishttps == 1)
            $scheme = isset($path['scheme']) ? $path['scheme'] : 'http';
        else
            $scheme = isset($path['scheme']) ? $path['scheme'] : 'https';

        $rel = trim($rel, "/");
        /* absolute URL is ready! */
        return $scheme . '://' . $path['host'] . "/$rel";
    }

    public function getLongTailKeywords($str, $len = 3, $min = 2) {
        $keywords = array();
        $str = str_replace("|", " | ", $str);
        //$common = array('i', 'a', 'about', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'com', 'de', 'en', 'for', 'from', 'how', 'in', 'is', 'it', 'la', 'of', 'on', 'or', 'that', 'the', 'this', 'to', 'was', 'what', 'when', 'where', 'who', 'will', 'with', 'und', 'the', 'www');
        $common = array('a', 'able', 'about', 'above', 'abroad', 'according', 'accordingly', 'across', 'actually', 'adj', 'after', 'afterwards', 'again', 'against', 'ago', 'ahead', 'ain\'t', 'all', 'allow', 'allows', 'almost', 'alone', 'along', 'alongside', 'already', 'also', 'although', 'always', 'am', 'amid', 'amidst', 'among', 'amongst', 'an', 'and', 'another', 'any', 'anybody', 'anyhow', 'anyone', 'anything', 'anyway', 'anyways', 'anywhere', 'apart', 'appear', 'appreciate', 'appropriate', 'are', 'aren\'t', 'around', 'as', 'a\'s', 'aside', 'ask', 'asking', 'associated', 'at', 'available', 'away', 'awfully', 'b', 'back', 'backward', 'backwards', 'be', 'became', 'because', 'become', 'becomes', 'becoming', 'been', 'before', 'beforehand', 'begin', 'behind', 'being', 'believe', 'below', 'beside', 'besides', 'best', 'better', 'between', 'beyond', 'both', 'brief', 'but', 'by', 'c', 'came', 'can', 'cannot', 'cant', 'can\'t', 'caption', 'cause', 'causes', 'certain', 'certainly', 'changes', 'clearly', 'c\'mon', 'co', 'co.', 'com', 'come', 'comes', 'concerning', 'consequently', 'consider', 'considering', 'contain', 'containing', 'contains', 'corresponding', 'could', 'couldn\'t', 'course', 'c\'s', 'currently', 'd', 'dare', 'daren\'t', 'definitely', 'described', 'despite', 'did', 'didn\'t', 'different', 'directly', 'do', 'does', 'doesn\'t', 'doing', 'done', 'don\'t', 'down', 'downwards', 'during', 'e', 'each', 'edu', 'eg', 'eight', 'eighty', 'either', 'else', 'elsewhere', 'end', 'ending', 'enough', 'entirely', 'especially', 'et', 'etc', 'even', 'ever', 'evermore', 'every', 'everybody', 'everyone', 'everything', 'everywhere', 'ex', 'exactly', 'example', 'except', 'f', 'fairly', 'far', 'farther', 'few', 'fewer', 'fifth', 'first', 'five', 'followed', 'following', 'follows', 'for', 'forever', 'former', 'formerly', 'forth', 'forward', 'found', 'four', 'from', 'further', 'furthermore', 'g', 'get', 'gets', 'getting', 'given', 'gives', 'go', 'goes', 'going', 'gone', 'got', 'gotten', 'greetings', 'h', 'had', 'hadn\'t', 'half', 'happens', 'hardly', 'has', 'hasn\'t', 'have', 'haven\'t', 'having', 'he', 'he\'d', 'he\'ll', 'hello', 'help', 'hence', 'her', 'here', 'hereafter', 'hereby', 'herein', 'here\'s', 'hereupon', 'hers', 'herself', 'he\'s', 'hi', 'him', 'himself', 'his', 'hither', 'hopefully', 'how', 'howbeit', 'however', 'hundred', 'i', 'i\'d', 'ie', 'if', 'ignored', 'i\'ll', 'i\'m', 'immediate', 'in', 'inasmuch', 'inc', 'inc.', 'indeed', 'indicate', 'indicated', 'indicates', 'inner', 'inside', 'insofar', 'instead', 'into', 'inward', 'is', 'isn\'t', 'it', 'it\'d', 'it\'ll', 'its', 'it\'s', 'itself', 'i\'ve', 'j', 'just', 'k', 'keep', 'keeps', 'kept', 'know', 'known', 'knows', 'l', 'last', 'lately', 'later', 'latter', 'latterly', 'least', 'less', 'lest', 'let', 'let\'s', 'like', 'liked', 'likely', 'likewise', 'little', 'look', 'looking', 'looks', 'low', 'lower', 'ltd', 'm', 'made', 'mainly', 'make', 'makes', 'many', 'may', 'maybe', 'mayn\'t', 'me', 'mean', 'meantime', 'meanwhile', 'merely', 'might', 'mightn\'t', 'mine', 'minus', 'miss', 'more', 'moreover', 'most', 'mostly', 'mr', 'mrs', 'much', 'must', 'mustn\'t', 'my', 'myself', 'n', 'name', 'namely', 'nd', 'near', 'nearly', 'necessary', 'need', 'needn\'t', 'needs', 'neither', 'never', 'neverf', 'neverless', 'nevertheless', 'new', 'next', 'nine', 'ninety', 'no', 'nobody', 'non', 'none', 'nonetheless', 'noone', 'no-one', 'nor', 'normally', 'not', 'nothing', 'notwithstanding', 'novel', 'now', 'nowhere', 'o', 'obviously', 'of', 'off', 'often', 'oh', 'ok', 'okay', 'old', 'on', 'once', 'one', 'ones', 'one\'s', 'only', 'onto', 'opposite', 'or', 'other', 'others', 'otherwise', 'ought', 'oughtn\'t', 'our', 'ours', 'ourselves', 'out', 'outside', 'over', 'overall', 'own', 'p', 'particular', 'particularly', 'past', 'per', 'perhaps', 'placed', 'please', 'plus', 'possible', 'presumably', 'probably', 'provided', 'provides', 'q', 'que', 'quite', 'qv', 'r', 'rather', 'rd', 're', 'really', 'reasonably', 'recent', 'recently', 'regarding', 'regardless', 'regards', 'relatively', 'respectively', 'right', 'round', 's', 'said', 'same', 'saw', 'say', 'saying', 'says', 'second', 'secondly', 'see', 'seeing', 'seem', 'seemed', 'seeming', 'seems', 'seen', 'self', 'selves', 'sensible', 'sent', 'serious', 'seriously', 'seven', 'several', 'shall', 'shan\'t', 'she', 'she\'d', 'she\'ll', 'she\'s', 'should', 'shouldn\'t', 'since', 'six', 'so', 'some', 'somebody', 'someday', 'somehow', 'someone', 'something', 'sometime', 'sometimes', 'somewhat', 'somewhere', 'soon', 'sorry', 'specified', 'specify', 'specifying', 'still', 'sub', 'such', 'sup', 'sure', 't', 'take', 'taken', 'taking', 'tell', 'tends', 'the', 'th', 'than', 'thank', 'thanks', 'thanx', 'that', 'that\'ll', 'thats', 'that\'s', 'that\'ve', 'the', 'their', 'theirs', 'them', 'themselves', 'then', 'thence', 'there', 'thereafter', 'thereby', 'there\'d', 'therefore', 'therein', 'there\'ll', 'there\'re', 'theres', 'there\'s', 'thereupon', 'there\'ve', 'these', 'they', 'they\'d', 'they\'ll', 'they\'re', 'they\'ve', 'thing', 'things', 'think', 'third', 'thirty', 'this', 'thorough', 'thoroughly', 'those', 'though', 'three', 'through', 'throughout', 'thru', 'thus', 'till', 'to', 'together', 'too', 'took', 'toward', 'towards', 'tried', 'tries', 'truly', 'try', 'trying', 't\'s', 'twice', 'two', 'u', 'un', 'under', 'underneath', 'undoing', 'unfortunately', 'unless', 'unlike', 'unlikely', 'until', 'unto', 'up', 'upon', 'upwards', 'us', 'use', 'used', 'useful', 'uses', 'using', 'usually', 'v', 'value', 'various', 'versus', 'very', 'via', 'viz', 'vs', 'w', 'want', 'wants', 'was', 'wasn\'t', 'way', 'we', 'we\'d', 'welcome', 'well', 'we\'ll', 'went', 'were', 'we\'re', 'weren\'t', 'we\'ve', 'what', 'whatever', 'what\'ll', 'what\'s', 'what\'ve', 'when', 'whence', 'whenever', 'where', 'whereafter', 'whereas', 'whereby', 'wherein', 'where\'s', 'whereupon', 'wherever', 'whether', 'which', 'whichever', 'while', 'whilst', 'whither', 'who', 'who\'d', 'whoever', 'whole', 'who\'ll', 'whom', 'whomever', 'who\'s', 'whose', 'why', 'will', 'willing', 'wish', 'with', 'within', 'without', 'wonder', 'won\'t', 'would', 'wouldn\'t', 'www', 'x', 'y', 'yes', 'yet', 'you', 'you\'d', 'you\'ll', 'your', 'you\'re', 'yours', 'yourself', 'yourselves', 'you\'ve', 'z', 'zero');
        $str = preg_replace('/[^a-z0-9\s-]+/', '', strtolower(strip_tags($str)));
        $str = preg_split('/\s+-\s+|\s+/', $str, -1, PREG_SPLIT_NO_EMPTY);
        while (0 < $len--)
            for ($i = 0; $i < count($str) - $len; $i++) {
                $word = array_slice($str, $i, $len + 1);
                if (in_array($word[0], $common) || in_array(end($word), $common))
                    continue;
                $word = implode(' ', $word);
                if (!isset($keywords[$len][$word]))
                    $keywords[$len][$word] = 0;
                $keywords[$len][$word] ++;
            }
        $return = array();
        foreach ($keywords as &$keyword) {
            $keyword = array_filter($keyword, function($v) use($min) {
                return !!($v > $min);
            });
            arsort($keyword);
            $return = array_merge($return, $keyword);
        }
        return $return;
    }

    public function fnd_pos($needle, $haystack) {
        $fnd = array();
        $pos = 0;

        while ($pos <= strlen($haystack)) {
            $pos = strpos($haystack, $needle, $pos);
            if ($pos > -1) {
                $fnd[] = $pos++;
                continue;
            }
            break;
        }
        return $fnd;
    }

    public function removeElementsByTagName($tagName, $document) {
        $nodeList = $document->getElementsByTagName($tagName);
        for ($nodeIdx = $nodeList->length; --$nodeIdx >= 0;) {
            $node = $nodeList->item($nodeIdx);
            $node->parentNode->removeChild($node);
        }
    }

    public function get_header_encoding($location_id, $url, $runtype) {

        $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $url)), "/");

        if ($runtype == 'fullweb') {

            $dataFound = $this->getCRECacheData($location_id, $url, "selectHeaderEncodingData");
            if (!empty($dataFound)) {
                $dataFound = $dataFound[0]['data_header'];
                if (!empty($dataFound)) {
                    return $dataFound;
                }
            }
        }

        $headersar = get_headers($url);
        $indx = 0;
        $headerstr = '';
        foreach ($headersar as $headear) {
            if (strpos(strtolower($headear), strtolower("charset=")) !== false) {
                $headerstr = $headear;
                break;
            }
            $indx++;
        }
        if ($headerstr != '') {
            $headers = explode("charset=", $headerstr);
            $encoding = isset($headers[1]) ? trim($headers[1]) : 'UTF-8';
        } else {
            $encoding = 'UTF-8';
        }

        if ($runtype == 'fullweb') {

            $dataFound = $this->getCRECacheData($location_id, $url, "selectHeaderEncodingData");

            if (!empty($dataFound)) {
                // update
                $id = $dataFound[0]['data_id'];

                $this->getCRECacheData($location_id, $url, "updateHeaderEncodingData", array("encoding" => $encoding, "id" => $id));
            } else {

                // insert
                $this->getCRECacheData($location_id, $url, "insertHeaderEncodingData", array("url" => $trimurl, "encoding_type" => $encoding, "location_id" => $location_id));
            }
        }

        return $encoding;
    }

    public function appendhttp($url) {
        if (!preg_match("~^(?:f|ht)tps?://~i", $url)) {
            $url = trim($url, "/");
            $url = "http://" . $url;
        }
        return $url;
    }

    public function remove_html_comments($content = '') {
        return preg_replace('/<!--(.|\s)*?-->/', '', $content);
    }

    public function get_remote_size($location_id, $url, $runtype) {

        $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $url)), "/");

        if ($runtype == 'fullweb') {

            $dataFound = $this->getCRECacheData($location_id, $url, "selectRemoteSizeData");
            if (!empty($dataFound)) {
                $dataFound = $dataFound[0]['data_size'];
                if ($dataFound > 0) {
                    return $dataFound;
                }
            }
        }

        $url = $this->appendhttp($url);
        $c = curl_init();
        curl_setopt_array($c, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => FALSE,
            CURLOPT_SSL_VERIFYHOST => FALSE,
            CURLOPT_HTTPHEADER => $this->user_agent(),
            CURLOPT_REFERER => REFERER
        ));
        curl_exec($c);

        $siz = curl_getinfo($c, CURLINFO_SIZE_DOWNLOAD);

        curl_close($c);

        if ($runtype == 'fullweb') {

            $dataFound = $this->getCRECacheData($location_id, $url, "selectRemoteSizeData");

            if (!empty($dataFound)) {
                // update
                $id = $dataFound[0]['data_id'];

                $this->getCRECacheData($location_id, $url, "updateRemoteSizeData", array("size" => $siz, "id" => $id));
            } else {

                // insert
                $this->getCRECacheData($location_id, $url, "insertRemoteSizeData", array("url" => $trimurl, "size" => $siz, "location_id" => $location_id));
            }
        }

        return $siz;
    }

    public function strip_html_tags($text) {
        $text = preg_replace(
                array(
            // Remove invisible content
            '@<head[^>]*?>.*?</head>@siu',
            '@<style[^>]*?>.*?</style>@siu',
            '@<script[^>]*?.*?</script>@siu',
            '@<object[^>]*?.*?</object>@siu',
            '@<embed[^>]*?.*?</embed>@siu',
            '@<applet[^>]*?.*?</applet>@siu',
            '@<noframes[^>]*?.*?</noframes>@siu',
            '@<noscript[^>]*?.*?</noscript>@siu',
            '@<noembed[^>]*?.*?</noembed>@siu',
            // Add line breaks before and after blocks
            '@</?((address)|(blockquote)|(center)|(del))@iu',
            '@</?((div)|(h[1-9])|(ins)|(isindex)|(p)|(pre))@iu',
            '@</?((dir)|(dl)|(dt)|(dd)|(li)|(menu)|(ol)|(ul))@iu',
            '@</?((table)|(th)|(td)|(caption))@iu',
            '@</?((form)|(button)|(fieldset)|(legend)|(input))@iu',
            '@</?((label)|(select)|(optgroup)|(option)|(textarea))@iu',
            '@</?((frameset)|(frame)|(iframe))@iu',
                ), array(
            ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
            "\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0",
            "\n\$0", "\n\$0",
                ), $text);
        return strip_tags($text);
    }

    public function get_remote_status($location_id, $url, $runtype) {

        $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $url)), "/");

        if ($runtype == 'fullweb') {

            $dataFound = $this->getCRECacheData($location_id, $url, "selectRemoteStatusData");
            if (!empty($dataFound)) {
                $dataFound = $dataFound[0]['data_status'];
                if ($dataFound > 0) {
                    return $dataFound;
                }
            }
        }
        $url = $this->appendhttp($url);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch,CURLOPT_USERAGENT, $this->user_agent());
        curl_setopt($ch, CURLOPT_REFERER, REFERER);
        
        curl_exec($ch);
        $sts = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($runtype == 'fullweb') {

            $dataFound = $this->getCRECacheData($location_id, $url, "selectRemoteStatusData");

            if (!empty($dataFound)) {
                // update
                $id = $dataFound[0]['data_id'];

                $this->getCRECacheData($location_id, $url, "updateRemoteStatusData", array("status" => $sts, "id" => $id));
            } else {

                // insert
                $this->getCRECacheData($location_id, $url, "insertRemoteStatusData", array("url" => $trimurl, "status" => $sts, "location_id" => $location_id));
            }
        }

        return $sts;
    }

    public function getCRECacheData($location_id, $url, $queryType, $dataF = array()) {

        $cre_cache = TableRegistry::get('tbl_cre_cache');

        $crecache_data_array = array();

        $query = $cre_cache->query();

        if ($queryType == "insert") {
            // cre_cache tbl insert

            if ($query->insert(['location_id', 'url', 'result', 'created'])
                            ->values(
                                    [
                                        'location_id' => $dataF['location_id'],
                                        'url' => $dataF['url'],
                                        'result' => $dataF['result'],
                                        'created' => date("Y-m-d H:i:s")
                                    ]
                            )
                            ->execute()) {

                return true;
            }
            return false;
        } else if ($queryType == "insertRemoteStatusData") {
            // cre_cache tbl insert

            if ($query->insert(['location_id', 'url', 'status', 'created'])
                            ->values(
                                    [
                                        'location_id' => $dataF['location_id'],
                                        'url' => $dataF['url'],
                                        'result' => $dataF['status'],
                                        'created' => date("Y-m-d H:i:s")
                                    ]
                            )
                            ->execute()) {

                return true;
            }
            return false;
        } else if ($queryType == "insertHeaderEncodingData") {
            // cre_cache tbl insert

            if ($query->insert(['location_id', 'url', 'encoding_type', 'created'])
                            ->values(
                                    [
                                        'location_id' => $dataF['location_id'],
                                        'url' => $dataF['url'],
                                        'encoding_type' => $dataF['encoding_type'],
                                        'created' => date("Y-m-d H:i:s")
                                    ]
                            )
                            ->execute()) {

                return true;
            }
            return false;
        } else if ($queryType == "insertRemoteSizeData") {
            // cre_cache tbl insert

            if ($query->insert(['location_id', 'url', 'size', 'created'])
                            ->values(
                                    [
                                        'location_id' => $dataF['location_id'],
                                        'url' => $dataF['url'],
                                        'size' => $dataF['size'],
                                        'created' => date("Y-m-d H:i:s")
                                    ]
                            )
                            ->execute()) {

                return true;
            }
            return false;
        } else if ($queryType == "update") {
            // cre_cache tbl update

            if ($query->update()
                            ->set(
                                    [
                                        'result' => $dataF['result']
                                    ]
                            )
                            ->where(['id' => $dataF['id']])
                            ->execute()) {
                return true;
            } else {
                return false;
            }
        } else if ($queryType == "updateRemoteStatusData") {
            // cre_cache tbl update

            if ($query->update()
                            ->set(
                                    [
                                        'status' => $dataF['status']
                                    ]
                            )
                            ->where(['id' => $dataF['id']])
                            ->execute()) {
                return true;
            } else {
                return false;
            }
        } else if ($queryType == "updateHeaderEncodingData") {
            // cre_cache tbl update

            if ($query->update()
                            ->set(
                                    [
                                        'encoding_type' => $dataF['encoding']
                                    ]
                            )
                            ->where(['id' => $dataF['id']])
                            ->execute()) {
                return true;
            } else {
                return false;
            }
        } else if ($queryType == "updateRemoteSizeData") {
            // cre_cache tbl update

            if ($query->update()
                            ->set(
                                    [
                                        'size' => $dataF['size']
                                    ]
                            )
                            ->where(['id' => $dataF['id']])
                            ->execute()) {
                return true;
            } else {
                return false;
            }
        } else if ($queryType == "delete") {
            // cre_cache tbl delete
        } else if ($queryType == "select") {

            // cre_cache tbl select 
            $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $url)), "/");

            $results = $query->find("all", [
                        'conditions' => ['location_id' => $location_id, "url like" => $trimurl]
                    ])->all()->toArray();

            if (count($results) > 0) {

                foreach ($results as $index => $data) {

                    $result = trim($data->result);
                    $arr = unserialize($result);

                    array_push($crecache_data_array, array(
                        "data_array" => $arr,
                        "data_id" => $data->id
                    ));
                }
            }

            return $crecache_data_array;
        } else if ($queryType == "selectRemoteSizeData") {

            // cre_cache tbl select 
            $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $url)), "/");

            $results = $query->find("all", [
                        'conditions' => ['location_id' => $location_id, "url like" => $trimurl]
                    ])->all()->toArray();

            if (count($results) > 0) {

                foreach ($results as $index => $data) {

                    $size = intval($data->size);

                    array_push($crecache_data_array, array(
                        "data_size" => $size,
                        "data_id" => $data->id
                    ));
                }
            }

            return $crecache_data_array;
        } else if ($queryType == "selectRemoteStatusData") {

            // cre_cache tbl select 
            $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $url)), "/");

            $results = $query->find("all", [
                        'conditions' => ['location_id' => $location_id, "url like" => $trimurl]
                    ])->all()->toArray();

            if (count($results) > 0) {

                foreach ($results as $index => $data) {

                    $status = intval($data->status);

                    array_push($crecache_data_array, array(
                        "data_status" => $status,
                        "data_id" => $data->id
                    ));
                }
            }

            return $crecache_data_array;
        } else if ($queryType == "selectHeaderEncodingData") {

            // cre_cache tbl select 
            $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $url)), "/");

            $results = $query->find("all", [
                        'conditions' => ['location_id' => $location_id, "url like" => $trimurl]
                    ])->all()->toArray();

            if (count($results) > 0) {

                foreach ($results as $index => $data) {

                    $status = trim($data->encoding_type);

                    array_push($crecache_data_array, array(
                        "data_header" => $status,
                        "data_id" => $data->id
                    ));
                }
            }

            return $crecache_data_array;
        }
    }

    public function crawl_page($token, $url, $location_id, $runType) {

        // target pages    
        $ar = array();
        $url = trim(trim($url, "/"));

        $withhttps = "https://" . str_replace(array("https://", "http://"), array("", ""), $url);
        $sts = $this->get_remote_status($location_id, $withhttps, $runType);

        if ($sts == 200) {
            $site_url = $url = $withhttps;
        } else {
            $site_url = $this->appendhttp($url);
        }

        // start check if url is moved or not
        $urlheaders = get_headers($site_url, 1);
        
        $st = isset($urlheaders[0]) ? $urlheaders[0] : '';
        if ($st != '') {
            $st = explode("301", $st);
            if (count($st) >= 2) {
                if (isset($urlheaders['Location']) && $urlheaders['Location'] != '') {
                    $site_url = $urlheaders['Location'];
                }
            }
        }
        
        // end check if url is moved or not

        $roboturl = $site_url . '/robots.txt';
        $sitemapline = 0;
        $sitemapurl = '';
        $hascontent = '';
        $ar['robots'] = 1;
        if (!$this->homeurlcheck($roboturl)) {
            $ar['robots'] = 0;
        }
        
        if ($sitemapline == 0) {
            // case forSEO yoast plugin
            $site_map_url = $site_url . '/sitemap_index.xml';
            if ($this->homeurlcheck($site_map_url)) {
                $sitemapurl = $site_map_url;
                $ar['yoast'] = 1;
                $sitemapline = 1;
            }
        }

        if ($sitemapline == 0) {
            $site_map_url = $site_url . '/sitemap.xml';
            if ($this->homeurlcheck($site_map_url)) {
                $sitemapurl = $site_map_url;
                $sitemapline = 1;
            }
        }


        if ($sitemapline == 0) {
            $site_map_url = $site_url . '/sitemap';
            if ($this->homeurlcheck($site_map_url)) {
                $sitemapurl = $site_map_url;
                $sitemapline = 1;
            }
        }

        $robotfile = file_get_contents($roboturl);
        $file = explode("\n", $robotfile);
        if ($sitemapline == 0) {
            foreach ($file as $f) {
                if (strpos($f, 'sitemap.xml') !== false) {
                    preg_match_all('#\bhttps?://[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $f, $match);
                    $url = isset($match[0][0]) ? $match[0][0] : '';
                    if ($url == '') {
                        continue;
                    }
                    $name = trim(strtolower(basename($url)));
                    if ($name == 'sitemap.xml') {
                        $sitemapurl = $url;
                        $sitemapline = 1;
                        break;
                    }
                }
            }
        }

        if ($sitemapline == 0) {
            foreach ($file as $f) {
                if (strpos(strtolower($f), 'sitemap:') !== false) {
                    preg_match_all('#\bhttps?://[^,\s()<>]+(?:\([\w\d]+\)|([^,[:punct:]\s]|/))#', $f, $match);
                    $url = isset($match[0][0]) ? $match[0][0] : '';
                    if ($url == '') {
                        continue;
                    }
                    $name = trim(strtolower(basename($url)));
                    if ($name == 'sitemap') {
                        $sitemapurl = $url;
                        $sitemapline = 1;
                        break;
                    }
                }
            }
        }

        // disallow urls
        $disallow = array();
        if (!empty($file)) {
            foreach ($file as $f) {
                if (strpos(strtolower($f), 'disallow:') !== false) {
                    $str = explode("disallow:", strtolower($f));
                    $disall = trim(trim($str[1], "/"));
                    if ($disall != "") {
                        $disallow[] = $disall;
                    }
                }
            }
        }

        if (!isset($ar['yoast'])) {
            $ar['yoast'] = 0;
        }
        $urls = '';

        if ($sitemapline == 1) {
            $ar['sitemap'] = 1;
            $ar['sitemapurl'] = $sitemapurl;
            if ($ar['yoast'] == 1) {
                $urls = $this->getmapurls($token, $sitemapurl, $disallow, 1);
            } else {
                $urls = $this->getmapurls($token, $sitemapurl, $disallow, 0);
                if (empty($urls)) {
                    $urls = $this->getmapurls($token, $sitemapurl, $disallow, 1);
                }
            }
        } else {
            $ar['sitemap'] = 0;
        }
        $ar['sitemap_corrupted'] = 0;
        if (empty($urls)) {
            if ($ar['sitemap'] == 1) {
                $ar['sitemap_corrupted'] = 1;
            }
        }

        $ar['urls'] = $urls;
        return $ar;
    }

    public function getmapurls($token, $sitemapurl, $disallow, $is_parent) {
        // $target_urls = $this->getTargetPages($token);
        $target_urls = array();
        $sitemapurl = $this->appendhttp($sitemapurl);
        
        $urls = array();
        $arext = array('jpg', 'jpeg', 'png', 'gif', 'bmp', 'bat', 'exif', 'tiff', 'svg', 'bat', 'bpg', 'axd');
        //pr($is_parent); die;


        if ($is_parent == 1) {
            // case of SEO yoast 

            $xml = trim(@file_get_contents($sitemapurl));
            if($xml == ''){
                return $urls;
            }
            $pdata = simplexml_load_string($xml);

            foreach ($pdata as $dt) {
                if (isset($dt->loc) && $dt->loc != '') {

                    $dat = trim(file_get_contents($dt->loc));
                    $innerdata = simplexml_load_string($dat);

                    foreach ($innerdata as $innerdt) {

                        $ext = isset($innerdt->loc->{0}) ? strtolower(trim(pathinfo($innerdt->loc->{0}, PATHINFO_EXTENSION))) : '';
                        $ext = explode("?", $ext);
                        $ext = $ext[0];
                        if (!in_array($ext, $arext)) {
                            $fg = 0;
                            foreach ($disallow as $dis) {
                                if (strpos($innerdt->loc, $dis) !== false) {
                                    $fg = 1;
                                }
                            }
                            if ($fg == 0) {

                                $ob = json_decode(json_encode($innerdt->loc));
                                if (is_object($ob))
                                    $ur = $ob->{0};
                                else
                                    $ur = $ob[0];

                                $urhash = explode("#", $ur);
                                if (count($urhash) > 1) {
                                    $ur = $urhash[0];
                                }

                                $istarget = 0;
                                $uur = trim(str_replace(array("https://", "http://", "www."), array("", "", ""), $ur), "/");

                                $obj = new stdClass();
                                $obj->{0} = $ur;

                                if ($istarget == 1)
                                    array_unshift($urls, $obj);
                                else
                                    array_push($urls, $obj);
                            }
                        }
                    }
                }
            }
        }
        else {

            $xml = trim(@file_get_contents($sitemapurl));
            if($xml == ''){
                return $urls;
            }
            $data = @simplexml_load_string($xml);

            foreach ($data as $dat) {

                $ext = isset($dat->loc->{0}) ? strtolower(trim(pathinfo($dat->loc->{0}, PATHINFO_EXTENSION))) : '';
                $ext = explode("?", $ext);
                $ext = $ext[0];
                if (trim(strtolower($ext)) == 'xml') {
                    continue;
                }
                if (!in_array($ext, $arext)) {
                    $fg = 0;
                    foreach ($disallow as $dis) {
                        if (strpos($dat->loc, $dis) !== false) {
                            $fg = 1;
                        }
                    }

                    if ($fg == 0) {

                        $ob = json_decode(json_encode($dat->loc));
                        if (is_object($ob))
                            $ur = $ob->{0};
                        else
                            $ur = $ob[0];

                        $urhash = explode("#", $ur);
                        if (count($urhash) > 1) {
                            $ur = $urhash[0];
                        }

                        $istarget = 0;
                        $uur = trim(str_replace(array("https://", "http://", "www."), array("", "", ""), $ur), "/");

                        $obj = new stdClass();
                        $obj->{0} = $ur;

                        if ($istarget == 1)
                            array_unshift($urls, $obj);
                        else
                            array_push($urls, $obj);
                    }
                }
            }
        }
        /* if (!empty($urls)) {
          foreach ($target_urls as $target) {
          array_unshift($urls, $target);
          }
          } */

        return $urls;
    }

    public function target_pages($user_id) {

        global $wpdb;
        $UserID = $user_id;

        $target_pages = $this->Cre->alltargetpages($_REQUEST, new AppController());
        $xd = 0;

        $outerarr = array();
        $outerarr['robots'] = 1;
        $outerarr['sitemap'] = 1;
        $outerarr['urls'] = $target_pages;

        return $outerarr;
    }

    public function homeurlcheck($url) {
        try {
            $exists = false;

            if (!$exists && in_array('curl', get_loaded_extensions())) {

                $ch = curl_init($url);

                curl_setopt($ch, CURLOPT_NOBODY, true);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
                curl_setopt($ch,CURLOPT_USERAGENT, $this->user_agent());
                curl_setopt($ch, CURLOPT_REFERER, REFERER);
                curl_exec($ch);
                $response = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                if ($response === 200 || $response === 300 || $response === 301 || $response === 302 || $response === 304 || $response === 307) {
                    $exists = true;
                }

                curl_close($ch);
            }

            return $exists;
        } catch (Exception $e) {
            $message = $e->getMessage();
            return true;
        }
    }

    //===================================================================
}

?>
