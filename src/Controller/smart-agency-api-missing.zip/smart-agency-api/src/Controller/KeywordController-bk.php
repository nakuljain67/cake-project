<?php

namespace App\Controller;

require_once(ROOT . DS . 'vendor' . DS . "dompdf" . DS . "autoload.inc.php");
require_once(ROOT . DS . 'vendor' . DS . "PHPMailer" . DS . "PHPMailerAutoload.php");
require_once(ROOT . DS . 'vendor' . DS . "simplehtmldom" . DS . "simple_html_dom.php");

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;
use Dompdf\Dompdf;
use Dompdf\Options;

class KeywordController extends AppController {

    private $connection;

    public function initialize() {
        parent::initialize();
        header('Access-Control-Allow-Origin: *');
        $this->loadModel("Keygroups");
        $this->loadComponent('SmartEmail');
        $this->connection = ConnectionManager::get('default');
    }

    /* default method called */

    public function index() {

        $this->autoRender = false;

        $this->json(1, array(
            "method" => "index",
            "messge" => "silence is golden"
        ));
    }

    /* All Campaign Operations */

    public function createCampaign() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $data = json_decode(file_get_contents('php://input'));
            $token = $this->request->header("token");
            $name = isset($data->name) ? trim($data->name) : '';
            $target_country = isset($data->country_id) ? intval($data->country_id) : 0;
            $target = isset($data->target) ? trim($data->target) : 'national';
            $google_location = isset($data->google_location) ? trim($data->google_location) : '';

            if (!empty($token)) {

                if ($this->is_token_valid()) {

                    if (empty($name)) {
                        $this->json(0, "campaign name", array("campaign name" => "required"));
                    }

                    if ($target_country == 0) {
                        $this->json(0, "country id", array("country id" => "required"));
                    }

                    if ($target == "local" && empty($google_location)) {
                        $this->json(0, "local location", array("local location" => "required"));
                    }

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];

                    try {

                        $campaign_create_status = $this->Keyword->createLocationCampaign(array("location_id" => $location_id, "name" => $name, "country" => $target_country, "target" => $target, "google_location" => $google_location, "user_id" => $user_id));

                        if ($campaign_create_status) {

                            $this->json(1, "campaign created", $campaign_create_status);
                        } else {

                            $this->json(0, "failed to create campaign");
                        }
                    } catch (Exception $ex) {
                        
                    }
                }
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function editCampaign() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $data = json_decode(file_get_contents('php://input'));
                $token = $this->request->header("token");
                $campaign_id = isset($data->campaign_id) ? intval($data->campaign_id) : 0;
                $name = isset($data->name) ? trim($data->name) : '';
                $target_country = isset($data->country_id) ? intval($data->country_id) : 0;
                $target = isset($data->target) ? trim($data->target) : 'national';
                $google_location = isset($data->google_location) ? trim($data->google_location) : '';

                if ($this->is_token_valid()) {

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];

                    if (empty($name)) {
                        $this->json(0, "campaign name", array("campaign_name" => "required"));
                    }

                    if ($target_country == 0) {
                        $this->json(0, "country name", array("country_id" => "required"));
                    }

                    if ($target == "local" && empty($google_location)) {
                        $this->json(0, "local location", array("local location" => "required"));
                    }

                    if ($target == "national") {
                        $google_location = '';
                    }

                    if ($this->Keyword->is_valid_campaign($campaign_id)) {

                        if ($this->Keyword->editLocationCampaign(array("campaign_id" => $campaign_id, "location_id" => $location_id, "name" => $name, "country" => $target_country, "target" => $target, "google_location" => $google_location, "user_id" => $user_id))) {

                            $this->json(1, "campaign updated");
                        } else {

                            $this->json(0, "failed to update campaign");
                        }
                    } else {

                        $this->json(0, "invalid campaign id", array("campaign id" => "required"));
                    }
                } else {
                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function deleteCampaign() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $data = json_decode(file_get_contents('php://input'));
                $token = $this->request->header("token");
                $campaign_id = isset($data->campaign_id) ? intval($data->campaign_id) : 0;

                if ($this->is_token_valid()) {

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];

                    if ($this->Keyword->is_valid_campaign($campaign_id)) {

                        if ($this->Keyword->deleteLocationCampaign(array("location_id" => $location_id, "campaign_id" => $campaign_id), new AppController())) {

                            $this->json(1, "campaign deleted");
                        } else {

                            $this->json(0, "failed to delete campaign");
                        }
                    } else {

                        $this->json(0, "invalid campaign id", array("valid campaign id" => "required"));
                    }
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function listCampaign() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');

            if ($this->is_token_valid()) {

                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];

                if (empty($location_id)) {

                    $this->json(0, "location_id is empty", array("valid token" => "required"));
                }
                $this->json(1, "campaign found", $this->Keyword->listLocationCampaign(array("location_id" => $location_id, "user_id" => $user_id)));
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* All Campaign Operation ends here */

    /* Keyword Operation starts */

    public function createKeygroup() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            try {

                $token = $this->request->header('token');
                $data = json_decode(file_get_contents('php://input'));
                $campaign_id = isset($data->campaign_id) ? intval($data->campaign_id) : 0;
                $landing_url = isset($data->landing_url) ? trim($data->landing_url) : '';
                $keyword = isset($data->keyword) ? trim($data->keyword) : '';
                $synkeyword = isset($data->synkeyword) && count($data->synkeyword) > 0 ? $data->synkeyword : array();
                $google_location = '';
                $new_group = isset($data->new_group) ? intval($data->new_group) : 1;
                $group_id = isset($data->group_id) ? intval($data->group_id) : 0;
                $live_date = isset($data->live_date) ? $data->live_date : '';
                $home_page = isset($data->home_page) ? trim($data->home_page) : '';
                $resource_page = isset($data->resource_page) ? trim($data->resource_page) : '';
                $is_target = isset($data->is_target) ? $data->is_target : 1;
                $notes = isset($data->notes) ? trim($data->notes) : '';
                $status = isset($data->status) ? trim($data->status) : 1;
                // creating keygroup
                if ($this->is_token_valid()) {

                    if (empty($keyword)) {
                        $this->json(0, "Please Enter Primary Keyword");
                    }

                    if ($campaign_id == 0) {
                        $this->json(0, "Please Select Campaign");
                    }

                    if (!empty($landing_url)) {
                        if (!$this->is_valid_url($landing_url)) {
                            $this->json(0, "Invalid URL format for Landing URL");
                        }
                    }

                    if (!empty($home_page)) {
                        if (!$this->is_valid_url($home_page)) {
                            $this->json(0, "Invalid URL format for Home Page URL");
                        }
                    }

                    if (!empty($resource_page)) {
                        if (!$this->is_valid_url($resource_page)) {
                            $this->json(0, "Invalid URL format for Resource Page URL");
                        }
                    }

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];

                    if (empty($location_id)) {

                        $this->json(0, "location_id is empty", array("valid token" => "required"));
                    }

                    if ($group_id < 0 && $new_group == 0) {
                        $this->json(0, "Invalid group id", array("group_id" => "required"));
                    }
                    // get local location of current campaign here
                    $results = $this->connection
                            ->execute("SELECT local_location FROM tbl_campaigns WHERE id = " . $campaign_id)
                            ->fetchAll('assoc');

                    if (count($results) > 0) {

                        $google_location = $results[0]['local_location'];
                    } else {

                        $this->json(0, "invalid campaign id");
                    }

                    // checking for duplicate in syn keywords as well with primary keyword
                    if (in_array($keyword, $synkeyword)) {

                        $this->json(0, "Primary keyword is same as Synonym keyword, keyword: " . $keyword);
                    }

                    // checking duplicate keyword of primary keyword in table saved keywords
                    if ($this->Keyword->isGroupKeywordAvailable(array("location_id" => $location_id, "campaign_id" => $campaign_id, "keyword" => $keyword))) {

                        $this->json(1, "Primary keyword is already in this campaign id, keyword: " . $keyword);
                    }

                    if (count($synkeyword) > 0) {

                        //checking syno keywords duplicasy itself

                        if ($this->has_duplicate_values($synkeyword)) {

                            $this->json(0, "Synonym group has duplicate keywords");
                        }

                        // checking duplicat in syno keywords as well with saved keyrword
                        foreach ($synkeyword as $synckey) {

                            if ($this->Keyword->isGroupKeywordAvailable(array("location_id" => $location_id, "campaign_id" => $campaign_id, "keyword" => $keyword))) {

                                $this->json(1, "Synonym keyword is alreay with this campaign id, keyword: " . $synckey);
                            }
                        }
                    }

                    if ($new_group == 1) {

                        $keygroup_status = $this->Keyword->createLocationKeygroup(array(
                            "location_id" => $location_id,
                            "user_id" => $user_id,
                            'campaign_id' => $campaign_id,
                            'google_location' => $google_location,
                            'landing_page' => $landing_url,
                            'live_date' => $live_date,
                            'home_page' => $home_page,
                            'resource_page' => $resource_page,
                            'is_target' => $is_target,
                            'notes' => $notes,
                            'status' => $status,
                            'created' => date("Y-m-d H:i:s")
                        ));

                        if (count($keygroup_status) > 0) {
                            $keygroup_id = $keygroup_status[0]['id'];
                        }

                        $group_id = $keygroup_id;
                    } else {
                        
                    }

                    if (count($synkeyword) > 0) {

                        foreach ($synkeyword as $sdata) {

                            $this->createKeyword(array(
                                "group_id" => $group_id,
                                "campaign_id" => $campaign_id,
                                "location_id" => $location_id,
                                "keyword" => $sdata,
                                "is_primary" => 0,
                                "user_id" => $user_id
                            ));
                        }
                    }

                    if ($this->createKeyword(array(
                                "group_id" => $group_id,
                                "campaign_id" => $campaign_id,
                                "location_id" => $location_id,
                                "keyword" => $keyword,
                                "is_primary" => 1,
                                "user_id" => $user_id
                            ))) {

                        $this->json(1, "keyword created");
                    } else {

                        $this->json(1, "failed to create keygroup keyword");
                    }
                } else {
                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function editKeygroup() {
        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            try {

                $token = $this->request->header('token');
                $data = json_decode(file_get_contents('php://input'));
                $campaign_id = isset($data->campaign_id) ? intval($data->campaign_id) : 0;
                $landing_url = isset($data->landing_url) ? trim($data->landing_url) : '';
                $keyword = isset($data->keyword) ? trim($data->keyword) : '';
                $synkeyword = isset($data->synkeyword) ? $data->synkeyword : array();
                $google_location = '';
                $group_id = isset($data->group_id) ? intval($data->group_id) : 0;
                $live_date = isset($data->live_date) ? $data->live_date : '';
                $home_page = isset($data->home_page) ? trim($data->home_page) : '';
                $resource_page = isset($data->resource_page) ? trim($data->resource_page) : '';
                $is_target = isset($data->is_target) ? $data->is_target : 1;
                $notes = isset($data->notes) ? trim($data->notes) : '';
                $status = isset($data->status) ? trim($data->status) : 1;
                $grppKeywords = array();
                // creating keygroup
                if ($this->is_token_valid()) {

                    if (empty($keyword)) {
                        $this->json(0, "Please Enter Primary Keyword");
                    }

                    if (!empty($landing_url)) {
                        if (!$this->is_valid_url($landing_url)) {
                            $this->json(0, "Invalid URL format for Landing URL");
                        }
                    }

                    if (!empty($home_page)) {
                        if (!$this->is_valid_url($home_page)) {
                            $this->json(0, "Invalid URL format for Home Page URL");
                        }
                    }

                    if (!empty($resource_page)) {
                        if (!$this->is_valid_url($resource_page)) {
                            $this->json(0, "Invalid URL format for Resource Page URL");
                        }
                    }

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];

                    if (empty($location_id)) {

                        $this->json(0, "location_id is empty", array("valid token" => "required"));
                    }

                    if (count($this->Keyword->is_valid_keygroup($group_id)) == 0) {

                        $this->json(0, "Invalid group id", array("group_id" => "required"));
                    }

                    if ($group_id < 1) {
                        $this->json(0, "Invalid group id", array("group_id" => "required"));
                    }
                    // get location location by campaign id
                    $results = $this->connection
                            ->execute("SELECT local_location FROM tbl_campaigns WHERE id = " . $campaign_id)
                            ->fetchAll('assoc');

                    if (count($results) > 0) {

                        $google_location = $results[0]['local_location'];
                    } else {

                        $this->json(0, "invalid campaign id");
                    }

                    // checking for duplicate in syn keywords as well with primary keyword
                    if (in_array($keyword, $synkeyword)) {

                        $this->json(0, "Primary keyword is same as Synonym keyword, keyword: " . $keyword);
                    }

                    if (count($synkeyword) > 0) {

                        //checking syno keywords duplicasy itself

                        if ($this->has_duplicate_values($synkeyword)) {

                            $this->json(0, "Synonym group has duplicate keywords");
                        }
                    }

                    $keygroup_status = $this->Keyword->updateLocationKeygroup(array(
                        "location_id" => $location_id,
                        "user_id" => $user_id,
                        "group_id" => $group_id,
                        'campaign_id' => $campaign_id,
                        'google_location' => $google_location,
                        'landing_page' => $landing_url,
                        'live_date' => $live_date,
                        'home_page' => $home_page,
                        'resource_page' => $resource_page,
                        'is_target' => $is_target,
                        'notes' => $notes,
                        'status' => $status,
                        'created' => date("Y-m-d H:i:s")
                    ));
                    // query to get all saved keywords of current campaign id
                    $results = $this->connection
                            ->execute("SELECT keyword FROM tbl_keywords WHERE campaign_id = " . $campaign_id)
                            ->fetchAll('assoc');

                    $tableKeywords = array();

                    foreach ($results as $dbKey) {
                        //pushing these keywords into array
                        array_push($tableKeywords, strtolower(trim($dbKey['keyword'])));
                    }

                    if (count($synkeyword) > 0) {

                        foreach ($synkeyword as $sdata) {

                            array_push($grppKeywords, strtolower(trim($sdata)));

                            if ($this->Keyword->isGroupKeywordAvailableExceptCurrentCampaign(array("location_id" => $location_id, "campaign_id" => $campaign_id, "keyword" => $sdata))) {
                                // syn keyword available
                            } else {
                                $this->createKeyword(array(
                                    "group_id" => $group_id,
                                    "campaign_id" => $campaign_id,
                                    "location_id" => $location_id,
                                    "keyword" => $sdata,
                                    "is_primary" => 0,
                                    "user_id" => $user_id
                                ));
                            }
                        }
                    }

                    array_push($grppKeywords, strtolower(trim($keyword)));

                    if ($this->Keyword->isGroupKeywordAvailableExceptCurrentCampaign(array("location_id" => $location_id, "campaign_id" => $campaign_id, "keyword" => $keyword))) {
                        // primary keyword available
                    } else {
                        $this->createKeyword(array(
                            "group_id" => $group_id,
                            "campaign_id" => $campaign_id,
                            "location_id" => $location_id,
                            "keyword" => $keyword,
                            "is_primary" => 1,
                            "user_id" => $user_id
                        ));
                    }

                    foreach ($tableKeywords as $fkey) {

                        if (in_array($fkey, $grppKeywords)) {
                            // keyword remains there
                        } else {
                            // make entry to keyword deleted table
                            $this->Keyword->moveKeywordToDeletedTable(array("keyword" => $fkey, "campaign_id" => $campaign_id, "location_id" => $location_id));
                        }
                    }

                    $this->json(1, "keygroup info updated");
                } else {
                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function deleteKeygroup() {
        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            try {

                $token = $this->request->header('token');
                $data = json_decode(file_get_contents('php://input'));
                $keygroup_id = isset($data->keygroup_id) ? intval($data->keygroup_id) : 0;

                if ($this->is_token_valid()) {

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];

                    if (empty($location_id)) {

                        $this->json(0, "location_id is empty", array("valid token" => "required"));
                    }

                    if (count($this->Keyword->is_valid_keygroup($keygroup_id)) == 0) {

                        $this->json(0, "Invalid group id", array("group_id" => "required"));
                    }

                    if ($keygroup_id < 1) {
                        $this->json(0, "Invalid group id", array("group_id" => "required"));
                    }

                    if ($this->Keyword->deleteLocationKeygroup(array("keygroup_id" => $keygroup_id))) {
                        // keygroup deleted
                        $this->json(1, "keygroup deleted");
                    } else {

                        $this->json(0, "failed to delete keygroup");
                    }
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function createKeyword($data = array()) {
        $this->autoRender = false;
        if ($this->Keyword->createLocationKeyword($data)) {

            return true;
        } else {
            return false;
        }
    }

    public function updateKeyword($data = array()) {
        $this->autoRender = false;
        if ($this->Keyword->updateLocationKeyword($data)) {

            return true;
        } else {
            return false;
        }
    }

    // Not in use - Overriden by getCampaignGroups
    public function listKeygroup() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $data = json_decode(file_get_contents('php://input'));
            $campaign_id = isset($data->campaign_id) ? intval($data->campaign_id) : 0;
            if ($this->is_token_valid()) {

                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];

                if (empty($location_id)) {

                    $this->json(0, "location_id is empty", array("valid token" => "required"));
                }
                $this->json(1, $this->Keyword->listLocationKeygroups(array("location_id" => $location_id, "user_id" => $user_id, "campaign_id" => $campaign_id)));
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function getKeygroupLandingPages($data = array()) {

        $tbl_keygroup = TableRegistry::get('tbl_keygroup');
        $keygroup = $tbl_keygroup->query();

        $groups = $keygroup->find('all', [
                    'conditions' => ['location_id' => $data['location_id'], "landing_page" => $data['landing_page'], "status" => 1]
                ])->toArray();

        return $groups;
    }

    public function getTargetKeywords($data = array()) {

        $tbl_keywords = TableRegistry::get('tbl_keywords');
        $keywords = $tbl_keywords->query();

        $landingPageGroups = $this->getKeygroupLandingPages(array("location_id" => $data['location_id'], "landing_page" => $data['landing_page']));
        $targetKeywords = array();
        foreach ($landingPageGroups as $index => $data) {
            $id = $data->id;
            $result = $tbl_keywords->find('all', [
                        'conditions' => ['group_id' => $id]
                    ])->toArray();
            foreach ($result as $key => $value) {
                array_push($targetKeywords, array("keyword" => $value->keyword, "rank" => $value->rank));
            }
        }

        return $targetKeywords;
    }

    public function total_conversions($location_id, $RankingURL, $from_date, $to_date, $type = '') {

        $ConvCountForClient = 0;
        $source['organic'] = 0;
        $source['paid'] = 0;
        $source['referral'] = 0;
        $source['social'] = 0;
        $source['direct'] = 0;
        $source['total'] = 0;

        $sql = "SELECT  sum(`organic`) as total_organic, sum(`paid`) as total_paid, sum(`referral`) as total_referral,"
                . " sum(`social`) as total_social, sum(`direct`) as total_direct, sum(`total`) as total_conv "
                . "FROM `tbl_conversions_data` WHERE `location_id` = $location_id and `created` >='$from_date' and `created` <= '$to_date' "
                . "and TRIM(BOTH  '/' FROM REPLACE(REPLACE(REPLACE (url, 'http://', ''),'https://',''),'www.','')) = '$RankingURL'";


        $result = $this->connection
                ->execute($sql)
                ->fetchAll('assoc');


        if (!empty($result)) {
            $source['organic'] = $result[0]['total_organic'];
            $source['paid'] = $result[0]['total_paid'];
            $source['referral'] = $result[0]['total_referral'];
            $source['social'] = $result[0]['total_social'];
            $source['direct'] = $result[0]['total_direct'];
            $source['total'] = $ConvCountForClient = $result[0]['total_conv'];
        }
        if ($ConvCountForClient == '') {
            $ConvCountForClient = 0;
        }
        if ($type == 'all') {
            return $source;
        } else {
            return $ConvCountForClient;
        }
    }

    public function get_seo_date($webname, $location_id, $from_date, $to_date) {

        $webname = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $webname), "/"));

        $data = $this->connection
                ->execute("SELECT sum(`total`) as Total_val, sum(organic) as organic_val FROM `api_short_analytics_$location_id` WHERE TRIM(BOTH  '/' FROM REPLACE(REPLACE(REPLACE (pageURL, 'http://', ''),'https://',''),'www.','')) = '" . $webname . "' group by pageURL order by `dateOfVisit` desc LIMIT 1 ")
                ->fetchAll('assoc');

        $total_visits = isset($data[0]['Total_val']) ? $data[0]['Total_val'] : 0;
        $total_organic_visits = isset($data[0]['organic_val']) ? $data[0]['organic_val'] : 0;

        $conversion_rate = "0";
        $total_conversions = 0;

        // count converion
        $total_conversions = $this->total_conversions($location_id, $webname, $from_date, $to_date);

        if ($total_visits > 0) {
            $conversion_rate = $this->topercent(($total_conversions / $total_visits) * 10000);
        }

        $ar = array(
            'org_visits' => $total_organic_visits,
            'org_conversion' => $total_conversions,
            'conversion_rate' => $conversion_rate
        );

        return $ar;
    }

    public function getLocationCampaignKeywords() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $data = json_decode(file_get_contents('php://input'));
            $campaign_id = isset($data->campaign_id) ? trim($data->campaign_id) : 0;
            $data_order = isset($data->sortby) ? trim($data->sortby) : "sort_from_a_z";
            $from_date = isset($data->from_date) ? $data->from_date : date("Y-m-d", strtotime("-1 day"));
            $to_date = isset($data->to_date) ? $data->to_date : date("Y-m-d", strtotime("-31 day"));
            $keywordType = isset($data->keyword_type) ? trim($data->keyword_type) : 'all';
            $is_primary = isset($data->isprimary) ? $data->isprimary : 0;
            // keyword_type: all or target
            // isprimary: either 1 or 0.
            /* sort_from_a_z, sort_from_z_a, created_date_asc, created_date_desc, updated_date_asc, updated_date_desc */
            if ($this->is_token_valid()) {
                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];
                $keywordGrpData = array();
                // sorting conditions
                $sort_conditions = '';
                if ($data_order == "sort_from_a_z") {
                    $sort_conditions = array('Keywords.keyword' => 'ASC');
                } else if ($data_order == "sort_from_z_a") {

                    $sort_conditions = array('Keywords.keyword' => 'DESC');
                } else if ($data_order == "created_date_asc") {

                    $sort_conditions = array('Keywords.created' => 'ASC');
                } else if ($data_order == "created_date_desc") {

                    $sort_conditions = array('Keywords.created' => 'DESC');
                } else if ($data_order == "updated_date_asc") {

                    $sort_conditions = array('Keywords.modified' => 'ASC');
                } else if ($data_order == "updated_date_desc") {

                    $sort_conditions = array('Keywords.modified' => 'DESC');
                }

                // filter on basis of primary and see all keywords
                $seeAll = array();
                if (!empty($is_primary) && $is_primary == 1) {
                    $seeAll = array('Keywords.isprimary' => 1);
                }
                if ($campaign_id == 0) {

                    if ($keywordType == "all") {

                        $keyGrpData = $this->Keygroups->find("all", [
                                    'contain' => ['Keywords' => [
                                            'conditions' => $seeAll,
                                            'sort' => $sort_conditions
                                        ]],
                                ])->all()->toArray();
                    } else if ($keywordType == "target") {

                        $keyGrpData = $this->Keygroups->find("all", [
                                    "conditions" => ["Keygroups.is_target" => 1],
                                    'contain' => ['Keywords' => [
                                            'conditions' => $seeAll,
                                            'sort' => $sort_conditions
                                        ]]
                                ])->all()->toArray();
                    }
                } else {

                    if ($this->Keyword->is_valid_campaign($campaign_id)) {

                        if ($keywordType == "all") {

                            $keyGrpData = $this->Keygroups->find("all", [
                                        "conditions" => ["Keygroups.campaign_id" => $campaign_id],
                                        'contain' => ['Keywords' => [
                                                'conditions' => $seeAll,
                                                'sort' => $sort_conditions
                                            ]]
                                    ])->all()->toArray();
                        } else if ($keywordType == "target") {

                            $keyGrpData = $this->Keygroups->find("all", [
                                        "conditions" => ["Keygroups.campaign_id" => $campaign_id, "Keygroups.is_target" => 1],
                                        'contain' => ['Keywords' => [
                                                'conditions' => $seeAll,
                                                'sort' => $sort_conditions
                                            ]]
                                    ])->all()->toArray();
                        }
                    } else {

                        $this->json(0, "invalid campaign id", array("campaign id" => "required"));
                    }
                }

                $keygrp_data_found = array();
                $group_info = array();
                $getglobalseodata = array("org_visits" => 0, "org_conversion" => 0, "conversion_rate" => 0);
                $allprimarykeywords = array();
                $nogroups = array();
                if (count($keyGrpData) > 0) {

                    foreach ($keyGrpData as $key => $value) {

                        $group_id = $value->id;
                        $group_target = $value->is_target;
                        $keyword = array();
                        $landing_page = $this->fully_trim($value->landing_page);
                        $CurrentRank = 0;
                        if (count($value->keywords) > 0) {
                            $is_ranked_url_target = 0;
                            foreach ($value->keywords as $index => $key_data) {

                                $CurrentRank = $key_data->rank == NULL ? 0 : $key_data->rank;
                                $isprimary = $key_data->isprimary;
                                $ranked_url = $key_data->ranked_url;
                                $camp_data = $this->fully_trim($ranked_url);
                                if (!strcmp($landing_page, $ranked_url) && !empty($ranked_url)) {
                                    $is_ranked_url_target = 1;
                                }
                                $keyword_id = $key_data->id;

                                if ($ranked_url != '') {
                                    $getseodata = $this->get_seo_date($ranked_url, $location_id, $from_date, $to_date);
                                } else {
                                    $getseodata = $getglobalseodata;
                                }

                                $org_visits = $getseodata['org_visits'];
                                $org_conversion = $getseodata['org_conversion'];
                                $org_conversion_rate = $getseodata['conversion_rate'];
                                $search_vol = $key_data->googleSearchVolume;
                                $compt = $this->topercent($key_data->difficulty * 10000);
                                $bid = $this->formattomney($this->moneyfrmmicros($key_data->cpc));

                                // BUCKET code start

                                $current_bucket = '';
                                $bucket_color = '#fff;';
                                $bucket_color_style = '';

                                if ($CurrentRank == '0' || $CurrentRank == '50+') {
                                    $current_bucket = '50+';
                                    $bucket_color_style .= '#ed6b75';
                                } else if ($CurrentRank > 10 && $CurrentRank <= 50) {
                                    $current_bucket = '11-50';
                                    $bucket_color_style .= '#659be0';
                                } else if ($CurrentRank >= 4 && $CurrentRank <= 10) {
                                    $current_bucket = '4-10';
                                    $bucket_color_style .= '#337ab7;';
                                } else if ($CurrentRank >= 1 && $CurrentRank <= 3) {
                                    $current_bucket = 'Top 3';
                                    $bucket_color_style .= '#36c6d3';
                                }

                                $sqlQuery = 'SELECT rank, dateOfRank FROM tbl_keywords_history WHERE campaign_id = ' . $campaign_id . ' and LOWER(TRIM(keyword)) = "' . trim(strtolower($key_data->keyword)) . '" order by `dateOfRank` desc LIMIT 15';

                                $date_enter = $this->connection
                                        ->execute($sqlQuery)
                                        ->fetchAll('assoc');

                                $camp_id = $key_data->campaign_id;
                                $kywrd = trim(strtolower($key_data->keyword));

                                $sqlQueryDetails = "SELECT rank, dateOfRank FROM tbl_keywords_history WHERE LOWER(TRIM(keyword)) like '$kywrd' "
                                        . "AND campaign_id = $camp_id AND dateOfRank IS NOT NULL  group by keyword order by dateOfRank desc LIMIT 1";

                                $date_result = $this->connection
                                        ->execute($sqlQueryDetails)
                                        ->fetchAll('assoc');

                                $bucket_change = 0;
                                if (count($date_enter) > 0) {
                                    foreach ($date_enter as $in => $row_enter) {
                                        $currankhist = isset($row_enter['rank']) ? $row_enter['rank'] : 0;
                                        $existing_bucket = $this->bucket_name($currankhist);
                                        if ($current_bucket != $existing_bucket) {
                                            $date_in_bucket = $row_enter['dateOfRank'];
                                            $bucket_change = 1;
                                            break;
                                        }
                                    }
                                } else {
                                    $date_in_bucket = date('Y-m-d', strtotime('last Sunday'));
                                }

                                if (empty($date_enter)) {
                                    $last_time_date = date('Y-m-d', strtotime('last Sunday'));
                                } else {
                                    if (count($date_enter) > 1) {
                                        $last_time_date = isset($date_enter[count($date_enter) - 1]['dateOfRank']) ? $date_enter[count($date_enter) - 1]['dateOfRank'] : '';
                                    }
                                }

                                if (empty($last_time_date)) {
                                    $last_time_date = date('Y-m-d', strtotime('last Sunday'));
                                }

                                if ($bucket_change == 0) {
                                    $date_in_bucket = $last_time_date;
                                }

                                $date_enter = $date_result;

                                if (!empty($date_enter)) {

                                    $date_enter_val = isset($date_enter[0]['dateOfRank']) ? $date_enter[0]['dateOfRank'] : $key_data->dateOfRank;
                                } else {
                                    $date_enter_val = $key_data->dateOfRank;
                                }

                                $date_enter_val = date("d M Y", strtotime($date_enter_val));
                                $date_in_bucket = date("d M Y", strtotime($date_in_bucket));

                                $now = time(); // or your date as well
                                $your_date = strtotime($date_in_bucket);
                                $datediff = $now - $your_date;
                                $date_in_bucket_days = floor($datediff / (60 * 60 * 24));
                                $bg_color_style = '';
                                if ($date_in_bucket_days >= 90) {
                                    $date_in_bucket_days = 90;
                                }
                                if ($current_bucket == '11-50' || $current_bucket == '50+') {
                                    if ($date_in_bucket_days >= 90) {
                                        $bg_color_style = 'color:red!important;font-weight:bold;';
                                    }
                                }
                                if ($current_bucket == 'Top 3' && $date_in_bucket_days >= 90) {
                                    $bg_color_style = 'color:green!important;font-weight:bold;';
                                }
                                //echo $date_in_bucket_days.'sss<br>'; exit;

                                $your_date = strtotime($last_time_date);
                                //$your_date = strtotime($date_enter_val);
                                $datediff = $now - $your_date;
                                $total_days = floor($datediff / (60 * 60 * 24));

                                $bucket_val = $current_bucket;
                                $days_in_bucket_val = $date_in_bucket_days;

                                $percentage_of_time = sprintf("%.2f", ($date_in_bucket_days / $total_days) * 100);
                                if ($percentage_of_time <= 100) {
                                    $percentage_of_time = $percentage_of_time . '%';
                                } else {
                                    $percentage_of_time = '100.00%';
                                }

                                // get history
                                $txt = '';
                                if ($campaign_id > 0) {
                                    $txt = "AND campaign_id = $campaign_id";
                                }
                                $sqlQueryHistory = "SELECT rank,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank FROM tbl_keywords_history WHERE location_id = $location_id $txt AND LOWER(TRIM(keyword)) = '" . $key_data->keyword . "' AND dateOfRank>='" . $from_date . "' AND dateOfRank<='" . $to_date . "' ORDER BY dateOfRank DESC LIMIT 1";
                                $historydata = $this->connection->execute($sqlQueryHistory)->fetchAll('assoc');
                                $old_rank = 0;
                                $old_maps_rank = 0;
                                $old_mobile_rank = 0;
                                $old_mobile_maps_rank = 0;
                                $old_bing_rank = 0;
                                $rank_change = 0;
                                $maps_rank_change = 0;
                                $mobile_rank_change = 0;
                                $mobile_maps_rank_change = 0;
                                $bing_rank = 0;
                                $bing_rank_change = 0;
                                $bing_map_rank_change = 0;
                                $old_bing_maps_rank = 0;
                                if (count($historydata) > 0) {
                                    $old_rank = $historydata[0]['rank'];
                                    $old_maps_rank = $historydata[0]['maps_rank'];
                                    $old_mobile_rank = $historydata[0]['mobile_rank'];
                                    $old_mobile_maps_rank = $historydata[0]['mobile_maps_rank'];
                                    $old_bing_rank = $historydata[0]['bing_rank'];
                                    $old_bing_maps_rank = $historydata[0]['bing_maps_rank'];
                                }

                                $rank_change = intval($key_data->rank) - intval($old_rank);
                                $maps_rank_change = intval($key_data->maps_rank) - intval($old_maps_rank);
                                $mobile_rank_change = intval($key_data->mobile_rank) - intval($old_mobile_rank);
                                $mobile_maps_rank_change = intval($key_data->mobile_maps_rank) - intval($old_mobile_maps_rank);
                                $bing_rank_change = intval($key_data->bing_rank) - intval($old_bing_rank);
                                $bing_map_rank_change = intval($key_data->bing_maps_rank) - intval($old_bing_maps_rank);

                                // BUCKET code end       

                                array_push($keyword, array(
                                    "id" => intval($keyword_id),
                                    "keyword" => $key_data->keyword,
                                    "is_ranked_url_target" => $is_ranked_url_target,
                                    "isprimary" => $isprimary == NULL ? 0 : $isprimary,
                                    "istarget" => $group_target == NULL ? 0 : $group_target,
                                    "ranked_url" => $key_data->ranked_url == NULL ? '' : $key_data->ranked_url,
                                    "rank" => array("l" => $key_data->rank == NULL ? 50 : intval($key_data->rank), "r" => $rank_change),
                                    "maps_rank" => array("l" => $key_data->maps_rank == NULL ? 50 : intval($key_data->maps_rank), "r" => $maps_rank_change),
                                    "mobile_rank" => array("l" => $key_data->mobile_rank == NULL ? 50 : intval($key_data->mobile_rank), "r" => $mobile_rank_change),
                                    "mobile_maps_rank" => array("l" => $key_data->mobile_maps_rank == NULL ? 50 : intval($key_data->mobile_maps_rank), "r" => $mobile_maps_rank_change),
                                    "bing_rank" => array("l" => $key_data->bing_rank == NULL ? 50 : intval($key_data->bing_rank), "r" => $bing_rank_change),
                                    "bing_maps_rank" => array("l" => $key_data->bing_maps_rank == NULL ? 50 : intval($key_data->bing_maps_rank), "r" => $bing_map_rank_change),
                                    "org_visits" => $org_visits,
                                    "org_conv" => $org_conversion,
                                    "org_conv_rate" => $org_conversion_rate,
                                    "googleSearchVolume" => $search_vol,
                                    "comp" => $compt,
                                    "bid" => $bid,
                                    "bucket" => $current_bucket,
                                    "bucket_days" => $days_in_bucket_val,
                                    "time" => "100.00%",
                                    "bucket_text_color" => $bucket_color,
                                    "bucket_background_color" => $bucket_color_style
                                ));

                                if ($isprimary == 1) {

                                    array_push($allprimarykeywords, $keyword);
                                }
                            }
                        }
                        array_push($group_info, array(
                            "group_id" => $group_id,
                            "keywords" => $keyword
                        ));
                    }
                }
                if ($is_primary == 1) {

                    $this->json(1, "keywords found", $allprimarykeywords);
                } else {
                    
                }

                $this->json(1, "keywords found", $group_info);
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {
            $this->json(0, "silence is golden");
        }
    }

    // rank vs target section 
    public function getRankVsTargetData() {

        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $data = json_decode(file_get_contents('php://input'));
            $campaign_id = isset($data->campaign_id) ? intval($data->campaign_id) : 0;

            if ($this->is_token_valid()) {

                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];

                if ($campaign_id == 0) {

                    $keyGrpData = $this->Keygroups->find("all", [
                                'contain' => ['Keywords']
                            ])->all()->toArray();
                } else {

                    if ($this->Keyword->is_valid_campaign($campaign_id)) {

                        $keyGrpData = $this->Keygroups->find("all", [
                                    "conditions" => ["Keygroups.campaign_id" => $campaign_id],
                                    'contain' => ['Keywords']
                                ])->all()->toArray();
                    } else {

                        $this->json(0, "invalid campaign id", array("campaign id" => "required"));
                    }
                }

                $group_info = array();

                if (count($keyGrpData) > 0) {

                    foreach ($keyGrpData as $key => $value) {
                        // landing page from tbl_keygroup
                        $landing_page = $value->landing_page != NULL ? $value->landing_page : '';
                        $group_target = $value->is_target;
                        $group_id = $value->id;
                        $keyword = array();

                        $campaign_details = $this->getCampaignDetailsById($value->campaign_id, array("name", "local_location"));
                        $camp_name = '';
                        $camp_location = '';
                        if (!empty($campaign_details) && $campaign_id == 0) {
                            $camp_name = $campaign_details[0]['name'];
                            $camp_location = $campaign_details[0]['local_location'];
                        }
                        if (count($value->keywords) > 0) {

                            foreach ($value->keywords as $in => $kwrd) {
                                // ranked url from tbl_keywords

                                $ranked_page = $kwrd->ranked_url != NULL ? $kwrd->ranked_url : '';
                                $is_match = 0;
                                $rank_score = $kwrd->rank == NULL ? 50 : $kwrd->rank;
                                $rank_available = $kwrd->rank == NULL ? 0 : 1;
                                // comparing ranked_url with landing page
                                if ($this->trimUrl($landing_page) == $this->trimUrl($ranked_page) && !empty($landing_page && !empty($ranked_page))) {
                                    $is_match = 1;
                                }
                                array_push($keyword, array(
                                    "keyword" => $kwrd->keyword,
                                    "isprimary" => $kwrd->isprimary,
                                    "istarget" => $group_target,
                                    "target_url" => $landing_page,
                                    "ranking_url" => $ranked_page,
                                    "rank" => intval($rank_score),
                                    "match" => $is_match,
                                    "rank_avail" => intval($rank_available)
                                ));
                            }
                        }

                        // push found keywords in group_info
                        array_push($group_info, array(
                            "group_id" => $group_id,
                            "camp_name" => $camp_name,
                            "camp_loc" => $camp_location,
                            "keywords" => $keyword
                        ));
                    }
                }

                if (count($keyword) > 0) {

                    $this->json(1, "data found", $group_info);
                } else {

                    $this->json(0, "no data found", $group_info);
                }
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function getCampaignDetailsById($id, $fields_name) {
        $this->autoRender = false;
        if ($id > 0) {
            if ($this->Keyword->is_valid_campaign($id)) {

                $fields = implode(",", $fields_name);

                $sqlQueryForCampaignDetails = "SELECT $fields from tbl_campaigns where id = " . $id;
                $results = $this->connection->execute($sqlQueryForCampaignDetails)->fetchAll("assoc");
                return $results;
            }
        }
        return false;
    }

    // Setting Columns to show on keyword tool
    public function setKeywordsColumn() {

        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $data = json_decode(file_get_contents('php://input'));
            $show_colums = isset($data->show_colums) ? $data->show_colums : '';
            // show_columns: comma seperated columns
            if ($this->is_token_valid()) {

                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];
                if (!empty($show_colums)) {
                    $show_colums = explode(",", $show_colums);
                    $has_saved_columns = $this->get_user_meta($location_id, 'keyword_columns');
                    if (empty($has_saved_columns)) {
                        $this->add_user_meta($location_id, "keyword_columns", json_encode($show_colums));
                    } else {
                        $this->update_user_meta($location_id, "keyword_columns", json_encode($show_colums));
                    }
                    $this->json(1, "keyword columns saved");
                } else {

                    $this->json(0, "no columns found", array("columns" => "required"));
                }
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    // get saved columns
    public function getKeywordsColumns() {
        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            $token = $this->request->header('token');

            if ($this->is_token_valid()) {

                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];

                $has_saved_columns = $this->get_user_meta($location_id, 'keyword_columns');
                if (!empty($has_saved_columns)) {
                    $this->json(1, "columns found", implode(",", json_decode($has_saved_columns)));
                } else {

                    $this->json(0, "columns not saved so far");
                }
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        }
    }

    // get campaign groups
    public function getCampaignGroups() {

        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $data = json_decode(file_get_contents('php://input'));
            $campaign_id = isset($data->campaign_id) ? trim($data->campaign_id) : 0;
            $data_order = isset($data->sortby) ? trim($data->sortby) : "sort_from_a_z";
            $status = isset($data->status) ? $data->status : '';
            /* sort_from_a_z, sort_from_z_a, created_date_asc, created_date_desc, updated_date_asc, updated_date_desc */
            if ($this->is_token_valid()) {

                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];
                $keyGrpData = array();

                // sorting conditions
                $sort_conditions = '';
                if ($data_order == "sort_from_a_z") {

                    $sort_conditions = array('Keywords.keyword' => 'ASC');
                } else if ($data_order == "sort_from_z_a") {

                    $sort_conditions = array('Keywords.keyword' => 'DESC');
                } else if ($data_order == "created_date_asc") {

                    $sort_conditions = array('Keywords.created' => 'ASC');
                } else if ($data_order == "created_date_desc") {

                    $sort_conditions = array('Keywords.created' => 'DESC');
                } else if ($data_order == "updated_date_asc") {

                    $sort_conditions = array('Keywords.modified' => 'ASC');
                } else if ($data_order == "updated_date_desc") {

                    $sort_conditions = array('Keywords.modified' => 'DESC');
                }

                if ($campaign_id == 0) {

                    $keyGrpData = $this->Keygroups->find("all", [
                                'contain' => ['Keywords' => [
                                        'sort' => $sort_conditions
                                    ]]
                            ])->all()->toArray();
                } else {

                    if ($this->Keyword->is_valid_campaign($campaign_id)) {

                        $keyGrpData = $this->Keygroups->find("all", [
                                    "conditions" => ["Keygroups.campaign_id" => $campaign_id],
                                    'contain' => ['Keywords' => [
                                            'sort' => $sort_conditions
                                        ]]
                                ])->all()->toArray();
                    } else {

                        $this->json(0, "invalid campaign id", array("campaign id" => "required"));
                    }
                }

                $keygrp_data_found = array();
                $group_info = array();

                if (count($keyGrpData) > 0) {

                    foreach ($keyGrpData as $key => $value) {
                        $syn_keyword = array();
                        $primary_keywords = '';
                        $group_id = $value->id;
                        $group_status = $value->status;
                        $live_date = $value->live_date;
                        $resource_page = $value->resource_page;
                        $notes = $value->notes;
                        $campaign_id = $value->campaign_id;
                        $group_target = $value->is_target;
                        $google_location = $value->google_location;
                        $group_createdBy = $value->created_by;
                        $group_date = $value->modified;
                        $home_page = $value->home_page;
                        $landing_page = $value->landing_page;
                        if (count($value->keywords) > 0) {

                            foreach ($value->keywords as $index => $key_data) {
                                $keyword = $key_data->keyword;
                                $isprimary = $key_data->isprimary;
                                if ($isprimary == 0) {
                                    array_push($syn_keyword, $keyword);
                                } else if ($isprimary == 1) {
                                    $primary_keywords = $keyword;
                                }
                            }
                        }

                        $grp_status = array(
                            "group_id" => $group_id,
                            "status" => $group_status,
                            "is_target" => $group_target,
                            "created_by" => $this->getUserDetails($group_createdBy)[0]['fname'] . " " . $this->getUserDetails($group_createdBy)[0]['lname'],
                            "created_date" => $this->ChangeDateFormat($group_date),
                            "location" => $google_location,
                            "home_page" => $home_page,
                            "landing_url" => $landing_page,
                            "keyword" => $primary_keywords,
                            "synkeyword" => $syn_keyword,
                            "notes" => $notes,
                            "resource_page" => $resource_page,
                            "live_date" => $live_date,
                            "campaign_id" => $campaign_id
                        );

                        if ($status == '') {
                            array_push($group_info, $grp_status);
                        } else if ($status == 0 && $group_status == 0) {
                            array_push($group_info, $grp_status);
                        } else if ($status == 1 && $group_status == 1) {
                            array_push($group_info, $grp_status);
                        }
                        //array_push($keygrp_data_found, $group_info);
                    }
                }

                if (count($group_info) > 0) {

                    $this->json(1, "data found", $group_info);
                } else {

                    $this->json(1, "no data found", $group_info);
                }
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        }
    }

    public function locationConversionPage() {

        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $data = json_decode(file_get_contents('php://input'));
            $landing_page = isset($data->url) ? trim($data->url) : '';
            $page_type = isset($data->page_type) ? trim($data->page_type) : '';
            $operation_type = isset($data->operation_type) ? trim($data->operation_type) : '';

            if ($this->is_token_valid()) {

                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];

                if (empty($location_id)) {

                    $this->json(0, "location is empty", array("valid token" => "required"));
                }

                $status = $this->Keyword->locationConversionPage(array(
                    "operation" => "exists",
                    "url" => "",
                    "type" => $page_type,
                    "location_id" => $location_id
                ));
                //$this->pr(json_decode($urls));
                $this->json(1, $urls);
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function isLandingPageExists() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $data = json_decode(file_get_contents('php://input'));
            $landing_page = isset($data->url) ? trim($data->url) : '';
            // $page_type = isset($data->page_type) ? trim($data->page_type) : '';

            if ($this->is_token_valid()) {

                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];

                if (empty($location_id)) {

                    $this->json(0, "location is empty", array("valid token" => "required"));
                }

                $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $landing_page)), "/");

                $page_types = array("landing_page", "thankyou_page");

                $found = 0;
                $pg_type = '';
                foreach ($page_types as $page_type) {

                    $status = $this->Keyword->locationConversionPage(array(
                        "operation" => "exists",
                        "url" => $trimurl,
                        "type" => $page_type,
                        "location_id" => $location_id
                    ));

                    if ($status['status']) {
                        $found = 1;
                        $pg_type = $status['type'];
                    }
                }
                if ($found) {

                    $this->json(0, "url already exists in " . $landing_page, array("page_type" => $pg_type));
                } else {

                    $this->json(1, "ok");
                }
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function removeLocationConversionPage() {

        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $data = json_decode(file_get_contents('php://input'));
            $landing_page = isset($data->url) ? trim($data->url) : '';
            $page_type = isset($data->page_type) ? trim($data->page_type) : '';

            if ($this->is_token_valid()) {

                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];

                if (empty($location_id)) {

                    $this->json(0, "location is empty", array("valid token" => "required"));
                }

                $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $landing_page)), "/");

                $status = $this->Keyword->locationConversionPage(array(
                    "operation" => "remove",
                    "url" => $trimurl,
                    "type" => $page_type,
                    "location_id" => $location_id
                ));

                if ($status['status']) {

                    $this->json(1, "page removed");
                } else {

                    $this->json(0, "failed to remove");
                }
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function addConversionPage() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $data = json_decode(file_get_contents('php://input'));
            $landing_page = isset($data->page_url) ? trim($data->page_url) : '';
            $page_type = isset($data->page_type) ? trim($data->page_type) : '';
            $mesage = '';
            if ($page_type == "landing_page") {
                $mesage = "Landing Page";
            } else if ($page_type == "") {
                $mesage = "Thank you page";
            }
            if ($this->is_token_valid()) {

                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];

                if (empty($location_id)) {

                    $this->json(0, "location_id is empty", array("valid token" => "required"));
                }

                if ($this->Keyword->createConversionLandingPage(array("location_id" => $location_id, "page_url" => $landing_page, "user_id" => $user_id, "type" => $page_type))) {

                    $this->json(1, $mesage . " added");
                } else {

                    $this->json(0, "Already " . $mesage . " added");
                }
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function countConversionMetrics($location_id, $RankingURL, $from_date, $to_date, $type = '') {

        $ConvCountForClient = 0;
        $source['organic'] = 0;
        $source['paid'] = 0;
        $source['referral'] = 0;
        $source['social'] = 0;
        $source['direct'] = 0;
        $source['total'] = 0;
        $land_url = $this->website_format($RankingURL);

        $results = $this->connection
                ->execute("SELECT sum(organic) as total_organic, sum(paid) as total_paid,sum(referral) as total_referral, sum(social) as total_social,sum(direct) as total_direct,sum(total) as total_conv FROM tbl_conversions_data WHERE location_id = " . $location_id . " and `created` >='$from_date' and `created` <= '$to_date' and (`url` = '$RankingURL' || `url` = '$land_url' || `url` = 'http://$land_url' || `url` = 'https://$land_url' || `url` = 'www.$land_url')")
                ->fetchAll('assoc');

        if (!empty($results)) {

            $data = $results[0];

            $source['organic'] = $data['total_organic'];
            $source['paid'] = $data['total_paid'];
            $source['referral'] = $data['total_referral'];
            $source['social'] = $data['total_social'];
            $source['direct'] = $data['total_direct'];
            $source['total'] = $ConvCountForClient = $data['total_conv'];
        } if ($type == 'all') {

            return $source;
        }
    }

    //upload CSV file - import keywords
    public function uploadKeywordCSV() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $data = json_decode(file_get_contents('php://input'));
            $campaign_id = isset($data->campaign_id) ? trim($data->campaign_id) : 0;

            if ($this->is_token_valid()) {

                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];

                if ($this->Keyword->is_valid_campaign($campaign_id)) {

                    $duplicate_msg = 'Please remove duplicate keywords. Following duplicate keywords found <br/><br/>';
                    $duplicatefounds = 0;
                    // uploading csv file
                    if ($_FILES["file-0"]["name"] != "") {
                        $file = $_FILES["file-0"]['tmp_name'];
                        $now = date("Y-m-d H:i:s");
                        $fp = fopen($file, 'r');

                        if ($fp) {
                            $count = 0;
                            while (($line = fgetcsv($fp, 1000, ";")) != FALSE) {

                                $line = $line[0];
                                $line = explode(',', $line);
                                if ($count == 0) {
                                    if (count($line) != 8) {
                                        $this->json(0, "You are using a wrong csv format. Please check sample Doc");
                                    }
                                }

                                if ($count > 0) {

                                    $pkeyword = $line[0];
                                    $skeyword = array();
                                    if (trim($line[1]) != '') {
                                        $skeyword = explode(':', $line[1]);
                                    }

                                    $allkeywordsdata = $skeyword;
                                    $allkeywordsdata[] = $pkeyword;

                                    $allkeywords = array();
                                    foreach ($allkeywordsdata as $allkeywordsdt) {
                                        $allkeywords[] = trim(strtolower($allkeywordsdt));
                                    }

                                    $duplikeywords = array();
                                    $duplicateonly = array();
                                    foreach ($allkeywords as $allkeyword) {
                                        if (!in_array($allkeyword, $duplikeywords)) {
                                            $duplikeywords[] = $allkeyword;
                                        } else {
                                            $duplicateonly[] = $allkeyword;
                                        }
                                    }

                                    $alreadyadded = 0;
                                    $duplicatetxt = array();
                                    if (!empty($duplicateonly)) {
                                        $duplicatetxt = implode(", ", $duplicateonly);
                                        $duplicate_msg .= $duplicatetxt;
                                        $alreadyadded++;
                                        $duplicatefounds++;
                                        continue;
                                    }

                                    $duplicatescnts = array();

                                    if (count($allkeywords) > 0) {

                                        foreach ($allkeywords as $allkeyword) {

                                            $haduplicate = $this->connection
                                                    ->execute("SELECT pk.keyword FROM tbl_keywords k INNER JOIN tbl_keywords pk ON k.group_id = pk.group_id WHERE pk.isprimary = 1 AND k.campaign_id = " . $campaign_id . " AND k.keyword = '" . $allkeyword . "'")
                                                    ->fetchAll('assoc');

                                            if (!empty($haduplicate)) {
                                                $duplicatescnts[] = "Keyword '" . $allkeyword . "' already exists in group '" . $haduplicate[0]['keyword'] . "' (Primary)";
                                            }
                                        }
                                    }

                                    if (!empty($duplicatescnts)) {
                                        $txt = '';
                                        foreach ($duplicatescnts as $duplicat) {
                                            $txt .= "$duplicat <br/>";
                                        }
                                        if ($alreadyadded == 1) {
                                            $duplicate_msg .= '<br/><br/>';
                                        }

                                        $duplicate_msg .= $txt;
                                        $duplicatefounds++;
                                        continue;
                                    }
                                }
                                $count++;
                            }

                            if ($duplicatefounds > 0) {
                                $this->json(0, $duplicate_msg);
                            }

                            $uid = $user_id;
                            $campaign_data = $this->connection
                                    ->execute("SELECT local_location FROM tbl_campaigns WHERE id = " . $campaign_id)
                                    ->fetchAll('assoc');
                            $locallocation = $campaign_data[0]['local_location'];

                            $fp = fopen($file, 'r');
                            $cnt = 0;
                            $group_id = 0;
                            while (($line = fgetcsv($fp, 1000, ";")) != FALSE) {
                                if ($cnt == 0) {
                                    $cnt++;
                                    continue;
                                }
                                $line = $line[0];
                                $line = explode(',', $line);
                                $landingpage = trim($line[2]);
                                $livedate = trim($line[5]);
                                $homepage = trim($line[3]);
                                $resourcepage = trim($line[6]);
                                $is_target_keyword = isset($line[4]) && trim($line[4]) != '' ? trim($line[4]) : 'No';
                                $notes = trim($line[7]);
                                $status = 1;

                                $pkeyword = trim($line[0]);
                                $skeyword = array();
                                if (trim($line[1]) != '') {
                                    $skeyword = explode(':', trim($line[1]));
                                }
                                // creating keygroups
                                $keygroup_status = $this->Keyword->createLocationKeygroup(array(
                                    "location_id" => $location_id,
                                    "user_id" => $user_id,
                                    'campaign_id' => $campaign_id,
                                    'google_location' => $locallocation,
                                    'landing_page' => $landingpage,
                                    'live_date' => $livedate,
                                    'home_page' => $homepage,
                                    'resource_page' => $resourcepage,
                                    'is_target' => $is_target_keyword,
                                    'notes' => $notes,
                                    'status' => $status,
                                    'created' => date("Y-m-d H:i:s")
                                ));

                                if (count($keygroup_status) > 0) {
                                    $keygroup_id = $keygroup_status[0]['id'];
                                }

                                $group_id = $keygroup_id;

                                if (count($skeyword) > 0) {
                                    array_unshift($skeyword, $pkeyword);
                                } else {
                                    $skeyword = array($pkeyword);
                                }

                                $i = 0;
                                foreach ($skeyword as $keyword) {
                                    if (trim($keyword) != '') {
                                        $isprimary = 0;
                                        if ($i == 0) {
                                            $isprimary = 1;
                                        }
                                        // creating keywords
                                        $this->createKeyword(array(
                                            "group_id" => $group_id,
                                            "campaign_id" => $campaign_id,
                                            "location_id" => $location_id,
                                            "keyword" => $keyword,
                                            "is_primary" => $isprimary,
                                            "user_id" => $user_id
                                        ));

                                        $i++;
                                    }
                                }
                            }
                            $this->json(1, "CSV File successfully imported.");
                        }
                        $this->json(0, "File is empty. Please add some records.");
                    }
                } else {

                    $this->json(0, "Invalid Campaign Id", array("campaign id" => "required"));
                }
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    // this method is download the file placed in /webroot folder
    public function downloadSampleCSV() {
        $this->autoRender = false;
        $filePath = WWW_ROOT . 'files/sample_keywords.csv';
        $this->response->file($filePath, array('download' => true, 'name' => 'sample_keywords.csv'));
    }

    // executive summary report
    public function executiveSummaryReport() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $data = json_decode(file_get_contents('php://input'));
            $campaign_id = isset($data->campaign_id) ? intval($data->campaign_id) : 0;
            $is_target = isset($data->is_target) ? intval($data->is_target) : 0;
            $from_data = isset($data->from_date) ? $data->from_date : date("Y-m-d", strtotime("-31 day"));
            $to_data = isset($data->to_date) ? $data->to_date : date("Y-m-d", strtotime("-1 day"));

            if ($this->is_token_valid()) {

                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];

                if ($campaign_id == 0) {
                    // condition for show all keywords

                    $avgSql = "SELECT avg(case when rank IS NULL then 50 else rank end) as average from tbl_keywords";

                    $results = $this->connection
                            ->execute($avgSql)
                            ->fetchAll('assoc');
                    $this->json(1, "report found", $this->executiveSummaryReportMetrics($location_id, $from_data, $to_data, $campaign_id, $is_target));
                } else {
                    // campaign id has some value now
                    if ($this->Keyword->is_valid_campaign($campaign_id)) {

                        $this->json(1, "report found", $this->executiveSummaryReportMetrics($location_id, $from_data, $to_data, $campaign_id, $is_target));
                    } else {

                        $this->json(0, "invalid campaign id", array("campaign id" => "required"));
                    }
                }
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    // calculations of executive summary report
    public function executiveSummaryReportMetrics($location_id, $from_date, $to_date, $campaign_id = 0, $is_target = 0) {

        /*
         * Param details
         * ================================================
         * location_id : id of current location logged in 
         * from_date: record from which date
         * to_date: record upto which date
         * campaign_id: record of any campaign then its id here else for all applied
         * is_target: for target keywords if yes then 1 else 0
         */

        $get_data = $this->calculateKeywordsMetrics($location_id, $from_date, $to_date, $campaign_id, $is_target);

        $keywords_data = $get_data['keyword_data'];
        $rankvstarget = $get_data['ranked_data'];

        $number_of_keywords = array();
        $average_rank = array();
        $top50_avg_rank = array();
        $top10_rank = array();
        $top3_rank = array();
        $top1_rank = array();
        $seo_score = array();
        $visibility_score = array();
        $rankvstarget_score = array();
        $all_landing_urls = array();

        $marketing_eff_score = array(
            "current_score" => "54.81",
            "last_90days_score" => "26.7",
            "last_90days_score_change" => 28.11,
            "last_180days_score" => "27.45",
            "last_180days_score_change" => 27.36,
            "last_1yr_score" => "0.45",
            "last_1yr_score_change" => 54.36,
        );

        $content_optimization_score = array(
            "current_score" => "75.51",
            "last_90days_score" => "0",
            "last_90days_score_change" => 75.51,
            "last_180days_score" => "0",
            "last_180days_score_change" => 75.51,
            "last_1yr_score" => "N/A",
            "last_1yr_score_change" => 75.51,
        );

        $citation_score = array(
            "current_score" => "5.36",
            "last_90days_score" => "N/A",
            "last_90days_score_change" => "N/A",
            "last_180days_score" => "N/A",
            "last_180days_score_change" => "N/A",
            "last_1yr_score" => "N/A",
            "last_1yr_score_change" => "N/A",
        );

        $siteaudit_score = array(
            "current_score" => "64",
            "last_90days_score" => "69",
            "last_90days_score_change" => -5,
            "last_180days_score" => "69",
            "last_180days_score_change" => -5,
            "last_1yr_score" => "N/A",
            "last_1yr_score_change" => "N/A",
        );

        if (!empty($keywords_data)) {

            $number_of_keywords = array(
                "current_score" => $keywords_data['total_keywords'],
                "last_90days_score" => $keywords_data['keywords_days90'],
                "last_90days_score_change" => intval($keywords_data['total_keywords']) - intval($keywords_data['keywords_days90']),
                "last_180days_score" => $keywords_data['keywords_days180'],
                "last_180days_score_change" => intval($keywords_data['total_keywords']) - intval($keywords_data['keywords_days180']),
                "last_1yr_score" => $keywords_data['keywords_yearback'],
                "last_1yr_score_change" => intval($keywords_data['total_keywords']) - intval($keywords_data['keywords_yearback']),
            );

            $visibility_score = array(
                "current_score" => $data1 = $this->doPercentage($keywords_data['current_top10_rank'], $keywords_data['total_keywords']),
                "last_90days_score" => $data2 = $this->doPercentage($keywords_data['top10_rank_days90'], $keywords_data['keywords_days90']),
                "last_90days_score_change" => floatval($data1 - $data2),
                "last_180days_score" => $data3 = $this->doPercentage($keywords_data['top10_rank_days90'], $keywords_data['keywords_days180']),
                "last_180days_score_change" => floatval($data1 - $data3),
                "last_1yr_score" => $data4 = $this->doPercentage($keywords_data['top10_rank_days90'], $keywords_data['keywords_yearback']),
                "last_1yr_score_change" => floatval($data1 - $data4),
            );

            $average_rank = array(
                "current_score" => $keywords_data['current_avg_rank'],
                "last_90days_score" => $keywords_data['avg_rank_days90'],
                "last_90days_score_change" => floatval($keywords_data['avg_rank_days90'] - $keywords_data['current_avg_rank']),
                "last_180days_score" => $keywords_data['avg_rank_days180'],
                "last_180days_score_change" => floatval($keywords_data['avg_rank_days180'] - $keywords_data['current_avg_rank']),
                "last_1yr_score" => $keywords_data['avg_rank_yearback'],
                "last_1yr_score_change" => floatval($keywords_data['avg_rank_yearback'] - $keywords_data['current_avg_rank']),
            );

            $top50_avg_rank = array(
                "current_score" => $data1 = $this->doPercentage($keywords_data['current_sum_top50_rank'], $keywords_data['top50_sum_total']),
                "last_90days_score" => $data2 = $this->doPercentage($keywords_data['top50_sum_rank_days90'], $keywords_data['top50_sum_total']),
                "last_90days_score_change" => floatval($data1 - $data2),
                "last_180days_score" => $data3 = $this->doPercentage($keywords_data['top50_sum_rank_days180'], $keywords_data['top50_sum_total']),
                "last_180days_score_change" => floatval($data1 - $data3),
                "last_1yr_score" => $data4 = $this->doPercentage($keywords_data['top50_sum_rank_yearback'], $keywords_data['top50_sum_total']),
                "last_1yr_score_change" => floatval($data1 - $data4),
            );

            $top10_rank = array(
                "current_score" => $keywords_data['current_top10_rank'],
                "last_90days_score" => $keywords_data['top10_rank_days90'],
                "last_90days_score_change" => intval($keywords_data['current_top10_rank']) - intval($keywords_data['top10_rank_days90']),
                "last_180days_score" => $keywords_data['top10_rank_days180'],
                "last_180days_score_change" => intval($keywords_data['current_top10_rank']) - intval($keywords_data['top10_rank_days180']),
                "last_1yr_score" => $keywords_data['top10_rank_yearback'],
                "last_1yr_score_change" => intval($keywords_data['current_top10_rank']) - intval($keywords_data['top10_rank_yearback']),
            );

            $seo_score = array(
                "current_score" => $data1 = $this->doPercentage($keywords_data['current_top10_rank'], $keywords_data['current_avg_rank']),
                "last_90days_score" => $data2 = $this->doPercentage($keywords_data['top10_rank_days90'], $keywords_data['avg_rank_days90']),
                "last_90days_score_change" => floatval($data1 - $data2),
                "last_180days_score" => $data3 = $this->doPercentage($keywords_data['top10_rank_days180'], $keywords_data['avg_rank_days180']),
                "last_180days_score_change" => floatval($data1 - $data3),
                "last_1yr_score" => $data4 = $this->doPercentage($keywords_data['top10_rank_yearback'], $keywords_data['avg_rank_yearback']),
                "last_1yr_score_change" => floatval($data1 - $data4),
            );

            $top3_rank = array(
                "current_score" => $keywords_data['current_top3_rank'],
                "last_90days_score" => $keywords_data['top3_rank_days90'],
                "last_90days_score_change" => intval($keywords_data['current_top3_rank']) - intval($keywords_data['top3_rank_days90']),
                "last_180days_score" => $keywords_data['top3_rank_days180'],
                "last_180days_score_change" => intval($keywords_data['current_top3_rank']) - intval($keywords_data['top3_rank_days180']),
                "last_1yr_score" => $keywords_data['top3_rank_yearback'],
                "last_1yr_score_change" => intval($keywords_data['current_top3_rank']) - intval($keywords_data['top3_rank_yearback']),
            );

            $top1_rank = array(
                "current_score" => $keywords_data['current_top1_rank'],
                "last_90days_score" => $keywords_data['top1_rank_days90'],
                "last_90days_score_change" => intval($keywords_data['current_top1_rank']) - intval($keywords_data['top1_rank_days90']),
                "last_180days_score" => $keywords_data['top1_rank_days180'],
                "last_180days_score_change" => intval($keywords_data['current_top1_rank']) - intval($keywords_data['top1_rank_days180']),
                "last_1yr_score" => $keywords_data['top1_rank_yearback'],
                "last_1yr_score_change" => intval($keywords_data['current_top1_rank']) - intval($keywords_data['top1_rank_yearback']),
            );

            if ($campaign_id == 0) {

                foreach ($rankvstarget['all_landing_urls'] as $in => $data) {
                    $land_url = $data['landing_page'] == NULL ? '' : $data['landing_page'];
                    $land_url = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $land_url)), "/");
                    array_push($all_landing_urls, $land_url);
                }
            } else {
                foreach ($rankvstarget['campaign_landing_urls'] as $in => $data) {
                    $land_url = $data['landing_page'] == NULL ? '' : $data['landing_page'];
                    $land_url = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $land_url)), "/");
                    array_push($all_landing_urls, $land_url);
                }
            }

            if (count($rankvstarget) > 0) {
                // current rank vs target calculation
                $current_data = $this->findRankVsTargetMetrics($all_landing_urls, $rankvstarget['count_urls']);
                // last 90 days rank vs target calculation
                $last90days_data = $this->findRankVsTargetMetrics($all_landing_urls, $rankvstarget['last_90_days']);
                // last 180 days rank vs target calculation
                $last180days_data = $this->findRankVsTargetMetrics($all_landing_urls, $rankvstarget['last_180_days']);
                // last 1 Yr rank vs target calculation
                $last1yrdays_data = $this->findRankVsTargetMetrics($all_landing_urls, $rankvstarget['last_1_yr']);

                $rankvstarget_score = array(
                    "current_score" => $data1 = $this->doPercentage($current_data['ranked_count'], $current_data['total_count']),
                    "last_90days_score" => $data2 = $this->doPercentage($last90days_data['ranked_count'], $last90days_data['total_count']),
                    "last_90days_score_change" => floatval($data1 - $data2),
                    "last_180days_score" => $data3 = $this->doPercentage($last180days_data['ranked_count'], $last180days_data['total_count']),
                    "last_180days_score_change" => floatval($data1 - $data3),
                    "last_1yr_score" => $data4 = $this->doPercentage($last1yrdays_data['ranked_count'], $last1yrdays_data['total_count']),
                    "last_1yr_score_change" => floatval($data1 - $data4),
                );
            }
        }

        $summary_array = array(
            "visibility_score" => $visibility_score,
            "total_number_of_keywords" => $number_of_keywords,
            "average_rank_data" => $average_rank,
            "rank_top50" => $top50_avg_rank,
            "top10_rank" => $top10_rank,
            "top3_rank" => $top3_rank,
            "rank_vs_target" => $rankvstarget_score,
            "top1_rank" => $top1_rank,
            "seo_score" => $seo_score,
            "marketing_eff_score" => $marketing_eff_score,
            "content_optimization_score" => $content_optimization_score,
            "citation_score" => $citation_score,
            "siteaudit_score" => $siteaudit_score
        );

        return $summary_array;
    }

    public function findRankVsTargetMetrics($source_urls, $matching_urls) {

        $allrankedKeywords = 0;
        $allkeywords = 0;
        // calculating current rank/target value in %, formula used count(ranked url keyword)/count(all keywords)
        foreach ($matching_urls as $k => $v) {
            $cid = $v['campaign_id'];
            $gid = $v['group_id'];
            $rankUrl = $v['ranked_url'] == NULL ? '' : $v['ranked_url'];
            $rankUrl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $rankUrl)), "/");
            if (in_array($rankUrl, $source_urls)) {
                $allrankedKeywords++;
            }
            $allkeywords++;
        }

        return array("ranked_count" => $allrankedKeywords, "total_count" => $allkeywords);
    }

    /* Number of Kewords */

    public function calculateKeywordsMetrics($location_id, $from_date, $to_date, $campaign_id = '', $is_target = 0) {

        /*
         * to_date is coming as current_date
         */
        // date ranges
        $back90daysDate = date("Y-m-d", strtotime("$to_date -3 month"));
        $back180daysDate = date("Y-m-d", strtotime("$to_date -6 month"));
        $back1YrdaysDate = date("Y-m-d", strtotime("$to_date -12 month"));
        // join query to make in join if target selected
        $sqlJoinQueryForTargetKeywords = '';
        $targetCondition = '';
        $campaign_condition = '';
        $campaign_condition_keygroup = '';
        if ($is_target == 1) {
            $sqlJoinQueryForTargetKeywords = " INNER JOIN tbl_keygroup kg ON kw.group_id = kg.id";
            $targetCondition = " AND kg.is_target = 1";
        }
        if (!empty($campaign_id)) {
            $campaign_condition = " AND kw.campaign_id = " . $campaign_id;
            $campaign_condition_keygroup = " AND kg.campaign_id = " . $campaign_id;
        }

        // 90 days back
        $NumberofKeywords = $this->connection
                ->execute("SELECT "
                        //number of keywords
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$from_date' and kw.dateOfRank <= '$to_date') AS total_keywords,"
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$back90daysDate' and kw.dateOfRank <= '$to_date') AS keywords_days90,"
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$back180daysDate' and kw.dateOfRank <= '$to_date') as keywords_days180, "
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$back1YrdaysDate' and kw.dateOfRank <= '$to_date') as keywords_yearback,"
                        //avg rank
                        . "(SELECT ROUND(avg(case when rank IS NULL then 50 else kw.rank end),2) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$from_date'  and kw.dateOfRank <= '$to_date') as current_avg_rank,"
                        . "(SELECT ROUND(avg(case when rank IS NULL then 50 else kw.rank end),2) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$back90daysDate' and kw.dateOfRank <= '$to_date') AS avg_rank_days90,"
                        . "(SELECT ROUND(avg(case when rank IS NULL then 50 else kw.rank end),2) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$back180daysDate' and kw.dateOfRank <= '$to_date') as avg_rank_days180, "
                        . "(SELECT ROUND(avg(case when rank IS NULL then 50 else kw.rank end),2) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$back1YrdaysDate' and kw.dateOfRank <= '$to_date') as avg_rank_yearback,"
                        //avg rank top 50
                        . "(SELECT sum(kw.rank) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 50 and kw.dateOfRank >= '$from_date' and kw.dateOfRank <= '$to_date' and kw.rank IS NOT NULL) as current_sum_top50_rank,"
                        . "(SELECT sum(kw.rank) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 50 and kw.dateOfRank >= '$back90daysDate' and kw.dateOfRank <= '$to_date' and kw.rank IS NOT NULL) AS top50_sum_rank_days90,"
                        . "(SELECT sum(kw.rank) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 50 and kw.dateOfRank >= '$back180daysDate' and kw.dateOfRank <= '$to_date' and kw.rank IS NOT NULL) as top50_sum_rank_days180, "
                        . "(SELECT sum(kw.rank) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 50 and kw.dateOfRank >= '$back1YrdaysDate' and kw.dateOfRank <= '$to_date' and kw.rank IS NOT NULL) as top50_sum_rank_yearback,"
                        . "(SELECT sum(case when rank IS NULL then 50 else kw.rank end) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank <= '$to_date') as top50_sum_total,"
                        //rank of first page top 10
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 10 and kw.dateOfRank >= '$from_date' and kw.dateOfRank <= '$to_date') as current_top10_rank,"
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 10 and kw.dateOfRank >= '$back90daysDate' and kw.dateOfRank <= '$to_date') AS top10_rank_days90,"
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 10 and kw.dateOfRank >= '$back180daysDate' and kw.dateOfRank <= '$to_date') as top10_rank_days180, "
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 10 and kw.dateOfRank >= '$back1YrdaysDate' and kw.dateOfRank <= '$to_date') as top10_rank_yearback,"
                        //top 3
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 3 and kw.dateOfRank >= '$from_date' and kw.dateOfRank <= '$to_date') as current_top3_rank,"
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 3 and kw.dateOfRank >= '$back90daysDate' and kw.dateOfRank <= '$to_date') AS top3_rank_days90,"
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 3 and kw.dateOfRank >= '$back180daysDate' and kw.dateOfRank <= '$to_date') as top3_rank_days180, "
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 3 and kw.dateOfRank >= '$back1YrdaysDate' and kw.dateOfRank <= '$to_date') as top3_rank_yearback,"
                        //1st place
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank = 1 and kw.dateOfRank >= '$from_date' and kw.dateOfRank <= '$to_date') as current_top1_rank,"
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank = 1 and kw.dateOfRank >= '$back90daysDate' and kw.dateOfRank <= '$to_date') AS top1_rank_days90,"
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank = 1 and kw.dateOfRank >= '$back180daysDate' and kw.dateOfRank <= '$to_date') as top1_rank_days180, "
                        . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank = 1 and kw.dateOfRank >= '$back1YrdaysDate' and kw.dateOfRank <= '$to_date') as top1_rank_yearback"
                )
                ->fetchAll('assoc');

        // resources for calculation of rank vs target
        $all_landing_urls = $this->connection->execute("SELECT kg.landing_page FROM tbl_keygroup kg where kg.location_id = " . $location_id . $targetCondition . $campaign_condition_keygroup)->fetchAll('assoc');
        $all_campaign_wise = array();

        $campaid_condition = '';
        if (!empty($campaign_id)) {
            $all_campaign_wise = $this->connection->execute("SELECT kg.landing_page FROM tbl_keygroup kg where kg.location_id = " . $location_id . " $targetCondition AND kg.campaign_id = " . $campaign_id)->fetchAll('assoc');
            $campaid_condition = " AND kw.campaign_id = " . $campaign_id;
        }

        $ranked_urls_count = $this->connection->execute("SELECT kw.campaign_id,kw.group_id,kw.ranked_url FROM tbl_keywords kw where kw.location_id = " . $location_id . " $campaid_condition and kw.dateOfRank >= '$from_date' and kw.dateOfRank <= '$to_date' ")->fetchAll('assoc');
        $ranked_urls_total = $this->connection->execute("SELECT kw.campaign_id,kw.group_id,kw.ranked_url FROM tbl_keywords kw where kw.location_id = " . $location_id . " $campaid_condition and kw.dateOfRank <= '$to_date' ")->fetchAll('assoc');
        $ranked_urls_count_last90days = $this->connection->execute("SELECT kw.campaign_id,kw.group_id,kw.ranked_url FROM tbl_keywords kw where kw.location_id = " . $location_id . " $campaid_condition and kw.dateOfRank >= '$back90daysDate' and kw.dateOfRank <= '$to_date' ")->fetchAll('assoc');
        $ranked_urls_count_last180days = $this->connection->execute("SELECT kw.campaign_id,kw.group_id,kw.ranked_url FROM tbl_keywords kw where kw.location_id = " . $location_id . " $campaid_condition and kw.dateOfRank >= '$back180daysDate' and kw.dateOfRank <= '$to_date' ")->fetchAll('assoc');
        $ranked_urls_count_last1yr = $this->connection->execute("SELECT kw.campaign_id,kw.group_id,kw.ranked_url FROM tbl_keywords kw where kw.location_id = " . $location_id . " $campaid_condition and kw.dateOfRank >= '$back1YrdaysDate' and kw.dateOfRank <= '$to_date' ")->fetchAll('assoc');

        if (count($NumberofKeywords) > 0) {
            $NumberofKeywords = $NumberofKeywords[0];
        }

        return array(
            "ranked_data" => array(
                "count_urls" => $ranked_urls_count,
                "last_90_days" => $ranked_urls_count_last90days,
                "last_180_days" => $ranked_urls_count_last180days,
                "last_1_yr" => $ranked_urls_count_last1yr,
                "total_keywords_list" => $ranked_urls_total,
                "all_landing_urls" => $all_landing_urls,
                "campaign_landing_urls" => $all_campaign_wise
            ),
            "keyword_data" => $NumberofKeywords
        );
    }

    public function scheduleReport() {
        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            $data = json_decode(file_get_contents('php://input'));
            $token = $this->request->header('token');
            $campaign_id = isset($data->campaign_id) ? intval($data->campaign_id) : 0;
            if ($campaign_id != 0) {
                if (!$this->Keyword->is_valid_campaign($campaign_id)) {
                    $this->json(0, "Invalid campaign_id", array("campaign_id" => "required"));
                }
            }
            $sch_type = isset($data->sch_type) && trim($data->sch_type) != '' ? $data->sch_type : '0';
            $sch_report_type = isset($data->sch_report_type) && trim($data->sch_report_type) != '' ? $data->sch_report_type : '0';
            $email_info = isset($data->email_info) && $data->email_info != '' ? $data->email_info : '';
            $sch_frequency = isset($data->sch_frequency) && trim($data->sch_frequency) != '' ? $data->sch_frequency : '0';
            $sch_reportVolume = isset($data->sch_reportVolume) && trim($data->sch_reportVolume) != '' ? $data->sch_reportVolume : '0';
            if ($sch_type == '0') {
                $type = "keyword_report";
            } elseif ($sch_type == '1') {
                $type = "competitor_report";
            } elseif ($sch_type == '2') {
                $type = "rank_target_report";
            } else {
                $type = "executive_report";
            }
            if ($sch_frequency == '0') {
                $frequecy = "Weekly";
            } else {
                $frequency = "Monthly";
            }
            if ($sch_reportVolume == '0') {
                $volume = "Last 7 Days";
            } elseif ($sch_reportVolume == '1') {
                $volume = "Last 30 Days";
            } else {
                $volume = "Last 90 Days";
            }
            if ($sch_report_type == '0') {
                $report_type = "pdf";
            } else {
                $report_type = "csv";
            }
            if ($this->is_token_valid()) {
                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];
                $sch_report = TableRegistry::get('tbl_sch_settings');
                $matchcount = $sch_report->find()->where(['location_id' => $location_id, 'campaign_id' => $campaign_id])->count();
                if ($matchcount == 0) {
                    $query = $sch_report->query();
                    $result = $query->insert(['location_id', 'campaign_id', 'sch_frequency', 'sch_reportVolume', 'sch_type', 'report_type', 'sch_status', 'created', 'created_by'])
                            ->values(
                                    [
                                        'location_id' => $location_id,
                                        'campaign_id' => $campaign_id,
                                        'sch_frequency' => $frequecy,
                                        'sch_reportVolume' => $volume,
                                        'sch_type' => $type,
                                        'report_type' => $report_type,
                                        'sch_status' => '1',
                                        'created' => date("Y-m-d H:i:s"),
                                        'created_by' => $user_id,
                                    ]
                            )
                            ->execute();
                    $result = $query->find('all', ['fields' => 'id', 'order' => ['id' => 'DESC']])->first();
                    $em_sch_id = $result->id;
                    $email_report = TableRegistry::get('tbl_sch_emails');
                    foreach ($email_info as $key => $data) {
                        $query = $email_report->query();
                        $query->insert(['sch_id', 'em_emailTo', 'em_status'])
                                ->values(
                                        [
                                            'sch_id' => $em_sch_id,
                                            'em_emailTo' => $data->email,
                                            'em_status' => $data->status,
                                        ]
                                )
                                ->execute();
                    }
                } else {
                    $query = $sch_report->query();
                    $query->update()
                            ->set(
                                    [
                                        'campaign_id' => $campaign_id,
                                        'sch_frequency' => $frequecy,
                                        'sch_reportVolume' => $volume,
                                        'sch_type' => $type,
                                        'report_type' => $report_type,
                                        'sch_status' => '1',
                                    ]
                            )
                            ->where(['location_id' => $location_id, 'campaign_id' => $campaign_id])
                            ->execute();
                    $result = $query->find('all', ['fields' => 'id', 'conditions' => ['location_id' => $location_id, 'campaign_id' => $campaign_id]])->first();
                    $em_sch_id = $result->id;
                    $email_report = TableRegistry::get('tbl_sch_emails');
                    $matchcount = $email_report->deleteAll(['sch_id' => $em_sch_id]);
                    foreach ($email_info as $key => $data) {
                        $query = $email_report->query();
                        $query->insert(['sch_id', 'em_emailTo', 'em_status'])
                                ->values(
                                        [
                                            'sch_id' => $em_sch_id,
                                            'em_emailTo' => $data->email,
                                            'em_status' => $data->status,
                                        ]
                                )
                                ->execute();
                    }
                }
                $this->json(1, "Email scheduler is successfully updated.");
            } else {
                $this->json(0, "Invalid token", array("token" => "required"));
            }
        } else {
            $this->json(0, "silence is golden");
        }
    }

    public function getScheduleReport() {
        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            $data = json_decode(file_get_contents('php://input'));
            $token = $this->request->header('token');
            $campaign_id = isset($data->campaign_id) ? intval($data->campaign_id) : 0;
            if ($campaign_id != 0) {
                if (!$this->Keyword->is_valid_campaign($campaign_id)) {
                    $this->json(0, "Invalid campaign_id", array("campaign_id" => "required"));
                }
            }
            if ($this->is_token_valid()) {
                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];
                $data = TableRegistry::get('tbl_sch_settings');
                $report = $data->find('all', [
                            'conditions' => ['location_id' => $location_id, 'campaign_id' => $campaign_id],
                        ])->first();
                if (!empty($report)) {
                    $result['sch_frequency'] = $report->sch_frequency;
                    $result['sch_reportVolume'] = $report->sch_reportVolume;
                    $result['sch_type'] = $report->sch_type;
                    $result['report_type'] = $report->report_type;
                    $id = $report->id;
                    $data = TableRegistry::get('tbl_sch_emails');
                    $report = $data->find('all', [
                                'conditions' => ['sch_id' => $id],
                            ])->toArray();
                    $i = 0;
                    $email = [];
                    foreach ($report as $new) {
                        $email[$i]['emailTo'] = $new->em_emailTo;
                        $email[$i]['status'] = $new->em_status;
                        $i++;
                    }
                    $result['email_info'] = $email;
                    $this->json(1, "Info about Email scheduler Report.", $result);
                } else {
                    $this->json(0, "No Data found.");
                }
            } else {
                $this->json(0, "Invalid token", array("token" => "required"));
            }
        } else {
            $this->json(0, "silence is golden");
        }
    }

    public function cronScheduleReport() {
        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST" && $_POST['all_report']) {
            $con = new ConnectionManager;
            $cn = $con->get('default');
            $all_report = $_POST['all_report'];
            if (!empty($all_report)) {
                foreach ($all_report as $single_report) {
                    $frequency = strtolower($single_report['sch_frequency']);
                    $location_id = $single_report['location_id'];
                    $campaign_id = $single_report['campaign_id'];
                    $location_data = TableRegistry::get('tbl_locations');
                    $groups = $location_data->find('all', [
                                'conditions' => ['id' => $location_id],
                                'fields' => ['website', 'name'],
                            ])->first();
                    $website = $this->fully_trim($groups->website);
                    $project_name = $groups->name;
                    $sch_type = $single_report['sch_type'];
                    $report_type = $single_report['report_type'];
                    $date = date('m/d/Y');
                    $type_name = strtolower(str_replace("ly", "", $single_report['sch_frequency']));
                    if ($single_report['sch_status'] == 0) {
                        continue;
                    }
                    if ($single_report['sch_frequency'] == "Weekly") {
                        /* Weekly Sending Data */
                        $to_date = date("Y-m-d", strtotime("last Sunday"));
                        /* getting 1 day back to $to_date from Schedule Report */
                        if ($single_report['sch_reportVolume'] == "Last 30 Days") {
                            $from_date = date('Y-m-d', strtotime('-30 days', strtotime($to_date)));
                        } else if ($single_report['sch_reportVolume'] == "Last 7 Days") {
                            $from_date = date('Y-m-d', strtotime('-7 days', strtotime($to_date)));
                        } else if ($single_report['sch_reportVolume'] == "Last 90 Days") {
                            $from_date = date('Y-m-d', strtotime('-90 days', strtotime($to_date)));
                        }
                    } else if ($single_report['sch_frequency'] == "Monthly") {
                        /* Monthly Sending Data */
                        $to_date = date("Y-m-d", strtotime("last day of previous month"));
                        /* getting last day of Prev Month $to_date from Schedule Report */
                        if ($single_report['sch_reportVolume'] == "Last 30 Days") {
                            $from_date = date('Y-m-d', strtotime('-30 days', strtotime($to_date)));
                        } else if ($single_report['sch_reportVolume'] == "Last 7 Days") {
                            $from_date = date('Y-m-d', strtotime('-7 days', strtotime($to_date)));
                        } else if ($single_report['sch_reportVolume'] == "Last 90 Days") {
                            $from_date = date('Y-m-d', strtotime('-90 days', strtotime($to_date)));
                        }
                    }
                    /* ..ends */
                    if ($sch_type == 'keyword_report') {
                        $keywordType = 'all';
                        $is_primary = 0;
                        $data_order = "sort_from_a_z";
                        $keywordReport = $this->keywordReportData($campaign_id, $data_order, $from_date, $to_date, $keywordType, $is_primary, $location_id);
                        //pr($keywordReport); die;
                        if ($report_type == 'pdf') {
                            $str = '';
                            $headerchoices = array(
                                "Keyword" => 1,
                                "Ranked Url" => 1,
                                "<img class='icimg' src='" . WWW_ROOT . "img/icons/google.ico' /> Google" => 1,
                                "<img class='icimg' src='" . WWW_ROOT . "img/icons/google_maps.ico' /> Google Maps" => 1,
                                "<img class='icimg' src='" . WWW_ROOT . "img/icons/google.ico' /> Mobile" => 1,
                                "<img class='icimg' src='" . WWW_ROOT . "img/icons/google_maps.ico' /> Mobile Maps" => 1,
                                "<img class='icimg' src='" . WWW_ROOT . "img/icons/bing.ico' /> Bing" => 1,
                                "<img class='icimg' src='" . WWW_ROOT . "img/icons/bing.ico' /> Bing Maps" => 1,
                                "Org Visits" => 1,
                                "Org Conv" => 1,
                                "Org Conv %" => 1,
                                "Search Vol" => 1,
                                "Comp" => 1,
                                "Bid" => 1,
                                "Bucket" => 1,
                                "Days In Bucket" => 1,
                                "Time %" => 1
                            );
                            $logo = WWW_ROOT . 'img/logo-2.png';
                            $str .= '<style>';
                            //$str .= file_get_contents(get_template_directory_uri().'/report-theme/assets/global/plugins/bootstrap/css/bootstrap.min.css');
                            $str .= '.columnrep{min-width: 170px; word-break: break-all;} .tblgrps td, .tblgrps th {
                border-color: #f3f3f3; padding: 10px; margin: 0; text-align: center;}
                .icimg {width: 16px; height: 16px; } .primarybadge {background: #22B04B;margin-right: 3px; padding: 5px; border-radius: 8px; color: #fff;}
                .local_icon {margin-left: 8px; color: #f39452;}
                .secondarybadge {background: #FF7F27; margin-right: 3px; padding: 5px; border-radius: 8px; color: #fff;}
                .padding_full{padding:10px 3px; font-size: 15px; border: 1px solid #ddd;}
                .keyword_width{width:20%;} .ranking_width{width:33%;} .bg-green-jungle{ padding: 5px; color: #fff; background: #26C281!important;} .bg-blue{     padding: 5px; color: #fff; background: #3598dc!important;}
                .bg-red-thunderbird {    padding: 5px; background: #D91E18 !important; color: #fff;} td.text-center { text-align: center; padding: 10px 5px; } .arroicn {display: inline-block; width: 15px; } .tarword{background: blue; margin-right: 3px; padding: 5px; border-radius: 8px; color: #fff;}';
                            $str .= '.greensign{ color: green; font-weight: 700; margin-left: 10px;} .redsign{ color: red; font-weight: 700; margin-left: 10px; } .normalsign{color: #040686; font-weight: 700; margin-left: 10px; }';
                            $str .= '</style>';
                            $str .= '<table border="0" width="100%"><tr><td align="left" ><img style="max-width:300px; max-height:55px;"  src="' . $logo . '"/></td><td style="font-size:25px;" align="right" width="20%">' . "www." . $website .
                                    '</td></tr></table><br/>';
                            $str .= '<h3 style="text-align:center;">' . $project_name . ' - Keyword Report</h3><br/>';

                            $str .= '<table class="table table-bordered tblgrps" cellspacing = "0" cellpadding = "0" border="1">
        <thead>
            <tr>';
                            $widpdf = 750;
                            $ht = 1000;
                            foreach ($headerchoices as $head => $sts) {
                                $disp = '';
                                $x = '';
                                if ($sts == 1) {
                                    $wid = '';
                                    if ($x == 0 || x == 1) {
                                        $wid = 'style = "width: 100px;"';
                                    }
                                    $str .= '<th ' . $wid . ' data-idx="' . $x . '" class="columnrep" >' . strip_tags($head) . '</th>';
                                    $widpdf = $widpdf + 60;
                                }
                                $x++;
                            }
                            $str .= '</tr>
                </thead>
                <tbody>';
                            $color_index = 0;
                            foreach ($keywordReport as $data) {
                                $color = $color_index % 2 == 0 ? '#fff' : '#eee';
                                $color_index++;
                                $str .= '<tr style="background-color:' . $color . ';">
                    <td class="padding_full" style="text-align:center;">' . $data['keyword'] . '</td>
                    <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['ranked_url'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['rank']['l'] . "     " . $data['rank']['r'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['maps_rank']['l'] . "    " . $data['maps_rank']['r'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['mobile_rank']['l'] . "     " . $data['mobile_rank']['r'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['mobile_maps_rank']['l'] . "    " . $data['mobile_maps_rank']['r'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['bing_rank']['l'] . "    " . $data['bing_rank']['r'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['bing_maps_rank']['l'] . "    " . $data['bing_maps_rank']['r'] . '</td>
                <td class="padding_full" style="text-align:center;">' . $data['org_visits'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['org_conv'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['org_conv_rate'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['googleSearchVolume'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['comp'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['bid'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['bucket'] . '</td>
                <td class="padding_full" style="text-align:center;">' . $data['bucket_days'] . '</td>
                <td class="padding_full" style="text-align:center;">' . $data['time'] . '</td>
              </tr>';
                            }
                            $str .='</tbody></table>';
                            $report_name = $website . '_' . $sch_type . '_' . date("Y_m_d") . '.' . $report_type;
                            $dompdf = new DOMPDF();
                            $dompdf->load_html($str);
                            $customPaper = array(0, 0, $widpdf, $ht);
                            $dompdf->set_paper($customPaper);
                            $dompdf->render();
                            $pdf = $dompdf->output();
                            file_put_contents(WWW_ROOT . 'pdf/' . $report_name, $pdf);
                        }
                        if ($report_type == 'csv') {
                            $str = '';
                            $headerchoices = array(
                                "Keyword" => 1,
                                "Ranked Url" => 1,
                                "<img class='icimg' src='" . WWW_ROOT . "img/icons/google.ico' /> Google" => 1,
                                "<img class='icimg' src='" . WWW_ROOT . "img/icons/google_maps.ico' /> Google Maps" => 1,
                                "<img class='icimg' src='" . WWW_ROOT . "img/icons/google.ico' /> Mobile" => 1,
                                "<img class='icimg' src='" . WWW_ROOT . "img/icons/google_maps.ico' /> Mobile Maps" => 1,
                                "<img class='icimg' src='" . WWW_ROOT . "img/icons/bing.ico' /> Bing" => 1,
                                "<img class='icimg' src='" . WWW_ROOT . "img/icons/bing.ico' /> Bing Maps" => 1,
                                "Org Visits" => 1,
                                "Org Conv" => 1,
                                "Org Conv %" => 1,
                                "Search Vol" => 1,
                                "Comp" => 1,
                                "Bid" => 1,
                                "Bucket" => 1,
                                "Days In Bucket" => 1,
                                "Time %" => 1
                            );
                            $logo = WWW_ROOT . 'img/logo-2.png';
                            $str .= '<style>';
                            $str .= '.columnrep{min-width: 170px; word-break: break-all;} .tblgrps td, .tblgrps th {
                border-color: #f3f3f3; padding: 10px; margin: 0; text-align: center;}
                .icimg {width: 16px; height: 16px; } .primarybadge {background: #22B04B;margin-right: 3px; padding: 5px; border-radius: 8px; color: #fff;}
                .local_icon {margin-left: 8px; color: #f39452;}
                .secondarybadge {background: #FF7F27; margin-right: 3px; padding: 5px; border-radius: 8px; color: #fff;}
                .padding_full{padding:10px 3px; font-size: 15px; border: 1px solid #ddd;}
                .keyword_width{width:20%;} .ranking_width{width:33%;} .bg-green-jungle{ padding: 5px; color: #fff; background: #26C281!important;} .bg-blue{     padding: 5px; color: #fff; background: #3598dc!important;}
                .bg-red-thunderbird {    padding: 5px; background: #D91E18 !important; color: #fff;} td.text-center { text-align: center; padding: 10px 5px; } .arroicn {display: inline-block; width: 15px; } .tarword{background: blue; margin-right: 3px; padding: 5px; border-radius: 8px; color: #fff;}';
                            $str .= '.greensign{ color: green; font-weight: 700; margin-left: 10px;} .redsign{ color: red; font-weight: 700; margin-left: 10px; } .normalsign{color: #040686; font-weight: 700; margin-left: 10px; }';
                            $str .= '</style>';
                            $str .= '<table border="0" width="100%"><tr><td align="left" ><img style="max-width:300px; max-height:55px;"  src="' . $logo . '"/></td><td style="font-size:25px;" align="right" width="20%">' . "www." . $website .
                                    '</td></tr></table><br/>';
                            $str .= '<h3 style="text-align:center;">' . $project_name . ' - Keyword Report</h3><br/>';

                            $str .= '<table class="table table-bordered tblgrps" cellspacing = "0" cellpadding = "0" border="1">
        <thead>
            <tr>';
                            $widpdf = 750;
                            $ht = 1000;
                            foreach ($headerchoices as $head => $sts) {
                                $disp = '';
                                $x = '';
                                if ($sts == 1) {
                                    $wid = '';
                                    if ($x == 0 || x == 1) {
                                        $wid = 'style = "width: 100px;"';
                                    }
                                    $str .= '<th ' . $wid . ' data-idx="' . $x . '" class="columnrep" >' . strip_tags($head) . '</th>';
                                    $widpdf = $widpdf + 60;
                                }
                                $x++;
                            }
                            $str .= '</tr>
                </thead>
                <tbody>';
                            $color_index = 0;
                            foreach ($keywordReport as $data) {
                                $color = $color_index % 2 == 0 ? '#fff' : '#eee';
                                $color_index++;
                                $str .= '<tr style="background-color:' . $color . ';">
                    <td class="padding_full" style="text-align:center;">' . $data['keyword'] . '</td>
                    <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['ranked_url'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['rank']['l'] . "     " . $data['rank']['r'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['maps_rank']['l'] . "    " . $data['maps_rank']['r'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['mobile_rank']['l'] . "     " . $data['mobile_rank']['r'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['mobile_maps_rank']['l'] . "    " . $data['mobile_maps_rank']['r'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['bing_rank']['l'] . "    " . $data['bing_rank']['r'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['bing_maps_rank']['l'] . "    " . $data['bing_maps_rank']['r'] . '</td>
                <td class="padding_full" style="text-align:center;">' . $data['org_visits'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['org_conv'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['org_conv_rate'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['googleSearchVolume'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['comp'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['bid'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['bucket'] . '</td>
                <td class="padding_full" style="text-align:center;">' . $data['bucket_days'] . '</td>
                <td class="padding_full" style="text-align:center;">' . $data['time'] . '</td>
              </tr>';
                            }
                            $str .='</tbody></table>';
                            $report_name = $website . '_' . $sch_type . '_' . date("Y_m_d") . '.' . $report_type;
                            $html = str_get_html($str);
                            header('Content-type: application/ms-excel');
                            header('Content-Disposition: attachment; filename=' . $report_name);
                            $fp = '';
                            file_put_contents(WWW_ROOT . 'pdf/' . $report_name, $fp);
                            $fp = fopen(WWW_ROOT . 'pdf/' . $report_name, "w");
                            foreach ($html->find('tr') as $element) {
                                $td = array();
                                foreach ($element->find('th') as $row) {
                                    $td [] = $row->plaintext;
                                }
                                fputcsv($fp, $td);

                                $td = array();
                                foreach ($element->find('td') as $row) {
                                    $td [] = $row->plaintext;
                                }
                                fputcsv($fp, $td);
                            }
                            fclose($fp);
                        }
                    }
                    if ($sch_type == 'rank_target_report') {
                        $str = '';
                        $str .= '<style>.padding_full{padding:10px 3px; font-size: 15px; border: 1px solid #ddd;}
                        .keyword_width{width:20%;} .text-center{S;} 
                        .ranking_width{width:33%;} .bg-green-jungle{     padding: 5px; color: #fff; background: #26C281!important;} .bg-blue{     padding: 5px; color: #fff; background: #3598dc!important;}
                        .bg-red-thunderbird {    padding: 5px; background: #D91E18 !important; color: #fff;}
                        td.text-center { text-align: center; padding: 10px 5px; } 
                        .c2 th, .c2 td {padding: 10px; border: 1px solid #ddd;} .badge{padding: 4px;} </style>';
                        $logo = WWW_ROOT . 'img/logo-2.png';
                        $str .= '<table border="0" width="100%"><tr><td align="left" ><img style="max-width:300px; max-height:55px;"  src="' . $logo . '"></td> <td style="font-size:25px;" align="right" width="20%">' . $website . '</td></tr></table><br/>';
                        $str .= '<h3 style="text-align:center;">' . $project_name . 'Rank Vs Target Data Report</h3><br/>';
                        $str .= '<div class="col-md-12">';
                        $RankVsTargetDataReport = $this->RankVsTargetDataReport($campaign_id, $location_id);
                        foreach ($RankVsTargetDataReport as $key => $new) {
                            $str .= '<table class="c2" style="margin-top:10px; text-align: center; font-size:15px; border-radius: 3px 3px 3px 3px; width: 100%;">
                        <thead>
                            <tr>
                                <th width="26%">Keyword</th>
                                <th width="32%">Target URL</th>
                                <th width="32%">Ranking URL</th>
                                <th width="5%">Rank</th>
                                <th width="5%">Match</th>
                            </tr>
                        </thead>
                        <tbody>';
                            foreach ($new['keywords'] as $key => $data) {
                                $var = '';
                                $target = '';
                                if ($data['isprimary'] == 1) {
                                    $var = '<span style="background:#22B04B; margin-right:6px;" class="badge">P</span>';
                                }
                                if ($data['istarget'] == 1) {
                                    $target = '<span style="background:#FF7F27; margin-right:6px;" class="badge">T</span>';
                                }
                                if ($data['match'] == 1) {
                                    $match = 'Yes';
                                } else {
                                    $match = 'No';
                                }
                                $str .= '<tr>
                    <td class="padding_full" style="text-align:center;">' . $var . $target . $data['keyword'] . '</td>
                    <td class="padding_full" style="text-align:center;">' . $data['target_url'] . '</td>
                    <td class="padding_full" style="text-align:center;">' . $data['ranking_url'] . '</td>
                    <td class="padding_full" style="text-align:center;">' . $data['rank'] . '</td>
                    <td class="padding_full" style="text-align:center;">' . $match . '</td>
                    </tbody>
                    ';
                            }
                            $str .='</table>';
                        }
                        if ($report_type == 'pdf') {
                            $dompdf = new DOMPDF();
                            $dompdf->load_html($str);
                            $dompdf->set_paper('a4', 'landscape');
                            $dompdf->render();
                            $pdf = $dompdf->output();
                            $report_name = $website . '_' . $sch_type . '_' . date("Y_m_d") . '.' . $report_type;
                            file_put_contents(WWW_ROOT . 'pdf/' . $report_name, $pdf);
                        }
                        if ($report_type == 'csv') {
                            $report_name = $website . '_' . $sch_type . '_' . date("Y_m_d") . '.' . $report_type;
                            $html = str_get_html($str);
                            header('Content-type: application/ms-excel');
                            header('Content-Disposition: attachment; filename=' . $report_name);
                            $fp = '';
                            file_put_contents(WWW_ROOT . 'pdf/' . $report_name, $fp);
                            $fp = fopen(WWW_ROOT . 'pdf/' . $report_name, "w");
                            foreach ($html->find('tr') as $element) {
                                $td = array();
                                foreach ($element->find('th') as $row) {
                                    $td [] = $row->plaintext;
                                }
                                fputcsv($fp, $td);

                                $td = array();
                                foreach ($element->find('td') as $row) {
                                    $td [] = $row->plaintext;
                                }
                                fputcsv($fp, $td);
                            }
                            fclose($fp);
                        }
                    }
                    if ($sch_type == 'competitor_report') {
                        $str = '';
                        $str .= '<style>.padding_full{padding:10px 3px; font-size: 15px; border: 1px solid #ddd;}
                        .keyword_width{width:20%;} .text-center{S;} 
                        .ranking_width{width:33%;} .bg-green-jungle{     padding: 5px; color: #fff; background: #26C281!important;} .bg-blue{     padding: 5px; color: #fff; background: #3598dc!important;}
                        .bg-red-thunderbird {    padding: 5px; background: #D91E18 !important; color: #fff;}
                        td.text-center { text-align: center; padding: 10px 5px; } 
                        .c2 th, .c2 td {padding: 10px; border: 1px solid #ddd;} .badge{padding: 4px;} </style>';
                        $logo = WWW_ROOT . 'img/logo-2.png';
                        $str .= '<table border="0" width="100%"><tr><td align="left" ><img style="max-width:300px; max-height:55px;"  src="' . $logo . '"></td> <td style="font-size:25px;" align="right" width="20%">' . $website . '</td></tr></table><br/>';
                        $str .= '<h3 style="text-align:center;">' . $project_name . ' Competitor Report</h3><br/>';
                        $str .= '<div class="col-md-12">';
                        $competitor_data = $this->CompetitorSummaryKeywordsReport($campaign_id, $location_id);
                        $header = '';
                        $header .= '<table class="c2" style="margin-top:10px; text-align: center; font-size:15px; border-radius: 3px 3px 3px 3px; width: 100%;">
                        <thead>
                            <tr>
                                <th width="26%">Keyword</th>';
                        foreach ($competitor_data['header'] as $key => $new) {
                            $header .= ' <th width="26%">' . $new . '</th>';
                        }
                        $header .= '</tr>
                        </thead>
                        <tbody>';
                        foreach ($competitor_data['data'] as $key => $new) {
                            $str.= $header;
                            foreach ($new['keywords'] as $key => $data) {
                                // pr($data); die;
                                $var = '';
                                $target = '';
                                if ($data['is_primary'] == 1) {
                                    $var = '<span style="background:#22B04B; margin-right:6px;" class="badge">P</span>';
                                }
                                if ($data['is_target'] == 1) {
                                    $target = '<span style="background:#FF7F27; margin-right:6px;" class="badge">T</span>';
                                }
                                $str .= '<tr>
                    <td class="padding_full" style="text-align:center;">' . $var . $target . $data['keyword'] . '</td>';
                                foreach ($data['rank'] as $key => $abc) {
                                    $str .= '<td class="padding_full" style="text-align:center;">' . $abc['rank'] . '</td>';
                                }
                            }
                            $str .='</tbody></table>';
                        }
                        if ($report_type == 'pdf') {
                            $dompdf = new DOMPDF();
                            $dompdf->load_html($str);
                            $dompdf->set_paper('a4', 'landscape');
                            $dompdf->render();
                            $pdf = $dompdf->output();
                            $report_name = $website . '_' . $sch_type . '_' . date("Y_m_d") . '.' . $report_type;
                            file_put_contents(WWW_ROOT . 'pdf/' . $report_name, $pdf);
                        }
                        if ($report_type == 'csv') {
                            $report_name = $website . '_' . $sch_type . '_' . date("Y_m_d") . '.' . $report_type;
                            $html = str_get_html($str);
                            header('Content-type: application/ms-excel');
                            header('Content-Disposition: attachment; filename=' . $report_name);
                            $fp = '';
                            file_put_contents(WWW_ROOT . 'pdf/' . $report_name, $fp);
                            $fp = fopen(WWW_ROOT . 'pdf/' . $report_name, "w");
                            foreach ($html->find('tr') as $element) {
                                $td = array();
                                foreach ($element->find('th') as $row) {
                                    $td [] = $row->plaintext;
                                }
                                fputcsv($fp, $td);

                                $td = array();
                                foreach ($element->find('td') as $row) {
                                    $td [] = $row->plaintext;
                                }
                                fputcsv($fp, $td);
                            }
                            fclose($fp);
                        }
                    }
                    if ($sch_type == 'executive_report') {
                        $str = '';
                        $style = '<style>
            .reportdiv{min-height: 500px; margin-top: 5px;} 
            .dwnld-executive-rprt{margin-top: 5px; }
            .boxreport {
                border: 1px solid #ddd;
                padding: 15px 10px;
                text-align: center;
                margin-bottom: 15px;
            }
            div{
                line-height: 1.6;
            }
            .headreportdiv {
                font-weight: 600;
                font-size: 15px;
            }
            .scorediv {
                font-weight: 600;
                font-size: 16px;
            }
            .row.headermaindiv {
                margin-bottom: 15px;
            }
            .totl_keywords {
                margin-bottom: 10px;
                font-size: 16px;
                font-weight: 600;
            }
        </style>';
                        $str = '<style>.padding_full{padding:10px 3px; font-size: 15px; border: 1px solid #ddd;}
                .keyword_width{width:20%;}
                .ranking_width{width:33%;} .blockmainupper.col-md-4, .blockmain.col-md-4{width: 330px; display: inline-block;} .boxreport {
                    border: 1px solid #ddd;
                    padding: 15px 10px;
                    text-align: center;
                    margin-bottom: 15px;
                    min-height: 115px;
                    padding-top: 35px !important;
                }
                .col-md-4.boxreportinner {
                    width: 90px;
                    display: inline-block;
                }
                .reportdiv{ width: 1200px; }
                .row{width: 300px; display: inline-block;}

                    .col-md-4.lowerdv {
                    width: 330px;
                    display: inline-block;
                }

                .lowerdv .boxreport, .blockmain .boxreport{ height: 190px; }
                                </style>';
                        $str .= $style;
                        $logo = WWW_ROOT . 'img/logo-2.png';
                        $str .= '<table border="0" width="100%"><tr><td align="left" ><img style="max-width:300px; max-height:55px;"  src="' . $logo . '"></td> <td style="font-size:25px;" align="right" width="20%">' . 'www.' . $website . '</td></tr></table><br/>';
                        $str .= '<h3 style="text-align:center;">' . $project_name . ' Executive Report</h3><br/>';
                        $is_target = 0;
                        $executive_report = $this->executiveReportData($campaign_id, $is_target, $from_date, $to_date, $location_id);
                        $str .= '<div class="reportdiv portlet light">                                    
                        <div class="clearfix"></div>                                    
                        <div class="traffic_report">
                            <div class="totl_keywords">Total Keywords : ' . $executive_report['total_number_of_keywords']['current_score'] . '</div>
                             <table><tr>
                            <td>
                                <div class="col-md-4 blockmain">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Visibility Score</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                        $str .= $executive_report['visibility_score']['current_score'];
                        $str .= '%</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                        $str .= $executive_report['visibility_score']['last_90days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['visibility_score']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                        $str .= $executive_report['visibility_score']['last_180days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['visibility_score']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                        $str .= $executive_report['visibility_score']['last_1yr_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['visibility_score']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                <td>   <div class="col-md-4 blockmain">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Total Number of Keywords</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                        $str .= $executive_report['total_number_of_keywords']['current_score'];
                        $str .= '</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                        $str .= $executive_report['total_number_of_keywords']['last_90days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['total_number_of_keywords']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                        $str .= $executive_report['total_number_of_keywords']['last_180days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['total_number_of_keywords']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                        $str .= $executive_report['total_number_of_keywords']['last_1yr_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['total_number_of_keywords']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                <td> <div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Avg Rank</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                        $str .= empty($executive_report['average_rank_data']['current_score']) ? 0 : $executive_report['average_rank_data']['current_score'];
                        $str .= '</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                        $str .= empty($executive_report['average_rank_data']['last_90days_score']) ? 0 : $executive_report['average_rank_data']['last_90days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['average_rank_data']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                        $str .= empty($executive_report['average_rank_data']['last_180days_score']) ? 0 : $executive_report['average_rank_data']['last_180days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['average_rank_data']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                        $str .= empty($executive_report['average_rank_data']['last_1yr_score']) ? 0 : $executive_report['average_rank_data']['last_1yr_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['average_rank_data']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td></tr>
                                <tr>
                                <td><div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Rank in Top 50</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                        $str .= $executive_report['rank_top50']['current_score'];
                        $str .= '</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                        $str .= $executive_report['rank_top50']['last_90days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['rank_top50']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                        $str .= $executive_report['rank_top50']['last_180days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['rank_top50']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                        $str .= $executive_report['rank_top50']['last_1yr_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['rank_top50']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                <td><div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Top 10</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                        $str .= $executive_report['top10_rank']['current_score'];
                        $str .= '</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                        $str .= $executive_report['top10_rank']['last_90days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['top10_rank']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                        $str .= $executive_report['top10_rank']['last_180days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['top10_rank']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                        $str .= $executive_report['top10_rank']['last_1yr_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['top10_rank']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                <td><div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Top 3</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                        $str .= $executive_report['top3_rank']['current_score'];
                        $str .= '</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                        $str .= $executive_report['top3_rank']['last_90days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['top3_rank']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                        $str .= $executive_report['top3_rank']['last_180days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['top3_rank']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                        $str .= $executive_report['top3_rank']['last_1yr_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['top3_rank']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                </tr>
                                <tr>
                                <td><div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Marketing Eff.Score</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                        $str .= $executive_report['marketing_eff_score']['current_score'];
                        $str .= '%</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                        $str .= $executive_report['marketing_eff_score']['last_90days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['marketing_eff_score']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                        $str .= $executive_report['marketing_eff_score']['last_180days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['marketing_eff_score']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                        $str .= $executive_report['marketing_eff_score']['last_1yr_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['marketing_eff_score']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                <td><div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Content Optimization Score</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                        $str .= $executive_report['content_optimization_score']['current_score'];
                        $str .= '%</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                        $str .= $executive_report['content_optimization_score']['last_90days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['content_optimization_score']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                        $str .= $executive_report['content_optimization_score']['last_180days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['top3_rank']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                        $str .= $executive_report['content_optimization_score']['last_1yr_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['content_optimization_score']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                <td><div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Citation Score</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                        $str .= $executive_report['citation_score']['current_score'];
                        $str .= '%</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                        $str .= $executive_report['citation_score']['last_90days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['citation_score']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                        $str .= $executive_report['citation_score']['last_180days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['citation_score']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                        $str .= $executive_report['citation_score']['last_1yr_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['citation_score']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td></tr><tr>
                                 <td><div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Site Audit Score</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                        $str .= $executive_report['siteaudit_score']['current_score'];
                        $str .= '%</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                        $str .= $executive_report['siteaudit_score']['last_90days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['siteaudit_score']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                        $str .= $executive_report['siteaudit_score']['last_180days_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['siteaudit_score']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                        $str .= $executive_report['siteaudit_score']['last_1yr_score'];
                        $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['siteaudit_score']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                <td></tr></table>   
                        </div>
                        </div>';
                        if ($report_type == 'pdf') {
                            $dompdf = new DOMPDF();
                            $dompdf->load_html($str);
                            $customPaper = array(0, 0, 1000, 1200);
                            $dompdf->set_paper($customPaper);
                            $dompdf->render();
                            $pdf = $dompdf->output();
                            $report_name = $website . '_' . $sch_type . '_' . date("Y_m_d") . '.' . $report_type;
                            file_put_contents(WWW_ROOT . 'pdf/' . $report_name, $pdf);
                        }
                        if ($report_type == 'csv') {
                            $report_name = $website . '_' . $sch_type . '_' . date("Y_m_d") . '.' . $report_type;
                            $html = str_get_html($str);
                            header('Content-type: application/ms-excel');
                            header('Content-Disposition: attachment; filename=' . $report_name);
                            $fp = '';
                            file_put_contents(WWW_ROOT . 'pdf/' . $report_name, $fp);
                            $fp = fopen(WWW_ROOT . 'pdf/' . $report_name, "w");
                            foreach ($html->find('tr') as $element) {
                                $td = array();
                                foreach ($element->find('th') as $row) {
                                    $td [] = $row->plaintext;
                                }
                                fputcsv($fp, $td);

                                $td = array();
                                foreach ($element->find('td') as $row) {
                                    $td [] = $row->plaintext;
                                }
                                fputcsv($fp, $td);
                            }
                            fclose($fp);
                        }
                    }
                    $id = $single_report['id'];
                    $all_email = $cn->execute("SELECT * FROM `tbl_sch_emails` WHERE `em_status` = 1 and `sch_id` = $id")->fetchAll("assoc");
                    foreach ($all_email as $row_email) {
                        $em_emailTo = trim($row_email['em_emailTo']);
                        $to = $em_emailTo;
                        $from = "notifications@enfusen.com";
                        $type = "schedule_report";
                        $mailSentResponse = $this->SmartEmail->SendMail($to, $from, array(
                            "frequency" => $frequency,
                            "date" => $date,
                            "type_name" => $type_name,
                            "report_name" => $report_name), $type);
                        if ($mailSentResponse['status'] == 1) {
                            echo "successfull to send mail.";
                        } else {
                            echo "Failed to send mail.";
                        }
                    }
                }
            }
            die;
        } else {
            $this->json(0, "Invalid Request");
        }
    }

    public function downloadReport() {
        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            $data = json_decode(file_get_contents('php://input'));
            $token = $this->request->header('token');
            $campaign_id = isset($data->campaign_id) ? intval($data->campaign_id) : 0;
            if ($campaign_id != 0) {
                if (!$this->Keyword->is_valid_campaign($campaign_id)) {
                    $this->json(0, "Invalid campaign_id", array("campaign_id" => "required"));
                }
            }
            $sch_type = isset($data->sch_type) && trim($data->sch_type) != '' ? $data->sch_type : '1';
            $sch_report_type = isset($data->sch_report_type) && trim($data->sch_report_type) != '' ? $data->sch_report_type : '0';
            $from_date = isset($data->from_date) ? $data->from_date : date("Y-m-d", strtotime("-1 day"));
            $to_date = isset($data->to_date) ? $data->to_date : date("Y-m-d", strtotime("-31 day"));
            if ($sch_type == '0') {
                $type = "keyword_report";
            } elseif ($sch_type == '1') {
                $type = "competitor_report";
            } elseif ($sch_type == '2') {
                $type = "rank_target_report";
            } else {
                $type = "executive_report";
            }
            if ($sch_report_type == '0') {
                $report_type = "pdf";
            } else {
                $report_type = "csv";
            }
            if ($this->is_token_valid()) {
                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];
                $website = $this->fully_trim($tokenDetails['website']);
                $project_name = $tokenDetails['name'];
                if ($type == 'keyword_report') {
                    $keywordType = 'all';
                    $is_primary = 0;
                    $data_order = "sort_from_a_z";
                    $keywordReport = $this->keywordReportData($campaign_id, $data_order, $from_date, $to_date, $keywordType, $is_primary, $location_id);
                    $str = '';
                    $headerchoices = array(
                        "Keyword" => 1,
                        "Ranked Url" => 1,
                        "<img class='icimg' src='" . WWW_ROOT . "img/icons/google.ico' /> Google" => 1,
                        "<img class='icimg' src='" . WWW_ROOT . "img/icons/google_maps.ico' /> Google Maps" => 1,
                        "<img class='icimg' src='" . WWW_ROOT . "img/icons/google.ico' /> Mobile" => 1,
                        "<img class='icimg' src='" . WWW_ROOT . "img/icons/google_maps.ico' /> Mobile Maps" => 1,
                        "<img class='icimg' src='" . WWW_ROOT . "img/icons/bing.ico' /> Bing" => 1,
                        "<img class='icimg' src='" . WWW_ROOT . "img/icons/bing.ico' /> Bing Maps" => 1,
                        "Org Visits" => 1,
                        "Org Conv" => 1,
                        "Org Conv %" => 1,
                        "Search Vol" => 1,
                        "Comp" => 1,
                        "Bid" => 1,
                        "Bucket" => 1,
                        "Days In Bucket" => 1,
                        "Time %" => 1
                    );
                    $logo = WWW_ROOT . 'img/logo-2.png';
                    $str .= '<style>';
                    $str .= '.columnrep{min-width: 170px; word-break: break-all;} .tblgrps td, .tblgrps th {
                border-color: #f3f3f3; padding: 10px; margin: 0; text-align: center;}
                .icimg {width: 16px; height: 16px; } .primarybadge {background: #22B04B;margin-right: 3px; padding: 5px; border-radius: 8px; color: #fff;}
                .local_icon {margin-left: 8px; color: #f39452;}
                .secondarybadge {background: #FF7F27; margin-right: 3px; padding: 5px; border-radius: 8px; color: #fff;}
                .padding_full{padding:10px 3px; font-size: 15px; border: 1px solid #ddd;}
                .keyword_width{width:20%;} .ranking_width{width:33%;} .bg-green-jungle{ padding: 5px; color: #fff; background: #26C281!important;} .bg-blue{     padding: 5px; color: #fff; background: #3598dc!important;}
                .bg-red-thunderbird {    padding: 5px; background: #D91E18 !important; color: #fff;} td.text-center { text-align: center; padding: 10px 5px; } .arroicn {display: inline-block; width: 15px; } .tarword{background: blue; margin-right: 3px; padding: 5px; border-radius: 8px; color: #fff;}';
                    $str .= '.greensign{ color: green; font-weight: 700; margin-left: 10px;} .redsign{ color: red; font-weight: 700; margin-left: 10px; } .normalsign{color: #040686; font-weight: 700; margin-left: 10px; }';
                    $str .= '</style>';
                    $str .= '<table border="0" width="100%"><tr><td align="left" ><img style="max-width:300px; max-height:55px;"  src="' . $logo . '"/></td><td style="font-size:25px;" align="right" width="20%">' . "www." . $website .
                            '</td></tr></table><br/>';
                    $str .= '<h3 style="text-align:center;">' . $project_name . ' - Keyword Report</h3><br/>';

                    $str .= '<table class="table table-bordered tblgrps" cellspacing = "0" cellpadding = "0" border="1">
                                <thead>
                                    <tr>';
                    $widpdf = 750;
                    $ht = 1000;
                    foreach ($headerchoices as $head => $sts) {
                        $disp = '';
                        $x = '';
                        if ($sts == 1) {
                            $wid = '';
                            if ($x == 0 || x == 1) {
                                $wid = 'style = "width: 100px;"';
                            }
                            $str .= '<th ' . $wid . ' data-idx="' . $x . '" class="columnrep" >' . strip_tags($head) . '</th>';
                            $widpdf = $widpdf + 60;
                        }
                        $x++;
                    }
                    $str .= '</tr>
                </thead>
                <tbody>';
                    $color_index = 0;
                    foreach ($keywordReport as $data) {
                        $color = $color_index % 2 == 0 ? '#fff' : '#eee';
                        $color_index++;
                        $str .= '<tr style="background-color:' . $color . ';">
                    <td class="padding_full" style="text-align:center;">' . $data['keyword'] . '</td>
                    <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['ranked_url'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['rank']['l'] . "     " . $data['rank']['r'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['maps_rank']['l'] . "    " . $data['maps_rank']['r'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['mobile_rank']['l'] . "     " . $data['mobile_rank']['r'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['mobile_maps_rank']['l'] . "    " . $data['mobile_maps_rank']['r'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['bing_rank']['l'] . "    " . $data['bing_rank']['r'] . '</td>
                <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">' . $data['bing_maps_rank']['l'] . "    " . $data['bing_maps_rank']['r'] . '</td>
                <td class="padding_full" style="text-align:center;">' . $data['org_visits'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['org_conv'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['org_conv_rate'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['googleSearchVolume'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['comp'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['bid'] . '</td>
                 <td class="padding_full" style="text-align:center;">' . $data['bucket'] . '</td>
                <td class="padding_full" style="text-align:center;">' . $data['bucket_days'] . '</td>
                <td class="padding_full" style="text-align:center;">' . $data['time'] . '</td>
              </tr>';
                    }
                    $str .='</tbody></table>';
                    if ($report_type == 'pdf') {
                        $dompdf = new DOMPDF();
                        $dompdf->load_html($str);
                        $customPaper = array(0, 0, $widpdf, $ht);
                        $dompdf->set_paper($customPaper);
                        $dompdf->render();
                        $pdf = $dompdf->output();
                        $new = $dompdf->stream(str_replace(" ", "_", $project_name . '_keyword_Report.pdf'), array("Attachment" => true));
                    }
                    if ($report_type == 'csv') {
                        $report_name = $website . '_' . $type . '_' . date("Y_m_d") . '.' . $report_type;
                        $html = str_get_html($str);
                        // header('Content-type: application/ms-excel');
                        // header('Content-Disposition: attachment; filename='. $report_name);
                        $fp = '';
                        $filename = WWW_ROOT . 'pdf/' . $report_name;
                        file_put_contents(WWW_ROOT . 'pdf/' . $report_name, $fp);
                        $fp = fopen(WWW_ROOT . 'pdf/' . $report_name, "w");
                        foreach ($html->find('tr') as $element) {
                            $td = array();
                            foreach ($element->find('th') as $row) {
                                $td [] = $row->plaintext;
                            }
                            fputcsv($fp, $td);

                            $td = array();
                            foreach ($element->find('td') as $row) {
                                $td [] = $row->plaintext;
                            }
                            fputcsv($fp, $td);
                        }
                        fclose($fp);
                        $file_path = WWW_ROOT . 'pdf' . DS . $report_name;
                        $this->response->file($file_path, array(
                            'download' => true,
                            'name' => $report_name,
                        ));
                        return $this->response;
                    }
                } elseif ($type == 'competitor_report') {
                    $str = '';
                    $str .= '<style>.padding_full{padding:10px 3px; font-size: 15px; border: 1px solid #ddd;}
                        .keyword_width{width:20%;} .text-center{S;} 
                        .ranking_width{width:33%;} .bg-green-jungle{     padding: 5px; color: #fff; background: #26C281!important;} .bg-blue{     padding: 5px; color: #fff; background: #3598dc!important;}
                        .bg-red-thunderbird {    padding: 5px; background: #D91E18 !important; color: #fff;}
                        td.text-center { text-align: center; padding: 10px 5px; } 
                        .c2 th, .c2 td {padding: 10px; border: 1px solid #ddd;} .badge{padding: 4px;} </style>';
                    $logo = WWW_ROOT . 'img/logo-2.png';
                    $str .= '<table border="0" width="100%"><tr><td align="left" ><img style="max-width:300px; max-height:55px;"  src="' . $logo . '"></td> <td style="font-size:25px;" align="right" width="20%">' . "www." . $website . '</td></tr></table><br/>';
                    $str .= '<h3 style="text-align:center;">' . $project_name . ' Competitor Report</h3><br/>';
                    $str .= '<div class="col-md-12">';
                    $competitor_data = $this->CompetitorSummaryKeywordsReport($campaign_id, $location_id);
                    $header = '';
                    $header .= '<table class="c2" style="margin-top:10px; text-align: center; font-size:15px; border-radius: 3px 3px 3px 3px; width: 100%;">
                        <thead>
                            <tr>
                                <th width="26%">Keyword</th>';
                    foreach ($competitor_data['header'] as $key => $new) {
                        $header .= ' <th width="26%">' . $new . '</th>';
                    }
                    $header .= '</tr>
                        </thead>
                        <tbody>';
                    foreach ($competitor_data['data'] as $key => $new) {
                        $str.= $header;
                        foreach ($new['keywords'] as $key => $data) {
                            // pr($data); die;
                            $var = '';
                            $target = '';
                            if ($data['is_primary'] == 1) {
                                $var = '<span style="background:#22B04B; margin-right:6px;" class="badge">P</span>';
                            }
                            if ($data['is_target'] == 1) {
                                $target = '<span style="background:#FF7F27; margin-right:6px;" class="badge">T</span>';
                            }
                            $str .= '<tr>
                    <td class="padding_full" style="text-align:center;">' . $var . $target . $data['keyword'] . '</td>';
                            foreach ($data['rank'] as $key => $abc) {
                                $str .= '<td class="padding_full" style="text-align:center;">' . $abc['rank'] . '</td>';
                            }
                        }
                        $str .='</tbody></table>';
                    }
                    if ($report_type == 'pdf') {
                        $dompdf = new DOMPDF();
                        $dompdf->load_html($str);
                        $dompdf->set_paper('a4', 'landscape');
                        $dompdf->render();
                        $pdf = $dompdf->output();
                        $new = $dompdf->stream(str_replace(" ", "_", $project_name . '_competitor_Report.pdf'), array("Attachment" => true));
                    }
                    if ($report_type == 'csv') {
                        $report_name = $website . '_' . $type . '_' . date("Y_m_d") . '.' . $report_type;
                        $html = str_get_html($str);
                        // header('Content-type: application/ms-excel');
                        // header('Content-Disposition: attachment; filename='. $report_name);
                        $fp = '';
                        $filename = WWW_ROOT . 'pdf/' . $report_name;
                        file_put_contents(WWW_ROOT . 'pdf/' . $report_name, $fp);
                        $fp = fopen(WWW_ROOT . 'pdf/' . $report_name, "w");
                        foreach ($html->find('tr') as $element) {
                            $td = array();
                            foreach ($element->find('th') as $row) {
                                $td [] = $row->plaintext;
                            }
                            fputcsv($fp, $td);

                            $td = array();
                            foreach ($element->find('td') as $row) {
                                $td [] = $row->plaintext;
                            }
                            fputcsv($fp, $td);
                        }
                        fclose($fp);
                        $file_path = WWW_ROOT . 'pdf' . DS . $report_name;
                        $this->response->file($file_path, array(
                            'download' => true,
                            'name' => $report_name,
                        ));
                        return $this->response;
                    }
                } elseif ($type == 'rank_target_report') {
                    $str = '';
                    $str .= '<style>.padding_full{padding:10px 3px; font-size: 15px; border: 1px solid #ddd;}
                        .keyword_width{width:20%;} .text-center{S;} 
                        .ranking_width{width:33%;} .bg-green-jungle{     padding: 5px; color: #fff; background: #26C281!important;} .bg-blue{     padding: 5px; color: #fff; background: #3598dc!important;}
                        .bg-red-thunderbird {    padding: 5px; background: #D91E18 !important; color: #fff;}
                        td.text-center { text-align: center; padding: 10px 5px; } 
                        .c2 th, .c2 td {padding: 10px; border: 1px solid #ddd;} .badge{padding: 4px;} </style>';
                    $logo = WWW_ROOT . 'img/logo-2.png';
                    $str .= '<table border="0" width="100%"><tr><td align="left" ><img style="max-width:300px; max-height:55px;"  src="' . $logo . '"></td> <td style="font-size:25px;" align="right" width="20%">' . "www." . $website . '</td></tr></table><br/>';
                    $str .= '<h3 style="text-align:center;">' . $project_name .
                            ' Rank Vs Target Data Report</h3><br/>';
                    $str .= '<div class="col-md-12">';
                    $RankVsTargetDataReport = $this->RankVsTargetDataReport($campaign_id, $location_id);
                    foreach ($RankVsTargetDataReport as $key => $new) {
                        $str .= '<table class="c2" style="margin-top:10px; text-align: center; font-size:15px; border-radius: 3px 3px 3px 3px; width: 100%;">
                        <thead>
                            <tr>
                                <th width="26%">Keyword</th>
                                <th width="32%">Target URL</th>
                                <th width="32%">Ranking URL</th>
                                <th width="5%">Rank</th>
                                <th width="5%">Match</th>
                            </tr>
                        </thead>
                        <tbody>';
                        foreach ($new['keywords'] as $key => $data) {
                            $var = '';
                            $target = '';
                            if ($data['isprimary'] == 1) {
                                $var = '<span style="background:#22B04B; margin-right:6px;" class="badge">P</span>';
                            }
                            if ($data['istarget'] == 1) {
                                $target = '<span style="background:#FF7F27; margin-right:6px;" class="badge">T</span>';
                            }
                            if ($data['match'] == 1) {
                                $match = 'Yes';
                            } else {
                                $match = 'No';
                            }
                            $str .= '<tr>
                    <td class="padding_full" style="text-align:center;">' . $var . $target . $data['keyword'] . '</td>
                    <td class="padding_full" style="text-align:center;">' . $data['target_url'] . '</td>
                    <td class="padding_full" style="text-align:center;">' . $data['ranking_url'] . '</td>
                    <td class="padding_full" style="text-align:center;">' . $data['rank'] . '</td>
                    <td class="padding_full" style="text-align:center;">' . $match . '</td>
                    </tbody>
                    ';
                        }
                        $str .='</table>';
                    }
                    if ($report_type == 'pdf') {
                        $dompdf = new DOMPDF();
                        $dompdf->load_html($str);
                        $dompdf->set_paper('a4', 'landscape');
                        $dompdf->render();
                        $pdf = $dompdf->output();
                        $new = $dompdf->stream(str_replace(" ", "_", $project_name . '_Rank_Target_Report.pdf'), array("Attachment" => true));
                    }
                    if ($report_type == 'csv') {
                        $report_name = $website . '_' . $type . '_' . date("Y_m_d") . '.' . $report_type;
                        $html = str_get_html($str);
                        $fp = '';
                        $filename = WWW_ROOT . 'pdf/' . $report_name;
                        file_put_contents(WWW_ROOT . 'pdf/' . $report_name, $fp);
                        $fp = fopen(WWW_ROOT . 'pdf/' . $report_name, "w");
                        foreach ($html->find('tr') as $element) {
                            $td = array();
                            foreach ($element->find('th') as $row) {
                                $td [] = $row->plaintext;
                            }
                            fputcsv($fp, $td);

                            $td = array();
                            foreach ($element->find('td') as $row) {
                                $td [] = $row->plaintext;
                            }
                            fputcsv($fp, $td);
                        }
                        fclose($fp);
                        $file_path = WWW_ROOT . 'pdf' . DS . $report_name;
                        $this->response->file($file_path, array(
                            'download' => true,
                            'name' => $report_name,
                        ));
                        return $this->response;
                    }
                } elseif ($type == 'executive_report') {
                    $str = '';
                    $style = '<style>
            .reportdiv{min-height: 500px; margin-top: 5px;} 
            .dwnld-executive-rprt{margin-top: 5px; }
            .boxreport {
                border: 1px solid #ddd;
                padding: 15px 10px;
                text-align: center;
                margin-bottom: 15px;
            }
            div{
                line-height: 1.6;
            }
            .headreportdiv {
                font-weight: 600;
                font-size: 15px;
            }
            .scorediv {
                font-weight: 600;
                font-size: 16px;
            }
            .row.headermaindiv {
                margin-bottom: 15px;
            }
            .totl_keywords {
                margin-bottom: 10px;
                font-size: 16px;
                font-weight: 600;
            }
        </style>';
                    $str = '<style>.padding_full{padding:10px 3px; font-size: 15px; border: 1px solid #ddd;}
                .keyword_width{width:20%;}
                .ranking_width{width:33%;} .blockmainupper.col-md-4, .blockmain.col-md-4{width: 330px; display: inline-block;} .boxreport {
                    border: 1px solid #ddd;
                    padding: 15px 10px;
                    text-align: center;
                    margin-bottom: 15px;
                    min-height: 115px;
                    padding-top: 35px !important;
                }
                .col-md-4.boxreportinner {
                    width: 90px;
                    display: inline-block;
                }
                .reportdiv{ width: 1200px; }
                .row{width: 300px; display: inline-block;}

                    .col-md-4.lowerdv {
                    width: 330px;
                    display: inline-block;
                }

                .lowerdv .boxreport, .blockmain .boxreport{ height: 190px; }
                                </style>';
                    $str .= $style;
                    $logo = WWW_ROOT . 'img/logo-2.png';
                    $str .= '<table border="0" width="100%"><tr><td align="left" ><img style="max-width:300px; max-height:55px;"  src="' . $logo . '"></td> <td style="font-size:25px;" align="right" width="20%">' . 'www.' . $website . '</td></tr></table><br/>';
                    $str .= '<h3 style="text-align:center;">' . $project_name . ' Executive Report</h3><br/>';
                    $is_target = 0;
                    $executive_report = $this->executiveReportData($campaign_id, $is_target, $from_date, $to_date, $location_id);
                    $str .= '<div class="reportdiv portlet light">                                    
                        <div class="clearfix"></div>                                    
                        <div class="traffic_report">
                            <div class="totl_keywords">Total Keywords : ' . $executive_report['total_number_of_keywords']['current_score'] . '</div>
                             <table><tr>
                            <td>
                                <div class="col-md-4 blockmain">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Visibility Score</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                    $str .= $executive_report['visibility_score']['current_score'];
                    $str .= '%</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                    $str .= $executive_report['visibility_score']['last_90days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['visibility_score']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                    $str .= $executive_report['visibility_score']['last_180days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['visibility_score']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                    $str .= $executive_report['visibility_score']['last_1yr_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['visibility_score']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                <td>   <div class="col-md-4 blockmain">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Total Number of Keywords</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                    $str .= $executive_report['total_number_of_keywords']['current_score'];
                    $str .= '</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                    $str .= $executive_report['total_number_of_keywords']['last_90days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['total_number_of_keywords']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                    $str .= $executive_report['total_number_of_keywords']['last_180days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['total_number_of_keywords']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                    $str .= $executive_report['total_number_of_keywords']['last_1yr_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['total_number_of_keywords']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                <td> <div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Avg Rank</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                    $str .= empty($executive_report['average_rank_data']['current_score']) ? 0 : $executive_report['average_rank_data']['current_score'];
                    $str .= '</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                    $str .= empty($executive_report['average_rank_data']['last_90days_score']) ? 0 : $executive_report['average_rank_data']['last_90days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['average_rank_data']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                    $str .= empty($executive_report['average_rank_data']['last_180days_score']) ? 0 : $executive_report['average_rank_data']['last_180days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['average_rank_data']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                    $str .= empty($executive_report['average_rank_data']['last_1yr_score']) ? 0 : $executive_report['average_rank_data']['last_1yr_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['average_rank_data']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td></tr>
                                <tr>
                                <td><div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Rank in Top 50</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                    $str .= $executive_report['rank_top50']['current_score'];
                    $str .= '</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                    $str .= $executive_report['rank_top50']['last_90days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['rank_top50']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                    $str .= $executive_report['rank_top50']['last_180days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['rank_top50']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                    $str .= $executive_report['rank_top50']['last_1yr_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['rank_top50']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                <td><div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Top 10</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                    $str .= $executive_report['top10_rank']['current_score'];
                    $str .= '</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                    $str .= $executive_report['top10_rank']['last_90days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['top10_rank']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                    $str .= $executive_report['top10_rank']['last_180days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['top10_rank']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                    $str .= $executive_report['top10_rank']['last_1yr_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['top10_rank']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                <td><div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Top 3</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                    $str .= $executive_report['top3_rank']['current_score'];
                    $str .= '</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                    $str .= $executive_report['top3_rank']['last_90days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['top3_rank']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                    $str .= $executive_report['top3_rank']['last_180days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['top3_rank']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                    $str .= $executive_report['top3_rank']['last_1yr_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['top3_rank']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                </tr>
                                <tr>
                                <td><div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Marketing Eff.Score</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                    $str .= $executive_report['marketing_eff_score']['current_score'];
                    $str .= '%</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                    $str .= $executive_report['marketing_eff_score']['last_90days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['marketing_eff_score']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                    $str .= $executive_report['marketing_eff_score']['last_180days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['marketing_eff_score']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                    $str .= $executive_report['marketing_eff_score']['last_1yr_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['marketing_eff_score']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                <td><div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Content Optimization Score</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                    $str .= $executive_report['content_optimization_score']['current_score'];
                    $str .= '%</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                    $str .= $executive_report['content_optimization_score']['last_90days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['content_optimization_score']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                    $str .= $executive_report['content_optimization_score']['last_180days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['top3_rank']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                    $str .= $executive_report['content_optimization_score']['last_1yr_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['content_optimization_score']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                <td><div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Citation Score</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                    $str .= $executive_report['citation_score']['current_score'];
                    $str .= '%</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                    $str .= $executive_report['citation_score']['last_90days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['citation_score']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                    $str .= $executive_report['citation_score']['last_180days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['citation_score']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                    $str .= $executive_report['citation_score']['last_1yr_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['citation_score']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td></tr><tr>
                                 <td><div class="col-md-4 lowerdv">   
                                    <div class="boxreport">
                                        <div class="headreportdiv">Site Audit Score</div>
                                        <div class="row headermaindiv">
                                            <div class="col-md-4"></div>
                                            <div class="col-lg-4 mainboxranks">';
                    $str .= $executive_report['siteaudit_score']['current_score'];
                    $str .= '%</div>
                                            <div class="col-md-4"></div>
                                        </div>
                                        <div class="">
                                            <table><tr><td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">90 Day</div>
                                                <div>';
                    $str .= $executive_report['siteaudit_score']['last_90days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['siteaudit_score']['last_90days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">180 Day</div>
                                                <div>';


                    $str .= $executive_report['siteaudit_score']['last_180days_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['siteaudit_score']['last_180days_score_change'] . '</div>
                                            </div>
                                            </td>
                                            <td>
                                            <div class="col-md-4 boxreportinner">
                                                <div class="headreportdiv">1 year</div>
                                                <div>';
                    $str .= $executive_report['siteaudit_score']['last_1yr_score'];
                    $str .= '</div>
                                                <div class="small">(Change)</div>
                                                <div>' . $executive_report['siteaudit_score']['last_1yr_score_change'] . '</div>
                                            </div>
                                            </td>
                                            </tr></table>
                                        </div>
                                    </div>
                                </div>
                                </td>
                                <td></tr></table>   
                        </div>
                        </div>';
                    if ($report_type == 'pdf') {
                        $dompdf = new DOMPDF();
                        $dompdf->load_html($str);
                        $customPaper = array(0, 0, 1000, 1200);
                        $dompdf->set_paper($customPaper);
                        $dompdf->render();
                        $pdf = $dompdf->output();
                        $new = $dompdf->stream(str_replace(" ", "_", $project_name . '_executive_Report.pdf'), array("Attachment" => true));
                    }
                    if ($report_type == 'csv') {
                        $report_name = $website . '_' . $type . '_' . date("Y_m_d") . '.' . $report_type;
                        $html = str_get_html($str);
                        $fp = '';
                        $filename = WWW_ROOT . 'pdf/' . $report_name;
                        file_put_contents(WWW_ROOT . 'pdf/' . $report_name, $fp);
                        $fp = fopen(WWW_ROOT . 'pdf/' . $report_name, "w");
                        foreach ($html->find('tr') as $element) {
                            $td = array();
                            foreach ($element->find('th') as $row) {
                                $td [] = $row->plaintext;
                            }
                            fputcsv($fp, $td);

                            $td = array();
                            foreach ($element->find('td') as $row) {
                                $td [] = $row->plaintext;
                            }
                            fputcsv($fp, $td);
                        }
                        fclose($fp);
                        $file_path = WWW_ROOT . 'pdf' . DS . $report_name;
                        $this->response->file($file_path, array(
                            'download' => true,
                            'name' => $report_name,
                        ));
                        return $this->response;
                    }
                }
            } else {
                $this->json(0, "Invalid token", array("token" => "required"));
            }
        } else {
            $this->json(0, "silence is golden");
        }
    }

    public function keywordReportData($campaign_id, $data_order, $from_date, $to_date, $keywordType, $is_primary, $location_id) {
        $keywordGrpData = array();
        // sorting conditions
        $sort_conditions = '';
        if ($data_order == "sort_from_a_z") {
            $sort_conditions = array('Keywords.keyword' => 'ASC');
        } else if ($data_order == "sort_from_z_a") {

            $sort_conditions = array('Keywords.keyword' => 'DESC');
        } else if ($data_order == "created_date_asc") {

            $sort_conditions = array('Keywords.created' => 'ASC');
        } else if ($data_order == "created_date_desc") {

            $sort_conditions = array('Keywords.created' => 'DESC');
        } else if ($data_order == "updated_date_asc") {

            $sort_conditions = array('Keywords.modified' => 'ASC');
        } else if ($data_order == "updated_date_desc") {

            $sort_conditions = array('Keywords.modified' => 'DESC');
        }

        // filter on basis of primary and see all keywords
        $seeAll = array();
        if (!empty($is_primary) && $is_primary == 1) {
            $seeAll = array('Keywords.isprimary' => 1);
        }
        if ($campaign_id == 0) {

            if ($keywordType == "all") {

                $keyGrpData = $this->Keygroups->find("all", [
                            'contain' => ['Keywords' => [
                                    'conditions' => $seeAll,
                                    'sort' => $sort_conditions
                                ]],
                        ])->all()->toArray();
            } else if ($keywordType == "target") {

                $keyGrpData = $this->Keygroups->find("all", [
                            "conditions" => ["Keygroups.is_target" => 1],
                            'contain' => ['Keywords' => [
                                    'conditions' => $seeAll,
                                    'sort' => $sort_conditions
                                ]]
                        ])->all()->toArray();
            }
        } else {

            if ($this->Keyword->is_valid_campaign($campaign_id)) {

                if ($keywordType == "all") {

                    $keyGrpData = $this->Keygroups->find("all", [
                                "conditions" => ["Keygroups.campaign_id" => $campaign_id],
                                'contain' => ['Keywords' => [
                                        'conditions' => $seeAll,
                                        'sort' => $sort_conditions
                                    ]]
                            ])->all()->toArray();
                } else if ($keywordType == "target") {

                    $keyGrpData = $this->Keygroups->find("all", [
                                "conditions" => ["Keygroups.campaign_id" => $campaign_id, "Keygroups.is_target" => 1],
                                'contain' => ['Keywords' => [
                                        'conditions' => $seeAll,
                                        'sort' => $sort_conditions
                                    ]]
                            ])->all()->toArray();
                }
            } else {

                return "Invalid Campaign";
            }
        }

        $keygrp_data_found = array();
        $group_info = array();
        $getglobalseodata = array("org_visits" => 0, "org_conversion" => 0, "conversion_rate" => 0);
        $allprimarykeywords = array();
        $nogroups = array();
        if (count($keyGrpData) > 0) {

            foreach ($keyGrpData as $key => $value) {
                $group_id = $value->id;
                $group_target = $value->is_target;
                $keyword = array();
                $landing_page = $this->fully_trim($value->landing_page);
                $CurrentRank = 0;
                if (count($value->keywords) > 0) {
                    $is_ranked_url_target = 0;
                    foreach ($value->keywords as $index => $key_data) {

                        $CurrentRank = $key_data->rank == NULL ? 0 : $key_data->rank;
                        $isprimary = $key_data->isprimary;
                        $ranked_url = $key_data->ranked_url;
                        $camp_data = $this->fully_trim($ranked_url);
                        if (!strcmp($landing_page, $ranked_url) && !empty($ranked_url)) {
                            $is_ranked_url_target = 1;
                        }
                        $keyword_id = $key_data->id;
                        if ($ranked_url != '') {
                            $getseodata = $this->get_seo_date($ranked_url, $location_id, $from_date, $to_date);
                        } else {
                            $getseodata = $getglobalseodata;
                        }

                        $org_visits = $getseodata['org_visits'];
                        $org_conversion = $getseodata['org_conversion'];
                        $org_conversion_rate = $getseodata['conversion_rate'];
                        $search_vol = $key_data->googleSearchVolume;
                        $compt = $this->topercent($key_data->difficulty * 10000);
                        $bid = $this->formattomney($this->moneyfrmmicros($key_data->cpc));

                        // BUCKET code start

                        $current_bucket = '';
                        $bucket_color = '#fff;';
                        $bucket_color_style = '';

                        if ($CurrentRank == '0' || $CurrentRank == '50+') {
                            $current_bucket = '50+';
                            $bucket_color_style .= '#ed6b75';
                        } else if ($CurrentRank > 10 && $CurrentRank <= 50) {
                            $current_bucket = '11-50';
                            $bucket_color_style .= '#659be0';
                        } else if ($CurrentRank >= 4 && $CurrentRank <= 10) {
                            $current_bucket = '4-10';
                            $bucket_color_style .= '#337ab7;';
                        } else if ($CurrentRank >= 1 && $CurrentRank <= 3) {
                            $current_bucket = 'Top 3';
                            $bucket_color_style .= '#36c6d3';
                        }

                        $sqlQuery = 'SELECT rank, dateOfRank FROM tbl_keywords_history WHERE campaign_id = ' . $campaign_id . ' and LOWER(TRIM(keyword)) = "' . trim(strtolower($key_data->keyword)) . '" order by `dateOfRank` desc LIMIT 15';

                        $date_enter = $this->connection
                                ->execute($sqlQuery)
                                ->fetchAll('assoc');

                        $camp_id = $key_data->campaign_id;
                        $kywrd = trim(strtolower($key_data->keyword));

                        $sqlQueryDetails = "SELECT rank, dateOfRank FROM tbl_keywords_history WHERE LOWER(TRIM(keyword)) like '$kywrd' "
                                . "AND campaign_id = $camp_id AND dateOfRank IS NOT NULL  group by keyword order by dateOfRank desc LIMIT 1";

                        $date_result = $this->connection
                                ->execute($sqlQueryDetails)
                                ->fetchAll('assoc');

                        $bucket_change = 0;
                        if (count($date_enter) > 0) {
                            foreach ($date_enter as $in => $row_enter) {
                                $currankhist = isset($row_enter['rank']) ? $row_enter['rank'] : 0;
                                $existing_bucket = $this->bucket_name($currankhist);
                                if ($current_bucket != $existing_bucket) {
                                    $date_in_bucket = $row_enter['dateOfRank'];
                                    $bucket_change = 1;
                                    break;
                                }
                            }
                        } else {
                            $date_in_bucket = date('Y-m-d', strtotime('last Sunday'));
                        }

                        if (empty($date_enter)) {
                            $last_time_date = date('Y-m-d', strtotime('last Sunday'));
                        } else {
                            if (count($date_enter) > 1) {
                                $last_time_date = isset($date_enter[count($date_enter) - 1]['dateOfRank']) ? $date_enter[count($date_enter) - 1]['dateOfRank'] : '';
                            }
                        }

                        if (empty($last_time_date)) {
                            $last_time_date = date('Y-m-d', strtotime('last Sunday'));
                        }

                        if ($bucket_change == 0) {
                            $date_in_bucket = $last_time_date;
                        }

                        $date_enter = $date_result;

                        if (!empty($date_enter)) {

                            $date_enter_val = isset($date_enter[0]['dateOfRank']) ? $date_enter[0]['dateOfRank'] : $key_data->dateOfRank;
                        } else {
                            $date_enter_val = $key_data->dateOfRank;
                        }

                        $date_enter_val = date("d M Y", strtotime($date_enter_val));
                        $date_in_bucket = date("d M Y", strtotime($date_in_bucket));

                        $now = time(); // or your date as well
                        $your_date = strtotime($date_in_bucket);
                        $datediff = $now - $your_date;
                        $date_in_bucket_days = floor($datediff / (60 * 60 * 24));
                        $bg_color_style = '';
                        if ($date_in_bucket_days >= 90) {
                            $date_in_bucket_days = 90;
                        }
                        if ($current_bucket == '11-50' || $current_bucket == '50+') {
                            if ($date_in_bucket_days >= 90) {
                                $bg_color_style = 'color:red!important;font-weight:bold;';
                            }
                        }
                        if ($current_bucket == 'Top 3' && $date_in_bucket_days >= 90) {
                            $bg_color_style = 'color:green!important;font-weight:bold;';
                        }
                        //echo $date_in_bucket_days.'sss<br>'; exit;

                        $your_date = strtotime($last_time_date);
                        //$your_date = strtotime($date_enter_val);
                        $datediff = $now - $your_date;
                        $total_days = floor($datediff / (60 * 60 * 24));

                        $bucket_val = $current_bucket;
                        $days_in_bucket_val = $date_in_bucket_days;

                        $percentage_of_time = sprintf("%.2f", ($date_in_bucket_days / $total_days) * 100);
                        if ($percentage_of_time <= 100) {
                            $percentage_of_time = $percentage_of_time . '%';
                        } else {
                            $percentage_of_time = '100.00%';
                        }

                        // get history
                        $txt = '';
                        if ($campaign_id > 0) {
                            $txt = "AND campaign_id = $campaign_id";
                        }
                        $sqlQueryHistory = "SELECT rank,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank FROM tbl_keywords_history WHERE location_id = $location_id $txt AND LOWER(TRIM(keyword)) = '" . $key_data->keyword . "' AND dateOfRank>='" . $from_date . "' AND dateOfRank<='" . $to_date . "' ORDER BY dateOfRank DESC LIMIT 1";
                        $historydata = $this->connection->execute($sqlQueryHistory)->fetchAll('assoc');
                        $old_rank = 0;
                        $old_maps_rank = 0;
                        $old_mobile_rank = 0;
                        $old_mobile_maps_rank = 0;
                        $old_bing_rank = 0;
                        $rank_change = 0;
                        $maps_rank_change = 0;
                        $mobile_rank_change = 0;
                        $mobile_maps_rank_change = 0;
                        $bing_rank = 0;
                        $bing_rank_change = 0;
                        $bing_map_rank_change = 0;
                        $old_bing_maps_rank = 0;
                        if (count($historydata) > 0) {
                            $old_rank = $historydata[0]['rank'];
                            $old_maps_rank = $historydata[0]['maps_rank'];
                            $old_mobile_rank = $historydata[0]['mobile_rank'];
                            $old_mobile_maps_rank = $historydata[0]['mobile_maps_rank'];
                            $old_bing_rank = $historydata[0]['bing_rank'];
                            $old_bing_maps_rank = $historydata[0]['bing_maps_rank'];
                        }

                        $rank_change = intval($key_data->rank) - intval($old_rank);
                        $maps_rank_change = intval($key_data->maps_rank) - intval($old_maps_rank);
                        $mobile_rank_change = intval($key_data->mobile_rank) - intval($old_mobile_rank);
                        $mobile_maps_rank_change = intval($key_data->mobile_maps_rank) - intval($old_mobile_maps_rank);
                        $bing_rank_change = intval($key_data->bing_rank) - intval($old_bing_rank);
                        $bing_map_rank_change = intval($key_data->bing_maps_rank) - intval($old_bing_maps_rank);

                        // BUCKET code end       

                        array_push($keyword, array(
                            "id" => intval($keyword_id),
                            "keyword" => $key_data->keyword,
                            "is_ranked_url_target" => $is_ranked_url_target,
                            "isprimary" => $isprimary == NULL ? 0 : $isprimary,
                            "istarget" => $group_target == NULL ? 0 : $group_target,
                            "ranked_url" => $key_data->ranked_url == NULL ? '' : $key_data->ranked_url,
                            "rank" => array("l" => $key_data->rank == NULL ? 50 : intval($key_data->rank), "r" => $rank_change),
                            "maps_rank" => array("l" => $key_data->maps_rank == NULL ? 50 : intval($key_data->maps_rank), "r" => $maps_rank_change),
                            "mobile_rank" => array("l" => $key_data->mobile_rank == NULL ? 50 : intval($key_data->mobile_rank), "r" => $mobile_rank_change),
                            "mobile_maps_rank" => array("l" => $key_data->mobile_maps_rank == NULL ? 50 : intval($key_data->mobile_maps_rank), "r" => $mobile_maps_rank_change),
                            "bing_rank" => array("l" => $key_data->bing_rank == NULL ? 50 : intval($key_data->bing_rank), "r" => $bing_rank_change),
                            "bing_maps_rank" => array("l" => $key_data->bing_maps_rank == NULL ? 50 : intval($key_data->bing_maps_rank), "r" => $bing_map_rank_change),
                            "org_visits" => $org_visits,
                            "org_conv" => $org_conversion,
                            "org_conv_rate" => $org_conversion_rate,
                            "googleSearchVolume" => $search_vol,
                            "comp" => $compt,
                            "bid" => $bid,
                            "bucket" => $current_bucket,
                            "bucket_days" => $days_in_bucket_val,
                            "time" => "100.00%",
                            "bucket_text_color" => $bucket_color,
                            "bucket_background_color" => $bucket_color_style
                        ));

                        if ($isprimary == 1) {

                            array_push($allprimarykeywords, $keyword);
                        }
                    }
                }
                array_push($group_info, array(
                    "group_id" => $group_id,
                    "keywords" => $keyword
                ));
            }
        }
        if ($is_primary == 1) {
            return $allprimarykeywords;
        } else {
            
        }
        return $keyword;
    }

    public function RankVsTargetDataReport($campaign_id, $location_id) {
        if ($campaign_id == 0) {

            $keyGrpData = $this->Keygroups->find("all", [
                        'contain' => ['Keywords']
                    ])->all()->toArray();
        } else {

            if ($this->Keyword->is_valid_campaign($campaign_id)) {

                $keyGrpData = $this->Keygroups->find("all", [
                            "conditions" => ["Keygroups.campaign_id" => $campaign_id],
                            'contain' => ['Keywords']
                        ])->all()->toArray();
            } else {
                
            }
        }

        $group_info = array();

        if (count($keyGrpData) > 0) {

            foreach ($keyGrpData as $key => $value) {
                // landing page from tbl_keygroup
                $landing_page = $value->landing_page != NULL ? $value->landing_page : '';
                $group_target = $value->is_target;
                $group_id = $value->id;
                $keyword = array();

                $campaign_details = $this->getCampaignDetailsById($value->campaign_id, array("name", "local_location"));
                $camp_name = '';
                $camp_location = '';
                if (!empty($campaign_details) && $campaign_id == 0) {
                    $camp_name = $campaign_details[0]['name'];
                    $camp_location = $campaign_details[0]['local_location'];
                }
                if (count($value->keywords) > 0) {

                    foreach ($value->keywords as $in => $kwrd) {
                        // ranked url from tbl_keywords

                        $ranked_page = $kwrd->ranked_url != NULL ? $kwrd->ranked_url : '';
                        $is_match = 0;
                        $rank_score = $kwrd->rank == NULL ? 50 : $kwrd->rank;
                        $rank_available = $kwrd->rank == NULL ? 0 : 1;
                        // comparing ranked_url with landing page
                        if ($this->trimUrl($landing_page) == $this->trimUrl($ranked_page) && !empty($landing_page && !empty($ranked_page))) {
                            $is_match = 1;
                        }
                        array_push($keyword, array(
                            "keyword" => $kwrd->keyword,
                            "isprimary" => $kwrd->isprimary,
                            "istarget" => $group_target,
                            "target_url" => $landing_page,
                            "ranking_url" => $ranked_page,
                            "rank" => intval($rank_score),
                            "match" => $is_match,
                            "rank_avail" => intval($rank_available)
                        ));
                    }
                }

                // push found keywords in group_info
                array_push($group_info, array(
                    "group_id" => $group_id,
                    "camp_name" => $camp_name,
                    "camp_loc" => $camp_location,
                    "keywords" => $keyword
                ));
            }
        }

        if (count($keyword) > 0) {
            return $group_info;
        } else {
            return "no_data_found";
        }
    }

    public function CompetitorSummaryKeywordsReport($campaign_id, $location_id) {
        $location_url = $this->getLocationUrlById($location_id);
        $this->loadmodel("Competitor");
        $cond = "g.location_id = $location_id";
        if ($campaign_id > 0) {
            $cond .= " AND g.campaign_id = $campaign_id";
        }
        // get all competitors
        $competitors = $this->Competitor->find("all", ["conditions" => ["location_id" => $location_id], "fields" => ["id", "website"]])->toArray();

        $competitors_array = array();

        $competitors_summary = array();
        foreach ($competitors as $competitor) {
            array_push($competitors_array, $competitor->website);
        }
        array_unshift($competitors_array, $location_url);

        foreach ($competitors_array as $competitor_url) {
            if (trim($competitor_url) != '') {
                array_push($competitors_summary, $this->fully_trim($competitor_url));
            }
        }

        $sqlQueryAllGroups = "SELECT g.*, c.name, c.local_location, c.target_country FROM tbl_keygroup g INNER JOIN tbl_campaigns c"
                . " ON g.campaign_id = c.id INNER JOIN tbl_keywords k ON k.group_id = g.id  WHERE $cond AND k.isprimary = 1 AND g.status = 1";

        $keywordgrps = $this->connection->execute($sqlQueryAllGroups)->fetchAll('assoc');

        $groups_array = array();
        $header_array = array();
        $group_ids = array();

        foreach ($keywordgrps as $inx => $keywordgrp) {

            $istarget = 'targettbl';
            if ($keywordgrp['is_target'] == "0") {
                $istarget = '';
            }
            if ($keywordgrp['landing_page'] != '') {
                $landingpages[] = $keywordgrp['landing_page'];
            }
            $group_id = $keywordgrp['id'];
            $sqlToGetKeywords = "SELECT * FROM tbl_keywords WHERE group_id = $group_id ORDER BY isprimary DESC";
            $keywords = $this->connection->execute($sqlToGetKeywords)->fetchAll('assoc');

            $keywords_summary = array();

            foreach ($keywords as $inxVal => $keywordrow) {

                $rankdata = $keywordrow['rank'] == NULL ? '' : $keywordrow['rank'];
                //pr($rankdata);
                $globalrankurl = $keywordrow['ranked_url'];
                $lastchangeicon = '';
                $weekchangeicon = '';
                $monthchangeicon = '';
                $local_icon = '';
                $arrranks = array();
                foreach ($competitors_array as $competitor_url) {
                    if (trim($competitor_url) != '') {
                        $fulltrimdcompt = str_replace(array("http://", "https://", "www."), array("", "", ""), trim(trim($competitor_url, "/")));
                        $arrranks["$fulltrimdcompt"] = "50+";
                    }
                }

                if (!empty($rankdata)) {
                    $forcompt = array();
                    foreach ($arrranks as $trimmdsite => $arrrank) {
                        if (isset($keywordrow['ranked_url']) && strpos($keywordrow['ranked_url'], $trimmdsite) !== false) {
                            if (!in_array($trimmdsite, $forcompt)) {
                                $forcompt[] = $trimmdsite;
                                $arrranks["$trimmdsite"] = $keywordrow['rank'];
                            }
                        }
                    }
                }
                $rank_summary = array();
                foreach ($competitors_array as $competitor_url) {
                    if (trim($competitor_url) != '') {
                        $trimcompetitor = str_replace(array("http://", "https://", "www."), array("", "", ""), trim(trim($competitor_url, "/")));
                        array_push($rank_summary, array(
                            "url" => $trimcompetitor,
                            "rank" => $arrranks["$trimcompetitor"]
                        ));
                    }
                }

                array_push($keywords_summary, array(
                    "keyword_id" => intval($keywordrow['id']),
                    "keyword" => $keywordrow['keyword'],
                    "is_primary" => intval($keywordrow['isprimary']),
                    "is_target" => intval($keywordgrp['is_target']),
                    "rank" => $rank_summary
                ));
            }
            array_push($groups_array, array(
                "group_id" => $group_id,
                "keywords" => $keywords_summary
            ));
        }
        $new = array("header" => $competitors_summary, "data" => $groups_array);
        return $new;
    }

    public function executiveReportData($campaign_id, $is_target, $from_date, $to_date, $location_id) {
        if ($campaign_id == 0) {
            $avgSql = "SELECT avg(case when rank IS NULL then 50 else rank end) as average from tbl_keywords";

            $results = $this->connection
                    ->execute($avgSql)
                    ->fetchAll('assoc');
            return $this->executiveSummaryReportMetrics($location_id, $from_date, $to_date, $campaign_id, $is_target);
        } else {
            // campaign id has some value now
            if ($this->Keyword->is_valid_campaign($campaign_id)) {
                return $this->executiveSummaryReportMetrics($location_id, $from_date, $to_date, $campaign_id, $is_target);
            } else {
                return "invalid_campaign";
            }
        }
    }

}
