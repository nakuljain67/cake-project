<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;

class DataController extends AppController {

    public function initialize() {
        parent::initialize();
        header('Access-Control-Allow-Origin: *');
    }

    /* default method called */

    public function index() {

        $this->autoRender = false;

        $this->json(1, array(
            "method" => "index",
            "messge" => "silence is golden"
        ));
    }

    /* get list of countries */

    public function countries() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $this->json(1, 'countries found', $this->Data->countrylist());
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* get list of states */

    public function states() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $this->json(1, 'states found', $this->Data->statelist());
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* get list of cities  */

    public function cities() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $this->json(1, 'cities found', $this->Data->citylist());
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* get states by country_id */

    public function statesByCountryId() {

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $states_array = $this->Data->statesByCountryId($_REQUEST);

                if (count($states_array) > 0):

                    $this->json(1, 'States found', $states_array);
                else:

                    $this->json(0, 'No States found', $states_array);
                endif;
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* get cities by state_id */

    public function citiesByStateId() {

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $cities_array = $this->Data->citiesByStateId($_REQUEST);

                if (count($cities_array) > 0):

                    $this->json(1, 'Cities found', $cities_array);
                else:

                    $this->json(1, 'No City found', $cities_array);
                endif;
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

}

?>