<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;

class DashboardController extends AppController {

    public $dashboard_widget_tbl;

    public function initialize() {
        parent::initialize();
        header('Access-Control-Allow-Origin: *');
        $this->dashboard_widget_tbl = TableRegistry::get('tbl_dashboard_widgets');
    }

    /* default called method */

    public function index() {

        $this->autoRender = false;

        $this->json(1, array(
            "method" => "index",
            "messge" => "silence is golden"
        ));
    }

    /* showing 4 colmns dashboard widget */

    public function dashboard4colswidget() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $dashWidgetArray = array(
                array(
                    "id" => 1,
                    "name" => "EFFICIENCY SCORE",
                    "middle_score" => 55.50,
                    "last_score" => 45.00,
                    "change" => 10,
                    "bg_color" => "bg-primary",
                    "is_removed" => 0
                ),
                array(
                    "id" => 2,
                    "name" => "SITE AUDIT SCORE",
                    "middle_score" => 80.50,
                    "last_score" => 60.00,
                    "change" => 20,
                    "bg_color" => "bg-success",
                    "is_removed" => 0
                ),
                array(
                    "id" => 3,
                    "name" => "CRE SCORE",
                    "middle_score" => 85.50,
                    "last_score" => 85.00,
                    "change" => 50,
                    "bg_color" => "bg-warning",
                    "is_removed" => 0
                ),
                array(
                    "id" => 4,
                    "name" => "CITATION SCORE",
                    "middle_score" => 55.50,
                    "last_score" => 45.00,
                    "change" => 10,
                    "bg_color" => 'bg-info',
                    "is_removed" => 0
                ),
                array(
                    "id" => 5,
                    "name" => "VISIBILITY SCORE",
                    "middle_score" => 55.50,
                    "last_score" => 45.00,
                    "change" => 10,
                    "bg_color" => 'bg-danger',
                    "is_removed" => 0,
                )
            );

            $this->json(1, $dashWidgetArray);
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* showing 3 colmns dashboard widget */

    public function dashboard3colswidget() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $dashWidgetArray = array(
                array(
                    "id" => 1,
                    "type" => "conversion",
                    "name" => "Conversion Values",
                    "total_conversions" => 75,
                    "conversion_rate" => 10.38,
                    "total_visits" => 1423,
                    "organic" => 940,
                    "direct" => 301,
                    "one_three" => 5,
                    "four_ten" => 15,
                    "eleven_twenty" => 30,
                    "twentyone_fifty" => 45,
                    "bounce_rate" => 76.38,
                    "time_on_site" => 10,
                    "last_month_changes" => 10,
                    "bg_color" => "bg-warning"
                ),
                array(
                    "id" => 2,
                    "type" => "traffic",
                    "name" => "Traffic Values",
                    "total_conversions" => 75,
                    "conversion_rate" => 10.38,
                    "total_visits" => 1423,
                    "organic" => 940,
                    "direct" => 301,
                    "one_three" => 5,
                    "four_ten" => 15,
                    "eleven_twenty" => 30,
                    "twentyone_fifty" => 45,
                    "bounce_rate" => 76.38,
                    "time_on_site" => 10,
                    "last_month_changes" => 17,
                    "bg_color" => "bg-success"
                ),
                array(
                    "id" => 3,
                    "type" => "keyword",
                    "name" => "Keyword Positions",
                    "total_conversions" => 75,
                    "conversion_rate" => 10.38,
                    "total_visits" => 1423,
                    "organic" => 940,
                    "direct" => 301,
                    "one_three" => 5,
                    "four_ten" => 15,
                    "eleven_twenty" => 30,
                    "twentyone_fifty" => 45,
                    "bounce_rate" => 76.38,
                    "time_on_site" => 10,
                    "last_month_changes" => 25,
                    "bg_color" => "bg-info"
                )
            );

            $this->json(1, $dashWidgetArray);
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* showing 2 colmns dashboard widget */

    public function dashboard2colswidget() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $dashWidgetArray = array(
                array(
                    "id" => 1,
                    "type" => "campaign",
                    "keyword" => "Amazon",
                    "name" => "Campaign Insights",
                    "foun_on" => "03 Mar 2017",
                    "issue" => "Connect Google Analytics",
                    "status" => "To Do",
                    "score" => 66,
                    "total_campaign_issues" => 13,
                    "visibility_score" => 5.77,
                    "total_keyword_issues" => 13,
                    "content_optimization" => 60.48,
                    "total_content_issues" => 13,
                    "site_audit_score" => 75,
                    "total_site_issues" => 13
                ),
                array(
                    "id" => 2,
                    "type" => "keyword",
                    "keyword" => "Amazon",
                    "name" => "Keyword Insights",
                    "foun_on" => "01 Apr 2017",
                    "status" => "Doing",
                    "score" => 66,
                    "total_campaign_issues" => 13,
                    "visibility_score" => 5.77,
                    "total_keyword_issues" => 13,
                    "content_optimization" => 60.48,
                    "total_content_issues" => 13,
                    "site_audit_score" => 75,
                    "total_site_issues" => 13
                ),
                array(
                    "id" => 3,
                    "type" => "content",
                    "keyword" => "Amazon",
                    "name" => "Content Insights",
                    "foun_on" => "03 Mar 2017",
                    "issue" => "Run your content recommendation",
                    "status" => "Done",
                    "score" => 66,
                    "total_campaign_issues" => 13,
                    "visibility_score" => 5.77,
                    "total_keyword_issues" => 13,
                    "content_optimization" => 60.48,
                    "total_content_issues" => 13,
                    "site_audit_score" => 75,
                    "total_site_issues" => 13,
                ),
                array(
                    "id" => 4,
                    "type" => "site",
                    "keyword" => "Amazon",
                    "name" => "Site Insights",
                    "foun_on" => "05 Feb 2017",
                    "issue" => "Run your citation audit",
                    "status" => "Done",
                    "score" => 66,
                    "total_campaign_issues" => 13,
                    "visibility_score" => 5.77,
                    "total_keyword_issues" => 13,
                    "content_optimization" => 60.48,
                    "total_content_issues" => 13,
                    "site_audit_score" => 75,
                    "total_site_issues" => 13
                )
            );

            $this->json(1, $dashWidgetArray);
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* showing landing pages category wise */

    public function dashboardlandingpages() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $landingPages = array(
                array(
                    "id" => '1',
                    "type" => "converting",
                    "first_name" => "Top Converting",
                    "last_name" => "Landing Pages",
                    "pages" => array(
                        array(
                            "id" => '1',
                            "page_link" => "www/Site/Loremipsum-dummy/text-link.",
                            "visits" => 65,
                            "current" => 18,
                            "previous" => +9
                        ),
                        array(
                            "id" => '2',
                            "page_link" => "www/Site/Loremipsum-dummy/text-link.",
                            "visits" => 65,
                            "current" => 18,
                            "previous" => +9
                        ),
                        array(
                            "id" => '3',
                            "page_link" => "www/Site/Loremipsum-dummy/text-link.",
                            "visits" => 65,
                            "current" => 18,
                            "previous" => +9
                        ),
                        array(
                            "id" => '4',
                            "page_link" => "www/Site/Loremipsum-dummy/text-link.",
                            "visits" => 65,
                            "current" => 18,
                            "previous" => +9
                        ),
                        array(
                            "id" => '5',
                            "page_link" => "www/Site/Loremipsum-dummy/text-link.",
                            "visits" => 65,
                            "current" => 18,
                            "previous" => +9
                        )
                    )
                ), array(
                    "id" => '2',
                    "type" => "organic",
                    "first_name" => "Top Organics",
                    "last_name" => "Traffic Pages",
                    "pages" => array(
                        array(
                            "id" => '1',
                            "page_link" => "www/Site/Loremipsum-dummy/text-link.",
                            "visits" => 65,
                            "current" => 18,
                            "previous" => +9
                        ),
                        array(
                            "id" => '2',
                            "page_link" => "www/Site/Loremipsum-dummy/text-link.",
                            "visits" => 65,
                            "current" => 18,
                            "previous" => +9
                        ),
                        array(
                            "id" => '3',
                            "page_link" => "www/Site/Loremipsum-dummy/text-link.",
                            "visits" => 65,
                            "current" => 18,
                            "previous" => +9
                        ),
                        array(
                            "id" => '4',
                            "page_link" => "www/Site/Loremipsum-dummy/text-link.",
                            "visits" => 65,
                            "current" => 18,
                            "previous" => +9
                        ),
                        array(
                            "id" => '5',
                            "page_link" => "www/Site/Loremipsum-dummy/text-link.",
                            "visits" => 65,
                            "current" => 18,
                            "previous" => +9
                        )
                    )
                ), array(
                    "id" => '3',
                    "type" => "keyword",
                    "first_name" => "Keyword",
                    "last_name" => "(By change in rank)",
                    "pages" => array(
                        array(
                            "id" => '1',
                            "page_link" => "www/Site/Loremipsum-dummy/text-link.",
                            "visits" => 65,
                            "current" => 18,
                            "previous" => 9
                        ),
                        array(
                            "id" => '2',
                            "page_link" => "www/Site/Loremipsum-dummy/text-link.",
                            "visits" => 65,
                            "current" => 18,
                            "previous" => 9
                        ),
                        array(
                            "id" => '3',
                            "page_link" => "www/Site/Loremipsum-dummy/text-link.",
                            "visits" => 65,
                            "current" => 18,
                            "previous" => 9
                        ),
                        array(
                            "id" => '4',
                            "page_link" => "www/Site/Loremipsum-dummy/text-link.",
                            "visits" => 65,
                            "current" => 18,
                            "previous" => 9
                        ),
                        array(
                            "id" => '5',
                            "page_link" => "www/Site/Loremipsum-dummy/text-link.",
                            "visits" => 65,
                            "current" => 18,
                            "previous" => 9
                        )
                    )
                )
            );

            $this->json(1, $landingPages);
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* showing data to pie-charts */

    public function dashboardpiecharts() {
        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $pieChartsData = array(
                array(
                    "id" => 1,
                    "first_name" => "Conversion",
                    "last_name" => "Metrics",
                    "pieChartType" => "pie",
                    "pieChartLabels" => ['Total Visits', 'Organic', 'Paid'],
                    "pieChartData" => [300, 500, 100]
                ),
                array(
                    "id" => 2,
                    "first_name" => "Traffic",
                    "last_name" => "Metrics",
                    "pieChartType" => "pie",
                    "pieChartLabels" => ['Top 3', '4-10', '11-20', '21-50'],
                    "pieChartData" => [100, 300, 500, 200]
                )
            );

            $this->json(0, $pieChartsData);
        }
    }

    /* showing dashboard widgets */

    public function widgets() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $arr = array();
                $type = isset($_REQUEST['type']) ? trim($_REQUEST['type']) : "";

                $widgets_array = array("col3div", "col4div", "col6div");

                if ($type == "col3div") {

                    $arr = array(
                        array('id' => 1, 'name' => 'Efficency Score', 'image' => ''),
                        array('id' => 2, 'name' => 'Site Audit', 'image' => ''),
                        array('id' => 3, 'name' => 'CRE Score', 'image' => ''),
                        array('id' => 4, 'name' => 'Citation Score', 'image' => ''),
                        array('id' => 5, 'name' => 'Visibilty Score', 'image' => ''),
                        array('id' => 6, 'name' => 'Total Keywords', 'image' => ''),
                        array('id' => 7, 'name' => 'Average Rank', 'image' => ''),
                        array('id' => 8, 'name' => 'Average Rank', 'image' => ''),
                        array('id' => 9, 'name' => 'Top 3 Ranked Keywords', 'image' => ''),
                        array('id' => 10, 'name' => 'Top 10 Ranked Keywords', 'image' => '')
                    );
                } else if ($type == "col4div") {

                    $arr = array(
                        array('id' => 101, 'name' => 'Conversion Values', 'image' => ''),
                        array('id' => 102, 'name' => 'Traffic Values', 'image' => ''),
                        array('id' => 103, 'name' => 'Keyword Positions', 'image' => ''),
                        array('id' => 104, 'name' => 'Time On Site', 'image' => ''),
                        array('id' => 105, 'name' => 'Conversion Metrics', 'image' => ''),
                        array('id' => 106, 'name' => 'Traffic Metrics', 'image' => ''),
                        array('id' => 107, 'name' => 'Rank Metrics', 'image' => '')
                    );
                } else if ($type == "col6div") {

                    $arr = array(
                        array('id' => 201, 'name' => 'Campaign Insights', 'image' => ''),
                        array('id' => 202, 'name' => 'Keyword Insights', 'image' => ''),
                        array('id' => 203, 'name' => 'Content Insights', 'image' => ''),
                        array('id' => 204, 'name' => 'Site Insights', 'image' => ''),
                        array('id' => 205, 'name' => 'Citation Insights', 'image' => ''),
                        array('id' => 206, 'name' => 'Top Converting Landing Pages', 'image' => ''),
                        array('id' => 207, 'name' => 'Top Organics Traffic Pages', 'image' => ''),
                        array('id' => 208, 'name' => 'Top Keyword (By change in rank)', 'image' => ''),
                    );
                }

                if (!empty($type) && in_array($type, $widgets_array))
                    $this->json(1, 'Widgets Found', $arr);
                else
                    $this->json(1, 'No Widgets Found', $arr);
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* showing dashboard widgets by location_id */

    public function locationWidgets() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $location_id = isset($_REQUEST['user_id']) ? intval($_REQUEST['user_id']) : 0;
                $agency_id = isset($_REQUEST['agency_id']) ? intval($_REQUEST['agency_id']) : 0;

                $results = $this->dashboard_widget_tbl->find('all', [
                    'conditions' => ['agency_id' => $agency_id, 'location_id' => $location_id]
                ]);

                $userWidgetsArray = array();

                if ($results->count() > 0) {

                    foreach ($results as $userWidgets):

                        array_push($userWidgetsArray, array(
                            'agency_id' => $userWidgets->agency_id,
                            'location_id' => $userWidgets->location_id,
                            'widgets' => json_decode($userWidgets->widgets_found)
                        ));
                    endforeach;

                    $this->json(1, "Dashboard Widgets Found", $userWidgetsArray);
                }else {

                    $this->json(0, "Location ID not found in Database with Agency ID: " . $agency_id);
                }
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* used to create dashboard widget */

    public function userWidget() {

        $this->autoRender = false;

        try {

            $AgencyId = isset($_REQUEST['agency_id']) ? $_REQUEST['agency_id'] : 0;
            $LocationId = isset($_REQUEST['location_id']) ? $_REQUEST['location_id'] : 0;
            $WidgetsFound = isset($_REQUEST['user_widgets']) ? $_REQUEST['user_widgets'] : "";

            $results = $this->dashboard_widget_tbl->find('all', [
                'conditions' => ['agency_id' => $agency_id, 'location_id' => $location_id]
            ]);

            if ($results->count() > 0) {

                $this->dashboard_widget_tbl->updateAll(['widgets_found' => json_encode($WidgetsFound), 'updated_dt' => date('Y-m-d H:i:s')], ['agency_id' => $AgencyId, 'location_id' => $LocationId]);
            } else {

                $usr_dashboard_tbl = $this->dashboard_widget_tbl;
                $user_widget = $usr_dashboard_tbl->newEntity();
                $user_widget->agency_id = $AgencyId;
                $user_widget->location_id = $LocationId;
                $user_widget->widgets_found = json_encode($WidgetsFound);
                $user_widget->created_dt = date("Y-m-d H:i:s");
                $user_widget->updated_dt = date("Y-m-d H:i:s");

                if ($usr_dashboard_tbl->save($user_widget)) {
                    //record inserted now...:)
                }
            }
        } catch (Exception $ex) {
            
        }
    }

}

?>