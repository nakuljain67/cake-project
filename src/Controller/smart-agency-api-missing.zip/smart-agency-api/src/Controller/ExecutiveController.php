<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;

class ExecutiveController extends AppController {

    private $connection;

    public function initialize() {
        parent::initialize();
        header('Access-Control-Allow-Origin: *');
        $this->connection = ConnectionManager::get('default');
    }

    /* default method called */

    public function index() {

        $this->autoRender = false;
        $this->json(0, "silence is golden");
    }

    // executive summary report
    public function generateExecutiveSummaryReport() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $data = json_decode(file_get_contents('php://input'));
            $campaign_id = isset($data->campaign_id) ? intval($data->campaign_id) : 0;
            $is_target = isset($data->is_target) ? intval($data->is_target) : 0;
            $from_data = isset($data->from_date) ? $data->from_date : date("Y-m-d", strtotime("-31 day"));
            $to_data = isset($data->to_date) ? $data->to_date : date("Y-m-d", strtotime("-1 day"));

            if ($this->is_token_valid()) {

                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];

                if ($campaign_id == 0) {
                    // condition for show all keywords

                    $avgSql = "SELECT avg(case when rank IS NULL then 50 else rank end) as average from tbl_keywords";

                    $results = $this->connection
                            ->execute($avgSql)
                            ->fetchAll('assoc');
                    $this->json(1, "report found", $this->executiveSummaryReportMetrics($location_id, $from_data, $to_data, $campaign_id, $is_target));
                } else {
                    // campaign id has some value now
                    if ($this->Keyword->is_valid_campaign($campaign_id)) {

                        $this->json(1, "report found", $this->executiveSummaryReportMetrics($location_id, $from_data, $to_data, $campaign_id, $is_target));
                    } else {

                        $this->json(0, "invalid campaign id", array("campaign id" => "required"));
                    }
                }
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    // calculations of executive summary report
    public function executiveSummaryReportMetrics($location_id, $from_date, $to_date, $campaign_id = 0, $is_target = 0) {

        /*
         * Param details
         * ================================================
         * location_id : id of current location logged in 
         * from_date: record from which date
         * to_date: record upto which date
         * campaign_id: record of any campaign then its id here else for all applied
         * is_target: for target keywords if yes then 1 else 0
         */

        $get_data = $this->calculateKeywordsMetrics($location_id, $from_date, $to_date, $campaign_id, $is_target);

        $keywords_data = $get_data['keyword_data'];
        $rankvstarget = $get_data['ranked_data'];

        $number_of_keywords = array();
        $average_rank = array();
        $top50_avg_rank = array();
        $top10_rank = array();
        $top3_rank = array();
        $top1_rank = array();
        $seo_score = array();
        $visibility_score = array();
        $rankvstarget_score = array();
        $all_landing_urls = array();

        $marketing_eff_score = array(
            "current_score" => "54.81",
            "last_90days_score" => "26.7",
            "last_90days_score_change" => 28.11,
            "last_180days_score" => "27.45",
            "last_180days_score_change" => 27.36,
            "last_1yr_score" => "0.45",
            "last_1yr_score_change" => 54.36,
        );

        $content_optimization_score = array(
            "current_score" => "75.51",
            "last_90days_score" => "0",
            "last_90days_score_change" => 75.51,
            "last_180days_score" => "0",
            "last_180days_score_change" => 75.51,
            "last_1yr_score" => "N/A",
            "last_1yr_score_change" => 75.51,
        );

        $citation_score = array(
            "current_score" => "5.36",
            "last_90days_score" => "N/A",
            "last_90days_score_change" => "N/A",
            "last_180days_score" => "N/A",
            "last_180days_score_change" => "N/A",
            "last_1yr_score" => "N/A",
            "last_1yr_score_change" => "N/A",
        );

        $siteaudit_score = array(
            "current_score" => "64",
            "last_90days_score" => "69",
            "last_90days_score_change" => -5,
            "last_180days_score" => "69",
            "last_180days_score_change" => -5,
            "last_1yr_score" => "N/A",
            "last_1yr_score_change" => "N/A",
        );

        if (!empty($keywords_data)) {

            $number_of_keywords = array(
                "current_score" => $keywords_data['total_keywords'],
                "last_90days_score" => $keywords_data['keywords_days90'],
                "last_90days_score_change" => intval($keywords_data['total_keywords']) - intval($keywords_data['keywords_days90']),
                "last_180days_score" => $keywords_data['keywords_days180'],
                "last_180days_score_change" => intval($keywords_data['total_keywords']) - intval($keywords_data['keywords_days180']),
                "last_1yr_score" => $keywords_data['keywords_yearback'],
                "last_1yr_score_change" => intval($keywords_data['total_keywords']) - intval($keywords_data['keywords_yearback']),
            );

            $visibility_score = array(
                "current_score" => $data1 = $this->doPercentage($keywords_data['current_top10_rank'], $keywords_data['total_keywords']),
                "last_90days_score" => $data2 = $this->doPercentage($keywords_data['top10_rank_days90'], $keywords_data['keywords_days90']),
                "last_90days_score_change" => floatval($data1 - $data2),
                "last_180days_score" => $data3 = $this->doPercentage($keywords_data['top10_rank_days90'], $keywords_data['keywords_days180']),
                "last_180days_score_change" => floatval($data1 - $data3),
                "last_1yr_score" => $data4 = $this->doPercentage($keywords_data['top10_rank_days90'], $keywords_data['keywords_yearback']),
                "last_1yr_score_change" => floatval($data1 - $data4),
            );

            $average_rank = array(
                "current_score" => $keywords_data['current_avg_rank'],
                "last_90days_score" => $keywords_data['avg_rank_days90'],
                "last_90days_score_change" => floatval($keywords_data['avg_rank_days90'] - $keywords_data['current_avg_rank']),
                "last_180days_score" => $keywords_data['avg_rank_days180'],
                "last_180days_score_change" => floatval($keywords_data['avg_rank_days180'] - $keywords_data['current_avg_rank']),
                "last_1yr_score" => $keywords_data['avg_rank_yearback'],
                "last_1yr_score_change" => floatval($keywords_data['avg_rank_yearback'] - $keywords_data['current_avg_rank']),
            );

            $top50_avg_rank = array(
                "current_score" => $data1 = $this->doPercentage($keywords_data['current_sum_top50_rank'], $keywords_data['top50_sum_total']),
                "last_90days_score" => $data2 = $this->doPercentage($keywords_data['top50_sum_rank_days90'], $keywords_data['top50_sum_total']),
                "last_90days_score_change" => floatval($data1 - $data2),
                "last_180days_score" => $data3 = $this->doPercentage($keywords_data['top50_sum_rank_days180'], $keywords_data['top50_sum_total']),
                "last_180days_score_change" => floatval($data1 - $data3),
                "last_1yr_score" => $data4 = $this->doPercentage($keywords_data['top50_sum_rank_yearback'], $keywords_data['top50_sum_total']),
                "last_1yr_score_change" => floatval($data1 - $data4),
            );

            $top10_rank = array(
                "current_score" => $keywords_data['current_top10_rank'],
                "last_90days_score" => $keywords_data['top10_rank_days90'],
                "last_90days_score_change" => intval($keywords_data['current_top10_rank']) - intval($keywords_data['top10_rank_days90']),
                "last_180days_score" => $keywords_data['top10_rank_days180'],
                "last_180days_score_change" => intval($keywords_data['current_top10_rank']) - intval($keywords_data['top10_rank_days180']),
                "last_1yr_score" => $keywords_data['top10_rank_yearback'],
                "last_1yr_score_change" => intval($keywords_data['current_top10_rank']) - intval($keywords_data['top10_rank_yearback']),
            );

            $seo_score = array(
                "current_score" => $data1 = $this->doPercentage($keywords_data['current_top10_rank'], $keywords_data['current_avg_rank']),
                "last_90days_score" => $data2 = $this->doPercentage($keywords_data['top10_rank_days90'], $keywords_data['avg_rank_days90']),
                "last_90days_score_change" => floatval($data1 - $data2),
                "last_180days_score" => $data3 = $this->doPercentage($keywords_data['top10_rank_days180'], $keywords_data['avg_rank_days180']),
                "last_180days_score_change" => floatval($data1 - $data3),
                "last_1yr_score" => $data4 = $this->doPercentage($keywords_data['top10_rank_yearback'], $keywords_data['avg_rank_yearback']),
                "last_1yr_score_change" => floatval($data1 - $data4),
            );

            $top3_rank = array(
                "current_score" => $keywords_data['current_top3_rank'],
                "last_90days_score" => $keywords_data['top3_rank_days90'],
                "last_90days_score_change" => intval($keywords_data['current_top3_rank']) - intval($keywords_data['top3_rank_days90']),
                "last_180days_score" => $keywords_data['top3_rank_days180'],
                "last_180days_score_change" => intval($keywords_data['current_top3_rank']) - intval($keywords_data['top3_rank_days180']),
                "last_1yr_score" => $keywords_data['top3_rank_yearback'],
                "last_1yr_score_change" => intval($keywords_data['current_top3_rank']) - intval($keywords_data['top3_rank_yearback']),
            );

            $top1_rank = array(
                "current_score" => $keywords_data['current_top1_rank'],
                "last_90days_score" => $keywords_data['top1_rank_days90'],
                "last_90days_score_change" => intval($keywords_data['current_top1_rank']) - intval($keywords_data['top1_rank_days90']),
                "last_180days_score" => $keywords_data['top1_rank_days180'],
                "last_180days_score_change" => intval($keywords_data['current_top1_rank']) - intval($keywords_data['top1_rank_days180']),
                "last_1yr_score" => $keywords_data['top1_rank_yearback'],
                "last_1yr_score_change" => intval($keywords_data['current_top1_rank']) - intval($keywords_data['top1_rank_yearback']),
            );

            if ($campaign_id == 0) {

                foreach ($rankvstarget['all_landing_urls'] as $in => $data) {
                    $land_url = $data['landing_page'] == NULL ? '' : $data['landing_page'];
                    $land_url = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $land_url)), "/");
                    array_push($all_landing_urls, $land_url);
                }
            } else {
                foreach ($rankvstarget['campaign_landing_urls'] as $in => $data) {
                    $land_url = $data['landing_page'] == NULL ? '' : $data['landing_page'];
                    $land_url = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $land_url)), "/");
                    array_push($all_landing_urls, $land_url);
                }
            }

            if (count($rankvstarget) > 0) {
                // current rank vs target calculation
                $current_data = $this->findRankVsTargetMetrics($all_landing_urls, $rankvstarget['count_urls']);
                // last 90 days rank vs target calculation
                $last90days_data = $this->findRankVsTargetMetrics($all_landing_urls, $rankvstarget['last_90_days']);
                // last 180 days rank vs target calculation
                $last180days_data = $this->findRankVsTargetMetrics($all_landing_urls, $rankvstarget['last_180_days']);
                // last 1 Yr rank vs target calculation
                $last1yrdays_data = $this->findRankVsTargetMetrics($all_landing_urls, $rankvstarget['last_1_yr']);

                $rankvstarget_score = array(
                    "current_score" => $data1 = $this->doPercentage($current_data['ranked_count'], $current_data['total_count']),
                    "last_90days_score" => $data2 = $this->doPercentage($last90days_data['ranked_count'], $last90days_data['total_count']),
                    "last_90days_score_change" => floatval($data1 - $data2),
                    "last_180days_score" => $data3 = $this->doPercentage($last180days_data['ranked_count'], $last180days_data['total_count']),
                    "last_180days_score_change" => floatval($data1 - $data3),
                    "last_1yr_score" => $data4 = $this->doPercentage($last1yrdays_data['ranked_count'], $last1yrdays_data['total_count']),
                    "last_1yr_score_change" => floatval($data1 - $data4),
                );
            }
        }

        $summary_array = array(
            "visibility_score" => $visibility_score,
            "total_number_of_keywords" => $number_of_keywords,
            "average_rank_data" => $average_rank,
            "rank_top50" => $top50_avg_rank,
            "top10_rank" => $top10_rank,
            "top3_rank" => $top3_rank,
            "rank_vs_target" => $rankvstarget_score,
            "top1_rank" => $top1_rank,
            "seo_score" => $seo_score,
            "marketing_eff_score" => $marketing_eff_score,
            "content_optimization_score" => $content_optimization_score,
            "citation_score" => $citation_score,
            "siteaudit_score" => $siteaudit_score
        );

        return $summary_array;
    }

    public function findRankVsTargetMetrics($source_urls, $matching_urls) {

        $allrankedKeywords = 0;
        $allkeywords = 0;
        // calculating current rank/target value in %, formula used count(ranked url keyword)/count(all keywords)
        foreach ($matching_urls as $k => $v) {
            $cid = $v['campaign_id'];
            $gid = $v['group_id'];
            $rankUrl = $v['ranked_url'] == NULL ? '' : $v['ranked_url'];
            $rankUrl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $rankUrl)), "/");
            if (in_array($rankUrl, $source_urls)) {
                $allrankedKeywords++;
            }
            $allkeywords++;
        }

        return array("ranked_count" => $allrankedKeywords, "total_count" => $allkeywords);
    }

    /* Number of Kewords */

    public function calculateKeywordsMetrics($location_id, $from_date, $to_date, $campaign_id = '', $is_target = 0) {

        /*
         * to_date is coming as current_date
         */
        try {

            $back90daysDate = date("Y-m-d", strtotime("$to_date -3 month"));
            $back180daysDate = date("Y-m-d", strtotime("$to_date -6 month"));
            $back1YrdaysDate = date("Y-m-d", strtotime("$to_date -12 month"));
            // join query to make in join if target selected
            $sqlJoinQueryForTargetKeywords = '';
            $targetCondition = '';
            $campaign_condition = '';
            $campaign_condition_keygroup = '';
            if ($is_target == 1) {
                $sqlJoinQueryForTargetKeywords = " INNER JOIN tbl_keygroup kg ON kw.group_id = kg.id";
                $targetCondition = " AND kg.is_target = 1";
            }
            if (!empty($campaign_id)) {
                $campaign_condition = " AND kw.campaign_id = " . $campaign_id;
                $campaign_condition_keygroup = " AND kg.campaign_id = " . $campaign_id;
            }

            // 90 days back
            $NumberofKeywords = $this->connection
                    ->execute("SELECT "
                            //number of keywords
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$from_date' and kw.dateOfRank <= '$to_date') AS total_keywords,"
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$back90daysDate' and kw.dateOfRank <= '$to_date') AS keywords_days90,"
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$back180daysDate' and kw.dateOfRank <= '$to_date') as keywords_days180, "
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$back1YrdaysDate' and kw.dateOfRank <= '$to_date') as keywords_yearback,"
                            //avg rank
                            . "(SELECT ROUND(avg(case when rank IS NULL then 50 else kw.rank end),2) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$from_date'  and kw.dateOfRank <= '$to_date') as current_avg_rank,"
                            . "(SELECT ROUND(avg(case when rank IS NULL then 50 else kw.rank end),2) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$back90daysDate' and kw.dateOfRank <= '$to_date') AS avg_rank_days90,"
                            . "(SELECT ROUND(avg(case when rank IS NULL then 50 else kw.rank end),2) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$back180daysDate' and kw.dateOfRank <= '$to_date') as avg_rank_days180, "
                            . "(SELECT ROUND(avg(case when rank IS NULL then 50 else kw.rank end),2) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank >= '$back1YrdaysDate' and kw.dateOfRank <= '$to_date') as avg_rank_yearback,"
                            //avg rank top 50
                            . "(SELECT sum(kw.rank) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 50 and kw.dateOfRank >= '$from_date' and kw.dateOfRank <= '$to_date' and kw.rank IS NOT NULL) as current_sum_top50_rank,"
                            . "(SELECT sum(kw.rank) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 50 and kw.dateOfRank >= '$back90daysDate' and kw.dateOfRank <= '$to_date' and kw.rank IS NOT NULL) AS top50_sum_rank_days90,"
                            . "(SELECT sum(kw.rank) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 50 and kw.dateOfRank >= '$back180daysDate' and kw.dateOfRank <= '$to_date' and kw.rank IS NOT NULL) as top50_sum_rank_days180, "
                            . "(SELECT sum(kw.rank) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 50 and kw.dateOfRank >= '$back1YrdaysDate' and kw.dateOfRank <= '$to_date' and kw.rank IS NOT NULL) as top50_sum_rank_yearback,"
                            . "(SELECT sum(case when rank IS NULL then 50 else kw.rank end) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.dateOfRank <= '$to_date') as top50_sum_total,"
                            //rank of first page top 10
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 10 and kw.dateOfRank >= '$from_date' and kw.dateOfRank <= '$to_date') as current_top10_rank,"
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 10 and kw.dateOfRank >= '$back90daysDate' and kw.dateOfRank <= '$to_date') AS top10_rank_days90,"
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 10 and kw.dateOfRank >= '$back180daysDate' and kw.dateOfRank <= '$to_date') as top10_rank_days180, "
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 10 and kw.dateOfRank >= '$back1YrdaysDate' and kw.dateOfRank <= '$to_date') as top10_rank_yearback,"
                            //top 3
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 3 and kw.dateOfRank >= '$from_date' and kw.dateOfRank <= '$to_date') as current_top3_rank,"
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 3 and kw.dateOfRank >= '$back90daysDate' and kw.dateOfRank <= '$to_date') AS top3_rank_days90,"
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 3 and kw.dateOfRank >= '$back180daysDate' and kw.dateOfRank <= '$to_date') as top3_rank_days180, "
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank BETWEEN 1 AND 3 and kw.dateOfRank >= '$back1YrdaysDate' and kw.dateOfRank <= '$to_date') as top3_rank_yearback,"
                            //1st place
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank = 1 and kw.dateOfRank >= '$from_date' and kw.dateOfRank <= '$to_date') as current_top1_rank,"
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank = 1 and kw.dateOfRank >= '$back90daysDate' and kw.dateOfRank <= '$to_date') AS top1_rank_days90,"
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank = 1 and kw.dateOfRank >= '$back180daysDate' and kw.dateOfRank <= '$to_date') as top1_rank_days180, "
                            . "(SELECT count(kw.id) FROM tbl_keywords kw $sqlJoinQueryForTargetKeywords where kw.location_id = " . $location_id . " $targetCondition $campaign_condition and kw.rank = 1 and kw.dateOfRank >= '$back1YrdaysDate' and kw.dateOfRank <= '$to_date') as top1_rank_yearback"
                    )
                    ->fetchAll('assoc');

            // resources for calculation of rank vs target
            $all_landing_urls = $this->connection->execute("SELECT kg.landing_page FROM tbl_keygroup kg where kg.location_id = " . $location_id . $targetCondition . $campaign_condition_keygroup)->fetchAll('assoc');
            $all_campaign_wise = array();

            $campaid_condition = '';
            if (!empty($campaign_id)) {
                $all_campaign_wise = $this->connection->execute("SELECT kg.landing_page FROM tbl_keygroup kg where kg.location_id = " . $location_id . " $targetCondition AND kg.campaign_id = " . $campaign_id)->fetchAll('assoc');
                $campaid_condition = " AND kw.campaign_id = " . $campaign_id;
            }

            $ranked_urls_count = $this->connection->execute("SELECT kw.campaign_id,kw.group_id,kw.ranked_url FROM tbl_keywords kw where kw.location_id = " . $location_id . " $campaid_condition and kw.dateOfRank >= '$from_date' and kw.dateOfRank <= '$to_date' ")->fetchAll('assoc');
            $ranked_urls_total = $this->connection->execute("SELECT kw.campaign_id,kw.group_id,kw.ranked_url FROM tbl_keywords kw where kw.location_id = " . $location_id . " $campaid_condition and kw.dateOfRank <= '$to_date' ")->fetchAll('assoc');
            $ranked_urls_count_last90days = $this->connection->execute("SELECT kw.campaign_id,kw.group_id,kw.ranked_url FROM tbl_keywords kw where kw.location_id = " . $location_id . " $campaid_condition and kw.dateOfRank >= '$back90daysDate' and kw.dateOfRank <= '$to_date' ")->fetchAll('assoc');
            $ranked_urls_count_last180days = $this->connection->execute("SELECT kw.campaign_id,kw.group_id,kw.ranked_url FROM tbl_keywords kw where kw.location_id = " . $location_id . " $campaid_condition and kw.dateOfRank >= '$back180daysDate' and kw.dateOfRank <= '$to_date' ")->fetchAll('assoc');
            $ranked_urls_count_last1yr = $this->connection->execute("SELECT kw.campaign_id,kw.group_id,kw.ranked_url FROM tbl_keywords kw where kw.location_id = " . $location_id . " $campaid_condition and kw.dateOfRank >= '$back1YrdaysDate' and kw.dateOfRank <= '$to_date' ")->fetchAll('assoc');

            if (count($NumberofKeywords) > 0) {
                $NumberofKeywords = $NumberofKeywords[0];
            }
        } catch (\Exception $ex) {
            
        }
        return array(
            "ranked_data" => array(
                "count_urls" => $ranked_urls_count,
                "last_90_days" => $ranked_urls_count_last90days,
                "last_180_days" => $ranked_urls_count_last180days,
                "last_1_yr" => $ranked_urls_count_last1yr,
                "total_keywords_list" => $ranked_urls_total,
                "all_landing_urls" => $all_landing_urls,
                "campaign_landing_urls" => $all_campaign_wise
            ),
            "keyword_data" => $NumberofKeywords
        );
    }

}

?>
