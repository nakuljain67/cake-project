<?php

namespace App\Controller;
require_once(ROOT . DS . 'vendor' . DS . "dompdf" . DS . "autoload.inc.php");
use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;
use Dompdf\Dompdf;
use Dompdf\Options;
class SiteAuditController extends AppController {

    public function initialize() {
        parent::initialize();
    }
    /* default method called */

    public function index() {

        $this->autoRender = false;

        $this->json(1, array(
            "method" => "index",
            "messge" => "silence is golden"
        ));
    }

    public function siteAuditRun() {
        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            $data = json_decode(file_get_contents('php://input'));
            $token = $this->request->header('token');

            if ($this->is_token_valid($token)) {
                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];
                //$project_name = $tokenDetails['name'];
               // $website = $this->fully_trim($tokenDetails['website']);
                $project_name = "Nakul Jain";
                $website = "rudrachat.com";
                $audit = TableRegistry::get('tbl_site_audit');
                $data1 = $audit->find("all", [
                            'conditions' => ['location_id' => $location_id, 'audit_status' => 'In Progress'],
                        ])->count();
                if ($data1 > 0) {
                    $this->json(0, "Failure, Site Audit Already in Progress.");
                }
                $sem = $this->semrush_api_info();
                $main_api_url = $sem['main_api_url'];
                $key = $sem['key'];
                $curl_url = 'management/v1/projects?key=' . $key;
                $post_data['project_name'] = $project_name;
                $post_data['url'] = $website;
                $data_string = json_encode($post_data);

                $create_new_project = $this->pc_post($username = '', $password = '', $main_api_url, $curl_url, $data_string, array("contentType" => "Content-Type: application/json"));
                $create_new_project = json_decode($create_new_project);
                if (isset($create_new_project->code) && $create_new_project->code > 0) {
                    $this->json(0, $create_new_project->message);
                }
                $project_id = $create_new_project->project_id;
               // pr($project_id); die;
                $curl_url = 'management/v1/projects/' . $project_id . '/siteaudit/enable?key=' . $key;
                $enable_site_audit_tool_post_data['domain'] = $website;
                $enable_site_audit_tool_post_data['scheduleDay'] = 0;
                $enable_site_audit_tool_post_data['notify'] = false;
                $enable_site_audit_tool_post_data['pageLimit'] = '1500';
                $enable_site_audit_tool_post_data['crawlSubdomains'] = false;

                $data_string = json_encode($enable_site_audit_tool_post_data);

                $enable_site_audit_tool = $this->pc_post($username = '', $password = '', $main_api_url, $curl_url, $data_string, array("contentType" => "Content-Type: application/json"));
                $curl_url = 'reports/v1/projects/' . $project_id . '/siteaudit/launch?key=' . $key;
                $data_string = json_encode(array());
                $all_info = $this->pc_post($username = '', $password = '', $main_api_url, $curl_url, $data_string, array("contentType" => "Content-Type: application/json"));
                $all_info = json_decode($all_info);
                $snapshot_id = $all_info->snapshot_id;
                $cities = TableRegistry::get('tbl_site_audit');
                $query = $cities->query();
                $query->insert(['user_id', 'location_id', 'campaign_id', 'snapshot_id', 'audit_status', 'last_audit', 'created', 'created_by'])
                        ->values(
                                [
                                    'user_id' => $user_id,
                                    'location_id' => $location_id,
                                    'campaign_id' => $project_id,
                                    'snapshot_id' => $snapshot_id,
                                    'audit_status' => 'In Progress',
                                    'last_audit' => date('Y-m-d H:i:s'),
                                    'created' => date("Y-m-d H:i:s"),
                                    'created_by' => $user_id
                                ]
                        )
                        ->execute();
                $this->json(1, "Site audit successfully started in background.");
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function siteAuditRerun() {
        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            $data = json_decode(file_get_contents('php://input'));
            $token = $this->request->header('token');
            if ($this->is_token_valid($token)) {
                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];
                $project_name = $tokenDetails['name'];
                $website = $this->fully_trim($tokenDetails['website']);
                $sem = $this->semrush_api_info();
                $main_api_url = $sem['main_api_url'];
                $key = $sem['key'];
                $audit = TableRegistry::get('tbl_site_audit');
                $data1 = $audit->find("all", [
                            'conditions' => ['location_id' => $location_id, 'audit_status' => 'In Progress'],
                        ])->count();
                if ($data1 > 0) {
                    $this->json(0, "Failure, Site Audit Already in Progress.");
                }
                $data = $audit->find("all", [
                            'conditions' => ['location_id' => $location_id],
                            'field' => ['campaign_id'],
                            'order' => ['last_audit' => 'asc'],
                        ])->first();

                if (empty($data)) {
                    $this->json(0, "Invalid Request");
                }
                $project_id = $data->campaign_id;
                $curl_url = 'management/v1/projects/' . $project_id . '/siteaudit/enable?key=' . $key;
                $enable_site_audit_tool_post_data['domain'] = $website;
                $enable_site_audit_tool_post_data['scheduleDay'] = 0;
                $enable_site_audit_tool_post_data['notify'] = false;
                $enable_site_audit_tool_post_data['pageLimit'] = '1500';
                $enable_site_audit_tool_post_data['crawlSubdomains'] = false;

                $data_string = json_encode($enable_site_audit_tool_post_data);
                $enable_site_audit_tool = $this->pc_post($username = '', $password = '', $main_api_url, $curl_url, $data_string, array("contentType" => "Content-Type: application/json"));
                $curl_url = 'reports/v1/projects/' . $project_id . '/siteaudit/launch?key=' . $key;
                $data_string = json_encode(array());
                $all_info = $this->pc_post($username = '', $password = '', $main_api_url, $curl_url, $data_string, array("contentType" => "Content-Type: application/json"));
                $all_info = json_decode($all_info);
                $snapshot_id = $all_info->snapshot_id;
                $cities = TableRegistry::get('tbl_site_audit');
                $query = $cities->query();
                $query->insert(['user_id', 'location_id', 'campaign_id', 'snapshot_id', 'audit_status', 'last_audit', 'created', 'created_by'])
                        ->values(
                                [
                                    'user_id' => $user_id,
                                    'location_id' => $location_id,
                                    'campaign_id' => $project_id,
                                    'snapshot_id' => $snapshot_id,
                                    'audit_status' => 'In Progress',
                                    'last_audit' => date('Y-m-d H:i:s'),
                                    'created' => date("Y-m-d H:i:s"),
                                    'created_by' => $user_id
                                ]
                        )
                        ->execute();
                $this->json(1, "Site audit successfully started in background.");
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function cronSiteAudit() {
        $con = new ConnectionManager;
        $cn = $con->get('default');
        $sem = $this->semrush_api_info();
        $main_api_url = $sem['main_api_url'];
        $key = $sem['key'];
        $audit = TableRegistry::get('tbl_site_audit');
        $in_progress_audit = $audit->find("all", [
                    'conditions' => ['audit_status' => 'In Progress'],
                    'order' => ['last_audit' => 'asc'],
                ])->first();
        if (!empty($in_progress_audit)) {
            $campaign_id = $in_progress_audit->campaign_id;
            $location_id = $in_progress_audit->location_id;
            $user_id = $in_progress_audit->user_id;
            $rerun = $in_progress_audit->rerun;
            $check_all_info = $in_progress_audit->all_info;
            $check_audit_id = $in_progress_audit->id;
            if ($check_all_info == '') {
                $curl_url = 'reports/v1/projects/' . $campaign_id . '/siteaudit/info?key=' . $key; // need to work here
                $all_info = $this->pc_get($username = '', $password = '', $main_api_url, $curl_url);
                $all_info = json_decode($all_info);
                $all_info = serialize($all_info);
                $curl_url = 'reports/v1/projects/' . $campaign_id . '/siteaudit/meta/issues?key=' . $key;
                $error_name = $this->pc_get($username = '', $password = '', $main_api_url, $curl_url);
                $error_name_list = serialize(json_decode($error_name));
                $query = $audit->query();
                $query->update()
                        ->set(
                                [
                                    'all_info' => $all_info,
                                    'error_name_list' => $error_name_list
                                ]
                        )
                        ->where(['id' => $check_audit_id])
                        ->execute();
            }
            $all_site_audit = $audit->find("all")->where(['id' => $check_audit_id])->first();
            $site_audit_result = unserialize($all_site_audit->all_info);
            $errors_list = $site_audit_result->current_snapshot->errors;
            $warning_list = $site_audit_result->current_snapshot->warnings;
            $notices_list = $site_audit_result->current_snapshot->notices;
            $snapshot_id = $site_audit_result->current_snapshot->snapshot_id;
            $defects_list = $site_audit_result->defects;
            if (!empty($defects_list)) {
                $cn->query("CREATE TABLE IF NOT EXISTS `tbl_site_audit_error_page_list_$location_id` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `snapshot_id` varchar(50) NOT NULL,
  `issue_id` int(11) NOT NULL,
  `target_url` varchar(700) NOT NULL,
  `page_id` varchar(100) NOT NULL,
  `discovered` varchar(50) NOT NULL,
  `info` text NOT NULL,
  `source_url` varchar(700) NOT NULL,
  `data_info` text NOT NULL,
  `error_details` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;");
                $cn->query("truncate table `tbl_site_audit_error_page_list_$location_id`");

                foreach ($defects_list as $issue_id => $limit_data) {
                    $sql = "SELECT * FROM `tbl_site_audit_error_page_list_$location_id` WHERE `snapshot_id` = '$snapshot_id' && `issue_id` = $issue_id LIMIT 1";
                    $check_existing_issue_id = $cn->execute($sql)->fetchAll("assoc");

                    if (empty($check_existing_issue_id)) {

                        echo ' Issue ID: ' . $issue_id . ', Limit Data: ' . $limit_data . '<br/>';
                        $curl_url = 'reports/v1/projects/' . $campaign_id . '/siteaudit/snapshot/' . $snapshot_id . '/issue/' . $issue_id . '?page=1&filter=&sort=index_asc&limit=' . $limit_data . '&key=' . $key;
                        $all_page_error_list = $this->pc_get($username = '', $password = '', $main_api_url, $curl_url);
                        //pr($all_page_error_list);exit;
                        $all_page_error_list = json_decode($all_page_error_list);
                        //pr($all_page_error_list);   die;

                        if (!empty($all_page_error_list->data)) {
                            foreach ($all_page_error_list->data as $row_page) {
                                $insue_list_ins = array();
                                $insue_list_ins['snapshot_id'] = $snapshot_id;
                                $insue_list_ins['issue_id'] = $issue_id;
                                if (isset($row_page->target_url)) {
                                    $insue_list_ins['target_url'] = $row_page->target_url;
                                }

                                $insue_list_ins['page_id'] = $row_page->page_id;
                                $insue_list_ins['discovered'] = $row_page->discovered;
                                $insue_list_ins['data_info'] = serialize($row_page);
                                if (isset($row_page->info)) {
                                    $insue_list_ins['info'] = serialize($row_page->info);
                                }
                                if (isset($row_page->source_url)) {
                                    $insue_list_ins['source_url'] = $row_page->source_url;
                                }
                                $cn->insert('tbl_site_audit_error_page_list_' . $location_id, $insue_list_ins);
                            }
                            //pr($all_page_error_list);
                            // exit;
                        } else {
                            $insue_list_ins['user_id'] = $user_id;
                            $insue_list_ins['snapshot_id'] = $snapshot_id;
                            $insue_list_ins['issue_id'] = $issue_id;
                            $insue_list_ins['data_info'] = serialize($all_page_error_list);
                            $cn->insert('tbl_site_audit_error_page_list', $insue_list_ins);
                        }
                    }
                }
                $update_audit_status['audit_status'] = 'get_error';
                $cn->update('tbl_site_audit', $update_audit_status, array('id' => $check_audit_id));
                echo 'Get All Error Page List';
            }
        }
        ///////////////////////// error module//////////////////////////////////////////
        $get_error_audit = $cn->execute("SELECT * FROM `tbl_site_audit` WHERE `audit_status` = 'get_error' order by `last_audit` asc")->fetchAll("assoc");
        if (!empty($get_error_audit)) {
            //pr($get_error_audit); die;
            $user_id = $get_error_audit[0]['user_id'];
            $location_id = $get_error_audit[0]['location_id'];
            $snapshot_id = $get_error_audit[0]['snapshot_id'];
            $campaign_id = $get_error_audit[0]['campaign_id'];
            $check_audit_id = $get_error_audit[0]['id'];
            $sql1 = "SELECT * FROM `tbl_site_audit_error_page_list_$location_id` WHERE snapshot_id = '$snapshot_id' && `source_url` != '' && `error_details` = '' && `page_id` != '' group by `page_id` order by `id` asc limit 200";
            $page_url_list = $cn->execute($sql1)->fetchAll("assoc");

            if (!empty($page_url_list)) {
                foreach ($page_url_list as $index_count => $row_page_list) {
                    //  pr($row_page_list); die;
                    $page_id = $row_page_list['page_id'];
                    echo $info = $row_page_list['id'] . ' - Index: ' . $index_count . ', Campaign Id, ' . $campaign_id . ', User Id: ' . $user_id . ', Page Id: ' . $page_id . '<br/>';
                    $curl_url = 'reports/v1/projects/' . $campaign_id . '/siteaudit/page/' . $page_id . '?key=' . $key;
                    $audit_page_info = $this->pc_get($username = '', $password = '', $main_api_url, $curl_url);
                    $audit_page_info = json_decode($audit_page_info);
                    $insert_error_details['error_details'] = serialize($audit_page_info);
                    $cn->update('tbl_site_audit_error_page_list_' . $location_id, $insert_error_details, array('page_id' => $page_id, 'snapshot_id' => $snapshot_id));
                }
            }

            $sql = "SELECT * FROM `tbl_site_audit_error_page_list_$location_id` WHERE snapshot_id = '$snapshot_id' && `source_url` != '' && `error_details` = '' && `page_id` != '' group by `page_id` order by `id` asc limit 1";
            $page_url_list = $cn->execute($sql)->fetchAll("assoc");
            if (empty($page_url_list)) {
                $update_audit_status['audit_status'] = 'Completed';
                $cn->update('tbl_site_audit', $update_audit_status, array('id' => $check_audit_id));
                echo "completed site audit";
            }
        }
        echo "success";
        die;
    }

    public function siteAuditDetail() {
        $con = new ConnectionManager;
        $cn = $con->get('default');
        $this->autoRender = false;
        $token = $this->request->header('token');
        if ($this->is_token_valid()) {
            $tokenDetails = $this->fetchTokenDetails($token);
            $location_id = $tokenDetails['location_id'];            
            $user_id = $tokenDetails['user_id'];
            $audit = TableRegistry::get('tbl_site_audit');

            $site_audit_info = $audit->find("all", [
                        'conditions' => ["location_id" => $location_id],
                        'order' => ['id' => 'desc'],
                    ])->first();

            if (!empty($site_audit_info)) {

                $sts = $site_audit_info->audit_status;
                $result = [];
                $datashow = 1;
                $result['site_audit_progress'] = 0;
                if (strtolower($sts) != 'completed') {
                    $result['site_audit_progress'] = 1;
                    $datashow = 0;
                    $site_audit_info = $audit->find("all", [
                                'conditions' => ["location_id" => $location_id, 'LOWER(audit_status)' => 'completed'],
                                'order' => ['id' => 'desc'],
                            ])->first();
                    if (!empty($site_audit_info)) {
                        $datashow = 1;
                    }
                }

                if ($datashow == 1) {
                    $site_audit_result = unserialize($site_audit_info->all_info);
                    $error_name = unserialize($site_audit_info->error_name_list);
                    $snapshot_id = $site_audit_info->snapshot_id;
                    foreach ($error_name->issues as $row_err) {
                        $error_id = $row_err->id;
                        $error_name_arr[$error_id]['id'] = $error_id;
                        $error_name_arr[$error_id]['title'] = $row_err->title;
                        $error_name_arr[$error_id]['title_page'] = $row_err->title_page;
                        $error_name_arr[$error_id]['url_column'] = $row_err->url_column;
                        $error_name_arr[$error_id]['info_column'] = $row_err->info_column;
                    }
                    $errors_list = $site_audit_result->current_snapshot->errors;
                    $warning_list = $site_audit_result->current_snapshot->warnings;
                    $notices_list = $site_audit_result->current_snapshot->notices;
                    $snapshot_id = $site_audit_result->current_snapshot->snapshot_id;
                    $sql = "SELECT `issue_id`,count(*) as total_issue FROM `tbl_site_audit_error_page_list_$location_id` WHERE `snapshot_id` = '$snapshot_id' && error_details != '' group by `issue_id`";

                    try {
                        $issue_count_result = $cn->execute($sql)->fetchAll("assoc");
                    } catch (\PDOException $e) {
                        $issue_count_result = array();
                    }
                    $issue_count_arr = array();
                    foreach ($issue_count_result as $row_result) {
                        $issue_count_arr[$row_result['issue_id']] = $row_result['total_issue'];
                    }
                    arsort($issue_count_arr);
                    $total_error_and_warning = array_sum($issue_count_arr);
                    foreach ($errors_list as $row_result) {
                        $get_number = 0;
                        $level_name[$row_result->id] = 'Critical';
                        if (isset($issue_count_arr[$row_result->id])) {
                            $get_number = $issue_count_arr[$row_result->id];
                        }
                        $total_error_list[$row_result->id] = $get_number;
                    }
                    $total_error_count = array_sum($total_error_list);
                    foreach ($warning_list as $row_result) {
                        $get_number = 0;
                        $level_name[$row_result->id] = 'Urgent';
                        if (isset($issue_count_arr[$row_result->id])) {
                            $get_number = $issue_count_arr[$row_result->id];
                        }
                        $total_warning_list[$row_result->id] = $get_number;
                    }
                    //arsort($total_warning_list);
                    $total_warning_count = array_sum($total_warning_list);
                    foreach ($notices_list as $row_result) {
                        $get_number = 0;
                        $level_name[$row_result->id] = 'Important';
                        if (isset($issue_count_arr[$row_result->id])) {
                            $get_number = $issue_count_arr[$row_result->id];
                        }
                        $total_notices_list[$row_result->id] = $get_number;
                    }
                    //arsort($total_notices_list);
                    $total_notices_count = array_sum($total_notices_list);
                    $i = 0;
                    $mobile = array();  
                    foreach ($error_name->issues as $row_error) {
                        $row_error_count = 0;
                    if (isset($issue_count_arr[$row_error->id])) {
                        if ($issue_count_arr[$row_error->id] > 0) {
                            $row_error_count = $issue_count_arr[$row_error->id];
                            $mobile[$i]['status'] = 'Needs Attention';
                        } 
                    } else {
                            $mobile[$i]['status'] = 'Completed';
                        }
                        $mobile[$i]['level'] = $level_name[$row_error->id];
                        $mobile[$i]['issue'] = $row_error_count . " " . str_replace("##count##", "", $error_name_arr[$row_error->id]['title_page']);
                        $mobile[$i]['date_found'] = date("d M Y", strtotime($site_audit_info->last_audit));
                        $mobile[$i]['snapshot_id'] = $site_audit_info->snapshot_id;
                        $mobile[$i]['issue_id'] = $row_error->id;
                        $i++;
                    }


                    $result['project_name'] = $site_audit_result->name;
                    $result['website'] = $site_audit_result->url;
                    $result['last_update'] = date('D, M d, Y', $site_audit_result->last_audit / 1000);
                    $result['pages_crawled'] = $site_audit_result->pages_crawled;
                    $result['healthy'] = $site_audit_result->healthy;
                    $result['broken'] = $site_audit_result->broken;
                    $result['haveIssues'] = $site_audit_result->haveIssues;
                    $result['redirected'] = $site_audit_result->redirected;
                    $result['blocked'] = $site_audit_result->blocked;
                    $result['total_score'] = $site_audit_result->current_snapshot->quality->value . '%';
                    $result['critical'] = $total_error_count;
                    $result['urgent'] = $total_warning_count;
                    $result['Important'] = $total_notices_count;
                    $result['view_full_report'] = $mobile;
                }

                $this->json(1, "Site Audit Detail", $result);
            } else {
                $this->json(0, "No Data Found");
            }
        } else {
            $this->json(0, "invalid token", array("token" => "required"));
        }
    }

    public function errorList() {
        $con = new ConnectionManager;
        $cn = $con->get('default');
        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            $data = json_decode(file_get_contents('php://input'));
            $token = $this->request->header('token');
            $snapshot_id = isset($data->snapshot_id) && trim($data->snapshot_id) != '' ? $data->snapshot_id : '';
            $issue_id = isset($data->issue_id) && trim($data->issue_id) != '' ? $data->issue_id : '';
            $arvalidation = array();
            if ($snapshot_id == "") {
                $arvalidation['snapshot_id'] = "Please provide snapshot_id.";
            }
            if ($issue_id == "") {
                $arvalidation['issue_id'] = "Please provide issue_id.";
            }
            if (!empty($arvalidation)) {
                $this->json(0, "Empty fields found", $arvalidation);
            }
            if ($this->is_token_valid()) {
                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];
                $sql = "SELECT * FROM `tbl_site_audit_error_page_list_$location_id` WHERE `issue_id` = $issue_id && `snapshot_id` = '$snapshot_id'";
                $error_list = $cn->execute($sql)->fetchAll("assoc");
                $found_target_url = 0;
                if ($error_list[0]['target_url'] != '') {
                    $found_target_url = 1;
                }
                $instruction = TableRegistry::get('tbl_site_audit_instruction');
                $site_audit_instruction = $instruction->find("all", [
                            'conditions' => ['issue_id' => $issue_id],
                        ])->first();
                $value_to = $site_audit_instruction->instruction;
                $i = 0;
                $mobile = array();
                foreach ($error_list as $error_index => $single_error) {
                    // pr($single_error['target_url']);die;
                    $mobile[$i]['page_url'] = $single_error['source_url'];
                    $target_url = '';
                    if (isset($single_error['target_url'])) {
                        $target_url = $single_error['target_url'];
                    }
                    $single_error_info = unserialize($single_error['info']);
                    $data_info = unserialize($single_error['data_info']);
                    if ($found_target_url == 1) {
                        $mobile[$i]['link_url'] = $target_url;
                        $mobile[$i]['http_code'] = $single_error_info;
                    } else {
                        if (!empty($single_error_info)) {
                            $count_pages = count($single_error_info->urls);
                            $mobile[$i]['similar_pages'] = $count_pages . " pages";
                        } else {
                            $mobile[$i]['similar_pages'] = "0 pages";
                        }
                    }
                    $mobile[$i]['discovered'] = date("d M Y H:i a", $single_error['discovered'] / 1000);
                    $i++;
                }
                $result['instructions_to_fix_issue'] = $value_to;
                $result['error_info'] = $mobile;
                $this->json(1, "Site Audit Error List", $result);
            } else {
                $this->json(0, "Invalid token", array("token" => "required"));
            }
        } else {
            $this->json(0, "silence is golden");
        }
    }

    public function historySiteAudit() {
        $this->autoRender = false;
        $token = $this->request->header('token');
        if ($this->is_token_valid()) {
            $data = json_decode(file_get_contents('php://input'));
            $limit = isset($data->limit) ? $data->limit : 20;
            $off = isset($data->offset) ? $data->offset : 1;
            
            $search_txt = isset($data->search_txt) ? trim(htmlspecialchars($data->search_txt)) : "";
            //$to_date = isset($data->to_date) ? trim($data->to_date) : "";
                                    
            $tokenDetails = $this->fetchTokenDetails($token);
            $location_id = $tokenDetails['location_id'];
            $user_id = $tokenDetails['user_id'];
            $audit = TableRegistry::get('tbl_site_audit');
            if($search_txt == ""){
                $count = $audit->find("all", [
                            'conditions' => ['audit_status' => 'Completed', "location_id" => $location_id],
                            'order' => ['id' => 'desc'],
                        ])->count();

                $site_audit_history = $audit->find("all", [
                            'conditions' => ['audit_status' => 'Completed', "location_id" => $location_id],
                            'order' => ['id' => 'desc'],
                        ])->limit($limit)->page($off)->toArray();
            } else {
                // search text
                $count = $audit->find("all", [                           
                            'conditions' => ['OR' => [
                                        ['audit_status' => 'Completed', "location_id" => $location_id, 'tbl_site_audit.last_audit like' => '%' . $search_txt . '%'],
                                        ['audit_status' => 'Completed', "location_id" => $location_id, 'tbl_site_audit.all_info like' => '%' . $search_txt . '%']
                                    ]
                            ],
                            'order' => ['id' => 'desc'],
                        ])->count();
                              
                $site_audit_history = $audit->find("all", [
                            'conditions' => ['OR' => [
                                        ['audit_status' => 'Completed', "location_id" => $location_id, 'tbl_site_audit.last_audit like' => '%' . $search_txt . '%'],
                                        ['audit_status' => 'Completed', "location_id" => $location_id, 'tbl_site_audit.all_info like' => '%' . $search_txt . '%']
                                    ]
                            ],
                            'order' => ['id' => 'desc'],
                        ])->limit($limit)->page($off)->toArray();
                
            }
                        
            if (!empty($site_audit_history)) {
                $i = 0;
                $mobile = [];
                foreach ($site_audit_history as $single_history) {
                    $single_audit_result = unserialize($single_history->all_info);
                    $mobile[$i]['audit_date'] = date("Y-m-d", strtotime($single_history->last_audit));
                    $mobile[$i]['score'] = $single_audit_result->current_snapshot->quality->value;
                    $mobile[$i]['error'] = $single_audit_result->errors;
                    $mobile[$i]['warning'] = $single_audit_result->warnings;
                    $mobile[$i]['notices'] = $single_audit_result->notices;
                    $mobile[$i]['pages_crawled'] = $single_audit_result->pages_crawled;
                    $mobile[$i]['healthy'] = $single_audit_result->healthy;
                    $mobile[$i]['broken'] = $single_audit_result->broken;
                    $mobile[$i]['haveIssues'] = $single_audit_result->haveIssues;
                    $mobile[$i]['redirected'] = $single_audit_result->redirected;
                    $mobile[$i]['blocked'] = $single_audit_result->blocked;
                    $i++;
                }
                $new["data"] = $mobile;
                $new['total_pages'] = (int) ($count / $limit) + 1;
                $new['Page_No'] = $off;
                $this->json(1, "Site Audit History.", $new);
            } else {
                $this->json(0, "No Audit History Found.");
            }
        } else {
            $this->json(0, "Invalid token", array("token" => "required"));
        }
    }

    public function allUrlIssue() {
        $con = new ConnectionManager;
        $cn = $con->get('default');
        $this->autoRender = false;
        $token = $this->request->header('token');
        if ($this->is_token_valid()) {
            $data = json_decode(file_get_contents('php://input'));
            //$data = $this->request->getData();
            isset($data->limit) ? $limit = $data->limit : $limit = '20';
            isset($data->offset) ? $off = $data->offset : $off = '1';
            $search_txt = isset($data->search_txt) ? trim(htmlspecialchars($data->search_txt)) : "";      
            $tokenDetails = $this->fetchTokenDetails($token);
            $location_id = $tokenDetails['location_id'];
            $user_id = $tokenDetails['user_id'];
            $audit = TableRegistry::get('tbl_site_audit');
            $site_audit_urlinfo = $audit->find("all", [
                        'conditions' => ['audit_status' => 'Completed', "location_id" => $location_id],
                        'order' => ['id' => 'desc'],
                    ])->first();
            $site_audit_result = unserialize($site_audit_urlinfo->all_info);
            $website_url = $site_audit_result->url;
            $total_issues = 0;
            if (!empty($site_audit_urlinfo)) {
                $snapshot_id = $site_audit_urlinfo->snapshot_id;
                // $sql = "SELECT * FROM `tbl_site_audit_error_page_list_$location_id` WHERE snapshot_id = '$snapshot_id' && `error_details` != '' && `source_url` != '' group by `page_id`";                
                $site_audit = TableRegistry::get('tbl_site_audit_error_page_list_' . $location_id, array('table' => 'tbl_site_audit_error_page_list_' . $location_id));                
                try {
                    
                    if($search_txt == ""){
                        $total_issues = $site_audit->find('all')
                                        ->where(['snapshot_id' => $snapshot_id, 'error_details!=""', 'source_url!=""'])->group('page_id')->order(['id' => 'ASC'])->count();
                        $all_audit_page_list = $site_audit->find('all')
                                    ->where(['snapshot_id' => $snapshot_id, 'error_details!=""', 'source_url!=""'])->group('page_id')->order(['id' => 'ASC'])->limit($limit)->page($off)->toArray();
                    }
                    else{
                        $total_issues = $site_audit->find('all')
                                        ->where(['snapshot_id' => $snapshot_id, 'error_details!=""', 'source_url like' => '%'.$search_txt.'%'])->group('page_id')->order(['id' => 'ASC'])->count();
                        
                        $all_audit_page_list = $site_audit->find('all')
                                    ->where(['snapshot_id' => $snapshot_id, 'error_details!=""', 'source_url like' => '%'.$search_txt.'%'])->group('page_id')->order(['id' => 'ASC'])->limit($limit)->page($off)->toArray();
                    }
                    
                } 
                catch (\Exception $e) {
                    
                    $all_audit_page_list = array();
                }
                catch (\PDOException $e) {
                    
                    $all_audit_page_list = array();
                }
                
                $result = [];
                $i = 0;
                foreach ($all_audit_page_list as $single_page) {
                    $total_error = 0;
                    $audit_page_info = unserialize($single_page['error_details']);
                    foreach ($audit_page_info->errors as $s_data) {
                        $total_error += count($s_data->data);
                    }
                    foreach ($audit_page_info->warnings as $s_data) {
                        $total_error += count($s_data->data);
                    }
                    foreach ($audit_page_info->notices as $s_data) {
                        $total_error += count($s_data->data);
                    }
                    $url = $single_page['source_url'];
                    $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $url)), "/");

                    $sql = "SELECT keyword, rank, isprimary FROM tbl_keygroup LEFT JOIN tbl_keywords ON tbl_keygroup.id = tbl_keywords.group_id where TRIM(BOTH  '/' FROM REPLACE(REPLACE(REPLACE (landing_page, 'http://', ''),'https://',''),'www.','')) like '$trimurl'";
                    $data = $cn->execute($sql)->fetchAll('assoc');
                    $keyword = '';
                    $rank = '';
                    foreach ($data as $new) {
                        if ($new["isprimary"] == 1) {
                            $keyword = $new["keyword"];
                            $rank = $new['rank'];
                            if (empty($rank) || $rank == 0) {
                                $rank = '50+';
                            }
                        }
                    }
                    $from_date = date("Y-m-d", strtotime("-31 days"));
                    $to_date = date("Y-m-d", strtotime("-1 days"));
                    $query = "SELECT SUM(total) as total_conv FROM tbl_conversions_data WHERE  TRIM(BOTH  '/' FROM REPLACE(REPLACE(REPLACE (url, 'http://', ''),'https://',''),'www.','')) like '$trimurl'  AND ('date' >= '$from_date' AND 'date' <= '$to_date')";
                    $conversion = $cn->execute($query)->fetchAll('assoc');
                    $data = $this->reportURL($url, $location_id);
                    $result[$i]["page_url"] = $single_page['source_url'];
                    $result[$i]["isssues"] = $total_error;
                    $result[$i]["keyword"] = $keyword;
                    $result[$i]["rank"] = $rank;
                    $result[$i]["organic_visit"] = $data[0]['total_organic'];
                    $result[$i]["time_on_site"] = $data[0]['time_on_site'];
                    $result[$i]["total_BounceRate"] = $data[0]['total_BounceRate'];
                    $result[$i]["total_conversion"] = $conversion[0]['total_conv'];
                    $i++;
                }
                $new["data"] = $result;
                $new['total_pages'] = (int) ($total_issues / $limit) + 1;
                $new['Page_No'] = $off;
                $this->json(1, "All URL Issue", $new);
            }
        } else {
            $this->json(0, "Invalid token", array("token" => "required"));
        }
    }

    public function targetUrlIssue() {
        $con = new ConnectionManager;
        $cn = $con->get('default');
        $this->autoRender = false;
        $token = $this->request->header('token');
        if ($this->is_token_valid()) {
            $tokenDetails = $this->fetchTokenDetails($token);
            $location_id = $tokenDetails['location_id'];
            $user_id = $tokenDetails['user_id'];
            $audit = TableRegistry::get('tbl_site_audit');
            $site_audit_urlinfo = $audit->find("all", [
                        'conditions' => ['audit_status' => 'Completed', "location_id" => $location_id],
                        'order' => ['id' => 'desc'],
                    ])->first();
            if (!empty($site_audit_urlinfo)) {
                $site_audit_result = unserialize($site_audit_urlinfo->all_info);
                $website_url = $site_audit_result->url;
                $snapshot_id = $site_audit_urlinfo->snapshot_id;
                $site_audit = TableRegistry::get('tbl_site_audit_error_page_list_' . $location_id, array('table' => 'tbl_site_audit_error_page_list_' . $location_id));
                try {
                    $all_audit_page_list = $site_audit->find('all')
                            ->where(['snapshot_id' => $snapshot_id, 'error_details!=""', 'source_url!=""'])
                            ->group('page_id')
                            ->order(['id' => 'ASC'])
                            ->toArray();
                } catch (\PDOException $e) {
                    $all_audit_page_list = array();
                }
                //pr($all_audit_page_list); die;
                if (!empty($all_audit_page_list)) {
                    $keygroup = TableRegistry::get('tbl_keygroup');
                    $landing_page = $keygroup->find("all", [
                                'conditions' => ['location_id' => $location_id],
                                'fields' => 'landing_page'])->toArray();
                    $target_url = [];
                    foreach ($landing_page as $key => $new) {
                        if (!empty($new->landing_page)) {
                            $target_url[] = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $new->landing_page)), "/");
                        }
                    }
                    //pr($target_url); die;
                    $result = [];
                    $i = 0;
                    foreach ($all_audit_page_list as $single_page) {
                        $url = $single_page['source_url'];
                        $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $url)), "/");
                        if (!in_array($trimurl, $target_url)) {
                            continue;
                        }
                        $total_error = 0;
                        $audit_page_info = unserialize($single_page['error_details']);
                        foreach ($audit_page_info->errors as $s_data) {
                            $total_error += count($s_data->data);
                        }
                        foreach ($audit_page_info->warnings as $s_data) {
                            $total_error += count($s_data->data);
                        }
                        foreach ($audit_page_info->notices as $s_data) {
                            $total_error += count($s_data->data);
                        }
                        $sql = "SELECT keyword, rank, isprimary FROM tbl_keygroup LEFT JOIN tbl_keywords ON tbl_keygroup.id = tbl_keywords.group_id where TRIM(BOTH  '/' FROM REPLACE(REPLACE(REPLACE (landing_page, 'http://', ''),'https://',''),'www.','')) like '$trimurl'";
                        $data = $cn->execute($sql)->fetchAll('assoc');
                        $keyword = '';
                        $rank = '';
                        foreach ($data as $new) {
                            if ($new["isprimary"] == 1) {
                                $keyword = $new["keyword"];
                                $rank = $new['rank'];
                                if (empty($rank) || $rank == 0) {
                                    $rank = '50+';
                                }
                            }
                        }
                        $from_date = date("Y-m-d", strtotime("-31 days"));
                        $to_date = date("Y-m-d", strtotime("-1 days"));
                        $query = "SELECT SUM(total) as total_conv FROM tbl_conversions_data WHERE  TRIM(BOTH  '/' FROM REPLACE(REPLACE(REPLACE (url, 'http://', ''),'https://',''),'www.','')) like '$trimurl'  AND ('date' >= '$from_date' AND 'date' <= '$to_date')";
                        $conversion = $cn->execute($query)->fetchAll('assoc');
                        $data = $this->reportURL($url, $location_id);
                        $result[$i]["page_url"] = $single_page['source_url'];
                        $result[$i]["isssues"] = $total_error;
                        $result[$i]["keyword"] = $keyword;
                        $result[$i]["rank"] = $rank;
                        $result[$i]["organic_visit"] = $data[0]['total_organic'];
                        $result[$i]["time_on_site"] = $data[0]['time_on_site'];
                        $result[$i]["total_BounceRate"] = $data[0]['total_BounceRate'];
                        $result[$i]["total_conversion"] = $conversion[0]['total_conv'];
                        $i++;
                    }
                    $this->json(1, "Target URL Issue", $result);
                } else {
                    $this->json(0, "No Target URl Found.");
                }
            } else {
                $this->json(0, "No Data Found.");
            }
        } else {
            $this->json(0, "Invalid token", array("token" => "required"));
        }
    }

     public function downloadAuditReport() {
         $con = new ConnectionManager;
        $cn = $con->get('default');
        $this->autoRender = false;
        $token = $this->request->header('token');
        if ($this->is_token_valid()) {    
            $tokenDetails = $this->fetchTokenDetails($token);  
            $location_id = $tokenDetails['location_id'];
            $user_id = $tokenDetails['user_id'];
            $audit = TableRegistry::get('tbl_site_audit');    
            $site_audit_info = $audit->find("all", [
                        'conditions' => ["location_id" => $location_id],
                        'order' => ['id' => 'desc'],
                    ])->first();

            if (count($site_audit_info) > 0) {               
                $sts = $site_audit_info->audit_status;
                if(strtolower($sts) != 'completed'){
                    $this->json(0, "Wait Site Audit is in Progress");
                }
                $site_audit_result = unserialize($site_audit_info->all_info);
                $error_name = unserialize($site_audit_info->error_name_list);
                $snapshot_id = $site_audit_info->snapshot_id;
                foreach ($error_name->issues as $row_err) {
                    $error_id = $row_err->id;
                    $error_name_arr[$error_id]['id'] = $error_id;
                    $error_name_arr[$error_id]['title'] = $row_err->title;
                    $error_name_arr[$error_id]['title_page'] = $row_err->title_page;
                    $error_name_arr[$error_id]['url_column'] = $row_err->url_column;
                    $error_name_arr[$error_id]['info_column'] = $row_err->info_column;
                }
                $errors_list = $site_audit_result->current_snapshot->errors;
                $warning_list = $site_audit_result->current_snapshot->warnings;
                $notices_list = $site_audit_result->current_snapshot->notices;
                $snapshot_id = $site_audit_result->current_snapshot->snapshot_id;
                $sql = "SELECT `issue_id`,count(*) as total_issue FROM `tbl_site_audit_error_page_list_$location_id` WHERE `snapshot_id` = '$snapshot_id' && error_details != '' group by `issue_id`";
                try{
                    $issue_count_result = $cn->execute($sql)->fetchAll("assoc");
                }
                catch (\PDOException $e){                   
                    $issue_count_result = array();
                }
                $issue_count_arr = array();
                foreach ($issue_count_result as $row_result) {
                    $issue_count_arr[$row_result['issue_id']] = $row_result['total_issue'];
                }
                arsort($issue_count_arr);
                $total_error_and_warning = array_sum($issue_count_arr);
                foreach ($errors_list as $row_result) {
                    $get_number = 0;
                    $level_name[$row_result->id] = 'Critical';
                    if (isset($issue_count_arr[$row_result->id])) {
                        $get_number = $issue_count_arr[$row_result->id];
                    }
                    $total_error_list[$row_result->id] = $get_number;
                }
                $total_error_count = array_sum($total_error_list);
                foreach ($warning_list as $row_result) {
                    $get_number = 0;
                    $level_name[$row_result->id] = 'Urgent';
                    if (isset($issue_count_arr[$row_result->id])) {
                        $get_number = $issue_count_arr[$row_result->id];
                    }
                    $total_warning_list[$row_result->id] = $get_number;
                }
                $total_warning_count = array_sum($total_warning_list);
                foreach ($notices_list as $row_result) {
                    $get_number = 0;
                    $level_name[$row_result->id] = 'Important';
                    if (isset($issue_count_arr[$row_result->id])) {
                        $get_number = $issue_count_arr[$row_result->id];
                    }
                    $total_notices_list[$row_result->id] = $get_number;
                }
                $total_notices_count = array_sum($total_notices_list);
/////////////////////////////PDF WOrk Start Here//////////////////
                $str ='';
                $logo = WWW_ROOT .'img/logo-2.png';
  $str .= '<table border="0" width="100%"><tr><td align="left" ><img style="max-width:300px; max-height:55px;"  src="'.$logo.'"/></td><td style="font-size:25px;" align="right" width="20%">' ."www.".$site_audit_result->url . '</td></tr></table><br/>';
    $str .= '<h3 style="text-align:center;">Site Audit: ' .$site_audit_result->name . '</h3><br/>';
    $str .='<style>
    .ex_pdf_table_c{width:30%;border: 1px solid #d9d9d9;padding: 10px;float:left;position: relative;}  
    .ex_pdf_name_c{width:31%;float:left;font-size: 18px;text-align: center;} 
    .color_left{color:#2b94e1;}
    .color_right{color:green;}
    .clear_c{clear:both;height:10px;}
    .border_sec{border-bottom:.5px solid #d9d9d9;line-height:30px;}
    .p_box_class{border:4px solid white;padding:15px;color:white;width:22%!important;vertical-align: top;}
    .padding_full{padding:12px 15px;float:left;text-align:center;}    
</style>';
    $str .= '<table border="0" width="100%">
    <tr>';
    for ($p_box = 1; $p_box <= 4; $p_box++) {
        if ($p_box == 1) {
            $p_box_name = 'Total Score';
            $p_box_val = $site_audit_result->current_snapshot->quality->value . '%';
            $p_box_color = '#5D8FC2';
        }
        if ($p_box == 2) {
            $p_box_name = 'Critical';
            $p_box_val = $total_error_count;
            $p_box_color = '#5DC4BF';
        }
        if ($p_box == 3) {
            $p_box_name = 'Urgent';
            $p_box_val = $total_warning_count;
            $p_box_color = '#64BD63';
        }
        if ($p_box == 4) {
            $p_box_name = 'Important';
            $p_box_val = $total_notices_count;
            $p_box_color = '#555555';
        }
        $str .= '<td align="center" class="p_box_class" style="background-color:' . $p_box_color . '">
            <span style="font-size: 20px;font-weight:bold;">' . $p_box_name . '</span><br/><br/>
            <span style="font-size: 47px;text-align:center;">' . $p_box_val . '</span><br/><br/><br/><br/>
        </td>';
    }
    $str .= '</tr>
</table>';
    $str .= '<table class="c2" style="margin-top:10px; font-size:14px; border-radius: 3px 3px 3px 3px; width:100%; border: 1px solid #cecece;">
        <tr style="background-color:#EBEBEB;">
            <th class="padding_full" style="text-align:center;">Level</th>
            <th class="padding_full" style="text-align:left;text-indent:10px;width:50%;">Issue</th>
            <th class="padding_full" style="text-align:center;">Date Found</th>
            <th class="padding_full" style="text-align:center;">Status</th>
        </tr>';
    $color_index = 0;
    foreach ($error_name->issues as $row_error) {

      $color = $color_index % 2 == 0 ? '#fff' : '#eee';
                $color_index++;  
      $row_error_count = 0;
       if (isset($issue_count_arr[$row_error->id])) {
                        if ($issue_count_arr[$row_error->id] > 0) {
                            $row_error_count = $issue_count_arr[$row_error->id];
                            $issue_status = 'Needs Attention';
                        }
                    }
             else {
                      $issue_status = 'Completed';
                 } 
      $issue_name = $row_error_count.' '. str_replace("##count##", "", $error_name_arr[$row_error->id]['title_page']);  
      $str .=  '<tr style="background-color:' . $color . ';">
                    <td class="padding_full" style="text-align:center;">'.$level_name[$row_error->id].'</td>
                    <td class="padding_full" style="text-align:left;text-indent:10px;width:50%;">'.$issue_name.'</td>
                    <td class="padding_full" style="text-align:center;">'.date('D, M d, Y', $site_audit_result->last_audit / 1000).'</td>
                    <td class="padding_full" style="text-align:center;">'.$issue_status.'</td>
              </tr>';
    } 
    $str .='</table>'; 
    $options = new Options();
    $options->setIsRemoteEnabled(true);
    $dompdf = new DOMPDF($options);
    $dompdf->load_html($str);
    $dompdf->set_paper('a4', 'landscape');
    $dompdf->render();
    $pdf = $dompdf->output();
   $new = $dompdf->stream(str_replace(" ", "_", $site_audit_result->name . '_Site_Audit_Report.pdf'), array("Attachment" => true));
////////////////////////////PDF Work End Here ///////////////////   
     } else {
             $this->json(0, "No Data Found");
            }
        } else {
            $this->json(0, "invalid token", array("token" => "required"));
        }
  }

    public function reportURL($page_url, $location_id) {

        $this->autoRender = false;
        $con = new ConnectionManager;
        $cn = $con->get('default');
        $from_date = date("Y-m-d", strtotime("-31 days")); // 31 means 30 days from to_date
        $to_date = date("Y-m-d", strtotime("-1 days"));

        $trimurl = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $page_url)), "/");

        if ($this->is_dbtable_exists("api_short_analytics_$location_id")) {
            $results = $cn
                    ->execute("SELECT sum(timeOnSite) as time_on_site, sum(total) as total_visit,sum(bounceRate) as total_BounceRate, sum(organic) as total_organic,sum(cpc) as total_cpc,sum(referral) as total_referral,sum(social) as total_social, sum(none) as total_direct FROM api_short_analytics_$location_id WHERE location_id = " . $location_id . " AND TRIM(BOTH  '/' FROM REPLACE(REPLACE(REPLACE (pageURL, 'http://', ''),'https://',''),'www.','')) like '$trimurl' AND `DateOfVisit` >= '$from_date' and `DateOfVisit` <= '$to_date' order by DateOfVisit desc")
                    ->fetchAll('assoc');
        }
        return $results;
    }

    public function is_dbtable_exists($tableName) {
        $con = new ConnectionManager;
        $cn = $con->get('default');
        $results = $cn
                ->execute("SHOW TABLES LIKE '" . $tableName . "'")
                ->fetchAll('assoc');

        if (count($results) > 0) {

            return true;
        } else {
            return false;
        }
    }

}

?>
