<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;

class CompetitorsController extends AppController {

    private $connection;

    public function initialize() {
        parent::initialize();
        header('Access-Control-Allow-Origin: *');
        $this->connection = ConnectionManager::get('default');
    }

    /* default method called */

    public function index() {

        $this->autoRender = false;
        $this->json(0, "silence is golden");
    }

    public function addCompetitors() {

        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $data = json_decode(file_get_contents('php://input'));
            $token = $this->request->header("token");
            $websites = isset($data->websites) ? trim($data->websites) : ''; // json object            
            if ($websites == '') {
                $this->json(0, "Please provide competitors");
            }
            $websites = explode(',', $websites);
            if (count($websites) > 4) {
                $this->json(0, "You can add maximum 4 competitors");
            }
            $location_id = isset($data->location_id) ? trim($data->location_id) : 0;

            if (!empty($token)) {

                if ($this->is_token_valid()) {
                    try {
                        $tokenDetails = $this->fetchTokenDetails($token);
                        $user_id = $tokenDetails['user_id'];
                        $agency_id = $tokenDetails['agency_id'];
                        $this->loadmodel("Location");
                        $hasloc = $this->Location->findById($location_id);
                        if ($hasloc->count() == 0) {
                            $this->json(1, "Invalid Location Id");
                        }
                        $this->loadmodel("Competitor");

                        // delete if comp. added
                        if ($this->Competitor->findByLocation_id($location_id)->count() > 0) {
                            $this->Competitor->deleteAll(array('Competitor.location_id' => $location_id), false);
                        }

                        $x = 0;
                        foreach ($websites as $website) {
                            if ($website != '') {
                                $campaign_create_status = $this->Competitor->createLocationCampaign(array("location_id" => $location_id, "website" => $website, "user_id" => $user_id));
                                if ($campaign_create_status) {
                                    $x++;
                                }
                            }
                        }

                        if ($x > 0) {
                            $this->json(1, "Competitors successfully added");
                        } else {
                            $this->Competitor->deleteAll(array('Competitor.location_id' => $location_id), false);
                            $this->json(0, "Failed to add competitors");
                        }
                    } catch (Exception $ex) {
                        
                    }
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function addCompetitor() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $data = json_decode(file_get_contents('php://input'));
            $token = $this->request->header("token");
            $website = isset($data->website) ? trim($data->website) : '';
            if ($website == '') {
                $this->json(0, "Please provide competitor url");
            }
            if (!empty($token)) {

                if ($this->is_token_valid()) {
                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];
                    try {
                        $this->loadmodel("Competitor");
                        $totalcompt = $this->Competitor->findByLocation_id($location_id);
                        if ($totalcompt->count() >= 4) {
                            $this->json(0, "You have already 4 competitors");
                        }
                        $campaign_create_status = $this->Competitor->createLocationCampaign(array("location_id" => $location_id, "website" => $website, "user_id" => $user_id));

                        if ($campaign_create_status) {

                            $this->json(1, "competitor created", $campaign_create_status);
                        } else {

                            $this->json(0, "failed to create competitor.");
                        }
                    } catch (Exception $ex) {
                        
                    }
                } else {
                    $this->json(0, "invalid token", array("token" => "required"));
                }
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function updateCompetitors() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $data = json_decode(file_get_contents('php://input'));
                $token = $this->request->header("token");
                $competitor_id = isset($data->competitor_id) ? intval($data->competitor_id) : 0;
                $website = isset($data->website) ? trim($data->website) : '';
                if ($website == '') {
                    $this->json(0, "Please provide competitor urls");
                }
                if ($this->is_token_valid()) {
                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];
                    $this->loadmodel("Competitor");
                    if ($this->Competitor->is_valid_campaign($competitor_id)) {

                        if ($this->Competitor->editLocationCampaign(array("id" => $competitor_id, "location_id" => $location_id, "website" => $website, "user_id" => $user_id))) {
                            $this->json(1, "competitor updated");
                        } else {

                            $this->json(0, "failed to update competitor");
                        }
                    } else {

                        $this->json(0, "invalid competitor id", array("campaign id" => "required"));
                    }
                } else {
                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function deleteCompetitor() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            try {
                $data = json_decode(file_get_contents('php://input'));
                $token = $this->request->header("token");
                $competitor_id = isset($data->competitor_id) ? intval($data->competitor_id) : 0;

                if ($this->is_token_valid()) {
                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];
                    $this->loadmodel("Competitor");
                    if ($this->Competitor->is_valid_campaign($competitor_id)) {

                        if ($this->Competitor->deleteLocationCampaign(array("location_id" => $location_id, "id" => $competitor_id))) {

                            $this->json(1, "competitor deleted");
                        } else {

                            $this->json(0, "Failed to delete competitor");
                        }
                    } else {

                        $this->json(0, "invalid competitor id", array("valid competitor id" => "required"));
                    }
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function listCompetitors() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');

            if ($this->is_token_valid()) {

                $tokenDetails = $this->fetchTokenDetails($token);
                $location_id = $tokenDetails['location_id'];
                $user_id = $tokenDetails['user_id'];

                if (empty($location_id)) {

                    $this->json(0, "Location_id is empty", array("valid token" => "required"));
                }
                $this->loadmodel("Competitor");
                $this->json(1, "Competitor List ", $this->Competitor->listLocationCampaign(array("location_id" => $location_id, "user_id" => $user_id)));
            } else {

                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    //added by sanjay@rudrainnovatives.com by 23 June 2016

    public function addKeywordCompetitor() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $data = json_decode(file_get_contents('php://input'));
            $token = $this->request->header("token");
            $website = isset($data->url) ? trim($data->url) : '';
            $limit = isset($data->limit) ? intval($data->limit) : $this->limit;
            $country_id = isset($data->country_id) ? strtolower(trim($data->country_id)) : '231';
            if ($website == '') {
                $this->json(0, "Please provide competitor url");
            }
            if (!empty($token)) {

                if ($this->is_token_valid()) {
                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];

                    if (!$this->countLocationCompetitors($location_id)) {
                        $this->json(0, "already all competitors added");
                    }

                    $trimWebsite = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $website)), "/");
                    $clweb = $this->getLocationUrlById($location_id);
                    $client_url = isset($clweb) ? $clweb : '';
                    $client_url = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $client_url)), "/");

                    $flag = 0;
                    if (!strcmp($trimWebsite, $client_url)) {
                        $flag = 1;
                    }

                    try {
                        $this->loadmodel("Competitor");
                        $comp_id = 0;

                        if (!$flag) {

                            $campaign_create_status = $this->Competitor->createLocationCampaign(array("location_id" => $location_id, "website" => $website, "user_id" => $user_id));

                            $findId = $this->Competitor->find('all', [
                                        'fields' => 'id',
                                        'conditions' => ["Competitor.location_id" => $location_id]
                                    ])->last();

                            $comp_id = $findId->id;
                        }

                        $resultdata = $this->pullKeywordsFromSemrush($website, $country_id, $limit);

                        $competitor_key = explode(PHP_EOL, $resultdata);
                        $keword_res = TableRegistry::get('tbl_keyword_research');

                        foreach ($competitor_key as $com_index => $row_data) {

                            if ($com_index > 0) {

                                $line = explode(';', $row_data);
                                $insert_opp['location_id'] = $location_id;
                                $insert_opp['competitor_id'] = $comp_id;
                                $insert_opp['url'] = $line[6];
                                $insert_opp['keyword'] = $line[0];
                                $insert_opp['position'] = $line[1];
                                $insert_opp['prev_position'] = $line[2];
                                $insert_opp['difference'] = $line[3];
                                $insert_opp['search_volume'] = $line[4];
                                $insert_opp['cpc'] = $line[5];
                                $insert_opp['competition'] = $line[9];
                                $insert_opp['traffic_percent'] = $line[7];
                                $insert_opp['traffic_cost'] = $line[8];
                                $insert_opp['results'] = $line[10];
                                $insert_opp['trends'] = $line[11];
                                //$insert_opp['user_id'] = $user_id;
                                $insert_opp['created'] = date("Y-m-d");
                                $insert_opp['created_by'] = $user_id;
                                // saving data
                                $entity = $keword_res->newEntity($insert_opp);
                                $keword_res->save($entity);
                                // getting last inserted id
                                // $group_id = $entity->id;
                            }
                        }

                        $this->json(1, "Keywords sucessully added");
                    } catch (Exception $ex) {
                        
                    }
                } else {
                    $this->json(0, "invalid token", array("token" => "required"));
                }
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function pullKeywordsFromSemrush($url, $country_id, $limit = 0) {
        try {
            $this->autoRender = false;

            $countriestbl = TableRegistry::get('tbl_countries');
            $country = $countriestbl->findById($country_id)->first();
            if (empty($country)) {
                return false;
            }
            $country = $country->code;

            if (trim($url) != '') {

                $sem = $this->semrush_api_info();
                $semrush_main_api_url = $sem['main_api_url'];
                $key = $sem['key'];
                $display_limit = ($limit == 0) ? $this->semrush_limit() : $limit;
                $curl_url = "?type=domain_organic&key=" . $key . "&export_columns=Ph,Po,Pp,Pd,Nq,Cp,Ur,Tr,Tc,Co,Nr,Td&domain=" . $url . "&database=" . strtolower($country) . "&display_sort=tr_desc&display_limit=" . $display_limit;
                $resultdata = $this->pc_get("", "", $semrush_main_api_url, $curl_url);

                if (strpos($resultdata, 'ERROR') !== false) {
                    return false;
                } else if (strpos($resultdata, 'ERROR 50') !== false) {
                    return false;
                }

                return $resultdata;
            } else {
                return false;
            }
        } catch (Exception $ex) {
            
        }
    }

    public function listCompetitorKeywords() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');

            try {

                if ($this->is_token_valid()) {

                    $data = (array) json_decode(file_get_contents('php://input'));
                    $offset = isset($data['offset']) ? $data['offset'] : $this->start; // this will be the page range starting from 0 onwards
                    $limit = isset($data['limit']) ? $data['limit'] : $this->limit;
                    $comp_id = isset($data['comp_id']) ? $data['comp_id'] : '';

                    if ($offset <= 0) {
                        $offset = 0;
                        $page = $offset + 1;
                    } else {
                        $page = $offset;
                    }

                    $this->loadmodel("Competitor");
                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $data['location_id'] = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];
                    if (empty($location_id)) {
                        $this->json(0, "Location_id is empty", array("valid token" => "required"));
                    }

                    $keywords_array = $this->Competitor->getCompetitorKeywords($data, $offset, $limit, $comp_id, new AppController());
                    // finding all keywords of current location
                    if (empty($comp_id)) {
                        // client url
                        $total_keywords = $this->Competitor->find('all', [
                                    'conditions' => ['location_id' => $location_id, "status" => 1]
                                ])->count();
                    } else {
                        // competitor wise
                        $total_keywords = $this->Competitor->find('all', [
                                    'conditions' => ['location_id' => $location_id, "competitor_id" => $comp_id, "status" => 1]
                                ])->count();
                    }


                    $remining_records = ($total_keywords % $this->limit);
                    $total_pages = floor(($total_keywords / $this->limit));
                    if ($remining_records > 0) {
                        $total_pages = $total_pages + 1;
                    }

                    if (count($keywords_array) > 0) {
                        $final_array['total_records'] = intval($total_keywords);
                        $final_array['total_pages'] = intval($total_pages);
                        $final_array['current_page'] = intval($page);
                        $final_array['data'] = $keywords_array;
                        $this->json(1, "Locations Found", $final_array);
                    } else {

                        $this->json(1, "No Data Found", $keywords_array);
                    }
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (\Exception $ex) {
                // error_log
            }
        }
    }

    public function countLocationCompetitors($location_id) {
        $this->autoRender = false;
        if ($location_id > 0) {
            try {
                $sqlQueryToChkCompetitors = "SELECT * FROM tbl_compititors where location_id = " . $location_id;
                $results = $this->connection->execute($sqlQueryToChkCompetitors)->fetchAll("assoc");
                if (count($results) > 4) {
                    return false;
                }
            } catch (\Exception $ex) {
                // error_log
            }
            return true;
        } else {
            return false;
        }
    }

    public function showAllCompetitors() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');

            try {

                if ($this->is_token_valid()) {

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];
                    $this->loadmodel("Competitor");

                    $all_data = $this->Competitor->getCompetitorsDetail($location_id, new AppController());

                    $this->json(1, "data found", $all_data);
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (\Exception $ex) {
                // error_log
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    // added by sanjay@rudrainnovatives on 26 June 2017
    public function editKeywordCompetitor() {
        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');

            try {

                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));
                    $competitor_url = isset($data['url']) ? $data['url'] : '';
                    $limit = isset($data['limit']) ? $data['limit'] : $this->limit;
                    $competitor_id = isset($data['comp_id']) ? $data['comp_id'] : 0;
                    $country_id = isset($data['country_id']) ? $data['country_id'] : '231';

                    if (!$this->is_valid_url($competitor_url)) {
                        $this->json(0, "Invalid URL format", array("url" => "required"));
                    }

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];

                    $this->loadmodel("Competitor");

                    $trimWebsite = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $competitor_url)), "/");
                    $clweb = $this->getLocationUrlById($location_id);
                    $client_url = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $clweb)), "/");

                    if ($competitor_id == 0) {
                        // no check of validation due to parent url
                        if (!strcmp($client_url, $trimWebsite)) {
                            $this->json(0, "Invalid Client url found");
                        }
                    } else {
                        $is_comp_id_valid = $this->Competitor->find("all", array('conditions' => array('Competitor.id' => $competitor_id, "location_id" => $location_id)))->toArray();

                        if (count($is_comp_id_valid) == 0) {
                            $this->json(0, "Competitor id is not valid for this location");
                        }
                    }

                    $flag = 0;
                    if (!strcmp($trimWebsite, $client_url)) {
                        $flag = 1;
                    }

                    $comp_id = 0;

                    $keword_res = TableRegistry::get('tbl_keyword_research');
                    $queryToUpdate = $keword_res->query();

                    if ($flag && $competitor_id == 0) {

                        $resultdata = $this->pullKeywordsFromSemrush($competitor_url, $country_id, $limit);
                        $competitor_key = explode(PHP_EOL, $resultdata);

                        // action for client_url
                        foreach ($competitor_key as $com_index => $row_data) {

                            if ($com_index > 0) {

                                $line = explode(';', $row_data);

                                $insert_opp['url'] = $line[6];
                                $insert_opp['keyword'] = $keyword = $line[0];
                                $insert_opp['position'] = $line[1];
                                $insert_opp['prev_position'] = $line[2];
                                $insert_opp['difference'] = $line[3];
                                $insert_opp['search_volume'] = $line[4];
                                $insert_opp['cpc'] = $line[5];
                                $insert_opp['competition'] = $line[9];
                                $insert_opp['traffic_percent'] = $line[7];
                                $insert_opp['traffic_cost'] = $line[8];
                                $insert_opp['results'] = $line[10];
                                $insert_opp['trends'] = $line[11];
                                //$insert_opp['user_id'] = $user_id;
                                // check keyword existance in table
                                $check_existing_key = $this->connection
                                        ->execute("SELECT * FROM tbl_keyword_research WHERE location_id = " . $location_id . " AND keyword = '" . $keyword . "'")
                                        ->fetchAll('assoc');
                                if (count($check_existing_key) > 0) {
                                    // already there need to update
                                    $insert_opp['modified'] = date("Y-m-d");
                                    $insert_opp['modified_by'] = $user_id;
                                    $keywordUpdateQuery = $queryToUpdate->update()
                                            ->set($insert_opp)
                                            ->where(['location_id' => $location_id, "keyword" => $keyword])
                                            ->execute();
                                } else {
                                    // new keyword
                                    $insert_opp['created'] = date("Y-m-d");
                                    $insert_opp['created_by'] = $user_id;
                                    $insert_opp['location_id'] = $location_id;
                                    // if url is client_url
                                    $insert_opp['competitor_id'] = $competitor_id;
                                    $entity = $keword_res->newEntity($insert_opp);
                                    $keword_res->save($entity);

                                    // getting last inserted id- $group_id = $entity->id;
                                }
                            }
                        }

                        $this->json(1, "Client Information Updated");
                    } else {
                        // action for competitor_url
                        if ($competitor_id > 0) {

                            $comp_details = $this->Competitor->findById($competitor_id)->first();

                            if (count($comp_details) > 0) {

                                $resultdata = $this->pullKeywordsFromSemrush($competitor_url, $country_id, $limit);
                                $competitor_key = explode(PHP_EOL, $resultdata);

                                $trim_comp_url = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $comp_details->website)), "/");

                                if (!strcmp($trim_comp_url, $trimWebsite)) {

                                    // updating existing keywords of competitor_url
                                    foreach ($competitor_key as $com_index => $row_data) {

                                        if ($com_index > 0) {

                                            $line = explode(';', $row_data);

                                            $insert_opp['url'] = $line[6];
                                            $insert_opp['keyword'] = $keyword = $line[0];
                                            $insert_opp['position'] = $line[1];
                                            $insert_opp['prev_position'] = $line[2];
                                            $insert_opp['difference'] = $line[3];
                                            $insert_opp['search_volume'] = $line[4];
                                            $insert_opp['cpc'] = $line[5];
                                            $insert_opp['competition'] = $line[9];
                                            $insert_opp['traffic_percent'] = $line[7];
                                            $insert_opp['traffic_cost'] = $line[8];
                                            $insert_opp['results'] = $line[10];
                                            $insert_opp['trends'] = $line[11];
                                            //$insert_opp['user_id'] = $user_id;
                                            // check keyword existance in table
                                            $check_existing_key = $this->connection
                                                    ->execute("SELECT * FROM tbl_keyword_research WHERE location_id = " . $location_id . " AND keyword = '" . $keyword . "'")
                                                    ->fetchAll('assoc');
                                            if (count($check_existing_key) > 0) {
                                                // already there need to update
                                                $insert_opp['modified'] = date("Y-m-d");
                                                $insert_opp['modified_by'] = $user_id;

                                                $keywordUpdateQuery = $queryToUpdate->update()
                                                        ->set($insert_opp)
                                                        ->where(['location_id' => $location_id, "keyword" => $keyword])
                                                        ->execute();
                                            } else {
                                                // new keyword
                                                $insert_opp['created'] = date("Y-m-d");
                                                $insert_opp['created_by'] = $user_id;
                                                $insert_opp['location_id'] = $location_id;
                                                // if url is client_url
                                                $insert_opp['competitor_id'] = $competitor_id;
                                                $entity = $keword_res->newEntity($insert_opp);
                                                $keword_res->save($entity);
                                                // getting last inserted id- $group_id = $entity->id;
                                            }
                                        }
                                    }
                                } else {
                                    // adding new keywords of Competitor_url
                                    // update competitor table

                                    $insert_new['website'] = $competitor_url;
                                    $insert_new['location_id'] = $location_id;
                                    $insert_new['created'] = date("Y-m-d");
                                    $insert_new['created_by'] = $user_id;

                                    $entityToInsert = $this->Competitor->newEntity($insert_new);
                                    $this->Competitor->save($entityToInsert);
                                    $savedId = $entityToInsert->id;

                                    $CompetitorUpdateQuery = $this->connection
                                            ->execute("UPDATE tbl_compititors set delete_location_id = " . $location_id . ", location_id = NULL where location_id = " . $location_id . " AND id = " . $competitor_id);

                                    $cKeywordUpdateQuery = $this->connection
                                            ->execute("UPDATE tbl_keyword_research set status = 0 where location_id = " . $location_id . " AND competitor_id = " . $competitor_id);

                                    // adding new keywords for changed competitor_url of current location
                                    foreach ($competitor_key as $com_index => $row_data) {

                                        if ($com_index > 0) {

                                            $line = explode(';', $row_data);
                                            $insert_opp['location_id'] = $location_id;
                                            $insert_opp['competitor_id'] = $savedId;
                                            $insert_opp['url'] = $line[6];
                                            $insert_opp['keyword'] = $line[0];
                                            $insert_opp['position'] = $line[1];
                                            $insert_opp['prev_position'] = $line[2];
                                            $insert_opp['difference'] = $line[3];
                                            $insert_opp['search_volume'] = $line[4];
                                            $insert_opp['cpc'] = $line[5];
                                            $insert_opp['competition'] = $line[9];
                                            $insert_opp['traffic_percent'] = $line[7];
                                            $insert_opp['traffic_cost'] = $line[8];
                                            $insert_opp['results'] = $line[10];
                                            $insert_opp['trends'] = $line[11];
                                            //$insert_opp['user_id'] = $user_id;
                                            $insert_opp['created'] = date("Y-m-d");
                                            $insert_opp['created_by'] = $user_id;
                                            // saving data
                                            $entity = $keword_res->newEntity($insert_opp);
                                            $keword_res->save($entity);
                                        }
                                    }
                                }

                                $this->json(1, "Competitor Information Updated");
                            } else {

                                $this->json(0, "Invalid Competitor id");
                            }
                        } else {

                            $this->json(0, "Invalid Competitor id");
                        }
                    }
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (\Exception $ex) {
                // error_log
            }
        }
    }

    public function removeLocationCompetitor() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');

            try {

                if ($this->is_token_valid()) {

                    $data = (array) json_decode(file_get_contents('php://input'));
                    $competitor_id = isset($data['id']) ? $data['id'] : 0;

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];
                    if (empty($location_id)) {
                        $this->json(0, "Location valie is empty", array("valid token" => "required"));
                    }
                    $this->loadmodel("Competitor");
                    $keword_res = TableRegistry::get('tbl_keyword_research');
                    $queryToUpdate = $keword_res->query();

                    $comp_details = $this->Competitor->findById($competitor_id)->first();

                    if (count($comp_details) > 0) {
                        // removing competitor of current location
                        /* $deleteStaus = $this->Competitor->deleteAll(array('Competitor.id' => $competitor_id, "Competitor.location_id" => $location_id), false);
                          if ($deleteStaus) {} */
                        $CompetitorUpdateQuery = $this->connection
                                ->execute("UPDATE tbl_compititors set delete_location_id = " . $location_id . ", location_id = NULL where location_id = " . $location_id . " AND id = " . $competitor_id);

                        $updateKeywordsQuery = $this->connection
                                ->execute("UPDATE tbl_keyword_research SET status = 0 WHERE location_id = " . $location_id . " AND competitor_id = " . $competitor_id);


                        $this->json(1, "Competitor URL deleted Successfully");
                        //$this->json(0, "Failed to delete");
                    } else {
                        $this->json(0, "Invalid Competitor id");
                    }
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (\Exception $ex) {
                // error_log
            }
        }
    }

    public function bulkKeywordsRemove() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');

            try {

                if ($this->is_token_valid()) {

                    $data = (array) json_decode(file_get_contents('php://input'));
                    // list of comma seperated keywords
                    $keywords = isset($data['keywords']) ? $data['keywords'] : array();

                    if (empty($keywords)) {
                        $this->json(0, "No keywords selected");
                    }

                    $keywords = implode(",", $keywords);

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];

                    $updateKeywordsQuery = $this->connection
                            ->execute("UPDATE tbl_keyword_research SET status = 0 WHERE id IN (" . $keywords . ") AND location_id = " . $location_id);

                    $this->json(1, "keyword removed successfully");
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (\Exception $ex) {
                // error_log
            }
        }
    }

    public function viewRemovedKeywords() {
        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');

            try {

                if ($this->is_token_valid()) {

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];
                    $this->loadmodel("Competitor");

                    $all_data = $this->Competitor->getRemovedCompetitorsKeyword($location_id, new AppController());

                    $this->json(1, $all_data);
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (\Exception $ex) {
                // error_log
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    //added by sanjay@rudrainnovatives.com on 27 June 2017
    //Competitors Block Header Section.
    public function getCompetitorSummaryBlock() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $data = (array) json_decode(file_get_contents('php://input'));
            $campaign_id = isset($data['campaign_id']) ? $data['campaign_id'] : 0;
            $from_date = isset($data['from_date']) ? $data['from_date'] : date("Y-m-d", strtotime("-31 day"));
            $to_date = isset($data['to_date']) ? $data['to_date'] : date("Y-m-d", strtotime("-1 day"));

            try {

                if ($this->is_token_valid()) {

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];
                    $location_url = $this->getLocationUrlById($location_id);
                    $this->loadmodel("Competitor");

                    $competitors = $this->Competitor->find("all", ["conditions" =>
                                ["location_id" => $location_id],
                                "fields" => ["id", "website"]]
                            )->toArray();
                    $competitors_array = array();
                    foreach ($competitors as $competitor) {
                        array_push($competitors_array, $competitor->website);
                    }
                    array_unshift($competitors_array, $location_url);
                    // array used to return final result to ui
                    $competitors_summary = array();

                    $bgColor = ["#55BF3B", "#DF5353", "#DF5353", "#8d4654", "#7798BF"];
                    $colorCount = 0;

                    foreach ($competitors_array as $competitor_url) {
                        if (trim($competitor_url) == '') {
                            continue;
                        }
                        $grank = 0;
                        $grank_total = 0;
                        $avg_grank = 0;
                        $firstplace = 0;
                        $top3 = 0;
                        $page1 = 0;
                        $total_keywords = 0;
                        $hgrank = 0;
                        $hgrank_total = 0;
                        $havg_grank = 0;
                        $hfirstplace = 0;
                        $htop3 = 0;
                        $hpage1 = 0;

                        $trimmedurl = $this->fully_trim($competitor_url);
                        $txt = '';
                        if ($campaign_id > 0) {
                            $txt = "AND campaign_id = $campaign_id";
                        }
                        $sql = "SELECT keyword, rank,ranked_url FROM tbl_keywords WHERE location_id = $location_id $txt";
                        $keywordata = $this->connection->execute($sql)->fetchAll('assoc');

                        foreach ($keywordata as $index => $keywordrow) {

                            $currank = $oldrank = 50;
                            $k = 0;
                            $keyword = strtolower(trim($keywordrow['keyword']));

                            if (!empty($keywordrow['rank'])) {

                                if (isset($keywordrow['ranked_url']) && strpos($keywordrow['ranked_url'], $trimmedurl) !== false) {
                                    if ($k == 0) {
                                        $rnk = $currank = $keywordrow['rank'];
                                        $grank++;
                                        $k++;
                                    }
                                }
                                // get history
                                $sqlQueryHistory = "SELECT rank, ranked_url FROM tbl_keywords_history WHERE location_id = $location_id $txt AND LOWER(TRIM(keyword)) = '" . $keyword . "' ORDER BY dateOfRank DESC LIMIT 1";
                                $historydata = $this->connection->execute($sqlQueryHistory)->fetchAll('assoc');
                                if (!empty($historydata)) {
                                    $hk = 0;
                                    foreach ($historydata as $inx => $valx) {

                                        if (isset($valx['ranked_url']) && strpos($valx['ranked_url'], $trimmedurl) !== false) {
                                            if ($hk == 0) {
                                                $hgrank++;
                                                $oldrank = $valx['rank'];
                                                $hk++;
                                            }
                                        }
                                    }
                                }// history loop ends here
                            }// upper if block closed here
                            $grank_total += $currank;
                            if ($currank == 1) {
                                $firstplace++;
                            }
                            if ($currank >= 1 && $currank <= 3) {
                                $top3++;
                            }
                            if ($currank >= 1 && $currank <= 10) {
                                $page1++;
                            }


                            $hgrank_total += $oldrank;
                            if ($oldrank == 1) {
                                $hfirstplace++;
                            }

                            if ($oldrank >= 1 && $oldrank <= 3) {
                                $htop3++;
                            }
                            if ($oldrank >= 1 && $oldrank <= 10) {
                                $hpage1++;
                            }

                            $total_keywords++;
                        }//$keywordata ends here

                        $avg_grank = sprintf("%.2f", $grank_total / $total_keywords);
                        $havg_grank = sprintf("%.2f", $hgrank_total / $total_keywords);

                        $avg_ch = $havg_grank - $avg_grank;
                        $avg_ch = round($avg_ch, 2);
                        if ($avg_ch > 0) {
                            $avg_class = 'greenlbl';
                            $sign = "+";
                        } else if ($avg_ch == 0) {
                            $avg_class = 'bluelbl';
                            $sign = "";
                        } else {
                            $avg_class = 'redlbl';
                            $sign = "-";
                        }

                        $rankchange = $grank - $hgrank;

                        if ($rankchange > 0) {
                            $rank_class = 'greenlbl';
                            $ranksign = "+";
                        } else if ($rankchange == 0) {
                            $rank_class = 'bluelbl';
                            $ranksign = "";
                        } else {
                            $rank_class = 'redlbl';
                            $ranksign = "-";
                        }

                        $fchange = $firstplace - $hfirstplace;

                        if ($fchange > 0) {
                            $fchange_class = 'greenlbl';
                            $franksign = "+";
                        } else if ($fchange == 0) {
                            $fchange_class = 'bluelbl';
                            $franksign = "";
                        } else {
                            $fchange_class = 'redlbl';
                            $franksign = "-";
                        }


                        $top3change = $top3 - $htop3;

                        if ($top3change > 0) {
                            $top3change_class = 'greenlbl';
                            $top3ranksign = "+";
                        } else if ($top3change == 0) {
                            $top3change_class = 'bluelbl';
                            $top3ranksign = "";
                        } else {
                            $top3change_class = 'redlbl';
                            $top3ranksign = "-";
                        }

                        $page1change = $page1 - $hpage1;

                        if ($page1change > 0) {
                            $page1change_class = 'greenlbl';
                            $page1ranksign = "+";
                        } else if ($page1change == 0) {
                            $page1change_class = 'bluelbl';
                            $page1ranksign = "";
                        } else {
                            $page1change_class = 'redlbl';
                            $page1ranksign = "-";
                        }

                        array_push($competitors_summary, array(
                            "url" => $this->fully_trim($competitor_url),
                            "bg_color" => $bgColor[$colorCount++],
                            "total_rankings" => array(
                                "rank" => $grank,
                                "sign" => $ranksign,
                                "rank_change" => abs($rankchange)
                            ),
                            "avg_position" => array(
                                "rank" => $avg_grank,
                                "sign" => $sign,
                                "rank_change" => abs($avg_ch)
                            ),
                            "first_place" => array(
                                "rank" => $firstplace,
                                "sign" => $franksign,
                                "rank_change" => abs($fchange)
                            ),
                            "top_3" => array(
                                "rank" => $top3,
                                "sign" => $top3ranksign,
                                "rank_change" => abs($top3change)
                            ),
                            "page_1" => array(
                                "rank" => $page1,
                                "sign" => $page1ranksign,
                                "rank_change" => abs($page1change)
                            )
                        ));
                    }

                    $this->json(1, "data found", $competitors_summary);
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (\Exception $ex) {
                // error_log
            }
        }
    }

    // keywords section
    public function getCompetitorSummaryKeywords() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');

            try {

                if ($this->is_token_valid()) {

                    $data = (array) json_decode(file_get_contents('php://input'));
                    $campaign_id = isset($data['campaign_id']) ? $data['campaign_id'] : 0;

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $location_url = $this->getLocationUrlById($location_id);
                    $user_id = $tokenDetails['user_id'];
                    $this->loadmodel("Competitor");
                    $cond = "g.location_id = $location_id";
                    if ($campaign_id > 0) {
                        $cond .= " AND g.campaign_id = $campaign_id";
                    }

                    // get all competitors
                    $competitors = $this->Competitor->find("all", ["conditions" => ["location_id" => $location_id], "fields" => ["id", "website"]])->toArray();

                    $competitors_array = array();

                    $competitors_summary = array();
                    foreach ($competitors as $competitor) {
                        array_push($competitors_array, $competitor->website);
                    }
                    array_unshift($competitors_array, $location_url);

                    foreach ($competitors_array as $competitor_url) {
                        if (trim($competitor_url) != '') {
                            array_push($competitors_summary, $this->fully_trim($competitor_url));
                        }
                    }

                    $sqlQueryAllGroups = "SELECT g.*, c.name, c.local_location, c.target_country FROM tbl_keygroup g INNER JOIN tbl_campaigns c"
                            . " ON g.campaign_id = c.id INNER JOIN tbl_keywords k ON k.group_id = g.id  WHERE $cond AND k.isprimary = 1 AND g.status = 1";

                    $keywordgrps = $this->connection->execute($sqlQueryAllGroups)->fetchAll('assoc');

                    $groups_array = array();
                    $header_array = array();
                    $group_ids = array();

                    foreach ($keywordgrps as $inx => $keywordgrp) {

                        $istarget = 'targettbl';
                        if ($keywordgrp['is_target'] == "0") {
                            $istarget = '';
                        }
                        if ($keywordgrp['landing_page'] != '') {
                            $landingpages[] = $keywordgrp['landing_page'];
                        }
                        $group_id = $keywordgrp['id'];
                        $sqlToGetKeywords = "SELECT * FROM tbl_keywords WHERE group_id = $group_id ORDER BY isprimary DESC";
                        $keywords = $this->connection->execute($sqlToGetKeywords)->fetchAll('assoc');

                        $keywords_summary = array();

                        foreach ($keywords as $inxVal => $keywordrow) {

                            $rankdata = $keywordrow['rank'] == NULL ? '' : $keywordrow['rank'];
                            //pr($rankdata);
                            $globalrankurl = $keywordrow['ranked_url'];
                            $lastchangeicon = '';
                            $weekchangeicon = '';
                            $monthchangeicon = '';
                            $local_icon = '';
                            $arrranks = array();
                            foreach ($competitors_array as $competitor_url) {
                                if (trim($competitor_url) != '') {
                                    $fulltrimdcompt = str_replace(array("http://", "https://", "www."), array("", "", ""), trim(trim($competitor_url, "/")));
                                    $arrranks["$fulltrimdcompt"] = "50+";
                                }
                            }

                            if (!empty($rankdata)) {
                                $forcompt = array();
                                foreach ($arrranks as $trimmdsite => $arrrank) {
                                    if (isset($keywordrow['ranked_url']) && strpos($keywordrow['ranked_url'], $trimmdsite) !== false) {
                                        if (!in_array($trimmdsite, $forcompt)) {
                                            $forcompt[] = $trimmdsite;
                                            $arrranks["$trimmdsite"] = $keywordrow['rank'];
                                        }
                                    }
                                }
                            }
                            $rank_summary = array();
                            foreach ($competitors_array as $competitor_url) {
                                if (trim($competitor_url) != '') {
                                    $trimcompetitor = str_replace(array("http://", "https://", "www."), array("", "", ""), trim(trim($competitor_url, "/")));
                                    array_push($rank_summary, array(
                                        "url" => $trimcompetitor,
                                        "rank" => $arrranks["$trimcompetitor"]
                                    ));
                                }
                            }

                            array_push($keywords_summary, array(
                                "keyword_id" => intval($keywordrow['id']),
                                "keyword" => $keywordrow['keyword'],
                                "is_primary" => intval($keywordrow['isprimary']),
                                "is_target" => intval($keywordgrp['is_target']),
                                "rank" => $rank_summary
                            ));
                        }
                        array_push($groups_array, array(
                            "group_id" => $group_id,
                            "keywords" => $keywords_summary
                        ));
                    }

                    $this->json(1, "keywords found", array("header" => $competitors_summary, "data" => $groups_array));
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (\Exception $ex) {
                // error_log
            }
        }
    }

    // added by sanjay@rudrainnovatives.com on 28 June 2017
    public function setCompetitorColumn() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');
            $data = json_decode(file_get_contents('php://input'));
            $show_colums = isset($data->show_colums) && !empty($data->show_colums) ? $data->show_colums : array();
            // show_columns: comma seperated columns

            try {

                if ($this->is_token_valid()) {

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];

                    if (!empty($show_colums)) {
                        $show_colums = explode(",", $show_colums);
                        $has_saved_columns = $this->get_user_meta($location_id, 'competitor_keyword_columns');
                        if (empty($has_saved_columns)) {
                            $this->add_user_meta($location_id, "competitor_keyword_columns", json_encode($show_colums));
                        } else {
                            $this->update_user_meta($location_id, "competitor_keyword_columns", json_encode($show_colums));
                        }
                        $this->json(1, "Competitors columns saved");
                    } else {

                        $this->json(0, "no columns found", array("columns" => "required"));
                    }
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (\Exception $ex) {
                // error_log
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function getCompetitorColumn() {
        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header('token');

            try {

                if ($this->is_token_valid()) {

                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];

                    $has_saved_columns = $this->get_user_meta($location_id, 'competitor_keyword_columns');
                    if (!empty($has_saved_columns)) {
                        $this->json(1, "columns found", implode(",", json_decode($has_saved_columns)));
                    } else {

                        $this->json(0, "columns not saved so far");
                    }
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (\Exception $ex) {
                //error_log
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    // class ends here...
}
