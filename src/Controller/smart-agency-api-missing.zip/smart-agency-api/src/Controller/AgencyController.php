<?php

namespace App\Controller;

use App\Controller\AppController;

class AgencyController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadComponent('SmartEmail');
        header('Access-Control-Allow-Origin: *');
    }

    /* default method called */

    public function index() {

        $this->autoRender = false;

        $this->json(1, array(
            "method" => "index",
            "messge" => "silence is golden"
        ));
    }

    /* create Agency */

    public function create() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            if (!empty($_REQUEST['prefix'])) {

                /* checking agency availability */
                if ($this->Agency->is_prefix_available($_REQUEST['prefix'])) {

                    $this->json(0, "Agency Prefix already taken");
                } else {

                    $createAgencyStatus = $this->Agency->create($_REQUEST);

                    if (count($createAgencyStatus) > 0):

                        /* notify admin/user that agency account has been setup */
                        $to = isset($_REQUEST['email']) ? $_REQUEST['email'] : ADMIN_EMAIL;
                        $mailSentResponse = $this->SmartEmail->SendMail(
                                $to, "parambir@rudrainnovatives.com", array(
                            "name" => $_REQUEST['name'],
                            "url" => "http://".$_REQUEST['prefix'] . "." . SMART_URL,
                            "username" => "sanjay1001",
                            "password" => "sanjay@123"), 'create_agency'
                        );

                        if ($mailSentResponse['status']) {

                            $this->json(1, "Agency Created", $createAgencyStatus);
                        } else {

                            $this->json(0, "Agency Created, Mail Sent failed", $createAgencyStatus);
                        }

                    else:

                        $this->json(0, "Failed to create Agency");
                    endif;
                }
            } else {

                $this->json(0, "Agency Prefix should not be empty");
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* edit Agency */

    public function edit() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            if ($createAgencyStatus = $this->Agency->edit($_REQUEST)):

                $this->json(1, "Agency Updated successfully");
            else:

                $this->json(0, "Invalid Agency");
            endif;
        }else {

            $this->json(0, "silence is golden");
        }
    }

    /* remove Agency */

    public function remove() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            if ($createAgencyStatus = $this->Agency->remove($_REQUEST)):

                $this->json(1, "Agency Deleted successfully");
            else:

                $this->json(0, "Invalid Agency");
            endif;
        }else {

            $this->json(0, "silence is golden");
        }
    }

    /* change Agency Status */

    public function toggleStatus() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            if ($createAgencyStatus = $this->Agency->updateStatus($_REQUEST)):

                $this->json(1, "Status updated successfully");
            else:

                $this->json(0, "Invalid Agency");
            endif;
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* get all Agencies */

    public function getList() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $list = $this->Agency->getList($_REQUEST, $this->start, $this->limit, new AppController());

            if (count($list) > 0) {

                $this->json(1, "Agency found", $list);
            } else {

                $this->json(0, "No Agency found");
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* get specific agency details */

    public function details() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $details = $this->Agency->agencydetails($_REQUEST, new AppController());

            if (count($details) > 0):

                $this->json(1, "Agency details found", $details);
            else:

                $this->json(1, "Invalid Agency");
            endif;
        }else {

            $this->json(0, "silence is golden");
        }
    }

    /* get agency types */

    public function agencyTypes() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $this->json(1, $this->Agency->getagencytypes());
        } else {

            $this->json(0, "silence is golden");
        }
    }

    /* get agency status */

    public function agencyStatus($agency_id) {

        $this->autoRender = false;

        return $this->Agency->getAgencyStatus($agency_id);
    }

}
?>

