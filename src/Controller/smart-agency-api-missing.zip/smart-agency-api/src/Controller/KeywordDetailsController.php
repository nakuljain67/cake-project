<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;

class KeywordDetailsController extends AppController {

    private $connection;

    public function initialize() {
        parent::initialize();
        header('Access-Control-Allow-Origin: *');
        $this->loadModel("Keyword");
        $this->connection = ConnectionManager::get('default');
    }

    /* default method called */

    public function index() {

        $this->autoRender = false;

        $this->json(1, array(
            "method" => "index",
            "messge" => "silence is golden"
        ));
    }

    // This function is used to get dates of run campaign i.e last run date, next sch date, etc
    public function getRunDates() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header("token");
            $data = json_decode(file_get_contents('php://input'));
            try {

                if ($this->is_token_valid()) {

                    $campaign_id = isset($data->campaign_id) ? intval($data->campaign_id) : 22;

                    if ($this->Keyword->is_valid_campaign($campaign_id)) {
                        $dates = array();
                        $tokenDetails = $this->fetchTokenDetails($token);
                        $location_id = $tokenDetails['location_id'];
                        $user_id = $tokenDetails['user_id'];

                        $sqlQueryToGetDates = "SELECT (SELECT dateOfRank FROM tbl_keywords_history WHERE campaign_id = $campaign_id "
                                . "AND location_id = $location_id ORDER BY dateOfRank DESC limit 1) as prev_rank_date,"
                                . " (SELECT rankdate FROM tbl_campaigns WHERE id = $campaign_id AND location_id = $location_id limit 1) as last_rank_date";

                        $campaign_history = $this->connection->execute($sqlQueryToGetDates)->fetchAll("assoc");

                        if (count($campaign_history) > 0) {

                            $previous_rank_date = $campaign_history[0]['prev_rank_date'];
                            if ($previous_rank_date != '') {
                                $previous_rank_date = date("D d M Y", strtotime("$previous_rank_date"));
                            }
                            $last_rank_date = $campaign_history[0]['last_rank_date'];
                            if ($last_rank_date != '') {
                                $last_rank_date = date("D d M Y", strtotime("$last_rank_date"));
                            }
                            $nextsch = date("Y-m-d");
                            if (strtolower(date("l")) == 'sunday') {
                                if ($lastrun == $nextsch) {
                                    $nextsch = date('D d M Y', strtotime("next Sunday"));
                                } else {
                                    $nextsch = date('D d M Y');
                                }
                            } else {
                                $nextsch = date('D d M Y', strtotime("next Sunday"));
                            }

                            array_push($dates, array(
                                "prev_rank" => $previous_rank_date,
                                "last_rank" => $last_rank_date,
                                "next_sch" => $nextsch,
                                "last_adword" => $last_rank_date,
                                "from" => date("Y-m-d", strtotime("-31 day")),
                                "to" => date("Y-m-d", strtotime("-1 day"))
                            ));
                            $this->json(1, "data found", $dates);
                        }

                        $this->json(1, "no data found", $dates);
                    } else {
                        $this->json(0, "Invalid campaign id", array("campaign_id" => "required"));
                    }
                } else {

                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (\Exception $ex) {
                // error_log
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

}

?>