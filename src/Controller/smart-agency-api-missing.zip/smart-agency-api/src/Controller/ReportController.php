<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;
use PHPMailer;
use Cake\Mailer\Email;

class ReportController extends AppController {

    public function initialize() {
        parent::initialize();
        //header('Access-Control-Allow-Origin: *');
    }

    /* default called method */

    public function index() {

        $this->autoRender = false;

        $this->json(1, array(
            "method" => "index",
            "messge" => "silence is golden"
        ));
    }

    /* semrush api units info */

    public function siteauditUnitsInfo() {

        $this->autoRender = false;

        $semrush_api_info = semrush_api_info();
        $key = $semrush_api_info['key'];
        $FinalURL = 'https://www.semrush.com/users/countapiunits.html?key=' . $key;

        $ch = curl_init($FinalURL);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

        $result_on = curl_exec($ch);
        echo json_decode($result_on);
    }

    /* semrush operations */

    public function semrushTrigger() {

        $this->autoRender = false;

        $project_name = isset($_REQUEST['brand_name']) ? trim($_REQUEST['brand_name']) : "Lenfest Institute";
        $url = isset($_REQUEST['url']) ? trim($_REQUEST['url']) : "https://www.lenfestinstitute.org/";

        $semrush_api_info = semrush_api_info();
        $main_api_url = $semrush_api_info['main_api_url'];
        $key = $semrush_api_info['key'];

        // code to create project_id
        //$project_id = $this->createSEMrushProject($semrush_api_info, $project_name, $url);
        // code to create snapshot id
        // $snapshot_id = $this->createSEMrushSnapshot($project_id, $semrush_api_info, $url);

        $project_id = 777293;
        $snapshot_id = "591c60b05f50e913a20fd98b";

        $serializedSiteAuditInfo = serialize($this->siteauditAllInfo($project_id, $semrush_api_info));

        $site_audit_result = unserialize($serializedSiteAuditInfo);
        $errors_list = $site_audit_result->current_snapshot->errors;
        $warning_list = $site_audit_result->current_snapshot->warnings;
        $notices_list = $site_audit_result->current_snapshot->notices;
        $snapshot_id = $site_audit_result->current_snapshot->snapshot_id;
        $defects_list = $site_audit_result->defects;

        $this->pr($this->siteauditErrorList($project_id, $semrush_api_info));

        //print_r(array($errors_list, $warning_list, $notices_list, $snapshot_id, $defects_list));
        //$serializedSiteAuditErrors = serialize($this->siteauditErrorList($project_id, $semrush_api_info));

        /* $page_id_array = array();

          foreach ($defects_list as $issue_id => $limit_data) {

          $siteAuditCrawlIssues = $this->siteAuditCrawlIssues($project_id, $snapshot_id, $issue_id, $limit_data, $semrush_api_info);

          foreach ($siteAuditCrawlIssues->data as $index => $data) {

          $this->pr($this->siteAuditProcessErrorPage($project_id, $data->page_id, $semrush_api_info));
          }
          } */

        //$this->pr($page_id_array);
        //$page_id = "591c60c0259acb1a2835023d";
        //$this->pr($this->siteAuditProcessErrorPage($project_id, $page_id, $semrush_api_info));
    }

    /* Create Project in SEMrush */

    public function createSEMrushProject($semrush_api_info, $project_name, $url) {

        $main_api_url = $semrush_api_info['main_api_url'];
        $key = $semrush_api_info['key'];

        $curl_url = 'management/v1/projects?key=' . $key;
        $post_data['project_name'] = $project_name;
        $post_data['url'] = $this->fully_trim($url);
        $data_string = json_encode($post_data);
        $create_new_project = $this->pc_post($username = '', $password = '', $main_api_url, $curl_url, $data_string);
        $create_new_project = json_decode($create_new_project);
        $project_id = $create_new_project->project_id;
        if ($project_id > 0) {
            return $project_id;
        }
        return 0;
    }

    /* Generate Snapshot in SEMrush correspoding to Project */

    public function createSEMrushSnapshot($project_id, $semrush_api_info, $url) {

        $main_api_url = $semrush_api_info['main_api_url'];
        $key = $semrush_api_info['key'];

        $curl_url = 'management/v1/projects/' . $project_id . '/siteaudit/enable?key=' . $key;
        $enable_site_audit_tool_post_data['domain'] = $this->fully_trim($url);
        $enable_site_audit_tool_post_data['scheduleDay'] = 0;
        $enable_site_audit_tool_post_data['notify'] = false;
        $enable_site_audit_tool_post_data['pageLimit'] = '1500';
        $enable_site_audit_tool_post_data['crawlSubdomains'] = false;

        $data_string = json_encode($enable_site_audit_tool_post_data);

        $enable_site_audit_tool = $this->pc_post($username = '', $password = '', $main_api_url, $curl_url, $data_string);

        // Run Audit
        $curl_url = 'reports/v1/projects/' . $project_id . '/siteaudit/launch?key=' . $key;
        $data_string = json_encode(array());
        $run_audit = $this->pc_post($username = '', $password = '', $main_api_url, $curl_url, $data_string);
        $run_audit = json_decode($run_audit);

        return $run_audit->snapshot_id;
    }

    /* get site audit all information */

    public function siteauditAllInfo($project_id, $semrush_api_info) {

        $main_api_url = $semrush_api_info['main_api_url'];
        $key = $semrush_api_info['key'];

        $curl_url = 'reports/v1/projects/' . $project_id . '/siteaudit/info?key=' . $key;
        $all_info = $this->pc_get($username = '', $password = '', $main_api_url, $curl_url);
        $all_info = json_decode($all_info);
        return $all_info;
    }

    /* get site audit error list */

    public function siteauditErrorList($project_id, $semrush_api_info) {

        $main_api_url = $semrush_api_info['main_api_url'];
        $key = $semrush_api_info['key'];

        $curl_url = 'reports/v1/projects/' . $project_id . '/siteaudit/meta/issues?key=' . $key;
        $error_name = $this->pc_get($username = '', $password = '', $main_api_url, $curl_url);
        $error_name_list = json_decode($error_name);
        return $error_name_list;
    }

    /* site audit crawl each page issues */

    public function siteAuditCrawlIssues($project_id, $snapshot_id, $issue_id, $limit_data, $semrush_api_info) {

        $main_api_url = $semrush_api_info['main_api_url'];
        $key = $semrush_api_info['key'];

        $curl_url = 'reports/v1/projects/' . $project_id . '/siteaudit/snapshot/' . $snapshot_id . '/issue/' . $issue_id . '?page=1&filter=&sort=index_asc&limit=' . $limit_data . '&key=' . $key;
        $all_page_error_list = $this->pc_get($username = '', $password = '', $main_api_url, $curl_url);
        $all_page_error_list = json_decode($all_page_error_list);
        return $all_page_error_list;
    }

    /* site audit to process error pages */

    public function siteAuditProcessErrorPage($project_id, $page_id, $semrush_api_info) {

        $main_api_url = $semrush_api_info['main_api_url'];
        $key = $semrush_api_info['key'];

        $curl_url = 'reports/v1/projects/' . $project_id . '/siteaudit/page/' . $page_id . '?key=' . $key;
        $audit_page_info = $this->pc_get($username = '', $password = '', $main_api_url, $curl_url);
        $audit_page_info = json_decode($audit_page_info);
        return $audit_page_info;
    }

}

?>