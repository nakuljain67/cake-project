<?php

namespace App\Controller;
require_once(ROOT . DS . 'vendor' . DS . "dompdf" . DS . "autoload.inc.php");

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;
use Cake\Routing\Router;
use Dompdf\Dompdf;
use Dompdf\Options;

class CitationController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->loadModel("Keygroups");
    }

    /* default method called */

    public function index() {

        $this->autoRender = false;

        $this->json(1, array(
            "method" => "index",
            "messge" => "silence is golden"
        ));

        $this->loadModel('Citation');
        $this->loadModel('Citationlist');
    }

    public function updateCitation() {
        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $token = $this->request->header('token');
                if ($this->is_token_valid()) {
                    $res = $this->fetchTokenDetails($token);
                    $agency_id = $res['agency_id'];
                    $citation = $this->Citation;
                    $citdata = $citation->newEntity();

                    $data = (array) json_decode(file_get_contents('php://input'));
                    $citation_id = isset($data['citation_id']) && trim($data['citation_id']) != '' ? $data['citation_id'] : $res['citation_id'];
                    $res = $this->Citation->findById($citation_id)->select(['agency_id'])->first();

                    if (empty($res)) {
                        $this->json(0, "Invalid Citation");
                    }
                    if ($res->agency_id != $agency_id) {
                        $this->json(0, "You are not authorized to update this citation");
                    }

                    $citdata->name = $name = isset($data['name']) && trim($data['name']) != '' ? $data['name'] : '';
                    $citdata->url = $url = isset($data['url']) && trim($data['url']) != '' ? $data['url'] : '';
                    $citdata->services = $services = isset($data['services']) && trim($data['services']) != '' ? $data['services'] : '';
                    $citdata->country_id = $country_id = isset($data['country_id']) && trim($data['country_id']) != '' ? $data['country_id'] : '';
                    $citdata->state_id = $state_id = isset($data['state_id']) && trim($data['state_id']) != '' ? $data['state_id'] : '';
                    $citdata->city_id = $city_id = isset($data['city_id']) && trim($data['city_id']) != '' ? $data['city_id'] : '';
                    $city = isset($data['city']) && trim($data['city']) != '' ? $data['city'] : '';
                    $citdata->address = $address = isset($data['address']) && trim($data['address']) != '' ? $data['address'] : '';
                    $citdata->phone = $phone = isset($data['phone']) && trim($data['phone']) != '' ? $data['phone'] : '';
                    $citdata->zip_code = $zip_code = isset($data['zip_code']) && trim($data['zip_code']) != '' ? $data['zip_code'] : '';

                    $arvalidation = array();
                    if ($url == "") {
                        $arvalidation['url'] = "Please provide website url";
                    }
                    if ($name == "") {
                        $arvalidation['name'] = "Please provide business name";
                    }
                    if ($country_id == "") {
                        $arvalidation['country_id'] = "Please provide country_id";
                    }
                    if ($state_id == "") {
                        $arvalidation['state_id'] = "Please provide state_id";
                    }
                    if ($address == "") {
                        $arvalidation['address'] = "Please provide address";
                    }
                    if ($zip_code == "") {
                        $arvalidation['zip_code'] = "Please provide zip code";
                    }
                    if ($phone == "") {
                        $arvalidation['phone'] = "Please provide phone number";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    $data['agency_id'] = $res['agency_id'];
                    $data['user_id'] = $res['user_id'];
                    if ($city != '') {
                        if ($city_id <= 0) {
                            // Added city if not available
                            $this->loadModel('Location');
                            $city_id = $this->Location->addCity($city, $state_id);
                            if ($city_id == 0) {
                                $this->json(1, "City already exist for this state");
                            }
                            $citdata->city_id = $data['city_id'] = $city_id;
                        }
                    }

                    $citdata->status = 1;
                    $citdata->created = date("Y-m-d H:i:s");
                    $citdata->created_by = $data['user_id'];
                    $citdata->modified_by = $data['user_id'];
                    $citdata->id = $citation_id;
                    $infoStatus = $citation->save($citdata);

                    if ($infoStatus) {
                        $arr = array('citation_id' => $citation_id);
                        if ($city != '') {
                            if ($citdata->city_id != '') {
                                $arr['new_city_id'] = $citdata->city_id;
                            }
                        }
                        $this->json(1, "Citation successfully updated", $arr);
                    } else {
                        $this->json(0, "Failed to add citation");
                    }
                } else {
                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function addCitation() {
        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $token = $this->request->header('token');
                if ($this->is_token_valid()) {
                    $res = $this->fetchTokenDetails($token);

                    $citation = $this->Citation;
                    $citdata = $citation->newEntity();

                    $data = (array) json_decode(file_get_contents('php://input'));
                    $citdata->location_id = $location_id = isset($data['location_id']) && trim($data['location_id']) != '' ? $data['location_id'] : $res['location_id'];
                    $citdata->name = $name = isset($data['name']) && trim($data['name']) != '' ? $data['name'] : '';
                    $citdata->url = $url = isset($data['url']) && trim($data['url']) != '' ? $data['url'] : '';
                    $citdata->services = $services = isset($data['services']) && trim($data['services']) != '' ? $data['services'] : '';
                    $citdata->country_id = $country_id = isset($data['country_id']) && trim($data['country_id']) != '' ? $data['country_id'] : '';
                    $citdata->state_id = $state_id = isset($data['state_id']) && trim($data['state_id']) != '' ? $data['state_id'] : '';
                    $citdata->city_id = $city_id = isset($data['city_id']) && trim($data['city_id']) != '' ? $data['city_id'] : '';
                    $city = isset($data['city']) && trim($data['city']) != '' ? $data['city'] : '';
                    $citdata->address = $address = isset($data['address']) && trim($data['address']) != '' ? $data['address'] : '';
                    $citdata->phone = $phone = isset($data['phone']) && trim($data['phone']) != '' ? $data['phone'] : '';
                    $citdata->zip_code = $zip_code = isset($data['zip_code']) && trim($data['zip_code']) != '' ? $data['zip_code'] : '';

                    $arvalidation = array();
                    if ($url == "") {
                        $arvalidation['url'] = "Please provide website url";
                    }
                    if ($name == "") {
                        $arvalidation['name'] = "Please provide business name";
                    }
                    if ($country_id == "") {
                        $arvalidation['country_id'] = "Please provide country_id";
                    }
                    if ($state_id == "") {
                        $arvalidation['state_id'] = "Please provide state_id";
                    }
                    if ($address == "") {
                        $arvalidation['zip_code'] = "Please provide address";
                    }
                    if ($zip_code == "") {
                        $arvalidation['address'] = "Please provide zip code";
                    }
                    if ($phone == "") {
                        $arvalidation['phone'] = "Please provide phone number";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    $data['agency_id'] = $res['agency_id'];
                    $data['user_id'] = $res['user_id'];
                    if ($city != '') {
                        if ($city_id <= 0) {
                            // Added city if not available
                            $this->loadModel('Location');
                            $city_id = $this->Location->addCity($city, $state_id);
                            if ($city_id == 0) {
                                $this->json(1, "City already exist for this state");
                            }
                            $citdata->city_id = $data['city_id'] = $city_id;
                        }
                    }

                    $citdata->agency_id = $data['agency_id'];
                    $citdata->status = 1;
                    $citdata->created = date("Y-m-d H:i:s");
                    $citdata->created_by = $data['user_id'];
                    $citdata->modified_by = $data['user_id'];
                    $infoStatus = $citation->save($citdata);

                    if ($infoStatus) {
                        $arr = array('citation_id' => $citdata->id);
                        if ($city != '') {
                            if ($citdata->city_id != '') {
                                $arr['new_city_id'] = $citdata->city_id;
                            }
                        }
                        $this->json(1, "Citation successfully added", $arr);
                    } else {
                        $this->json(0, "Failed to add citation");
                    }
                } else {
                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } catch (Exception $ex) {
                
            }
        } else {

            $this->json(0, "silence is golden");
        }
    }

    public function listCitations() {

        $this->autoRender = false;
        $limit = $this->limit = 12;
        try {
            $token = $this->request->header('token');
            if ($this->is_token_valid()) {
                $data = (array) json_decode(file_get_contents('php://input'));
                $offset = isset($data['offset']) ? $data['offset'] : $this->start;
                $offset = $offset - 1;
                if ($offset <= 0) {
                    $offset = 0;
                    $page = 1;
                } else {
                    $page = $offset + 1;
                    $offset = $offset * $limit;
                }

                $res = $this->fetchTokenDetails($token);
                $agency_id = $res['agency_id'];
                $location_id = $res['location_id'];
                $status = isset($data['status']) ? intval($data['status']) : 1;
                $search_txt = isset($data['search_txt']) ? htmlspecialchars(trim($data['search_txt'])) : "";

                if ($search_txt == '') {
                    $total_citations = $this->Citation->find('all', [
                                'conditions' => ['location_id' => $location_id, 'Citation.status' => $status]
                            ])->count();

                    $results = $this->Citation->find("all", [
                                'conditions' => ['location_id' => $location_id, 'Citation.status' => $status],
                                'order' => ['created' => 'DESC'],
                                'limit' => $limit,
                                'offset' => $offset
                            ])->contain(['City', 'State', 'Country'])->all()->toArray();
                } else {

                    $total_citations = $this->Citation->find('all', [
                                'conditions' => ['OR' => [
                                        ['location_id' => $location_id, 'Citation.status' => $status, 'name like' => '%' . $search_txt . '%'],
                                        ['location_id' => $location_id, 'Citation.status' => $status, 'url like' => '%' . $search_txt . '%']
                                    ]
                                ]
                            ])->count();

                    $results = $this->Citation->find("all", [
                                'conditions' => ['OR' => [
                                        ['location_id' => $location_id, 'Citation.status' => $status, 'name like' => '%' . $search_txt . '%'],
                                        ['location_id' => $location_id, 'Citation.status' => $status, 'url like' => '%' . $search_txt . '%']
                                    ]
                                ],
                                'order' => ['created' => 'DESC'],
                                'limit' => $limit,
                                'offset' => $offset
                            ])->contain(['City', 'State', 'Country'])->all()->toArray();
                }

                $remining_records = ($total_citations % $this->limit);
                $total_pages = floor(($total_citations / $this->limit));
                if ($remining_records > 0) {
                    $total_pages = $total_pages + 1;
                }

                if (count($results) > 0) {
                    $final_array['total_records'] = $total_citations;
                    $final_array['total_pages'] = $total_pages;
                    $final_array['current_page'] = $page;
                    $final_array['data'] = $results;
                    $this->json(1, "Citations Found", $final_array);
                } else {

                    $this->json(1, "No Data Found", $results);
                }
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        } catch (Exception $ex) {
            
        }
    }

    public function citationDetail() {
        try {
            $token = $this->request->header('token');
            if ($this->is_token_valid()) {
                $res = $this->fetchTokenDetails($token);
                $agency_id = $res['agency_id'];

                $data = (array) json_decode(file_get_contents('php://input'));
                $id = isset($data['id']) && !empty($data['id']) ? intval($data['id']) : '';

                $query = $this->Citation->findById($id)->contain(['City', 'State', 'Country']);
                $result = $query->first();
                if (empty($result)) {
                    $this->json(0, "No Data Found");
                }
                if ($result->agency_id != $agency_id) {
                    $this->json(0, "You are not authorized to access this citation detail");
                }
                $this->json(1, "Data Found", $result);
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        } catch (Exception $ex) {
            
        }
    }

    public function citationReport() {
        try {
            $token = $this->request->header('token');
            if ($this->is_token_valid()) {
                $res = $this->fetchTokenDetails($token);
                $agency_id = $res['agency_id'];

                $full_array = array();

                $data = (array) json_decode(file_get_contents('php://input'));
                $id = isset($data['id']) && !empty($data['id']) ? intval($data['id']) : '';
                $query = $this->Citation->findById($id)->contain(['City', 'State', 'Country']);
                $result = $query->first();
                if (empty($result)) {
                    $this->json(0, "No Data Found");
                }
                if ($result->agency_id != $agency_id) {
                    $this->json(0, "You are not authorized to access this citation detail");
                }
                $full_array['citation_detail'] = $result;

                $reportquery = $this->Citationlist->find("all", [
                    "conditions" => ['Citationlist.citation_id' => $id],
                    'order' => ['last_run' => 'DESC'],
                    'limit' => 1,
                ]);

                // citation_mode " -1 : (not run yet anytime), 0 : not running, 1: running
                $full_array['citation_mode'] = "-1";
                $report = $reportquery->first();
                if (!empty($report)) {
                    $full_array['citation_mode'] = "1";
                    if (strtolower($report->status) != 'completed') {
                        $full_array['citation_mode'] = "0";
                    }
                }

                $full_array['citation_report'] = '';
                // citationlist has data
                if ($full_array['citation_mode'] == "0") {
                    $full_array['citation_report'] = $report;
                } else if ($full_array['citation_mode'] == "1") {
                    // in case if report is running
                    $newreportquery = $this->Citationlist->find("all", [
                        "conditions" => ['Citationlist.citation_id' => $id, 'LOWER(Citationlist.status)' => 'completed'],
                        'order' => ['last_run' => 'DESC'],
                        'limit' => 1,
                    ]);
                    $secondlastreport = $newreportquery->first();
                    if (!empty($secondlastreport)) {
                        $full_array['citation_report'] = $secondlastreport;
                    }
                }

                $this->json(1, "Data Found", $full_array);
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        } catch (Exception $ex) {
            
        }
    }

    /**
     * Date :- 27-june-17
     * Function disc :- Function for run citations for get and store report id 
     * Required Parameter :- Business Info's Business name, phone and street address (city, state, zip) should not be empty (when not using business info from location)
     */
    public function runCitation() {
        try {
            $this->autoRender = false;
            if (TEMPDISABLED == 1) {
                $this->json(1, "Citation is runing successfully.");
            }
            $new_citation = []; // empty array for store details 
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));

                    $arvalidation = array();
                    if (!isset($data['citation_id']) || $data['citation_id'] == "") {

                        $arvalidation['citation_id'] = "Please provide citation_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    $citation_id = $data['citation_id'];
                    $locationData = $this->getLocationData($citation_id);

                    if (!empty($locationData)) {

                        /* set array for citations */
                        $new_citation["Name"] = $locationData['name'];
                        $new_citation["BusinessInfo"]["BusinessName"] = $locationData['name'];
                        $new_citation["BusinessInfo"]["StreetAddress"] = $locationData['address'];
                        $new_citation['BusinessInfo']['City'] = $locationData['city'];
                        $new_citation['BusinessInfo']['State'] = $locationData['state'];
                        $new_citation['BusinessInfo']['ZipCode'] = $locationData['zip_code'];
                        $new_citation['BusinessInfo']['WebsiteUrl'] = $locationData['url'];
                        $new_citation['BusinessInfo']['PhoneNumber'] = $locationData['phone'];
                        $new_citation['BusinessInfo']['Country'] = $locationData['country'];
                        $new_citation['KeywordSearchesForCompetitiveAnalysis']['Keyword'] = $locationData['search_keywords'];
                        $new_citation['KeywordSearchesForCompetitiveAnalysis']['GoogleLocation'] = $locationData['geo_location'];
                        $new_citation['TotalCompetitorsToAnalyze'] = 10;
                        $new_citation['NumResultsToGatherPerQuery'] = 200;
                        $new_citation['GatherCitationStrengthData'] = true;
                    }

                    $placesscoutDetails = $this->placesscout_api_info(); // accessing api credentials
                    if (!empty($placesscoutDetails)) {
                        $username = $placesscoutDetails["username"];
                        $password = $placesscoutDetails["password"];
                        $main_api_url = $placesscoutDetails["main_api_url"];

                        try {
                            /* Running citations report */
                            $curl_url = 'citationreports';
                            $contentType = "Content-Type: application/json";
                            $new_citations = $this->pc_post($username, $password, $main_api_url, $curl_url, json_encode($new_citation), array("contentType" => "Content-Type: application/json")); //Create New Citaions
                            $reports = json_decode($new_citations);

                            $ReportId = $reports->id; //  get report id from citation 

                            if (!empty($ReportId) && $ReportId != "") {

                                $check = $this->check_reportId($ReportId);

                                if ($check == 0) {
                                    $model = $this->loadModel('Citationlist');
                                    $insert = $model->newEntity();
                                    $insert->location_id = $locationData['location_id'];
                                    $insert->citation_id = $locationData['id'];
                                    $insert->reportId = $ReportId;
                                    $insert->status = 'In Progress';
                                    $insert->last_run = date('Y-m-d H:i:s');
                                    $insert->created = date('Y-m-d H:i:s');
                                    $insert->created_by = $locationData['location_id'];
                                    $insert->modified_by = $locationData['location_id'];

                                    if ($model->save($insert)) {
                                        // Run citaion report
                                        $citation_run['ReportId'] = $ReportId;
                                        $curl_url = 'citationreports/' . $ReportId . '/runreport';
                                        $citations_run = $this->pc_post($username, $password, $main_api_url, $curl_url, json_encode($citation_run), array("contentType" => "Content-Type: application/json")); // Citations report run
                                        $this->json(1, "Citation is runing successfully.");
                                    } else {
                                        $this->json(0, "Citation database Error occured");
                                    }
                                }
                            } else {
                                $this->json(0, "Report Id not found , citation Error");
                            }
                        } catch (Exception $e) {
                            
                        }
                    }
                }
            }
        } catch (Exception $ex) {
            $this->json(0, "Exception", $ex->getMessage());
        }
    }

    /**
     * Date :- 27-june-17
     * Function disc :- function for get location details from database 
     * Required Parameter :- Location id 
     */
    private function getLocationData($citation_id) {

        $conn = ConnectionManager::get('default');
        $query = "SELECT tbl_citations.id,tbl_citations.search_keywords, tbl_citations.geo_location, tbl_citations.location_id, tbl_citations.agency_id, tbl_citations.name, tbl_citations.url, tbl_citations.services, tbl_citations.phone, tbl_citations.address, tbl_citations.zip_code, tbl_countries.country, tbl_cities.name as city, tbl_states.name as state
                    FROM tbl_citations
                    LEFT JOIN tbl_countries ON tbl_countries.id = tbl_citations.country_id
                    LEFT JOIN tbl_cities ON tbl_citations.city_id = tbl_cities.id 
                    LEFT JOIN tbl_states ON tbl_states.id = tbl_citations.state_id
                    WHERE tbl_citations.id = '" . $citation_id . "' AND tbl_citations.status <> 0 ORDER BY `tbl_citations`.`modified` DESC LIMIT 1; ";

        $stmt = $conn->execute($query)->fetch('assoc');

        if (!empty($stmt)) {
            return $stmt;
        } else {
            return false;
        }
    }

    /**
     * Date :- 27-june-17
     * Function disc :- function for check report id is in database or not
     * Required Parameter :- Report id 
     */
    private function check_reportId($reportId) {
        $table = $this->loadModel('Citationlist');
        $total = $table->find("all")->where(["reportId" => $reportId])->count();
        if ($total > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    /**
     * Date :- 27-june-17
     * Update :- 28-june-17
     * Function disc :- function for Re run citation report 
     * Required Parameter :- location_id 
     */
    public function reRunCitations() {
        $this->autoRender = false;

        try {
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {
                    
                    $token = $token = $this->request->header('token');
                    $tokenData = $this->fetchTokenDetails($token);
                    
                    if (!empty($tokenData)) {
                        $user_id = $tokenData["user_id"];
                    } else {
                        $user_id = "";
                    }
                    
                    $data = (array) json_decode(file_get_contents('php://input'));

                    $arvalidation = array();
                    if (!isset($data['citation_id']) || $data['citation_id'] == "") {

                        $arvalidation['citation_id'] = "Please provide citation_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    $citation_id = $data['citation_id'];

                    $locationData = $this->getLocationData($citation_id); // get location details

                    if (!empty($locationData)) {

                        /* set array for citations */
                        $new_citation["Name"] = $locationData['name'];
                        $new_citation["BusinessInfo"]["BusinessName"] = $locationData['name'];
                        $new_citation["BusinessInfo"]["StreetAddress"] = $locationData['address'];
                        $new_citation['BusinessInfo']['City'] = $locationData['city'];
                        $new_citation['BusinessInfo']['State'] = $locationData['state'];
                        $new_citation['BusinessInfo']['ZipCode'] = $locationData['zip_code'];
                        $new_citation['BusinessInfo']['WebsiteUrl'] = $locationData['url'];
                        $new_citation['BusinessInfo']['PhoneNumber'] = $locationData['phone'];
                        $new_citation['BusinessInfo']['Country'] = $locationData['country'];
                        $new_citation['KeywordSearchesForCompetitiveAnalysis']['Keyword'] = $locationData['search_keywords'];
                        $new_citation['KeywordSearchesForCompetitiveAnalysis']['GoogleLocation'] = $locationData['geo_location'];
                        $new_citation['TotalCompetitorsToAnalyze'] = 10;
                        $new_citation['NumResultsToGatherPerQuery'] = 200;
                        $new_citation['GatherCitationStrengthData'] = true;
                    }
                    
                    $table = $this->loadModel('Citationlist');

                    $data = $table->find("all")->where(["citation_id" => $citation_id, "status" => "complete"])->order(["id" => "DESC"])->first();

                    if (!empty($data)) {
                        $citationData = $data->toArray();
                        $new_citation['ReportId'] = $citationData["reportId"]; // report id from database 

                        $checkData = $this->checkStatus($new_citation['ReportId']); // calling function check status 
                        if ($checkData == 1) {

                            $placesscoutDetails = $this->placesscout_api_info(); // accessing api credentials

                            if (!empty($placesscoutDetails)) {
                                $username = $placesscoutDetails["username"];
                                $password = $placesscoutDetails["password"];
                                $main_api_url = $placesscoutDetails["main_api_url"];

                                if (!empty($new_citation['ReportId'])) {

                                    /* Citations rerun Process */
                                    $curl_url = 'citationreports/' . $new_citation['ReportId'];
                                    $contentType = "Content-Type: application/json";
                                    $update_citaion = $this->pc_put($username, $password, $main_api_url, $curl_url, json_encode($new_citation), array("contentType" => "Content-Type: application/json"));
                                    $update_citaion = json_decode($update_citaion);

                                    $update = []; // blank array to store update data 

                                    $update["rerun"] = "Yes";
                                    $update["last_run"] = date("Y-m-d H:i:s");
                                    $update["modified_by"] = $user_id;
                                    $update["citation_id"] = $citationData['citation_id'];
                                    $update["reportId"] = $citationData['reportId'];
                                    $update["status"] = "In Progress";

                                    /* Insert a new citation report (re-run) */
                                    $insert = $table->newEntity();
                                    $insert->location_id = $data["location_id"];
                                    $insert->citation_id = $update["citation_id"];
                                    $insert->reportId = $update["reportId"];
                                    $insert->status = $update["status"];
                                    $insert->rerun = $update["rerun"];
                                    if ($table->save($insert)) {
                                        $citation_run['ReportId'] = $new_citation['ReportId'];
                                        $curl_url = 'citationreports/' . $new_citation['ReportId'] . '/runreport';
                                        $citations_run_result = $this->pc_post($username, $password, $main_api_url, $curl_url, json_encode($citation_run), array("contentType" => "Content-Type: application/json"));

                                        $this->json("1", "Citations Rerun Successfully.");
                                    } else {
                                        $this->json(0, "Rerun Process Failled.");
                                    }
                                } else {
                                    $this->json(0, "Report id not found.");
                                }
                            }
                        } else {
                            $this->json(0, "Citations is already in progress.");
                        }
                    } else {
                        $this->json(0, "Invalid Location id");
                    }
                } else {
                    $this->json(0, "Invalid Token");
                }
            }
        } catch (\Exception $ex) {
            
        }
    }

    /**
     * Date :- 29-june-17
     * Function disc :- Function for check status into database 
     * Required Parameter :- Report id 
     */
    private function checkStatus($reportId) {
        $table = $this->loadModel("Citationlist");
        $data = $table->find('all')->where(["reportId" => $reportId])->toArray();
        if (!empty($data)) {
            $status = $data[0]->status;
            if ($status == "complete") {
                return 1;
            } else {
                return 0;
            }
        }
    }

    /**
     * Date :- 29-june-17
     * Updated :- 30-june-17
     * Updated :- 1-july-17
     * Function disc :- function for get primary citations details 
     */
    public function getPrimaryCitations() {

        $this->autoRender = false;
        $result = array();
        $graphArr = array(); // array to store graph value 
        $search_val = "";
        $limit = 10;
        $page = 1;
        $status = "";

        try {
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));
                    $page = isset($data["offset"]) && !empty($data["offset"]) ? $data["offset"] : $page; // set page from body
                    $limit = isset($data["limit"]) && !empty($data["limit"]) ? $data["limit"] : $limit; // set limit from body
                    $search_val = isset($data['search_txt']) && !empty($data['search_txt']) ? $data['search_txt'] : $search_val; // set var for search by web-name 
                    $sortby = isset($data["sortby"]) ? $data["sortby"] : "score";
                    $orderby = isset($data["orderby"]) ? $data["orderby"] : "desc";

                    $arvalidation = array();
                    if (!isset($data['citation_id']) || $data['citation_id'] == "") {

                        $arvalidation['citation_id'] = "Please provide citation_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    $citation_id = $data['citation_id'];

                    $table = $this->loadModel('Citationlist');
                    $data = $table->find('all')->where(["citation_id" => $citation_id])->order(["id" => "DESC"])->first();
                    
                    $primaryIds = array();

                    if (!empty($data)) {

                        if ($data->status == "In Progress") {
                            $this->json(0, "Citation Report is in progress");
                        }

                        /* Geting details from citations table */
                        $mainData = $this->getDetails($data->citation_id);
                        $citationData = !empty($data->citations_data) && isset($data->citations_data) ? \json_decode($data->citations_data) : "";

                        //pr($citationData->citations); die('here');
                        
                        if (!empty($citationData->citations)) {
                            $num = 0;

                            /* Varible used for graph */
                            $graphArr["correctBusignessName"] = 0;
                            $graphArr["errorBusignessName"] = 0;
                            $graphArr["correctAddress"] = 0;
                            $graphArr["errorAddress"] = 0;
                            $graphArr["corectUrl"] = 0;
                            $graphArr["errorUrl"] = 0;
                            $graphArr["correctPhone"] = 0;
                            $graphArr["errorPhone"] = 0;
                            $graphArr["correctZip"] = 0;
                            $graphArr["errorZip"] = 0;
                            $graphArr["topCitationAudit"] = 0;
                            $graphArr["topCitationAuditError"] = 0;
                            $total = 0;
                            $verified = 0;
                            
                            foreach ($citationData->citations as $val):

                                /* Calculate score and verified */
                                $is_verifed = $val->isCitationVerified;
                                $total += 1;

                                if ($is_verifed == false && $is_verifed == "") {
                                    
                                } else {
                                    $verified += 1;
                                }

                                $check = $this->isPrimary($val->name); // calling function for check site is primary
                                $path = Router::url('/', true);

                                if ($check != false && !empty($check)) {

                                    $primaryIds[] = $check[0]->id; // storing primary ids into array 

                                    $result[$num]["logo"] = !empty($check[0]->logo) ? $path . "logos/" . $check[0]->logo : '';
                                    $result[$num]["webname"] = !empty($val->name) ? $this->appendhttp($val->name) : '';
                                    $result[$num]["link"] = !empty($val->link) ? $val->link : '';
                                    $result[$num]["score"] = !empty($check[0]->score) ? $check[0]->score : "";
                                    $result[$num]["nameColor"] = ($val->hasBusinessName == 'Y') ? "#008000" : "#FF0000";
                                    $result[$num]["name"] = !empty($mainData->name) ? $mainData->name : '';
                                    $result[$num]["siteurlColor"] = ($val->hasSiteUrl == 'Y') ? "#008000" : "#FF0000";
                                    $result[$num]["siteurl"] = !empty($mainData->url) ? $mainData->url : '';
                                    $result[$num]["addressColor"] = ($val->hasAddress == 'Y') ? "#008000" : "#FF0000";
                                    $result[$num]["address"] = !empty($mainData->address) ? $mainData->address : '';
                                    $result[$num]["zipColor"] = ($val->hasZip == 'Y') ? "#008000" : "#FF0000";
                                    $result[$num]["zip"] = !empty($mainData->zip_code) ? $mainData->zip_code : '';
                                    $result[$num]["phoneColor"] = ($val->hasPhone == 'Y') ? "#008000" : "#FF0000";
                                    $result[$num]["phone"] = !empty($mainData->phone) ? $mainData->phone : '';
                                    $result[$num]["citation_list_id"] = $data->id;



                                    /* Calculation for graph */
                                    ($val->hasBusinessName == 'Y') ? $graphArr["correctBusignessName"] += 1 : $graphArr["errorBusignessName"] += 1;
                                    ($val->hasPhone == 'Y') ? $graphArr["correctPhone"] += 1 : $graphArr["errorPhone"] += 1;
                                    ($val->hasZip == 'Y') ? $graphArr["correctZip"] += 1 : $graphArr["errorZip"] += 1;
                                    ($val->hasAddress == 'Y') ? $graphArr["correctAddress"] += 1 : $graphArr["errorAddress"] += 1;
                                    ($val->hasSiteUrl == 'Y') ? $graphArr["corectUrl"] += 1 : $graphArr["errorUrl"] += 1;
                                    ($graphArr["errorBusignessName"] == 0 && $graphArr["errorPhone"] == 0 && $graphArr["errorZip"] == 0) ? $graphArr["topCitationAudit"] += 1 : $graphArr["topCitationAuditError"] += 1;

                                    $num ++;
                                }

                            endforeach;

                            //print_R($result); die('here');

                            $score = round(($verified / $total) * 100, 2);

                            /* --- Top Citations Section not in citation result  --- */
                            $ciTable = $this->loadModel('CitationManager');
                            $ciData = $ciTable->find('all')->select(["domain_name", "score", "logo"])->where(["is_top_hundred" => 1, "id NOT IN" => array_unique($primaryIds)])->toArray();

                            $newArray = [];
                            $graphArr["total_score"] = $score;
                            $graphArr["total_top_sites"] = count($ciData);
                            $graphArr["top_citations"] = count($result);
                            $graphArr["topPercent"] = round($graphArr["top_citations"] / $graphArr["total_top_sites"] * 100); // calculate percentage of top websites

                            if (!empty($result)) {

                                /* Adding top citations into result array (Which is not matched) */
                                foreach ($ciData as $key => $res):
                                    $newArray[$key]["logo"] = $path . "logos/" . $res->logo;
                                    $newArray[$key]["webname"] = $this->appendhttp($res->domain_name);
                                    $newArray[$key]["link"] = "";
                                    $newArray[$key]["score"] = $res->score;
                                    $newArray[$key]["nameColor"] = "";
                                    $newArray[$key]["name"] = "";
                                    $newArray[$key]["addressColor"] = "";
                                    $newArray[$key]["address"] = "";
                                    $newArray[$key]["zipColor"] = "";
                                    $newArray[$key]["zip"] = "";
                                    $newArray[$key]["phoneColor"] = "";
                                    $newArray[$key]["phone"] = "";
                                    $newArray[$key]["citation_list_id"] = $data->id;
                                endforeach;

                                $result = array_merge($result, $newArray); // merge both array into one 
                                $result = $this->unique_multidim_array($result, "webname");
                                $result = array_values($result);

                                /* ------ Sorting code ------------ */

                                if ($sortby != '') {
                                    usort($result, function($a, $b) use ($sortby) {
                                        return $a["$sortby"] - $b["$sortby"];
                                    });
                                }
                                if ($orderby == "desc") {
                                    $result = array_reverse($result);
                                }


                                /* Code for searching */
                                if (!empty($search_val) && $search_val != '') {

                                    foreach ($result as $out):
                                        if (strpos($out['webname'], $search_val) !== false) {
                                            $new[] = $out;
                                        }
                                    endforeach;

                                    $result = $new; // add searched value into variable 
                                }

                                /* ---------------------- */

                                /* array pagination logic */
                                $return = [];
                                $count = count($result);
                                $totalPage = $count / $limit;

                                if ($count > $limit) {
                                    $range = $limit * $page;

                                    if ($page == 1) {
                                        $start = 0;
                                    } else if ($page == 2) {
                                        $start = $limit;
                                    } else if ($page > 2) {
                                        $start = $range - $limit;
                                    }

                                    for ($i = $start; $i < $range; $i++) {
                                        $return[] = @$result[$i];
                                    }

                                    /* pagination logic end */

                                    /* Combining multiple arrays for output */
                                    $returnData["data"] = array_filter($return);
                                    $returnData["graph"] = $graphArr;
                                    $returnData["total_records"] = $count;
                                    $returnData["total_pages"] = ceil($totalPage);
                                    $returnData["current_page"] = $page;

                                    //pr($returnData); die;



                                    $this->json(1, "Primary Citations List", $returnData);
                                } else {

                                    $returnData["data"] = array_filter($result);
                                    $returnData["graph"] = $graphArr;
                                    $returnData["total_records"] = $count;
                                    $returnData["total_pages"] = 1;
                                    $returnData["current_page"] = 1;

                                    $this->json(1, "Primary Citations List", $returnData);
                                }
                            } else {
                                $this->json(0, "No Primary Citations Found");
                            }
                        }
                        else {
                            $this->json(0, "No Primary Citations Found");
                        }
                    } else {
                        $this->json(0, "No Primary Citations Found");
                    }
                } else {
                    $this->json(0, "Invalid Token");
                }
            } else {
                $this->json(0, "Invalid Request Method.");
            }
        } catch (\Exception $e) {
            
        }
    }

    /**
     * Date :- 29-june-17
     * Function disc :- function for get primary citations details 
     */
    private function isPrimary($domain) {
        $table = $this->loadModel('CitationManager');
        $tableData = $table->find()->where(["is_top_hundred" => 1, "domain_name" => $this->fully_trim($domain)])->toArray();

        if (!empty($tableData)) {
            return $tableData;
        } else {
            return 0;
        }
    }

    /**
     * Date :- 30-june-17
     * Function disc :- function for get details from citations table 
     */
    Private function getDetails($citationsId) {
        $table = $this->loadModel('Citation');
        $data = $table->find("all")->select(['id', 'name', 'phone', 'zip_code', 'address', 'url'])->where(['id' => $citationsId])->first();
        if (!empty($data)) {
            return $data;
        } else {
            return 0;
        }
    }

    /**
     * Date :- 29-june-17
     * Updated :- 30-june-17
     * Updated :- 1-july-17
     * Function disc :- function for get Additional citations details 
     */
    public function getAdditionsCitations() {
        $this->autoRender = false;
        $result = array();
        $limit = 10;
        $page = 1;
        $search_val = "";

        try {
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));

                    $page = isset($data["offset"]) && !empty($data["offset"]) ? $data["offset"] : $page; // set page from body
                    $limit = isset($data["limit"]) && !empty($data["limit"]) ? $data["limit"] : $limit; // set limit from body
                    $search_val = isset($data['search_txt']) && !empty($data["search_txt"]) ? $data['search_txt'] : $search_val; // set var for search by web-name 
                    $sortby = isset($data["sortby"]) ? $data["sortby"] : "score";
                    $orderby = isset($data["orderby"]) ? $data["orderby"] : "desc";

                    $arvalidation = array();
                    if (!isset($data['citation_id']) || $data['citation_id'] == "") {

                        $arvalidation['citation_id'] = "Please provide citation_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    $citation_id = $data['citation_id'];

                    $table = $this->loadModel('Citationlist');
                    $data = $table->find('all')->where(["citation_id" => $citation_id])->order(["id" => "DESC"])->first();

                    if (!empty($data)) {
                        /* Geting details from citations table */
                        $mainData = $this->getDetails($data->citation_id);
                        $citationData = json_decode($data->citations_data);

                        if (!empty($citationData->citations)) {
                            $num = 0;
                            foreach ($citationData->citations as $val):

                                $check = $this->isPrimary($val->name); // calling function for check site is primary

                                if ($check == 0) {

                                    $result[$num]["webname"] = !empty($val->name) ? $this->appendhttp($val->name) : '';
                                    $result[$num]["link"] = !empty($val->link) ? $val->link : '';
                                    $result[$num]["score"] = !empty($check[0]->score) ? $check[0]->score : "";
                                    $result[$num]["nameColor"] = ($val->hasBusinessName == 'Y') ? "#008000" : "#FF0000";
                                    $result[$num]["name"] = !empty($mainData->name) ? $mainData->name : '';
                                    $result[$num]["siteurlColor"] = ($val->hasSiteUrl == 'Y') ? "#008000" : "#FF0000";
                                    $result[$num]["siteurl"] = !empty($mainData->url) ? $mainData->url : '';
                                    $result[$num]["addressColor"] = ($val->hasAddress == 'Y') ? "#008000" : "#FF0000";
                                    $result[$num]["address"] = !empty($mainData->address) ? $mainData->address : '';
                                    $result[$num]["zipColor"] = ($val->hasZip == 'Y') ? "#008000" : "#FF0000";
                                    $result[$num]["zip"] = !empty($mainData->zip_code) ? $mainData->zip_code : '';
                                    $result[$num]["phoneColor"] = ($val->hasPhone == 'Y') ? "#008000" : "#FF0000";
                                    $result[$num]["phone"] = !empty($mainData->phone) ? $mainData->phone : '';
                                    $result[$num]["citation_list_id"] = $data->id;

                                    $num ++;
                                }

                            endforeach;

                            /* Code for searching */
                            if (!empty($search_val) && $search_val != '') {
                                $new = [];
                                foreach ($result as $out):
                                    if (strpos($out['webname'], $search_val) !== false) {
                                        $new[] = $out;
                                    }
                                endforeach;

                                $result = $new; // add searched value into variable 
                            }

                            if ($sortby != '') {
                                usort($result, function($a, $b) use ($sortby) {
                                    return $a["$sortby"] - $b["$sortby"];
                                });
                            }
                            if ($orderby == "desc") {
                                $result = array_reverse($result);
                            }

                            $result = $this->unique_multidim_array($result, "webname"); // remove duplicate entry 
                            $result = array_values($result);

                            if (!empty($result)) {

                                /* array pagination logic */
                                $return = [];
                                $count = count($result);
                                $totalPage = $count / $limit;

                                if ($count > $limit) {
                                    $range = $limit * $page;

                                    if ($page == 1) {
                                        $start = 0;
                                    } else if ($page == 2) {
                                        $start = $limit;
                                    } else if ($page > 2) {
                                        $start = $range - $limit;
                                    }

                                    for ($i = $start; $i < $range; $i++) {
                                        $return[] = @$result[$i];
                                    }

                                    $returnData["data"] = array_filter($return);
                                    $returnData["total_records"] = $count;
                                    $returnData["total_pages"] = ceil($totalPage);
                                    $returnData["current_page"] = $page;

                                    $this->json(1, "Additional Citations List", $returnData);
                                } else {
                                    $returnData["data"] = array_filter($result);
                                    $returnData["total_records"] = $count;
                                    $returnData["total_pages"] = ceil($totalPage);
                                    $returnData["current_page"] = $page;

                                    $this->json(1, "Additional Citations List", $returnData);
                                }
                            } else {
                                $this->json(0, "No Additional Citations Found");
                            }
                        } else {
                            $this->json(0, "No Additional Citations Found");
                        }
                    } else {
                        $this->json(0, "No Additional Citations Found");
                    }
                } else {
                    $this->json(0, "Invalid Token");
                }
            } else {
                $this->json(0, "Invalid Request Method.");
            }
        } catch (\Exception $e) {
            
        }
    }

    /**
     * Date :- 30-june-17
     * Updated :- 1-july-17
     * Function disc :- Function for get Competitor Citations report 
     */
    public function getCompetitorCitations() {

        $this->autoRender = false;
        $result = []; // blank array to store Result 
        $limit = 10;
        $page = 1;
        $search_val = "";
        try {
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));
                    $page = isset($data["page"]) && !empty($data["offset"]) ? $data["offset"] : $page; // set page from body
                    $limit = isset($data["limit"]) && !empty($data["limit"]) ? $data["limit"] : $limit; // set limit from body 
                    $search_val = isset($data['search_txt']) && !empty($data["search_txt"]) ? $data['search_txt'] : $search_val; // set var for search by web-name 
                    $sortby = isset($data["sortby"]) ? $data["sortby"] : "keyword";
                    $orderby = isset($data["orderby"]) ? $data["orderby"] : "desc";

                    $arvalidation = array();
                    if (!isset($data['citation_id']) || $data['citation_id'] == "") {

                        $arvalidation['citation_id'] = "Please provide citation_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    /* Get value form citation list table */
                    $citation_id = $data['citation_id'];
                    $table = $this->loadModel('Citationlist');
                    $data = $table->find('all')->where(["citation_id" => $citation_id])->order(["id" => "DESC"])->first();

                    if (!empty($data)) {
                        $competitiveJson = $data->competitive_citation; // getting value from database
                        if (!empty($competitiveJson)) {
                            $competitiveData = json_decode($competitiveJson);
                            $competitiveCitationsData = $competitiveData->competitorCitationData;

                            /* Loop for set competitor citations value into array */
                            foreach ($competitiveCitationsData as $key => $val):
                                $citationsReportId = str_replace("/citations", "", $val->citationReportCitationsId); // citation report id 
                                $result[$key]["keyword"] = $val->serpData->keywordSearch->keyword;
                                $result[$key]["googleLocation"] = $val->serpData->keywordSearch->googleLocation;
                                $result[$key]["resultType"] = $val->serpData->serpResult->resultType;
                                $result[$key]["rank"] = $val->serpData->serpResult->rank;
                                $result[$key]["title"] = $val->serpData->serpResult->title;
                                $result[$key]["totalVerifiedCitations"] = $val->citationReportRun->totalVerifiedCitations;
                                $result[$key]["mentions"] = $val->citationReportRun->totalMentions;
                                $result[$key]["averageDomainAuthority"] = sprintf("%.2f", $val->citationReportRun->averageDomainAuthority);
                                $result[$key]["averagePageAuthority"] = sprintf("%.2f", $val->citationReportRun->averagePageAuthority);
                                $result[$key]["averageMozRank"] = sprintf("%.2f", $val->citationReportRun->averageMozRank);
                                $result[$key]["averageLinks"] = sprintf("%.2f", $val->citationReportRun->averageLinks);
                                $result[$key]["citation_list_id"] = $data->id;
                                $result[$key]["citation_report_id"] = $citationsReportId;
                            endforeach;
                        }

                        /* Code for searching */
                        if (!empty($search_val) && $search_val != '') {
                            $new = [];
                            foreach ($result as $out):
                                if (strpos($out['title'], $search_val) !== false) {
                                    $new[] = $out;
                                }
                            endforeach;

                            $result = $new; // add searched value into variable 
                        }

                        if ($sortby != '') {
                            usort($result, function($a, $b) use ($sortby) {
                                return $a["$sortby"] - $b["$sortby"];
                            });
                        }
                        if ($orderby == "desc") {
                            $result = array_reverse($result);
                        }

                        if (!empty($result)) {

                            /* array pagination logic */
                            $return = [];
                            $count = count($result);
                            $totalPage = $count / $limit;

                            if ($count > $limit) {
                                $range = $limit * $page;

                                if ($page == 1) {
                                    $start = 0;
                                } else if ($page == 2) {
                                    $start = $limit;
                                } else if ($page > 2) {
                                    $start = $range - $limit;
                                }

                                for ($i = $start; $i < $range; $i++) {
                                    $return[] = @$result[$i];
                                }

                                $returnData["data"] = array_filter($return);
                                $returnData["total_records"] = $count;
                                $returnData["total_pages"] = ceil($totalPage);
                                $returnData["current_page"] = $page;

                                $this->json(1, "Competitor Citations List", $returnData);
                            } else {

                                $returnData["data"] = array_filter($result);
                                $returnData["total_records"] = $count;
                                $returnData["total_pages"] = ceil($totalPage);
                                $returnData["current_page"] = $page;
                                $this->json(1, "Competitor Citations List", $returnData);
                            }
                        } else {
                            $this->json(0, "No Competitor Citation Found");
                        }
                    } else {
                        $this->json(0, "No Competitor Citation Found");
                    }
                } else {
                    $this->json(0, "Invalid token");
                }
            } else {
                $this->json(0, 'Invalid Request Method.');
            }
        } catch (\Exception $e) {
            
        }
    }

    /**
     * Date :- 30-june-17
     * Updated :- 1-july-17
     * Function disc :- Function for get Citations opportunities 
     */
    public function getCitationsOpportunities() {
        $this->autoRender = false;
        $citation_opp_arr = []; // blank array to store Result
        $limit = 10;
        $page = 1;
        $search_val = "";

        try {
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));

                    $page = isset($data["offset"]) && !empty($data["offset"]) ? $data["offset"] : $page; // set page from body
                    $limit = isset($data["limit"]) && !empty($data["limit"]) ? $data["limit"] : $limit; // set limit from body 
                    $search_val = isset($data['search_txt']) && !empty($data["search_txt"]) ? $data['search_txt'] : $search_val; // set var for search by web-name 
                    $sortby = isset($data["sortby"]) ? $data["sortby"] : "site";
                    $orderby = isset($data["orderby"]) ? $data["orderby"] : "desc";

                    $arvalidation = array();
                    if (!isset($data['citation_id']) || $data['citation_id'] == "") {

                        $arvalidation['citation_id'] = "Please provide citation_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    /* Get value form citation list table */
                    $citation_id = $data['citation_id'];
                    $table = $this->loadModel('Citationlist');
                    $data = $table->find('all')->select(["citation_id", "id"])->where(["citation_id" => $citation_id])->first();

                    if (empty($data)) {
                        $this->json(0, "Citations Opportunities Not Found");
                    }

                    if ($data->citation_id != "" && !empty($data->citation_id)) {
                        $db = TableRegistry::get('tbl_citation_competitor');
                        $citationsOpportunitiesData = $db->find()->select(["citations"])->where(["citation_tracker_id" => $data->id])->order(["created" => 'DESC'])->first();

                        if (!empty($citationsOpportunitiesData->citations)) {
                            $citation_data = json_decode($citationsOpportunitiesData->citations); // data from tbl_citation_competitor 
                            $citation_report = $citation_data[0]->citations;
                            if (!empty($citation_report)) {
                                $i = 0;
                                foreach ($citation_report as $key => $value):

                                    $isCitationVerified = $value->isCitationVerified;
                                    $isCitationVerified = $isCitationVerified == 1 ? 'Y' : 'N';
                                    $sc_pa = $sc_da = '';
                                    $mozRank = 0;
                                    if (isset($value->seoMozData->domainAuthority)) {

                                        $sc_da = round($value->seoMozData->domainAuthority, 2);
                                        $mozRank = round($value->seoMozData->rootDomainMozRank, 2);
                                        $sc_pa = round($value->seoMozData->pageAuthority, 2);
                                    }


                                    if (isset($citation_opp_arr[$value->name])) {

                                        $citation_opp_arr[$i]['num_competitor'] += 1;

                                        if ($sc_da > $citation_opp_arr[$i]['DA']) {
                                            $citation_opp_arr[$i]['DA'] = $sc_da;
                                        }
                                        if ($mozRank > $citation_opp_arr[$i]['mozRank']) {
                                            $citation_opp_arr[$i]['mozRank'] = $mozRank;
                                        }
                                    } else {

                                        $citation_opp_arr[$i]['site'] = $this->appendhttp($value->name);
                                        $citation_opp_arr[$i]['link'] = $value->link;
                                        $citation_opp_arr[$i]['DA'] = $sc_da;
                                        $citation_opp_arr[$i]['num_competitor'] = 1;
                                        $citation_opp_arr[$i]['mozRank'] = $mozRank;
                                        if (isset($citaion_site_list[$i])) {
                                            $citation_opp_arr[$i]['total_citaion'] = $citaion_site_list[$value->name];
                                            $citation_opp_arr[$i]['have_citation'] = 'Y';
                                        } else {
                                            $citation_opp_arr[$i]['total_citaion'] = 0;
                                            $citation_opp_arr[$i]['have_citation'] = 'N';
                                        }
                                    }
                                    $citation_opp_arr[$i]["citation_list_id"] = $data->id;

                                    $i++;
                                endforeach;

                                $citation_opp_arr = $this->unique_multidim_array($citation_opp_arr, 'site'); // remove duplicate entry from array

                                if (!empty($citation_opp_arr)) {

                                    /* Code for searching */
                                    if (!empty($search_val) && $search_val != '') {
                                        $new = [];
                                        foreach ($citation_opp_arr as $out):
                                            if (strpos($out['site'], $search_val) !== false) {
                                                $new[] = $out;
                                            }
                                        endforeach;

                                        $citation_opp_arr = $new; // add searched value into variable 
                                    }

                                    /* Sorting code */

                                    if ($sortby != '') {
                                        usort($citation_opp_arr, function($a, $b) use ($sortby) {
                                            return $a["$sortby"] - $b["$sortby"];
                                        });
                                    }

                                    if ($orderby == "desc") {
                                        $citation_opp_arr = array_reverse($citation_opp_arr);
                                    }

                                    /* array pagination logic */
                                    $return = [];
                                    $count = count($citation_opp_arr);

                                    /* Total opportunities here */

                                    $totalPage = $count / $limit;

                                    if ($count > $limit) {
                                        $range = $limit * $page;

                                        if ($page == 1) {
                                            $start = 0;
                                        } else if ($page == 2) {
                                            $start = $limit;
                                        } else if ($page > 2) {
                                            $start = $range - $limit;
                                        }

                                        for ($i = $start; $i < $range; $i++) {
                                            $return[] = @$citation_opp_arr[$i];
                                        }

                                        $returnData["data"] = array_filter($return);
                                        $returnData["total_records"] = $count;
                                        $returnData["total_pages"] = ceil($totalPage);
                                        $returnData["current_page"] = $page;

                                        $this->json(1, "Citations Opportunoties data List", $returnData);
                                    } else {

                                        $returnData["data"] = array_filter($citation_opp_arr);
                                        $returnData["total_records"] = $count;
                                        $returnData["total_pages"] = ceil($totalPage);
                                        $returnData["current_page"] = $page;
                                        $this->json(1, "Citations Opportunoties data List", $returnData);
                                    }
                                } else {
                                    $this->json(0, "Citations Opportunities Not Found");
                                }
                            }
                        } else {
                            $this->json(0, "Citations Opportunities Not Found");
                        }
                    } else {
                        $this->json(0, "Citations Opportunities Not Found");
                    }
                } else {
                    $this->json(0, "Invalid token");
                }
            } else {
                $this->json(0, 'Invalid Request Method.');
            }
        } catch (\Exception $e) {
            
        }
    }

    /**
     * Date :- 1-july-17
     * Updated :- 04-july-17
     * Function disc :- Function for get Citations history
     */
    public function getCitationsHistory() {
        $this->autoRender = false;
        $history = array();
        $verified = 0;
        $not_verified = 0;
        $total = 0;
        $attention = 0;
        $total_primary = 0;
        $total_additional = 0;
        $total_competitor = 0;
        $total_opportunities = 0;
        $limit = 10;
        $page = 1;
        $search_val = "";

        $returnArr = array();
        try {
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));

                    $page = isset($data["offset"]) && !empty($data["offset"]) ? $data["offset"] : $page; // set page from body
                    $limit = isset($data["limit"]) && !empty($data["limit"]) ? $data["limit"] : $limit; // set limit from body 
                    $search_val = isset($data['search_txt']) && !empty($data["search_txt"]) ? $data['search_txt'] : $search_val; // set var for search by web-name 
                    $sortby = isset($data["sortby"]) ? $data["sortby"] : "total_score";
                    $orderby = isset($data["orderby"]) ? $data["orderby"] : "desc";

                    $arvalidation = array();
                    if (!isset($data['citation_id']) || $data['citation_id'] == "") {

                        $arvalidation['citation_id'] = "Please provide citation_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    /* Get value form citation list table */
                    $citation_id = $data['citation_id'];

                    $table = $this->loadModel('Citationlist');
                    $tblData = $table->find('all')->select(["citations_data", "reportId", "last_run", "modified", "competitive_citation", "citation_id"])->where(["citation_id" => $citation_id, "status" => "complete"])->order(["modified" => 'DESC'])->toArray();
                    $primaryIds = array();
                    $i = 0;
                    if (!empty($tblData)) {
                        foreach ($tblData as $val):
                            $history[$i]["run_date"] = !empty($val->modified) ? date('d M Y g:i A', strtotime($val->modified)) : "";
                            $citations_data = json_decode($val->citations_data);
                            
                            if (!empty($citations_data)) {

                                foreach ($citations_data->citations as $value):
                                    $is_verifed = $value->isCitationVerified;
                                    $total += 1;
                                    if ($is_verifed == false && $is_verifed == "") {
                                        $not_verified += 1;
                                    } else {
                                        $verified += 1;
                                    }

                                    if ($value->citationStatus = "NeedsAttention") {
                                        $attention += 1;
                                    }

                                    $check = $this->isPrimary($value->name);

                                    /* condition for get total primary citation */
                                    if ($check != false && !empty($check)) {

                                        $primaryIds[] = $check[0]->id;
                                        $total_primary += 1; // count primary citation
                                    } else {
                                        $total_additional += 1; // count additional citation 
                                    }

                                endforeach;
                                $total_primary = 0;
                                /* --- Top Citations Section not in citation result  --- */
                                if(!empty($primaryIds)){
                                    $ciTable = $this->loadModel('CitationManager');
                                    $ciData = $ciTable->find('all')->where(["is_top_hundred" => 1, "id NOT IN" => array_unique($primaryIds)])->toArray();

                                    $total_primary += count($ciData); // total primary citation value
                                }

                                /* -------------------- Competetive section ------------ */

                                $competitiveJson = $val->competitive_citation; // getting value from database
                                if (!empty($competitiveJson)) {
                                    $competitiveData = json_decode($competitiveJson);
                                    $competitiveCitationsData = $competitiveData->competitorCitationData;
                                    $total_competitor = count($competitiveCitationsData);
                                }

                                /* ----------------- Opportunities ------------------- */

                                $db = TableRegistry::get('tbl_citation_competitor');
                                $citationsOpportunitiesData = $db->find()->select(["citations"])->where(["citation_tracker_id" => $val->citation_id . "/citations"])->order(["created" => 'DESC'])->first();

                                if (!empty($citationsOpportunitiesData->citations)) {
                                    $citation_data = json_decode($citationsOpportunitiesData->citations); // data from tbl_citation_competitor 
                                    $citation_report = $citation_data[0]->citations;
                                    $total_opportunities = count($citation_report);
                                }


                                $history[$i]["total_primary"] = $total_primary;
                                $history[$i]["total_additional"] = $total_additional;
                                $history[$i]["total_competitor"] = $total_competitor;
                                $history[$i]["total_opportunities"] = $total_opportunities;
                                $history[$i]["verified"] = $verified;
                                $history[$i]["not_verified"] = $not_verified;
                                $history[$i]["total"] = $total;
                                $history[$i]["total_score"] = round(($history[$i]["verified"] / $history[$i]["total"]) * 100, 2);
                                $history[$i]["need_attention"] = $attention;
                            }

                            $i++;

                        endforeach;
                        
                        
                        /* Code for searching */
                        if (!empty($search_val) && $search_val != '') {
                            $new = [];
                            foreach ($history as $out):
                                if (strpos($out['total_score'], $search_val) !== false) {
                                    $new[] = $out;
                                }
                            endforeach;

                            $history = $new; // add searched value into variable 
                        }

                        /* Sorting code */

                        if ($sortby != '') {
                            usort($history, function($a, $b) use ($sortby) {
                                return $a["$sortby"] - $b["$sortby"];
                            });
                        }

                        if ($orderby == "desc") {
                            $history = array_reverse($history);
                        }

                        /* array pagination logic */
                        $return = [];
                        $count = count($history);

                        /* Total opportunities here */

                        $totalPage = $count / $limit;

                        if ($count > $limit) {

                            $range = $limit * $page;

                            if ($page == 1) {
                                $start = 0;
                            } else if ($page == 2) {
                                $start = $limit;
                            } else if ($page > 2) {
                                $start = $range - $limit;
                            }

                            for ($i = $start; $i < $range; $i++) {
                                $return[] = @$history[$i];
                            }

                            $returnData["data"] = array_filter($return);
                            $returnData["total_records"] = $count;
                            $returnData["total_pages"] = ceil($totalPage);
                            $returnData["current_page"] = $page;

                            $this->json(1, "Citations History data List", $returnData);
                        } else {

                            $returnData["data"] = array_filter($history);
                            $returnData["total_records"] = $count;
                            $returnData["total_pages"] = ceil($totalPage);
                            $returnData["current_page"] = $page;
                            $this->json(1, "Citations History data List", $returnData);
                        }
                    } else {
                        $this->json(0, "No Data Found");
                    }

                    if (!empty($history)) {

                        $this->json(1, "Citation Historical Data", $history);
                    } else {
                        $this->json(0, "No citations History Found");
                    }
                } else {
                    $this->json(0, "Invalid token");
                }
            } else {
                $this->json(0, 'Invalid Request Method.');
            }
        } catch (\Exception $e) {
            
        }
    }

    /**
     * Date :- 3-july-17
     * Function disc :- Function for delete citation from database 
     * Parameter :- token (header), Location_id (body)
     */
    public function deleteCitations() {
        $this->autoRender = false;
        try {
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));

                    $arvalidation = array();
                    if (!isset($data['citation_id']) || $data['citation_id'] == "") {

                        $arvalidation['citation_id'] = "Please provide citation_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    //$location_id = $data['location_id'];
                    $citation_id = $data['citation_id'];
                    
                    $update = array("location_id" => 0, "deleted_location_id" => $citation_id);

                    $table = $this->loadModel('Citation');
                    $data = $table->find('all')->where(["id" => $citation_id])->order(["modified" => "DESC"])->toArray();

                    if (!empty($data) && isset($data)) {

                        $id = $data[0]->id; // id from tbl_citation table 

                        $query = $table->query();
                        $citationList = $this->loadModel('Citationlist');
                        $citationListData = $citationList->find('all')->where(["citation_id" => $id])->order(["modified" => "DESC"])->toArray();

                        if ($query->update()->set($update)->where(["id" => $id])->execute()) {

                            if (!empty($citationListData)) {
                                $citationListId = !empty($citationListData[0]->id) ? $citationListData[0]->id : '';

                                $this->deletePlacescoutReport($citationListData[0]->reportId); // calling function for delete report id from place scout 

                                $entity = $citationList->get($citationListId);
                                if ($citationList->delete($entity)) {
                                    $this->json(1, "Citation Deleted successfully");
                                } else {
                                    $this->json(1, "Citation deleted , but no citation list found");
                                }
                            } else {
                                $this->json(1, "Citation deleted , but no citation list found");
                            }

                            $this->json(1, "Citation deleted successfully");
                        } else {
                            $this->json(0, "Error occured");
                        }
                    } else {
                        $this->json(0, "No Data Found");
                    }
                } else {
                    $this->json(0, "Invalid token");
                }
            } else {
                $this->json(0, 'Invalid Request Method.');
            }
        } catch (\Exception $ex) {
            
        }
    }

    /**
     * Date :- 3-july-17
     * Function disc :- Function for delete citation from Place scout
     */
    private function deletePlacescoutReport($reportId) {

        try {
            $placesscoutDetails = $this->placesscout_api_info(); // accessing api credentials
            if (!empty($placesscoutDetails)) {
                $username = $placesscoutDetails["username"];
                $password = $placesscoutDetails["password"];
                $main_api_url = $placesscoutDetails["main_api_url"];

                $curl_url = 'citationreports';
                $new_citations = $this->pc_delete($username, $password, $main_api_url, $curl_url, array("contentType" => "Content-Type: application/json")); //Create New Citaions
            }
        } catch (Exception $ex) {
            
        }
    }

    /**
     * Date :- 04-july-17
     * Function disc:- Function for get total of all report 
     */
    public function getTotal() {

        $this->autoRender = false;

        $total_primary = 0;
        $total_additional = 0;
        $total_opportunities = 0;
        $total_competitor = 0;
        $return = array(); // blank array to save data to return 
        $primaryIds = array();
        
        try {
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));

                    $arvalidation = array();
                    if (!isset($data['citation_id']) || $data['citation_id'] == "") {

                        $arvalidation['citation_id'] = "Please provide citation_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    $citation_id = $data['citation_id'];

                    $table = $this->loadModel('Citationlist');
                    $data = $table->find('all')->where(["citation_id" => $citation_id])->order(["id" => "DESC"])->first();

                    if (empty($data)) {
                        $this->json(0, "No Data Found");
                    }
                    /* --------  Primary citation Section  ------ */
                    if (isset($data->citations_data) && !empty($data->citations_data)) {

                        $citationData = json_decode($data->citations_data, true); // parsing citation data from database 

                        if (!empty($citationData) && isset($citationData)) {

                            foreach ($citationData["citations"] as $val):

                                $check = $this->isPrimary($val['name']);

                                /* condition for get total primary citation */
                                if ($check != false && !empty($check)) {

                                    $primaryIds[] = $check[0]->id;
                                    $total_primary += 1; // count primary citation
                                } else {
                                    $total_additional += 1; // count additional citation 
                                }

                            endforeach;

                            /* Get citations from database which is not in report */

                            /* --- Top Citations Section not in citation result  --- */
                            $total_primary = 0;
                            if(!empty($primaryIds)){
                                $ciTable = $this->loadModel('CitationManager');
                                $ciData = $ciTable->find('all')->where(["is_top_hundred" => 1, "id NOT IN" => array_unique($primaryIds)])->toArray();

                                $total_primary += count($ciData); // total primary citation value  
                            }
                            
                            /* ------------ Competitor citation section ----------------- */

                            $competitiveJson = $data->competitive_citation; // getting value from database
                            if (!empty($competitiveJson)) {
                                $competitiveData = json_decode($competitiveJson);
                                $competitiveCitationsData = $competitiveData->competitorCitationData;

                                $total_competitor = count($competitiveCitationsData);
                            }

                            /* -------- Opportunities count section ----------- */

                            $db = TableRegistry::get('tbl_citation_competitor');
                            $citationsOpportunitiesData = $db->find()->select(["citations"])->where(["citation_tracker_id" => $data->id])->order(["created" => 'DESC'])->first();

                            if (!empty($citationsOpportunitiesData->citations)) {
                                $citation_data = json_decode($citationsOpportunitiesData->citations); // data from tbl_citation_competitor 
                                $citation_report = $citation_data[0]->citations;
                                $total_opportunities = count($citation_report);
                            }

                            $return["data"]["total_primary"] = $total_primary;
                            $return["data"]["total_additional"] = $total_additional;
                            $return["data"]["total_competitor"] = $total_competitor;
                            $return["data"]["total_opportunities"] = $total_opportunities;

                            if (!empty($return)) {
                                $this->json(1, "Total Data List", $return);
                            } else {
                                $this->json(0, "No Data Found");
                            }
                        }
                    } else {
                        $this->json(0, "No Data Found");
                    }
                } else {
                    $this->json(0, "Invalid token");
                }
            } else {
                $this->json(0, 'Invalid Request Method.');
            }
        } catch (Exception $ex) {
            
        }
    }

    /* function for get unique array */

    private function unique_multidim_array($array, $key) {
        $temp_array = array();
        $i = 0;
        $key_array = array();

        foreach ($array as $val) {
            if (!in_array($val[$key], $key_array)) {
                $key_array[$i] = $val[$key];
                $temp_array[$i] = $val;
            }
            $i++;
        }
        return $temp_array;
    }

    /**
     * Date :- 05-july-17
     * Function Disc :- Function for get citation site report 
     * Testing param :- {"citation_id":45, "site": "facebook.com"}
     */
    public function getSiteReport() {
        $this->autoRender = false;
        $page = 1;
        $limit = 10;
        $competitorCount = 0;
        $total_citations = 0;
        $domain_mozrank = 0;
        $citation_opp_arr = array();
        $da = 0;
        $instruction = "";
        $login_url = "";
        $final_data = array();
        $login = array();

        try {
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));

                    $page = isset($data["offset"]) && !empty($data["offset"]) ? $data["offset"] : $page; // set page from body
                    $limit = isset($data["limit"]) && !empty($data["limit"]) ? $data["limit"] : $limit; // set limit from body 
                    $search_val = isset($data['search_txt']) && !empty($data["search_txt"]) ? $data['search_txt'] : ""; // set var for search by web-name 
                    $site = isset($data["site"]) && !empty($data["site"]) ? $data["site"] : "";
                    $sortby = isset($data["sortby"]) ? $data["sortby"] : "site";
                    $orderby = isset($data["orderby"]) ? $data["orderby"] : "desc";

                    $arvalidation = array();
                    if (!isset($data['citation_list_id']) || $data['citation_list_id'] == "") {

                        $arvalidation['citation_list_id'] = "Please provide citation_list_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    $citation_list_id = $data['citation_list_id'];

                    /* Get value form citation list table */
                    //$citation_id = $data['citation_id'];
                    $table = $this->loadModel('Citationlist');
                    $data = $table->find('all')->select(["citation_id", "id"])->where(["id" => $citation_list_id])->first();

                    if (empty($data)) {
                        $this->json(0, "No Citation Data Found");
                    }

                    if (!empty($site)) {
                        //$db = TableRegistry::get('tbl_citation_competitor');
                        //$citationsOpportunitiesData = $db->find()->select(["citations"])->where(["citation_tracker_id" => $data->id])->order(["created" => 'DESC'])->first();

                        $db = TableRegistry::get('tbl_citationlist');
                        $citationsOpportunitiesData = $db->find()->select(["citations_data"])->where(["id" => $data->id])->order(["created" => 'DESC'])->first();

                        if (empty($citationsOpportunitiesData->citations_data)) {
                            $this->json(0, "No Data Found");
                        }

                        $citationsOpportunitiesData = $citationsOpportunitiesData->citations_data;

                        //pr(json_decode($citationsOpportunitiesData)); die;

                        if (!empty($citationsOpportunitiesData)) {
                            $citation_data = json_decode($citationsOpportunitiesData); // data from tbl_citation_competitor 
                            $citation_report = $citation_data->citations;
                            if (!empty($citation_report)) {
                                $i = 0;

                                $competitorCount = count($citation_report);

                                //print_r($citation_report); die;


                                foreach ($citation_report as $key => $value):

                                    $isCitationVerified = $value->isCitationVerified;
                                    $isCitationVerified = $isCitationVerified == 1 ? 'Y' : 'N';


                                    if ($this->fully_trim($value->name) == $this->fully_trim($site)) {

                                        //echo $value->citationStatus;
                                        $citation_opp_arr[$i]["domain"] = $value->name;
                                        $citation_opp_arr[$i]["verified"] = $isCitationVerified;
                                        $citation_opp_arr[$i]["name"] = $value->hasBusinessName;
                                        $citation_opp_arr[$i]["address"] = $value->hasAddress;
                                        $citation_opp_arr[$i]["phone"] = $value->hasPhone;
                                        $citation_opp_arr[$i]["siteurl"] = $value->hasSiteUrl;
                                        $citation_opp_arr[$i]["street_adress"] = $value->hasStreetAddress;
                                        $citation_opp_arr[$i]["city"] = $value->hasCity;
                                        $citation_opp_arr[$i]["state"] = $value->hasState;
                                        $citation_opp_arr[$i]["zip"] = $value->hasZip;
                                        $citation_opp_arr[$i]["da"] = !empty($value->seoMozData->domainAuthority) ? $value->seoMozData->domainAuthority : 'N/A';
                                        $citation_opp_arr[$i]["pa"] = !empty($value->seoMozData->pageAuthority) ? $value->seoMozData->pageAuthority : 'N/A';
                                        $citation_opp_arr[$i]["mozrank"] = !empty($value->seoMozData->mozRank) ? $value->seoMozData->mozRank : 'N/A';

                                        /* Final calculation section */
                                        $total_citations += 1;
                                        $da += intval($citation_opp_arr[$i]["da"]);
                                        $domain_mozrank += intval($citation_opp_arr[$i]["mozrank"]);
                                    }

                                    $i++;
                                endforeach;


                                $citation_opp_arr = array_values($citation_opp_arr);

                                /* getting data from citation manager table */
                                $table = $this->loadModel('CitationManager');
                                $tableData = $table->find()->where(["domain_name" => $site])->first();

                                if (!empty($tableData) && isset($tableData)) {

                                    $instruction = $tableData->instruction;
                                    $login_url = $tableData->login_url;
                                }

                                /* Final calculation section */
                                $final_data['status'] = $citation_report[0]->citationStatus;
                                $final_data["citation_site"] = $site;
                                $final_data['have_citation'] = $isCitationVerified;
                                $final_data['num_competitor'] = $competitorCount;
                                $final_data['total_citations'] = $total_citations;
                                $final_data['da'] = $da;
                                $final_data['domain_mozrank'] = $domain_mozrank;
                                $final_data['instructions'] = $instruction;
                                $final_data['login_url'] = $login_url;

                                $notes = $this->getNotes($site, $citation_list_id);

                                /* ---- Get Email login ---------- */
                                $logintable = TableRegistry::get('tbl_citation_logindata');
                                $tblData = $logintable->find('all')->where(["citation_list_id" => $citation_list_id])->first();
                                if (!empty($tblData)) {
                                    $login["citation_list_id"] = $tblData->citation_list_id;
                                    $login["site_url"] = $tblData->site_url;
                                    $login["username"] = $tblData->username;
                                    $login["password"] = $tblData->password;
                                } else {
                                    $login = [];
                                }

                                if (!empty($citation_opp_arr)) {

                                    /* Code for searching */
                                    if (!empty($search_val) && $search_val != '') {
                                        $new = [];
                                        foreach ($citation_opp_arr as $out):
                                            if (strpos($out['domain'], $search_val) !== false) {
                                                $new[] = $out;
                                            }
                                        endforeach;

                                        $citation_opp_arr = $new; // add searched value into variable 
                                    }

                                    /* array pagination logic */
                                    $return = [];
                                    $count = count($citation_opp_arr);

                                    $totalPage = $count / $limit;

                                    if ($count > $limit) {

                                        $range = $limit * $page;

                                        if ($page == 1) {
                                            $start = 0;
                                        } else if ($page == 2) {
                                            $start = $limit;
                                        } else if ($page > 2) {
                                            $start = $range - $limit;
                                        }

                                        for ($i = $start; $i < $range; $i++) {
                                            $return[] = @$citation_opp_arr[$i];
                                        }

                                        $returnData["data"] = array_filter($return);
                                        $returnData["final_calculation"] = $final_data;
                                        $returnData["notes"] = !empty($notes) ? $notes : "";
                                        $returnData["logindata"] = !empty($login) ? $login : "";
                                        $returnData["total_records"] = $count;
                                        $returnData["total_pages"] = ceil($totalPage);
                                        $returnData["current_page"] = $page;

                                        $this->json(1, "Citations Sites report data List", $returnData);
                                    } else {

                                        $returnData["data"] = array_filter($citation_opp_arr);
                                        $returnData["final_calculation"] = $final_data;
                                        $returnData["notes"] = !empty($notes) ? $notes : "";
                                        $returnData["logindata"] = !empty($login) ? $login : "";
                                        $returnData["total_records"] = $count;
                                        $returnData["total_pages"] = ceil($totalPage);
                                        $returnData["current_page"] = $page;
                                        $this->json(1, "Citations Sites report data List", $returnData);
                                    }
                                } else {
                                    $this->json(0, "No Data Found");
                                }
                            } else {
                                $this->json(0, "Citation Report Empty");
                            }
                        }
                    } else {
                        $this->json(0, "Provide Site url");
                    }
                } else {
                    $this->json(0, 'Invalid Token');
                }
            } else {
                $this->json(0, 'Invalid Request Method.');
            }
        } catch (\Exception $ex) {
            
        }
    }

    /**
     * Date :- 05-july-17
     * Function Disc :- function for save notes from citation 
     * Params :- {"citation_id":45, "site": "facebook.com", "notes": "This is only for Testing purpose", "location_id": 7}
     */
    public function saveCitationNotes() {
        $this->autoRender = false;

        try {
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {

                    /* Fetch token detatils for save in database */
                    $token = $this->request->header('token');

                    $tokenData = $this->fetchTokenDetails($token);
                    if (!empty($tokenData)) {
                        $user_id = $tokenData["user_id"];
                    } else {
                        $user_id = "";
                    }

                    $data = (array) json_decode(file_get_contents('php://input'));

                    $site = isset($data["site"]) && !empty($data["site"]) ? $data["site"] : "";
                    $notes = isset($data['notes']) && !empty($data['notes']) ? $data['notes'] : "";
                    $location_id = isset($data["location_id"]) && !empty($data['location_id']) ? $data['location_id'] : "";

                    $arvalidation = array();

                    if (!isset($data['citation_list_id']) || $data['citation_list_id'] == "") {

                        $arvalidation['citation_list_id'] = "Please provide citation_list_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    /* Get value form citation list table */
                    $citation_list_id = $data['citation_list_id'];

                    if (!empty($site) && !empty($notes)) {

                        /* ------- Save notes into database ------------ */
                        $table = $this->loadModel('Tblnotes'); // load model 

                        $insert = $table->newEntity();
                        $insert->location_id = 0;
                        $insert->notes = $notes;
                        $insert->citation_list_id = $citation_list_id;
                        $insert->url = $site;
                        $insert->created = date("Y-m-d H:i:s");
                        $insert->created_by = $user_id;
                        $insert->modified = date('Y-m-d H:i:s');
                        $insert->modified_by = $user_id;

                        /* save data into database */
                        if ($table->save($insert)) {
                            $this->json(1, "Notes Added Into Database");
                        } else {
                            $this->json(0, "Database Error Occured");
                        }
                    } else {
                        $this->json(0, "Provied All Required Fields");
                    }
                } else {
                    $this->json(0, 'Invalid Token');
                }
            } else {
                $this->json(0, 'Invalid Request Method.');
            }
        } catch (\Exception $ex) {
            
        }
    }

    /**
     * Date :- 05-july-17
     * Function Disc :- Function for save login details from citation opportunities page 
     * Params :- token* (Header), (Body) citation_id, site , login user id , login password 
     */
    public function saveLogin() {
        $this->autoRender = false;

        try {
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {

                    /* Fetch token detatils for save in database */
                    $token = $this->request->header('token');
                    $tokenData = $this->fetchTokenDetails($token);
                    if (!empty($tokenData)) {
                        $user_id = $tokenData["user_id"];
                    } else {
                        $user_id = "";
                    }

                    $data = (array) json_decode(file_get_contents('php://input'));

                    $site = isset($data["site"]) && !empty($data["site"]) ? $data["site"] : "";
                    $arvalidation = array();

                    if (!isset($data['citation_list_id']) || $data['citation_list_id'] == "") {

                        $arvalidation['citation_list_id'] = "Please provide citation_list_id";
                    }

                    if (!isset($data['username']) || $data['username'] == "") {

                        $arvalidation['username'] = "Please provide username";
                    }

                    if (!isset($data['password']) || $data['password'] == "") {

                        $arvalidation['password'] = "Please provide password";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }


                    /* Get value form citation list table */
                    $citation_list_id = $data['citation_list_id'];
                    $username = $data['username'];
                    $password = $data['password'];

                    if (!empty($citation_list_id) && !empty($username) && !empty($password)) {

                        /* save username and password into database */
                        $table = $this->loadModel("Citationlogin");
                        $insert = $table->newEntity();
                        $insert->citation_list_id = $citation_list_id;
                        $insert->site_url = $site;
                        $insert->username = $username;
                        $insert->password = $password;
                        $insert->created = date("Y-m-d H:i:s");
                        $insert->created_by = $user_id;
                        $insert->modified_by = $user_id;

                        if ($table->save($insert)) {
                            $this->json(1, "User Details Saved Into Database");
                        } else {
                            $this->json(0, "Cann't Save Data");
                        }
                    } else {
                        $this->json(0, "Please Provide All Required Data");
                    }
                } else {
                    $this->json(0, 'Invalid Token');
                }
            } else {
                $this->json(0, 'Invalid Request Method.');
            }
        } catch (\Exception $ex) {
            
        }
    }

    /**
     * Date :- 05-july-17
     * Updated :- 06-july-17
     * Function dis :- function for get notes according to site url
     */
    private function getNotes($url, $citation_list_id) {

        try {
            $return = array();
            if (!empty($url) && isset($url) && !empty($citation_list_id)) {

                $table = $this->loadModel('Tblnotes'); // load model
                $notesData = $table->find('all', array("contain" => ["User"]))->where(["url" => $url, "citation_list_id" => $citation_list_id])->toArray();

                if (isset($notesData) && !empty($notesData)) {

                    $i = 0;
                    foreach ($notesData as $val):

                        $return[$i]["notes_id"] = $val->id;
                        $return[$i]["created_by"] = $val->user->fname . " " . $val->user->lname;
                        $return[$i]["notes"] = $val->notes;
                        $return[$i]["created"] = date("d M Y h:i A", strtotime($val->created));
                        $i++;
                    endforeach;

                    return $return; // returning result 
                } else {
                    return $return;
                }
            }
        } catch (\Exception $e) {
            
        } catch (\PDOException $e) {
            
        }
    }

    /**
     * Date :- 05-july-17
     * Function disc :- function for get conpetitive reporting data 
     */
    public function getCompetitiveReport() {
        $this->autoRender = false;
        $calculatedData = array();
        $page = 1;
        $limit = 10;

        try {
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {
                    $data = (array) json_decode(file_get_contents('php://input'));
                    $citationreportId = isset($data['citation_report_id']) && !empty($data['citation_report_id']) ? $data['citation_report_id'] : "R8SqaqfHc0q0Uf3MiN8Wcg";
                    $page = isset($data["offset"]) && !empty($data["offset"]) ? $data["offset"] : $page; // set page from body
                    $limit = isset($data["limit"]) && !empty($data["limit"]) ? $data["limit"] : $limit; // set limit from body 
                    $search_val = isset($data['search_txt']) && !empty($data["search_txt"]) ? $data['search_txt'] : ""; // set var for search by web-name 
                    $sortby = isset($data["sortby"]) ? $data["sortby"] : "site";
                    $orderby = isset($data["orderby"]) ? $data["orderby"] : "desc";

                    //$citationreportId = "R8SqaqfHc0q0Uf3MiN8Wcg"; // only for testing 

                    $arvalidation = array();

                    if (!isset($data['citation_report_id']) || $data['citation_report_id'] == "") {

                        $arvalidation['citation_report_id'] = "Please provide citation_report_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    $table = TableRegistry::get('tbl_citation_competitor');
                    $citationCompetitiveData = $table->find("all")->select(['citations'])->where(["citationReportCitationsId" => $citationreportId . "/citations"])->first();

                    if (!empty($citationCompetitiveData)) {

                        $citationData = json_decode($citationCompetitiveData->citations);
                        $i = 0;
                        foreach ($citationData[0]->citations as $row_citaions):
                            $calculatedData[$i]["site"] = isset($row_citaions->name) ? $row_citaions->name : "N";
                            $calculatedData[$i]["verified"] = isset($row_citaions->isCitationVerified) && !empty($row_citaions->isCitationVerified) ? $row_citaions->isCitationVerified : "N";
                            $calculatedData[$i]["name"] = isset($row_citaions->hasBusinessName) ? $row_citaions->hasBusinessName : "N";
                            $calculatedData[$i]["fa"] = isset($row_citaions->hasAddress) ? $row_citaions->hasAddress : "";
                            $calculatedData[$i]["phone"] = isset($row_citaions->hasPhone) ? $row_citaions->hasPhone : "";
                            $calculatedData[$i]["url"] = isset($row_citaions->hasSiteUrl) ? $row_citaions->hasSiteUrl : "";
                            $calculatedData[$i]["sa"] = isset($row_citaions->hasStreetAddress) ? $row_citaions->hasStreetAddress : "";
                            $calculatedData[$i]["city"] = isset($row_citaions->hasCity) ? $row_citaions->hasCity : "";
                            $calculatedData[$i]["state"] = isset($row_citaions->hasState) ? $row_citaions->hasState : "";
                            $calculatedData[$i]["zip"] = isset($row_citaions->hasZip) ? $row_citaions->hasZip : "";
                            $calculatedData[$i]["pa"] = isset($row_citaions->seoMozData->pageAuthority) ? $row_citaions->seoMozData->pageAuthority : "";
                            $calculatedData[$i]["da"] = isset($row_citaions->seoMozData->domainAuthority) ? $row_citaions->seoMozData->domainAuthority : "";
                            $calculatedData[$i]["link"] = isset($row_citaions->link) ? $row_citaions->link : "";
                            $i++;
                        endforeach;

                        if (!empty($calculatedData)) {

                            /* Sorting code */

                            if ($sortby != '') {
                                usort($calculatedData, function($a, $b) use ($sortby) {
                                    return $a["$sortby"] - $b["$sortby"];
                                });
                            }

                            if ($orderby == "desc") {
                                $calculatedData = array_reverse($calculatedData);
                            }

                            /* Code for searching */
                            if (!empty($search_val) && $search_val != '') {
                                $new = [];
                                foreach ($calculatedData as $out):
                                    if (strpos($out['site'], $search_val) !== false) {
                                        $new[] = $out;
                                    }
                                endforeach;

                                $calculatedData = $new; // add searched value into variable 
                            }

                            /* array pagination logic */
                            $return = [];
                            $count = count($calculatedData);

                            $totalPage = $count / $limit;

                            if ($count > $limit) {

                                $range = $limit * $page;

                                if ($page == 1) {
                                    $start = 0;
                                } else if ($page == 2) {
                                    $start = $limit;
                                } else if ($page > 2) {
                                    $start = $range - $limit;
                                }

                                for ($i = $start; $i < $range; $i++) {
                                    $return[] = @$calculatedData[$i];
                                }

                                $returnData["data"] = array_filter($return);
                                $returnData["total_records"] = $count;
                                $returnData["total_pages"] = ceil($totalPage);
                                $returnData["current_page"] = $page;

                                $this->json(1, "Citations Competetive Report Data List", $returnData);
                            } else {

                                $returnData["data"] = array_filter($calculatedData);
                                $returnData["total_records"] = $count;
                                $returnData["total_pages"] = ceil($totalPage);
                                $returnData["current_page"] = $page;

                                $this->json(1, "Citations Competetive Report Data List", $returnData);
                            }
                        } else {
                            $this->json(0, "No Competitive Citation Data Found");
                        }
                    } else {
                        $this->json(0, "No Competitive Citation Data Found");
                    }
                } else {
                    $this->json(0, 'Invalid Token');
                }
            } else {
                $this->json(0, 'Invalid Request Method.');
            }
        } catch (Exception $ex) {
            
        }
    }

    /**
     * Date :- 06-july-17
     * Function disc :- Function for delete notes according to id 
     * Params :- function for delete notes from citation 
     */
    public function deleteNotes() {
        $this->autoRender = false;

        try {
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                if ($this->is_token_valid()) {

                    /* Fetch token detatils for save in database */
                    $token = $this->request->header('token');
                    $tokenData = $this->fetchTokenDetails($token);
                    if (!empty($tokenData)) {
                        $user_id = $tokenData["user_id"];
                    } else {
                        $user_id = "";
                    }

                    $data = (array) json_decode(file_get_contents('php://input'));

                    $arvalidation = array();

                    /* Validation section */

                    if (!isset($data['notes_id']) || $data['notes_id'] == "") {

                        $arvalidation['notes_id'] = "Please provide notes_id";
                    }

                    if (!empty($arvalidation)) {
                        $this->json(0, "Empty fields found", $arvalidation);
                    }

                    $notesId = $data['notes_id']; // get notes id 

                    $table = $this->loadModel('Tblnotes');
                    $query = $table->query();

                    if ($query->delete()->where(["id" => $notesId])->execute()) {
                        $this->json(1, "Notes Deleted sucessfully");
                    } else {
                        $this->json(0, "Notes Not Deleted .");
                    }
                } else {
                    $this->json(0, 'Invalid Token');
                }
            } else {
                $this->json(0, 'Invalid Request Method.');
            }
        } catch (Exception $ex) {
            
        }
    }
    
   /**
     * Date :- 07-July-17
     * Function Disc :- Function for Download PDF of citation report  
     */
    public function downloadPDF() {
        $this->autoRender = false;
        $primarydata = array();
        $xy = 1;
        set_time_limit(0);
        ini_set('memory_limit', '-1');

        try {
            if ($_SERVER['REQUEST_METHOD'] == "GET") {
                $token = base64_decode(base64_decode($_GET["token"]));  // get token from url 
                $is_token_valid = $this->is_token_valid($token);

                $citationId = isset($_GET['citation_id']) && !empty($_GET['citation_id']) ? $_GET['citation_id'] : "";

                if (empty($citationId)) {
                    $this->json(0, "Please Provide Citation Id");
                }

                if ($is_token_valid == 1) {

                    $table = TableRegistry::get('tbl_citationlist');
                    $tbldata = $table->find("all")->where(["citation_id" => $citationId])->order(["id" => "DESC"])->first();

                    if (empty($tbldata)) {
                        $this->json(0, "No Data Found");
                    }

                    $html = '<!DOCTYPE html>
                            <html lang="en">
                            <head>
                              <meta charset="utf-8">
                              <meta name="viewport" content="width=device-width, initial-scale=1">
                              <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
                              <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
                              <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
                            </head>
                            <body>

                            <div class="container">
                             <div class ="row"> 
                                    <span class="logo"><img src="http://www.agencyhq.com/wp-content/themes/genesis-child/images/logo.png" style="padding-bottom: 55px;
    padding-top: 25px;"></span>
                              </div>';

                    $primarydata = $this->getPrimaryCalculation($citationId);

                    $html .= '<!-- Table for primary citation -->
                              <div class ="row">
                              <div class ="label label-default" style="font-size: 90%; margin-bottom:20px;"> Primary Citation Reporting Data</div>

                              <table class="table table-striped">
                                <thead>
                                  <thead>
                                    <tr>
                                      <th>S.No</th>
                                      <th style="display:none">Logo</th>
                                      <th>Site</th>
                                      <th>Score</th>
                                      <th>Name</th>
                                      <th>Site Url</th>
                                      <th>Address</th>
                                      <th>Zip</th>
                                      <th>Phone</th>
                                    </tr>
                                </thead>
                                <tbody>';
                    
                    /* Primary citation section */
                    
                    if (!empty($primarydata["primary_data"])) {
                        $i = 1;
                        foreach ($primarydata["primary_data"] as $val):
                            $html .= '<tr>
                                        <td>' . $i . '</td>
                                        <td style="display:none"><img src=' . $val["logo"] . ' height="20" width="20"></td>
                                        <td><font color="">' . $val["webname"] . '</font></td>
                                        <td>' . $val["score"] . '</td>
                                        <td>' . $val["name"] . '</td>
                                        <td>' . @$val["siteurl"] . '</td>
                                        <td>' . $val["address"] . '</td>
                                        <td>' . $val["zip"] . '</td>
                                        <td>' . $val["phone"] . '</td>
                                       </tr>';
                            $i++;
                        endforeach;
                    }else {
                        $html .= '<tr><td>No Primary Citation Found.</td></tr>';
                    }
                    
                    /* Additional Citation section */

                    $html .= '</tbody>
                              </table>
                              </div>
                              <!-- END -->

                              <!-- Table for Additinal citation -->
                              <div class ="row">
                              <div class ="label label-default" style="font-size: 90%; margin-bottom:20px;">Additional Citation Data</div>

                              <table class="table table-striped">
                                <thead>
                                  <tr>
                                    <th>S.No</th>
                                    <th>Webname</th>
                                    <th style="display:none;">Score</th>
                                    <th>Site Url</th>
                                    <th>Address</th>
                                    <th>Zip</th>
                                    <th>Phone</th>
                                  </tr>
                                </thead>
                                <tbody>';
                    
                    /* Additional citation loop */
                    if(!empty($primarydata["additional_data"])){
                    $xy = 1;
                    foreach($primarydata["additional_data"] as $value):           
                    $html  .=   '<tr>
                                  <td>'.$xy.'</td>
                                  <td>'.$value["webname"].'</td>
                                  <td style="display:none;">'.$value["score"].'</td>
                                  <td>'.$value["siteurl"].'</td>
                                  <td>'.$value["address"].'</td>
                                  <td>'.$value["zip"].'</td>
                                  <td>'.$value["phone"].'</td>
                                </tr>';
                    $xy++;
                    endforeach;
                    } else {
                        $html .= '<tr><td>No Opportunity Data Found.</td></tr>';
                    }
                    
                    $html   .=    '</tbody>
                              </table>
                              </div>
                              <!-- END -->

                              <!-- Table for competetive citation -->
                              <div class ="row">
                              <div class ="label label-default" style="font-size: 90%; margin-bottom:20px;">Competetive Citation Data</div>

                              <table class="table table-striped">
                                <thead>';
                    
                    
                    
                    $html   .=   '<tr>
                                  <th>S.No</th>
                                  <th>Keyword</th>
                                  <th>Geo Location</th>
                                  <th>Result Type</th>
                                  <th>Rank</th>
                                  <th>Title</th>
                                  <th>Varified Citations</th>
                                  <th>Mentions</th>
                                  <th>Domain Authority</th>
                                  <th>Page Authority</th>
                                  <th>Moz Rank</th>
                                  <th>Avg. Links</th>
                                  </tr>';
                    
                    $competetiveReporting = $this->getCompetetiveCitationReport($citationId);
                    $j = 1; 
                    if(!empty($competetiveReporting)){
                    foreach($competetiveReporting as $out):
                    $html   .=  '</thead>
                                <tbody>
                                  <tr>
                                    <td>'.$j.'</td>
                                    <td>'.$out["keyword"].'</td>
                                    <td>'.$out["googleLocation"].'</td>
                                    <td>'.$out["resultType"].'</td>
                                    <td>'.$out["rank"].'</td>
                                    <td>'.$out["title"].'</td>
                                    <td>'.$out["totalVerifiedCitations"].'</td>
                                    <td>'.$out["mentions"].'</td>
                                    <td>'.$out["averageDomainAuthority"].'</td>
                                    <td>'.$out["averagePageAuthority"].'</td>
                                    <td>'.$out["averageMozRank"].'</td>
                                    <td>'.$out["averageLinks"].'</td>
                                  </tr>';
                    $j++;
                    endforeach;
                    } else {
                        $html .= '<tr><td>No Competetive Data Found.</td></tr>';
                    }
                    
                    $html   .= '</tbody>
                           </table>
                              </div>
                              <!-- END -->

                              <!-- Table for opportunity citation -->
                              <div class ="row">
                              <div class ="label label-default" style="font-size: 90%; margin-bottom:20px;">Citation Opportunity Data</div>
                              <table class="table table-striped">
                                <thead>';
                    
                    $html   .=   '<tr>
                                  <th>S.No</th>
                                  <th>Site</th>
                                  <th style="display:none">Link</th>
                                  <th>DA</th>
                                  <th>Competetor</th>
                                  <th>MozRank</th>
                                  <th>Citaion</th>
                                  <th>Have Citation</th>
                                  </tr>
                                </thead>
                                <tbody>';
                    $opportunities = $this->getOpportunitiesReport($citationId);
                    $p = 1;
                    if(!empty($opportunities)) {
                    foreach($opportunities as $va):
                    $html   .=     '<tr>
                                    <td>'.$p.'</td>
                                    <td>'.$va["site"].'</td>
                                    <td style="display:none">'.$va["link"].'</td>
                                    <td>'.$va["DA"].'</td>
                                    <td>'.$va["num_competitor"].'</td>
                                    <td>'.$va["mozRank"].'</td>
                                    <td>'.$va["total_citaion"].'</td>
                                    <td>'.$va["have_citation"].'</td>
                                  </tr>';
                    $p++;
                    endforeach;
                    } else {
                        $html .= '<tr><td>No Opportunities Data Found.</td></tr>';
                    }
                    
                    $html   .=  '</tbody>
                              </table>
                              </div>
                              <!-- END -->

                            </div>

                            </body>
                            </html>';

                   // echo $html ; die;
                    
                    $pdf_name = "Testing_pdf";

                    /* PDF generate and Download code */
                    
                    $dompdf = new DOMPDF();
                    $dompdf->load_html($html);
                    $dompdf->set_paper('a4', 'landscape');
                    $dompdf->render();
                    $pdf = $dompdf->output();
//                    print_r($pdf); die;
                    $new = $dompdf->stream(str_replace(" ", "_", $pdf_name . '.pdf'), array("Attachment" => true));
                }else {
                    $this->json(0, "Invalid Token");
                }
            } else {
                $this->json(0, "Invalid Request Method");
            }
        } catch (Exception $ex) {
            
        }
    }

    /*
     * Date :- 07-july-17
     * Function Disc :- Function for get primary citation calcutated result 
     */

    private function getPrimaryCalculation($citation_id) {
        
        $primaryIds = array();

        if (empty($citation_id)) {
            return 0;
        }

        $outpuArray = array(); // blank array to store result 

        $table = $this->loadModel("Citationlist");
        $data = $table->find('all')->where(["citation_id" => $citation_id])->order(["id" => "DESC"])->first();

        $primaryIds = array();

        if (!empty($data)) {

            if ($data->status == "In Progress") {
                return 0;
            }

            /* Geting details from citations table */
            $mainData = $this->getDetails($data->citation_id);
            $citationData = !empty($data->citations_data) && isset($data->citations_data) ? \json_decode($data->citations_data) : "";

            if (!empty($citationData->citations)) {
                $num = 0;

                /* Varible used for graph */
                $graphArr["correctBusignessName"] = 0;
                $graphArr["errorBusignessName"] = 0;
                $graphArr["correctAddress"] = 0;
                $graphArr["errorAddress"] = 0;
                $graphArr["corectUrl"] = 0;
                $graphArr["errorUrl"] = 0;
                $graphArr["correctPhone"] = 0;
                $graphArr["errorPhone"] = 0;
                $graphArr["correctZip"] = 0;
                $graphArr["errorZip"] = 0;
                $graphArr["topCitationAudit"] = 0;
                $graphArr["topCitationAuditError"] = 0;
                $total = 0;
                $verified = 0;
                $result = array(); // blank array to store primary citation data 
                $additional = array(); // blank array to store additional citation data 
                $a = 0;
                
                $path = Router::url('/', true);

                foreach ($citationData->citations as $val):

                    /* Calculate score and verified */
                    $is_verifed = $val->isCitationVerified;
                    $total += 1;

                    if ($is_verifed == false && $is_verifed == "") {
                        
                    } else {
                        $verified += 1;
                    }
                    
                    $primaryDatalist = $this->listPrimary();
                    
                    /* Primary Citation calculation data */
                    if(isset($primaryDatalist) && !empty($primaryDatalist)){
                        foreach($primaryDatalist as $list):
                            
                           if($list['urls'] == $this->fully_trim($val->name)){
                               
                               $primaryIds[] = $list['id']; // storing primary ids into array 

                                $result[$num]["logo"] = !empty($list['logo']) ? $path . "logos/" . $list['logo'] : '';
                                $result[$num]["webname"] = !empty($val->name) ? $this->appendhttp($val->name) : '';
                                $result[$num]["link"] = !empty($val->link) ? $val->link : '';
                                $result[$num]["score"] = !empty($list['score']) ? $list['score'] : "";
                                $result[$num]["name"] = !empty($mainData->name) ? $mainData->name : '';
                                $result[$num]["siteurl"] = !empty($mainData->url) ? $mainData->url : '';
                                $result[$num]["address"] = !empty($mainData->address) ? $mainData->address : '';
                                $result[$num]["zip"] = !empty($mainData->zip_code) ? $mainData->zip_code : '';
                                $result[$num]["phone"] = !empty($mainData->phone) ? $mainData->phone : '';
                                $result[$num]["citation_list_id"] = $data->id;
                                
                                /* Calculation of primary citation graph */
                                ($val->hasBusinessName == 'Y') ? $graphArr["correctBusignessName"] += 1 : $graphArr["errorBusignessName"] += 1;
                                ($val->hasPhone == 'Y') ? $graphArr["correctPhone"] += 1 : $graphArr["errorPhone"] += 1;
                                ($val->hasZip == 'Y') ? $graphArr["correctZip"] += 1 : $graphArr["errorZip"] += 1;
                                ($val->hasAddress == 'Y') ? $graphArr["correctAddress"] += 1 : $graphArr["errorAddress"] += 1;
                                ($val->hasSiteUrl == 'Y') ? $graphArr["corectUrl"] += 1 : $graphArr["errorUrl"] += 1;
                                ($graphArr["errorBusignessName"] == 0 && $graphArr["errorPhone"] == 0 && $graphArr["errorZip"] == 0) ? $graphArr["topCitationAudit"] += 1 : $graphArr["topCitationAuditError"] += 1;
                                
                                $num ++;
                                
                           } 
                           
                        endforeach;
                        
                        /* Additional Citation Calculation data */
                        $additional[$a]['webname'] = !empty($val->name) ? $this->appendhttp($val->name) : '';
                        $additional[$a]['link'] = !empty($val->link) ? $val->link : '';
                        $additional[$a]["score"] = !empty($list['score']) ? $list['score'] : "";
                        $additional[$a]["siteurl"] = !empty($mainData->url) ? $mainData->url : '';
                        $additional[$a]["address"] = !empty($mainData->address) ? $mainData->address : '';
                        $additional[$a]["zip"] = !empty($mainData->zip_code) ? $mainData->zip_code : '';
                        $additional[$a]["phone"] = !empty($mainData->phone) ? $mainData->phone : '';
                        $a++;  
                        
                    }
                    
                endforeach;
                
                $score = round(($verified / $total) * 100, 2);

                /* --- Top Citations Section not in citation result  --- */
                $ciTable = $this->loadModel('CitationManager');
                $ciData = $ciTable->find('all')->select(["domain_name", "score", "logo"])->where(["is_top_hundred" => 1, "id NOT IN" => array_unique($primaryIds)])->toArray();

                $newArray = [];
                $graphArr["total_score"] = $score;
                $graphArr["total_top_sites"] = count($ciData);
                $graphArr["top_citations"] = count($result);
                $graphArr["topPercent"] = round($graphArr["top_citations"] / $graphArr["total_top_sites"] * 100); // calculate percentage of top websites
                
                if (!empty($result)) {

                    /* Adding top citations into result array (Which is not matched) */
                    foreach ($ciData as $key => $res):
                        $newArray[$key]["logo"] = $path . "logos/" . $res->logo;
                        $newArray[$key]["webname"] = $this->appendhttp($res->domain_name);
                        $newArray[$key]["link"] = "";
                        $newArray[$key]["score"] = $res->score;
                        $newArray[$key]["nameColor"] = "";
                        $newArray[$key]["name"] = "";
                        $newArray[$key]["addressColor"] = "";
                        $newArray[$key]["address"] = "";
                        $newArray[$key]["zipColor"] = "";
                        $newArray[$key]["zip"] = "";
                        $newArray[$key]["phoneColor"] = "";
                        $newArray[$key]["phone"] = "";
                        $newArray[$key]["citation_list_id"] = $data->id;
                    endforeach;

                    $result = array_merge($result, $newArray); // merge both array into one 
                    $result = $this->unique_multidim_array($result, "webname"); // remove redundancy form array  
                    $result = array_values($result);

                    $outpuArray["primaryGraph"] = $graphArr;
                    $outpuArray["primary_data"] = $result;
                    $outpuArray["additional_data"] = $additional;
                    
                    if (!empty($outpuArray)) {
                        return $outpuArray;
                    } else {
                        return 0;
                    }
                } else {
                    return 0;
                }
            } else {
                return 0;
            }
        }
    }

    /*
     * Date :- 08-july-17
     * Function Disc :- Function for get competetive report 
     */

    private function getCompetetiveCitationReport($citation_id) {

        $result = array(); // blank array for store competetive Citation report 

        /* Get value form citation list table */
        $table = $this->loadModel('Citationlist');
        $data = $table->find('all')->where(["citation_id" => $citation_id])->order(["id" => "DESC"])->first();

        if (!empty($data)) {
            $competitiveJson = $data->competitive_citation; // getting value from database
            if (!empty($competitiveJson)) {
                $competitiveData = json_decode($competitiveJson);
                $competitiveCitationsData = $competitiveData->competitorCitationData;

                /* Loop for set competitor citations value into array */
                foreach ($competitiveCitationsData as $key => $val):

                    $citationsReportId = str_replace("/citations", "", $val->citationReportCitationsId); // citation report id 
                    $result[$key]["keyword"] = $val->serpData->keywordSearch->keyword;
                    $result[$key]["googleLocation"] = $val->serpData->keywordSearch->googleLocation;
                    $result[$key]["resultType"] = $val->serpData->serpResult->resultType;
                    $result[$key]["rank"] = $val->serpData->serpResult->rank;
                    $result[$key]["title"] = $val->serpData->serpResult->title;
                    $result[$key]["totalVerifiedCitations"] = $val->citationReportRun->totalVerifiedCitations;
                    $result[$key]["mentions"] = $val->citationReportRun->totalMentions;
                    $result[$key]["averageDomainAuthority"] = sprintf("%.2f", $val->citationReportRun->averageDomainAuthority);
                    $result[$key]["averagePageAuthority"] = sprintf("%.2f", $val->citationReportRun->averagePageAuthority);
                    $result[$key]["averageMozRank"] = sprintf("%.2f", $val->citationReportRun->averageMozRank);
                    $result[$key]["averageLinks"] = sprintf("%.2f", $val->citationReportRun->averageLinks);

                endforeach;

                if (!empty($result)) {
                    return $result;
                } else {
                    return 0;
                }
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }

    /*
     * Date :- 08-july-17
     * Function Disc :- Function for get opportunities report 
     */

    private function getOpportunitiesReport($citation_id) {

        $table = $this->loadModel('Citationlist');
        $data = $table->find('all')->select(["citation_id", "id"])->where(["citation_id" => $citation_id])->first();

        if (empty($data)) {
            $this->json(0, "Citations Opportunities Not Found");
        }

        if ($data->citation_id != "" && !empty($data->citation_id)) {
            $db = TableRegistry::get('tbl_citation_competitor');
            $citationsOpportunitiesData = $db->find()->select(["citations"])->where(["citation_tracker_id" => $data->id])->order(["created" => 'DESC'])->first();

            if (!empty($citationsOpportunitiesData->citations)) {
                $citation_data = json_decode($citationsOpportunitiesData->citations); // data from tbl_citation_competitor 
                $citation_report = $citation_data[0]->citations;
                if (!empty($citation_report)) {
                    $i = 0;
                    foreach ($citation_report as $key => $value):

                        $isCitationVerified = $value->isCitationVerified;
                        $isCitationVerified = $isCitationVerified == 1 ? 'Y' : 'N';
                        $sc_pa = $sc_da = '';
                        $mozRank = 0;
                        if (isset($value->seoMozData->domainAuthority)) {

                            $sc_da = round($value->seoMozData->domainAuthority, 2);
                            $mozRank = round($value->seoMozData->rootDomainMozRank, 2);
                            $sc_pa = round($value->seoMozData->pageAuthority, 2);
                        }


                        if (isset($citation_opp_arr[$value->name])) {

                            $citation_opp_arr[$i]['num_competitor'] += 1;

                            if ($sc_da > $citation_opp_arr[$i]['DA']) {
                                $citation_opp_arr[$i]['DA'] = $sc_da;
                            }
                            if ($mozRank > $citation_opp_arr[$i]['mozRank']) {
                                $citation_opp_arr[$i]['mozRank'] = $mozRank;
                            }
                        } else {

                            $citation_opp_arr[$i]['site'] = $this->appendhttp($value->name);
                            $citation_opp_arr[$i]['link'] = $value->link;
                            $citation_opp_arr[$i]['DA'] = $sc_da;
                            $citation_opp_arr[$i]['num_competitor'] = 1;
                            $citation_opp_arr[$i]['mozRank'] = $mozRank;
                            if (isset($citaion_site_list[$i])) {
                                $citation_opp_arr[$i]['total_citaion'] = $citaion_site_list[$value->name];
                                $citation_opp_arr[$i]['have_citation'] = 'Y';
                            } else {
                                $citation_opp_arr[$i]['total_citaion'] = 0;
                                $citation_opp_arr[$i]['have_citation'] = 'N';
                            }
                        }
                        $i++;
                    endforeach;

                    if (!empty($citation_opp_arr)) {
                        return $citation_opp_arr;
                    } else {
                        return 0;
                    }
                } else {
                    return 0;
                }
            }return 0;
        } else {
            return 0;
        }
    }
    
    /*
     * Date :- 10-july-17
     * Function for get all list of primary (Top Citation) List 
     */
    
    private function listPrimary(){
        try{
            $conn = ConnectionManager::get('default');
            $stmt = $conn->execute("SELECT TRIM(BOTH '/' FROM REPLACE( REPLACE( REPLACE( domain_name, 'http://', '' ) , 'https://', '' ) , 'www.', '' ) ) AS urls, logo, score, id FROM tbl_citations_manager WHERE is_top_hundred = 1");
            
            $row = $stmt->fetchAll('assoc');
            
            if(!empty($row)){
                return $row;
            } else {
                return false;
            }
            
        } catch (\Exception $ex) {
            
        } catch(\PDOException $e){
            
        }
        
    }

}

