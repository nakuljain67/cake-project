<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;
use PHPMailer;
use Cake\Mailer\Email;

class UserController extends AppController {

    private $connection;

    public function initialize() {
        parent::initialize();
        $this->loadComponent('SmartEmail');
        header('Access-Control-Allow-Origin: *');
        $this->connection = ConnectionManager::get('default');
    }

    /* default called method */

    public function index() {

        $this->autoRender = false;
        $this->json(1, array(
            "method" => "index",
            "messge" => "silence is golden"
        ));
    }

    /* login */

    public function login() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                // TEMP agency need to be dynamic later 
                //$agency_id = 2;
                $agency_id = isset($_REQUEST['client_id']) && trim($_REQUEST['client_id']) != '' ? trim(htmlspecialchars($_REQUEST['client_id'])) : md5(2); // default agency is 2                

                $email = isset($_REQUEST['email']) ? trim($_REQUEST['email']) : "";
                $password = isset($_REQUEST['password']) ? trim($_REQUEST['password']) : "";
                $login_type = isset($_REQUEST['login_type']) ? htmlspecialchars(trim($_REQUEST['login_type'])) : "portal"; // 'admin', 'portal' : for superadmin only

                $conditions = array(
                    'AND' => array(
                        array("email" => $email),
                        array("password" => md5($password))
                ));
                
                $this->loadModel('User');
                $this->loadModel('Location');
                $this->loadModel('LocationMap');
                $results = $this->User->find()->where($conditions)->contain(["Usertype"])->first();

                if (!empty($results)) {
                    if ($results->status == 0) {
                        $this->json(0, "Your account is decativated. Please contact to administrator.");
                    }

                    $user_id = $results->id;
                    
                    if ($results->usertype->code != 'SADM') {
                        $useragency = md5($results->agency_id);
                        if($agency_id != $useragency){
                            $this->json(0, "You are authorized to access this agency.",$useragency.' = '.$agency_id);
                        }
                    }
                    
                    $location_id = 0;
                    $website = "";
                    $name = "";
                                        
                    // check permissions : Admin and superadmin can access all locations
                    $reqadmin = 0;
                    if ($results->usertype->code == 'SADM') {
                        if($login_type == "admin"){
                            // TEMP seprate UI for superadmin - Need to add code in future
                            $this->json(0, "Hello superadmin, Your UI is in progress.");
                        }
                        else{
                            // in case if superadmin want to access portal as agency admin
                            $reqadmin = 1;
                        }
                        
                    } else if ($results->usertype->code == 'ADM') {
                        $reqadmin = 1;                                                                 
                    }
                    
                    if($reqadmin == 1){
                        $res = $this->Location->find("all", [
                                    'conditions' => ["MD5(Location.agency_id)" => $agency_id, "Location.status" => "1"],
                                    'order' => ['Location.id' => 'asc'],
                                ])->first();
                        if (!empty($res)) {
                            // case of agency admin, if no location created : redirect admin on location page                                                        
                            $location_id = $res->id;
                            $website = $res->website;
                            $name = $res->name;
                        }  
                    }
                    else{
                        $res = $this->Location->find("all", [
                                    'conditions' => ["MD5(Location.agency_id)" => $agency_id, "Location.status" => "1", 'Location.id' => 'SELECT location_id FROM '
                                        . 'tbl_location_mapping WHERE user_id = ' . $user_id . ' ORDER BY id ASC LIMIT 1'],
                                    'order' => ['Location.id' => 'asc'],
                                ])->first();
                        if (empty($res)) {
                            $this->json(0, "We do not find any location assigned to you. Please contact to agency admin");
                        }
                        $location_id = $res->id;
                        $website = $res->website;
                        $name = $res->name;
                    }
                    

                    $userToken = sha1($this->generateRandomString());  
                    $user_details = array();
                    array_push($user_details, array(
                        "firstName" => $results->fname,
                        "lastName" => $results->lname,
                        "email" => $results->email,
                        "usertype" => $results->usertype->type,
                        "token" => $userToken,                        
                        "location_id" => $location_id,
                        "website" => $website,
                        "name" => $name
                    ));

                    /* make user entry to token table */
                    $usr_token_tbl = TableRegistry::get('tbl_userlive_tokens');
                    $user_tkn = $usr_token_tbl->newEntity();
                    $user_tkn->userid = $results->id;
                    $user_tkn->token = $userToken;
                    $user_tkn->location_id = $location_id;
                    $user_tkn->token_created = date("Y-m-d H:i:s");
                    $user_tkn->token_expire = date("Y-m-d H:i:s", strtotime("+" . token_expire_days . " days"));

                    if ($usr_token_tbl->save($user_tkn)) {
                        // delete expired tokens
                        $now = date('Y-m-d H:i:s');
                        $usr_token_tbl->deleteAll(["token_expire < " => $now]);
                        $this->json(1, "Login successful", $user_details);
                    } else {
                        $this->json(0, "Login unsuccessful");
                    }
                } else {
                    /* invalid login */
                    $this->json(0, "Invalid Login");
                }
            } catch (Exception $ex) {
                
            }
        } else {
            $this->json(0, "silence is golden");
        }
    }

    /* check valid email */

    public function checkEmailValidity() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {
                $email = isset($_REQUEST['email']) ? trim($_REQUEST['email']) : "";
                if ($this->is_email_valid($email)) {

                    $this->json(1, "Valid email");
                } else {

                    $this->json(0, "Invalid email");
                }
            } catch (Exception $ex) {
                
            }
        } else {
            $this->json(0, "silence is golden");
        }
    }

    /* forget password */

    public function forgetPassword() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $users_table = TableRegistry::get('tbl_users');

                $email = isset($_REQUEST['email']) ? $_REQUEST['email'] : "";
                $url = isset($_REQUEST['url']) ? $_REQUEST['url'] : "";

                if (!empty($email) && !empty($url)) {
                    if ($this->is_email_valid($email)) {
                        $to = $email;
                        $from = "notifications@enfusen.com";
                        $link = $url;
                        $type = "forgot_password";

                        $mailSentResponse = $this->SmartEmail->SendMail($to, $from, $link, $type);

                        if ($mailSentResponse['status'] == 1) {
                            $users_table->updateAll(['verify_code' => $mailSentResponse['token']], ['email' => $email]);
                            $this->json(1, "Mail sent");
                        } else {

                            $this->json(0, "Failed to send mail");
                        }
                    } else {

                        $this->json(0, "Invalid email");
                    }
                } else {
                    echo $this->json(0, "Empty fields found");
                }
            } catch (Exception $ex) {
                
            }
        } else {
            $this->json(0, "silence is golden");
        }
    }

    /* Change Password */

    public function changePassword() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $users_table = TableRegistry::get('tbl_users');
                $token = isset($_REQUEST['token']) ? htmlspecialchars(trim($_REQUEST['token'])) : "";
                $conf_password = isset($_REQUEST['confpassword']) ? htmlspecialchars(trim($_REQUEST['confpassword'])) : "";
                $password = isset($_REQUEST['password']) ? htmlspecialchars(trim($_REQUEST['password'])) : "";
                $url = isset($_REQUEST['url']) ? trim($_REQUEST['url']) : "";
                /* password comaparison */

                if ($token == '') {
                    $this->json(0, "Invalid token");
                }
                if ($password == '') {
                    $this->json(0, "Password cannot be empty");
                }
                if ($conf_password == $password) {
                    /* is token valid  */
                    if ($this->isTokenExists($token)) {
                        /* updating user data */
                        $users_table->updateAll(['password' => md5($password)], ['verify_code' => $token]);
                        /* getting user email by token value */
                        $email = $this->getTableSingleDataByValue("tbl_users", "verify_code", $token, "email");
                        $email = $email[0]['email'];

                        $to = $email;
                        $from = "notifications@enfusen.com";
                        $link = $url;
                        $type = "reset_password";

                        $mailSentResponse = $this->SmartEmail->SendMail($to, $from, $link, $type);

                        if ($mailSentResponse['status'] == 1) {

                            $users_table->updateAll(['verify_code' => ''], ['email' => $email]);
                            $this->json(1, "Password Changed, Please check mail");
                        } else {

                            $this->json(0, "Failed to send mail");
                        }
                    } else {
                        $this->json(0, "Invalid token");
                    }
                } else {
                    $this->json(0, "Password not matched");
                }
            } catch (Exception $ex) {
                
            }
        } else {
            $this->json(0, "silence is golden");
        }
    }

    /* Check token exists or not */

    public function isTokenExists($token) {

        try {

            $users_table = TableRegistry::get('tbl_users');

            $total_rows = $users_table->find('all', [
                        'conditions' => ['verify_code' => $token]
                    ])->count();

            if ($total_rows > 0) {
                return true;
            }
            return false;
        } catch (Exception $ex) {
            
        }
    }

    /* delete all live token of users */

    public function deleteAllUserLiveSessions($userId) {

        try {

            $usr_token_tbl = TableRegistry::get('tbl_userlive_tokens');

            $total_rows = $usr_token_tbl->find('all', [
                        'conditions' => ['userid' => $userId]
                    ])->count();

            if ($total_rows > 0) {
                $usr_token_tbl->deleteAll(['userid' => $userId]);
                return true;
            }
            return false;
        } catch (Exception $ex) {
            
        }
    }

    /* delete a particular user live token */

    public function deleteUserCurrentSession($token) {

        try {

            $usr_token_tbl = TableRegistry::get('tbl_userlive_tokens');

            $total_rows = $usr_token_tbl->find('all', [
                        'conditions' => ['token' => $token]
                    ])->count();

            if ($total_rows > 0) {

                $usr_token_tbl->deleteAll(['token' => $token]);

                return true;
            }
            return false;
        } catch (Exception $ex) {
            
        }
    }

    /* do user logout */

    public function logout() {

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $token = isset($_REQUEST['token']) ? trim($_REQUEST['token']) : 0;

                if (!empty($token) && $token != 0) {

                    if ($this->deleteUserCurrentSession($token)) {

                        $this->json(1, "User logged out successfully");
                    } else {

                        $this->json(0, "Invalid Token");
                    }
                } else {
                    $this->json(0, "Invalid Token");
                }
            } catch (Exception $ex) {
                
            }
        } else {
            $this->json(0, "silence is golden");
        }
    }

    /* delete all live user sessions */

    public function logoutAllSession() {

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            try {

                $token = isset($_REQUEST['token']) ? trim($_REQUEST['token']) : 0;

                $userToken = $this->fetchTokenDetails($token);

                if (!empty($userToken)) {

                    $user_id = $userToken['user_id'];

                    if ($this->deleteAllUserLiveSessions($user_id)) {

                        $this->json(1, "User logged out successfully");
                    } else {

                        $this->json(0, "Failed to do user logout");
                    }
                } else {
                    $this->json(0, "Invalid Token");
                }
            } catch (Exception $ex) {
                
            }
        } else {
            $this->json(0, "silence is golden");
        }
    }

}

?>
