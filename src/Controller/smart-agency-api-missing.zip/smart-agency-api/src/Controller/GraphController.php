<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;

class GraphController extends AppController {

    private $connection;

    public function initialize() {
        parent::initialize();
        header('Access-Control-Allow-Origin: *');
        $this->loadModel("Keyword");
        $this->connection = ConnectionManager::get('default');
    }

    /* default method called */

    public function index() {

        $this->autoRender = false;

        $this->json(0, "silence is golden");
    }

    /*
     * This function is used to make graph for all tabs keywords, competitor, rank vs target, executive summary report and 
     * keyword history as well
     */

    public function makeGraph() {

        $this->autoRender = false;
        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $data = json_decode(file_get_contents('php://input'));
            $token = $this->request->header("token");
            $campaign_id = isset($data->campaign_id) ? intval($data->campaign_id) : 0; // json object
            $graphType = isset($data->gtype) ? trim($data->gtype) : 'keyword'; // json object
            $from_date = isset($data->from_date) ? trim($data->from_date) : date("Y-m-d", strtotime("-31 day")); // json object
            $to_date = isset($data->to_date) ? trim($data->to_date) : date("Y-m-d", strtotime("-1 day")); // json object
            $last_days = isset($data->count_days) ? intval($data->count_days) : 90;
            // count_days parameter is only used with keyword history, default value for count_days: 90 it can be either 90, 180, 365
            // $graphType should be someting like this: keyword, competitor, rank_vs_target, executive_report, keyword_history
            if (!empty($token)) {

                try {

                    if ($this->is_token_valid()) {

                        $tokenDetails = $this->fetchTokenDetails($token);
                        $location_id = $tokenDetails['location_id'];
                        $user_id = $tokenDetails['user_id'];

                        if ($graphType == "keyword") {
                            // keyword section is for all keywords, target keywords and manage keywords
                            $getWeeklyData = $this->getWeeklyDataMetrics($from_date, $to_date, $location_id, $campaign_id);
                            $getMonthlyData = $this->getMonthlyDataMetrics($from_date, $to_date, $location_id, $campaign_id);

                            $this->json(1, "keyword data found", array("weekly" => $getWeeklyData, "monthly" => $getMonthlyData));
                        } else if ($graphType == "competitor") {
                            // competitor section graph includes competitor and and keyword research.
                            $competitor_urls = $this->getLocationCompetitors($location_id);
                            $comp_array = array();
                            foreach ($competitor_urls as $key => $value) {
                                array_push($comp_array, $value['website']);
                            }
                            $getWeeklyData = $this->getCompetitorWeeklyDataMetrics($from_date, $to_date, $location_id, $campaign_id);
                            $getMonthlyData = $this->getCompetitorMonthlyDataMetrics($from_date, $to_date, $location_id, $campaign_id);

                            $this->json(1, "competitor data found", array("weekly" => $getWeeklyData, "monthly" => $getMonthlyData));
                        } else if ($graphType == "rank_vs_target") {

                            $left_side_value = $this->getRankVsTargetLeftSideValue($from_date, $to_date, $location_id, $campaign_id);
                            $ranking_data = $this->getRankVsTargetPercentageData($from_date, $to_date, $location_id, $campaign_id);
                            $avg_position = $this->getRankVsTargetAvgPositionData($from_date, $to_date, $location_id, $campaign_id);

                            $this->json(1, "rank_vs_target data found", array(
                                "left_side_metrics" => $left_side_value,
                                "ranking_percentage" => $ranking_data,
                                "avg_position" => $avg_position
                            ));
                        } else if ($graphType == "executive_report") {

                            $this->json(1, "executive data found", $this->getExecutiveSummaryReport($location_id));
                        } else if ($graphType == "keyword_history") {

                            $datas = $this->getKeywordHistoryData($last_days, $location_id, $campaign_id);
                            $this->json(1, "keyword history found", $datas);
                        } else {
                            $this->json(0, "invalid graph type", array("gtype" => "required"));
                        }
                    } else {

                        $this->json(0, "invalid token", array("token" => "required"));
                    }
                } catch (\Exception $ex) {
                    // error_log
                }
            }
        } else {
            
        }
    }

    public function getKeywordHistoryData($last_his_days, $location_id, $campaign_id) {

        if ($campaign_id == 0) {
            $cond = 'location_id = ' . $location_id;
        } else {
            if ($this->Keyword->is_valid_campaign($campaign_id)) {
                if ($campaign_id > 0) {
                    $cond = " AND campaign_id = $campaign_id";
                }
            } else {
                $this->json(0, "Invalid Campaign Id");
            }
        }

        $from_date = date("Y-m", strtotime("-2 months", time())) . '-01';
        $to_date = date("Y-m-d", time() - 8 * 24 * 3600);
        $active_c = 30;
        if (isset($last_his_days) && ($last_his_days == '180' || $last_his_days == '365')) {
            if ($last_his_days == '180') {
                $from_date = date("Y-m", strtotime("-5 months", time())) . '-01';
            } else if ($last_his_days == '365') {
                $from_date = date("Y-m", strtotime("-11 months", time())) . '-01';
            }
            $active_c = $last_his_days;
        }

        $new_date = $from_date;
        $rank_date_arr = array();
        $rank_date_arr[] = $new_date;
        while ($new_date < $to_date) {
            $change_date = date("Y-m-d", strtotime("first day of +1 month", strtotime($new_date)));
            $new_date = $change_date;
            if ($change_date < $to_date) {
                $rank_date_arr[] = $change_date;
            }
        }

        if (date('d') > 7) { // we had got current month keywords data
            $rank_date_arr[] = date('Y-m-') . '01';
        } else {
            for ($check_m_day = 1; $check_m_day <= date('d'); $check_m_day++) {
                if (date('l', strtotime(date('Y-m-') . '0' . $check_m_day)) == 'Monday') { //Get current month data
                    $rank_date_arr[] = date('Y-m-') . '01';
                }
            }
        }

        $rank_date_arr = array_unique($rank_date_arr);
        $y = 0;
        $cat_data = '';
        foreach ($rank_date_arr as $row_cat) {
            $cat_data .= '"' . date("m/d/Y", strtotime($row_cat)) . '",';
        }

        $sqlQueryToGetAllGroups = "SELECT id,landing_page,is_target FROM tbl_keygroup where $cond";
        $keywordgrps = $this->connection->execute($sqlQueryToGetAllGroups)->fetchAll("assoc");
        // groups array

        $groups_array = array();
        $xAxis = $rank_date_arr;

        foreach ($keywordgrps as $index => $keywordgrp) {

            $group_id = $keywordgrp['id'];
            $is_target = $keywordgrp['is_target'];


            $sqlQueryToGetDataKeywords = "SELECT keyword,ranked_url, rank, group_id, isprimary, location_id FROM tbl_keywords "
                    . "WHERE $cond AND group_id = $group_id "
                    . " ORDER BY isprimary DESC";

            $getDataResults = $this->connection->execute($sqlQueryToGetDataKeywords)->fetchAll('assoc');

            $keywords_array = array();

            foreach ($getDataResults as $ind => $keywordrow) {

                $keywordtext = $keywordrow['keyword'];
                if (empty($keywordtext))
                    continue;
                $is_primary = $keywordrow['isprimary'];
                $unique_key_name = str_replace(array(" ", "'"), "", $keywordtext);
                $timedkeyword = trim(strtolower($keywordrow['keyword']));
                $totalcnt = count($rank_date_arr);

                $data_points = array();
                $data_values = array();
                foreach ($rank_date_arr as $indx => $row_cat) {

                    $rnkunm = 0;
                    $fromdate = $row_cat;
                    $keywords = array();
                    $todate = date("Y-m-t", strtotime($row_cat));

                    $lastindx = $indx + 1;

                    if ($lastindx == $totalcnt) {

                        $sqlQueryToGetData = "SELECT keyword,ranked_url, rank, group_id, isprimary, location_id FROM tbl_keywords "
                                . "WHERE $cond AND LOWER(TRIM(keyword)) = '$timedkeyword' AND group_id = $group_id "
                                . " ORDER BY dateOfRank DESC LIMIT 1";
                    } else {

                        $sqlQueryToGetData = "SELECT keyword,ranked_url, rank, group_id, isprimary, location_id FROM tbl_keywords_history "
                                . "WHERE $cond AND LOWER(TRIM(keyword)) = '$timedkeyword' AND group_id = $group_id AND "
                                . "dateOfRank >= '$fromdate' AND dateOfRank <= '$todate' ORDER BY dateOfRank DESC LIMIT 1";
                    }

                    $keyworddata = $this->connection->execute($sqlQueryToGetData)->fetchAll('assoc');

                    if (empty($keyworddata)) {

                        $sqlQueryToGetData = "SELECT keyword,ranked_url, rank, group_id, isprimary, location_id FROM tbl_keywords "
                                . "WHERE $cond AND LOWER(TRIM(keyword)) = '$timedkeyword' AND group_id = $group_id AND "
                                . "dateOfRank >= '$fromdate' AND dateOfRank <= '$todate' ORDER BY dateOfRank DESC LIMIT 1";
                        $keyworddata = $this->connection->execute($sqlQueryToGetData)->fetchAll('assoc');
                    }

                    $rank = $keyworddata[0]['rank'] == NULL || empty($keyworddata[0]['rank']) ? 50 : intval($keyworddata[0]['rank']);
                    $rank_value = $keyworddata[0]['rank'] == NULL || empty($keyworddata[0]['rank']) ? "Not in Results" : intval($keyworddata[0]['rank']);

                    array_push($data_points, intval($rank));
                    array_push($data_values, $rank_value);
                }

                array_push($keywords_array, array(
                    "name" => $keywordtext,
                    "is_target" => intval($is_target),
                    "is_primary" => intval($is_primary),
                    "data" => $data_points,
                    "data_values" => $data_values
                ));
            }
            if (count($keywords_array) > 0) {
                array_push($groups_array, array(
                    "group_id" => intval($group_id),
                    "keyword" => $keywords_array
                ));
            }
        }

        return array(
            "xAxis" => $xAxis,
            "group_info" => $groups_array
        );
    }

    public function getKeywordBottomMetrics() {

        $this->autoRender = false;

        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $token = $this->request->header("token");

            if (!empty($token)) {

                if ($this->is_token_valid()) {

                    $data = json_decode(file_get_contents('php://input'));
                    $campaign_id = isset($data->campaign_id) ? intval($data->campaign_id) : 0; // json object
                    $from_date = isset($data->from_date) ? trim($data->from_date) : date("Y-m-d", strtotime("-31 day")); // json object
                    $to_date = isset($data->to_date) ? trim($data->to_date) : date("Y-m-d", strtotime("-1 day")); // json object
                    $rankType = isset($data->rank_type) ? trim($data->rank_type) : 'rank';
                    // calculation of bottom area data metrics for keyword
                    // $rankType =  google_rank, google_maps_rank, mobile_rank, mobile_maps_rank, bing_rank, bing_maps_rank
                    $tokenDetails = $this->fetchTokenDetails($token);
                    $location_id = $tokenDetails['location_id'];
                    $user_id = $tokenDetails['user_id'];

                    $valid_values_array = ["google_rank", "google_maps_rank", "mobile_rank", "mobile_maps_rank", "bing_rank", "bing_maps_rank"];

                    if (!in_array($rankType, $valid_values_array)) {
                        $this->json(0, "Invalid Rank type value", array("rank_type" => "required", "valid_values" => $valid_values_array));
                    }

                    if ($rankType == "google_rank") {
                        $rankType = "rank";
                    } else if ($rankType == "google_maps_rank") {
                        $rankType = "maps_rank";
                    }
                    if ($campaign_id == 0) {

                        $cond = 'location_id=' . $location_id;
                    } else {
                        if ($this->Keyword->is_valid_campaign($campaign_id)) {
                            if ($campaign_id > 0) {
                                $cond = " campaign_id = $campaign_id";
                            }
                        } else {
                            $this->json(0, "Invalid Campaign Id");
                        }
                    }
                    $query = '( 0 )';
                    if ($this->is_dbtable_exists("api_short_analytics_$location_id")) {
                        $query = "(SELECT sum(organic) FROM api_short_analytics_$location_id where location_id = " . $location_id . " )";
                    } else {
                        // error_log
                    }

                    // Metrics for Keyword Change
                    $sqlQueryToFindKeywordsMetrics = "SELECT (SELECT count(k.id) from tbl_keywords k INNER JOIN tbl_keywords_history kh on k.keyword = kh.keyword where k.location_id = " . $location_id . " AND k." . $rankType . " < kh." . $rankType . " AND k." . $rankType . "<>'') as rank_up, "
                            . "(SELECT count(k.id) from tbl_keywords k INNER JOIN tbl_keywords_history kh on k.keyword = kh.keyword where k.location_id = " . $location_id . " AND k." . $rankType . " > kh." . $rankType . " AND k." . $rankType . "<>'') as rank_down, "
                            . "(SELECT count(k.id) from tbl_keywords k INNER JOIN tbl_keywords_history kh on k.keyword = kh.keyword where k.location_id = " . $location_id . " AND k." . $rankType . " = kh." . $rankType . ") as rank_same, "
                            . "(SELECT count(id)  FROM tbl_keywords where " . $rankType . " IS NOT NULL AND " . $rankType . "<>'' AND location_id = " . $location_id . ") as count_current_ranked, "
                            . "(SELECT count(id)  FROM tbl_keywords_history where " . $rankType . " IS NOT NULL AND " . $rankType . "<>'' AND location_id = " . $location_id . " AND dateOfRank>='" . $from_date . "' AND dateOfRank<='" . $to_date . "') as count_history_ranked, "
                            . "(SELECT count(id)  FROM tbl_keywords where location_id = " . $location_id . ") as total_current_keywords, "
                            . "(SELECT count(id) FROM tbl_keywords_history where location_id = " . $location_id . " AND dateOfRank>='" . $from_date . "' AND dateOfRank<='" . $to_date . "') as total_history_keywords, "
                            . "(SELECT sum(case when " . $rankType . " IS NULL then 50 else " . $rankType . " end) FROM tbl_keywords where location_id = " . $location_id . ") as avg_current_rank_pos, "
                            . "(SELECT sum(case when " . $rankType . " IS NULL then 50 else " . $rankType . " end) FROM tbl_keywords_history where location_id = " . $location_id . " AND dateOfRank>='" . $from_date . "' AND dateOfRank<='" . $to_date . "') as avg_history_rank_pos, "
                            . "(SELECT count(id)  FROM tbl_keywords where location_id = " . $location_id . " AND " . $rankType . ">=1 AND " . $rankType . "<=10) as total_current_page1_keywords, "
                            . "(SELECT count(id) FROM tbl_keywords_history where location_id = " . $location_id . " AND dateOfRank>='" . $from_date . "' AND dateOfRank<='" . $to_date . "' AND " . $rankType . ">=1 AND " . $rankType . "<=10) as total_history_page1_keywords, "
                            . "$query as total_organic_visits ";


                    $resultsToGetKeywordsMetrics = $this->connection->execute($sqlQueryToFindKeywordsMetrics)->fetchAll("assoc");
                    //print_r($resultsToGetKeywordsMetrics);die;
                    $count_organic_visits = $count_history_page1_keywords = $count_page1_keywords = $count_page1_keywords = $history_avg_rank_keywords = $avg_rank_keywords = $avg_rank_keywords = $count_history_keywords = $count_keywords = $count_history_ranked_keywords = $count_went_up_keywords = $count_went_down_keywords = $count_stayed_same_keywords = $count_ranked_keywords = 0;

                    if (count($resultsToGetKeywordsMetrics) > 0) {

                        $count_keywords = $resultsToGetKeywordsMetrics[0]['total_current_keywords'];
                        // stayed same => current_keywords - ( went + down )
                        $count_went_up_keywords = $resultsToGetKeywordsMetrics[0]['rank_up'];
                        $count_went_down_keywords = $resultsToGetKeywordsMetrics[0]['rank_down'];
                        $stayed_same = intval($count_keywords - intval(($count_went_up_keywords + $count_went_down_keywords)));

                        $count_stayed_same_keywords = $stayed_same;
                        $count_ranked_keywords = $resultsToGetKeywordsMetrics[0]['count_current_ranked'];
                        $count_history_ranked_keywords = $resultsToGetKeywordsMetrics[0]['count_history_ranked'];
                        $count_history_keywords = $resultsToGetKeywordsMetrics[0]['total_history_keywords'];
                        $avg_rank_keywords = $resultsToGetKeywordsMetrics[0]['avg_current_rank_pos'];
                        $history_avg_rank_keywords = $resultsToGetKeywordsMetrics[0]['avg_history_rank_pos'];
                        $count_page1_keywords = $resultsToGetKeywordsMetrics[0]['total_current_page1_keywords'];
                        $count_history_page1_keywords = $resultsToGetKeywordsMetrics[0]['total_history_page1_keywords'];
                        $count_organic_visits = $resultsToGetKeywordsMetrics[0]['total_organic_visits'];
                    }

                    $history_ranking = $count_history_keywords == 0 ? 0 : floatval($count_history_ranked_keywords / $count_history_keywords);
                    $history_avg_rank = $count_history_keywords == 0 ? 0 : floatval($history_avg_rank_keywords / $count_history_keywords);
                    $total_ranking_avg = floatval(floatval($count_ranked_keywords / $count_keywords) - $history_ranking);
                    $average_post = floatval(floatval($avg_rank_keywords / $count_keywords) - $history_avg_rank);

                    $pages = $this->getLocationLandingPages($from_date, $to_date, $location_id, 0);
                    $landing_page_visits = 0;
                    $landing_pages_tracked_array = array();
                    // adding visits for landing pages
                    foreach ($pages as $dt) {

                        $visits_count = 0;
                        $webname = trim(trim(str_replace(array('http://', 'https://', 'www.'), array('', '', ''), $dt), "/"));
                        if ($this->is_dbtable_exists("api_short_analytics_$location_id")) {
                            $sql = "SELECT sum(organic) as organic_val FROM `api_short_analytics_$location_id` "
                                    . "WHERE TRIM(BOTH  '/' FROM REPLACE(REPLACE(REPLACE (pageURL, 'http://', ''),'https://',''),'www.','')) = '$webname' "
                                    . "group by pageURL order by dateOfVisit DESC LIMIT 1";
                            $countToGetData = $this->connection->execute($sql)->fetchAll("assoc");
                            if (count($countToGetData) > 0) {
                                $visits_count = $countToGetData[0]['organic_val'];
                            }
                        }
                        array_push($landing_pages_tracked_array, array(
                            "url" => $dt,
                            "visits" => $visits_count
                        ));

                        $landing_page_visits += $visits_count;
                    }

                    $output = array(
                        "went_up" => intval($count_went_up_keywords),
                        "went_down" => intval($count_went_down_keywords),
                        "stayed_same" => intval($count_stayed_same_keywords),
                        "total_ranking" => $count_ranked_keywords . "/" . $count_keywords,
                        "total_average_ranking" => sprintf("%.2f", $total_ranking_avg),
                        "total_average_position" => sprintf("%.2f", floatval($avg_rank_keywords / $count_keywords)),
                        "average_position" => sprintf("%.2f", $average_post),
                        "page1_ranking" => $count_page1_keywords,
                        "history_page1_ranking" => intval($count_page1_keywords - $count_history_page1_keywords),
                        "total_organic_visits" => $count_organic_visits,
                        "landing_pages_visits" => $landing_page_visits,
                        "landing_pages" => $landing_pages_tracked_array
                    );
                    $this->json(1, "data found", $output);
                } else {
                    $this->json(0, "invalid token", array("token" => "required"));
                }
            } else {
                $this->json(0, "invalid token", array("token" => "required"));
            }
        } else {
            
        }
    }

    public function getWeeklyDataMetrics($from_date, $to_date, $location_id, $campaign_id) {
// weekly calculation of data metrics
        $new_date = $from_date;
        $rank_date_arr = array();
        $rank_date_arr[] = $new_date;
        while ($new_date < $to_date) {
            $change_date = date('Y-m-d', strtotime($new_date) + 7 * 24 * 3600);
            $new_date = $change_date;
            if ($change_date < $to_date) {
                $rank_date_arr[] = $change_date;
            }
        }
        $rank_date_arr[] = $to_date;
        unset($rank_date_arr[count($rank_date_arr) - 1]);

        $total_rank_data = array();
        $first_place_data = array();
        $top_3_data = array();
        $top_10_data = array();

        $gorganic_avg_postion = 0;
        $gmaps_avg_postion = 0;
        $borganic_avg_postion = 0;
        $bmaps_avg_postion = 0;
        $mobile_avg_postion = 0;
        $mmaps_avg_postion = 0;

        if ($campaign_id == 0) {
            $cond = 'location_id=' . $location_id;
        } else {
            if ($this->Keyword->is_valid_campaign($campaign_id)) {
                if ($campaign_id > 0) {
                    $cond = " AND campaign_id = $campaign_id";
                }
            } else {
                $this->json(0, "Invalid Campaign Id", array());
            }
        }

        foreach ($rank_date_arr as $index_chart_date => $row_chart_date) {

            $last_index = $index_chart_date + 1;
            $DateOfRank1 = $row_chart_date;
            if (isset($rank_date_arr[$index_chart_date + 1])) {
                $DateOfRank2 = $rank_date_arr[$index_chart_date + 1];
            } else {
                $DateOfRank2 = $DateOfRank1;
            }

            $sql = "SELECT rank,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank, dateOfRank FROM tbl_keywords_history WHERE $cond and dateOfRank > '$DateOfRank1 00:00:00' and dateOfRank <= '$DateOfRank2 23:59:59' group by keyword";

            if (count($rank_date_arr) == $last_index) {
                $sql = "SELECT rank,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank, dateOfRank FROM tbl_keywords WHERE $cond group by keyword";
            }

            $date_result = $this->connection->execute($sql)->fetchAll("assoc");

            if ($index_chart_date == 0 && empty($date_result)) {
                $sql = "SELECT rank,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank, dateOfRank FROM tbl_keywords_history WHERE $cond group by keyword order by dateOfRank desc";
                $date_result = $this->connection->execute($sql)->fetchAll("assoc");
            }

            if (!empty($date_result)) {

                $goranic_rank = 0;
                $total_rank_gorganic = $first_place_rank_gorganic = $top_3_rank_gorganic = $top_10_rank_gorganic = $total_keywords_rank_gorganic = 0;

                $gmaps_rank = 0;
                $total_rank_gmaps = $first_place_rank_gmaps = $top_3_rank_gmaps = $top_10_rank_gmaps = $total_keywords_rank_gmaps = 0;

                $borganic_rank = 0;
                $total_rank_borganic = $first_place_rank_borganic = $top_3_rank_borganic = $top_10_rank_borganic = $total_keywords_rank_borganic = 0;

                $bmaps_rank = 0;
                $total_rank_bmaps = $first_place_rank_bmaps = $top_3_rank_bmaps = $top_10_rank_bmaps = $total_keywords_rank_bmaps = 0;

                $mobile_rank = 0;
                $total_rank_mobile = $first_place_rank_mobile = $top_3_rank_mobile = $top_10_rank_mobile = $total_keywords_rank_mobile = 0;

                $mmaps_rank = 0;
                $total_rank_mmaps = $first_place_rank_mmaps = $top_3_rank_mmaps = $top_10_rank_mmaps = $total_keywords_rank_mmaps = 0;

                $count_date_result = count($date_result);

                foreach ($date_result as $index => $row_result) {
// gogole organic rank
                    if (!empty($row_result['rank'])) {
                        $goranic_rank = $row_result['rank'];
                    }
// gogole map organic rank
                    if (!empty($row_result['maps_rank'])) {
                        $gmaps_rank = $row_result['maps_rank'];
                    }
// Bing organic rank
                    if (!empty($row_result['bing_rank'])) {
                        $borganic_rank = $row_result['bing_rank'];
                    }
// Bing maps rank
                    if (!empty($row_result['bing_maps_rank'])) {
                        $bmaps_rank = $row_result['bing_maps_rank'];
                    }
// Mobie rank
                    if (!empty($row_result['mobile_rank'])) {
                        $mobile_rank = $row_result['mobile_rank'];
                    }
// Mobie Maps rank
                    if (!empty($row_result['mobile_maps_rank'])) {
                        $mmaps_rank = $row_result['mobile_maps_rank'];
                    }

// Google Organic Rank Calculation Start
                    if ($goranic_rank > 0) {
                        $total_rank_gorganic += 1;
                        $total_keywords_rank_gorganic += $goranic_rank;
                    } else {
                        $total_keywords_rank_gorganic += 50;
                    }

                    if ($goranic_rank == 1) {
                        $first_place_rank_gorganic += 1;
                    }
                    if ($goranic_rank >= 1 && $goranic_rank <= 3) {
                        $top_3_rank_gorganic += 1;
                    }
                    if ($goranic_rank >= 1 && $goranic_rank <= 10) {
                        $top_10_rank_gorganic += 1;
                    }
// Google Organic Rank Calculation End
// Google Maps Rank Calculation Start
                    if ($gmaps_rank > 0) {
                        $total_rank_gmaps += 1;
                        $total_keywords_rank_gmaps += $gmaps_rank;
                    } else {
                        $total_keywords_rank_gmaps += 50;
                    }

                    if ($gmaps_rank == 1) {
                        $first_place_rank_gmaps += 1;
                    }
                    if ($gmaps_rank >= 1 && $gmaps_rank <= 3) {
                        $top_3_rank_gmaps += 1;
                    }
                    if ($gmaps_rank >= 1 && $gmaps_rank <= 10) {
                        $top_10_rank_gmaps += 1;
                    }
// Google Maps Rank Calculation End
// Bing Organic Rank Calculation Start
                    if ($borganic_rank > 0) {
                        $total_rank_borganic += 1;
                        $total_keywords_rank_borganic += $borganic_rank;
                    } else {
                        $total_keywords_rank_borganic += 50;
                    }

                    if ($borganic_rank == 1) {
                        $first_place_rank_borganic += 1;
                    }
                    if ($borganic_rank >= 1 && $borganic_rank <= 3) {
                        $top_3_rank_borganic += 1;
                    }
                    if ($borganic_rank >= 1 && $borganic_rank <= 10) {
                        $top_10_rank_borganic += 1;
                    }
// Bing Organic Rank Calculation End
// Bing Maps Rank Calculation Start
                    if ($bmaps_rank > 0) {
                        $total_rank_bmaps += 1;
                        $total_keywords_rank_bmaps += $bmaps_rank;
                    } else {
                        $total_keywords_rank_bmaps += 50;
                    }

                    if ($bmaps_rank == 1) {
                        $first_place_rank_bmaps += 1;
                    }
                    if ($bmaps_rank >= 1 && $bmaps_rank <= 3) {
                        $top_3_rank_bmaps += 1;
                    }
                    if ($bmaps_rank >= 1 && $bmaps_rank <= 10) {
                        $top_10_rank_bmaps += 1;
                    }
// Bing Maps Rank Calculation End
// Mobile Rank Calculation Start
                    if ($mobile_rank > 0) {
                        $total_rank_mobile += 1;
                        $total_keywords_rank_mobile += $mobile_rank;
                    } else {
                        $total_keywords_rank_mobile += 50;
                    }

                    if ($mobile_rank == 1) {
                        $first_place_rank_mobile += 1;
                    }
                    if ($mobile_rank >= 1 && $mobile_rank <= 3) {
                        $top_3_rank_mobile += 1;
                    }
                    if ($mobile_rank >= 1 && $mobile_rank <= 10) {
                        $top_10_rank_mobile += 1;
                    }
// Mobile Rank Calculation End
// Mobile Maps Rank Calculation Start
                    if ($mmaps_rank > 0) {
                        $total_rank_mmaps += 1;
                        $total_keywords_rank_mmaps += $mmaps_rank;
                    } else {
                        $total_keywords_rank_mmaps += 50;
                    }

                    if ($mmaps_rank == 1) {
                        $first_place_rank_mmaps += 1;
                    }
                    if ($mmaps_rank >= 1 && $mmaps_rank <= 3) {
                        $top_3_rank_mmaps += 1;
                    }
                    if ($mmaps_rank >= 1 && $mmaps_rank <= 10) {
                        $top_10_rank_mmaps += 1;
                    }
// Mobile Maps Rank Calculation End
                }

                $gorganic_avg_postion = sprintf("%.2f", $total_keywords_rank_gorganic / $count_date_result);
                $gmaps_avg_postion = sprintf("%.2f", $total_keywords_rank_gmaps / $count_date_result);
                $borganic_avg_postion = sprintf("%.2f", $total_keywords_rank_borganic / $count_date_result);
                $bmaps_avg_postion = sprintf("%.2f", $total_keywords_rank_bmaps / $count_date_result);
                $mobile_avg_postion = sprintf("%.2f", $total_keywords_rank_mobile / $count_date_result);
                $mmaps_avg_postion = sprintf("%.2f", $total_keywords_rank_mmaps / $count_date_result);
            }

// google organcic total start

            $totalrank_gorganic[$row_chart_date] = sprintf("%.2f", ($total_rank_gorganic / $count_date_result) * 100);
            $avg_postion_gorganic[$row_chart_date] = $gorganic_avg_postion;
            $first_place_gorganic[$row_chart_date] = $first_place_rank_gorganic;
            $top_3_gorganic[$row_chart_date] = $top_3_rank_gorganic;
            $top_10_gorganic[$row_chart_date] = $top_10_rank_gorganic;
// google organcic total end
// google maps total start

            $totalrank_gmaps[$row_chart_date] = sprintf("%.2f", ($total_rank_gmaps / $count_date_result) * 100);
            $avg_postion_gmaps[$row_chart_date] = $gmaps_avg_postion;
            $first_place_gmaps[$row_chart_date] = $first_place_rank_gmaps;
            $top_3_gmaps[$row_chart_date] = $top_3_rank_gmaps;
            $top_10_gmaps[$row_chart_date] = $top_10_rank_gmaps;
// google maps total end    
// bing organcic total start

            $totalrank_borganic[$row_chart_date] = sprintf("%.2f", ($total_rank_borganic / $count_date_result) * 100);
            $avg_postion_borganic[$row_chart_date] = $borganic_avg_postion;
            $first_place_borganic[$row_chart_date] = $first_place_rank_borganic;
            $top_3_borganic[$row_chart_date] = $top_3_rank_borganic;
            $top_10_borganic[$row_chart_date] = $top_10_rank_borganic;
// bing organcic total end
// bing maps total start    
//pr($total_rank_bmaps);

            $totalrank_bmaps[$row_chart_date] = sprintf("%.2f", ($total_rank_bmaps / $count_date_result) * 100);
            $avg_postion_bmaps[$row_chart_date] = $bmaps_avg_postion;
            $first_place_bmaps[$row_chart_date] = $first_place_rank_bmaps;
            $top_3_bmaps[$row_chart_date] = $top_3_rank_bmaps;
            $top_10_bmaps[$row_chart_date] = $top_10_rank_bmaps;
// bing maps total end
// Mobile total start

            $totalrank_mobile[$row_chart_date] = sprintf("%.2f", ($total_rank_mobile / $count_date_result) * 100);
            $avg_postion_mobile[$row_chart_date] = $mobile_avg_postion;
            $first_place_mobile[$row_chart_date] = $first_place_rank_mobile;
            $top_3_mobile[$row_chart_date] = $top_3_rank_mobile;
            $top_10_mobile[$row_chart_date] = $top_10_rank_mobile;
// Mobile total end
// Mobile maps total start

            $totalrank_mmaps[$row_chart_date] = sprintf("%.2f", ($total_rank_mmaps / $count_date_result) * 100);
            $avg_postion_mmaps[$row_chart_date] = $mmaps_avg_postion;
            $first_place_mmaps[$row_chart_date] = $first_place_rank_mmaps;
            $top_3_mmaps[$row_chart_date] = $top_3_rank_mmaps;
            $top_10_mmaps[$row_chart_date] = $top_10_rank_mmaps;
// Mobile maps total end 
        }

// gorganic Last Step Data Start

        $total_rank_chart_cat_gorganic = array();
        $total_rank_chart_data_gorganic = array();

        foreach ($totalrank_gorganic as $index_gorganic => $curr_gorganic_rank) {
            array_push($total_rank_chart_cat_gorganic, date("d M", strtotime($index_gorganic)));
//$total_rank_chart_cat_gorganic .= date("d M", strtotime($index_gorganic)) . ",";
            array_push($total_rank_chart_data_gorganic, floatval($curr_gorganic_rank));
        }

        $avg_postion_chart_cat_gorganic = array();
        $avg_postion_chart_data_gorganic = array();
        foreach ($avg_postion_gorganic as $avgpos_gorganic => $curr_gorganic_avgpos) {

            array_push($avg_postion_chart_cat_gorganic, date("d M", strtotime($avgpos_gorganic)));

            array_push($avg_postion_chart_data_gorganic, floatval($curr_gorganic_avgpos));
        }
        $first_place_chart_cat_gorganic = array();
        $first_place_chart_data_gorganic = array();
        foreach ($first_place_gorganic as $top1_gorganic => $curr_gorganic_top1) {
            array_push($first_place_chart_cat_gorganic, date("d M", strtotime($top1_gorganic)));
            array_push($first_place_chart_data_gorganic, floatval($curr_gorganic_top1));
        }

        $top_3_chart_cat_gorganic = array();
        $top_3_chart_data_gorganic = array();
        foreach ($top_3_gorganic as $top3_gorganic => $curr_gorganic_top3) {
            array_push($top_3_chart_cat_gorganic, date("d M", strtotime($top3_gorganic)));
//$top_3_chart_cat_gorganic .= date("d M", strtotime($top3_gorganic)) . ',';
            array_push($top_3_chart_data_gorganic, floatval($curr_gorganic_top3));
//$top_3_chart_data_gorganic .= $curr_gorganic_top3 . ', ';
        }

        $top_10_chart_cat_gorganic = array();
        $top_10_chart_data_gorganic = array();
        foreach ($top_10_gorganic as $top10_gorganic => $curr_top10_avgpos) {
            array_push($top_10_chart_cat_gorganic, date("d M", strtotime($top10_gorganic)));
            array_push($top_10_chart_data_gorganic, floatval($curr_top10_avgpos));
        }

// gorganic Last Step Data End
// gmaps Last Step Data Start
        $total_rank_chart_cat_gmaps = array();
        $total_rank_chart_data_gmaps = array();
        foreach ($totalrank_gmaps as $index_gmaps => $curr_gmaps_rank) {
            array_push($total_rank_chart_cat_gmaps, date("d M", strtotime($index_gmaps)));
            array_push($total_rank_chart_data_gmaps, floatval($curr_gmaps_rank));
//$total_rank_chart_data_gmaps .= $curr_gmaps_rank . ', ';
        }
        $avg_postion_chart_cat_gmaps = array();
        $avg_postion_chart_data_gmaps = array();
        foreach ($avg_postion_gmaps as $avgpos_gmaps => $curr_gmaps_avgpos) {
            array_push($avg_postion_chart_cat_gmaps, date("d M", strtotime($avgpos_gmaps)));
            array_push($avg_postion_chart_data_gmaps, floatval($curr_gmaps_avgpos));
        }
        $first_place_chart_cat_gmaps = array();
        $first_place_chart_data_gmaps = array();
        foreach ($first_place_gmaps as $top1_gmaps => $curr_gmaps_top1) {
            array_push($first_place_chart_cat_gmaps, date("d M", strtotime($top1_gmaps)));
            array_push($first_place_chart_data_gmaps, floatval($curr_gmaps_top1));
        }

        $top_3_chart_cat_gmaps = array();
        $top_3_chart_data_gmaps = array();
        foreach ($top_3_gmaps as $top3_gmaps => $curr_gmaps_top3) {
            array_push($top_3_chart_cat_gmaps, date("d M", strtotime($top3_gmaps)));
            array_push($top_3_chart_data_gmaps, floatval($curr_gmaps_top3));
        }

        $top_10_chart_cat_gmaps = array();
        $top_10_chart_data_gmaps = array();
        foreach ($top_10_gmaps as $top10_gmaps => $curr_top10_avgpos) {
            array_push($top_10_chart_cat_gmaps, date("d M", strtotime($top10_gmaps)));
            array_push($top_10_chart_data_gmaps, floatval($curr_top10_avgpos));
        }
// gmaps Last Step Data End
// borganic Last Step Data Start
        $total_rank_chart_cat_borganic = array();
        $total_rank_chart_data_borganic = array();
        foreach ($totalrank_borganic as $index_borganic => $curr_borganic_rank) {
            array_push($total_rank_chart_cat_borganic, date("d M", strtotime($index_borganic)));
            array_push($total_rank_chart_data_borganic, floatval($curr_borganic_rank));
        }
        $avg_postion_chart_cat_borganic = array();
        $avg_postion_chart_data_borganic = array();
        foreach ($avg_postion_borganic as $avgpos_borganic => $curr_borganic_avgpos) {
            array_push($avg_postion_chart_cat_borganic, date("d M", strtotime($avgpos_borganic)));
            array_push($avg_postion_chart_data_borganic, floatval($curr_borganic_avgpos));
        }

        $first_place_chart_cat_borganic = array();
        $first_place_chart_data_borganic = array();
        foreach ($first_place_borganic as $top1_borganic => $curr_borganic_top1) {
            array_push($first_place_chart_cat_borganic, date("d M", strtotime($top1_borganic)));
            array_push($first_place_chart_data_borganic, floatval($curr_borganic_top1));
        }

        $top_3_chart_cat_borganic = array();
        $top_3_chart_data_borganic = array();
        foreach ($top_3_borganic as $top3_borganic => $curr_borganic_top3) {
            array_push($top_3_chart_cat_borganic, date("d M", strtotime($top3_borganic)));
            array_push($top_3_chart_data_borganic, floatval($curr_borganic_top3));
        }

        $top_10_chart_cat_borganic = array();
        $top_10_chart_data_borganic = array();
        foreach ($top_10_borganic as $top10_borganic => $curr_top10_avgpos) {
            array_push($top_10_chart_cat_borganic, date("d M", strtotime($top10_borganic)));
            array_push($top_10_chart_data_borganic, floatval($curr_top10_avgpos));
        }

// borganic Last Step Data End
// bmaps Last Step Data Start
        $total_rank_chart_cat_bmaps = array();
        $total_rank_chart_data_bmaps = array();
        foreach ($totalrank_bmaps as $index_bmaps => $curr_bmaps_rank) {
            array_push($total_rank_chart_cat_bmaps, date("d M", strtotime($index_bmaps)));
            array_push($total_rank_chart_data_bmaps, floatval($curr_bmaps_rank));
        }
        $avg_postion_chart_cat_bmaps = array();
        $avg_postion_chart_data_bmaps = array();
        foreach ($avg_postion_bmaps as $avgpos_bmaps => $curr_bmaps_avgpos) {
            array_push($avg_postion_chart_cat_bmaps, date("d M", strtotime($avgpos_bmaps)));
            array_push($avg_postion_chart_data_bmaps, floatval($curr_bmaps_avgpos));
        }
        $first_place_chart_cat_bmaps = array();
        $first_place_chart_data_bmaps = array();
        foreach ($first_place_bmaps as $top1_bmaps => $curr_bmaps_top1) {
            array_push($first_place_chart_cat_bmaps, date("d M", strtotime($top1_bmaps)));
            array_push($first_place_chart_data_bmaps, floatval($curr_bmaps_top1));
        }

        $top_3_chart_cat_bmaps = array();
        $top_3_chart_data_bmaps = array();
        foreach ($top_3_bmaps as $top3_bmaps => $curr_bmaps_top3) {
            array_push($top_3_chart_cat_bmaps, date("d M", strtotime($top3_bmaps)));
            array_push($top_3_chart_data_bmaps, floatval($curr_bmaps_top3));
        }

        $top_10_chart_cat_bmaps = array();
        $top_10_chart_data_bmaps = array();
        foreach ($top_10_bmaps as $top10_bmaps => $curr_top10_avgpos) {
            array_push($top_10_chart_cat_bmaps, date("d M", strtotime($top10_bmaps)));
            array_push($top_10_chart_data_bmaps, floatval($curr_top10_avgpos));
        }
// bmaps Last Step Data End
// mobile Last Step Data Start
        $total_rank_chart_cat_mobile = array();
        $total_rank_chart_data_mobile = array();
        foreach ($totalrank_mobile as $index_mobile => $curr_mobile_rank) {
            array_push($total_rank_chart_cat_mobile, date("d M", strtotime($index_mobile)));
            array_push($total_rank_chart_data_mobile, floatval($curr_mobile_rank));
        }
        $avg_postion_chart_cat_mobile = array();
        $avg_postion_chart_data_mobile = array();
        foreach ($avg_postion_mobile as $avgpos_mobile => $curr_mobile_avgpos) {
            array_push($avg_postion_chart_cat_mobile, date("d M", strtotime($avgpos_mobile)));
            array_push($avg_postion_chart_data_mobile, floatval($curr_mobile_avgpos));
        }
        $first_place_chart_cat_mobile = array();
        $first_place_chart_data_mobile = array();
        foreach ($first_place_mobile as $top1_mobile => $curr_mobile_top1) {
            array_push($first_place_chart_cat_mobile, date("d M", strtotime($top1_mobile)));
            array_push($first_place_chart_data_mobile, floatval($curr_mobile_top1));
        }

        $top_3_chart_cat_mobile = array();
        $top_3_chart_data_mobile = array();
        foreach ($top_3_mobile as $top3_mobile => $curr_mobile_top3) {
            array_push($top_3_chart_cat_mobile, date("d M", strtotime($top3_mobile)));
            array_push($top_3_chart_data_mobile, floatval($curr_mobile_top3));
        }

        $top_10_chart_cat_mobile = array();
        $top_10_chart_data_mobile = array();
        foreach ($top_10_mobile as $top10_mobile => $curr_top10_avgpos) {
            array_push($top_10_chart_cat_mobile, date("d M", strtotime($top10_mobile)));
            array_push($top_10_chart_data_mobile, floatval($curr_top10_avgpos));
        }
// mobile Last Step Data End
// mmaps Last Step Data Start
        $total_rank_chart_cat_mmaps = array();
        $total_rank_chart_data_mmaps = array();
        foreach ($totalrank_mmaps as $index_mmaps => $curr_mmaps_rank) {
            array_push($total_rank_chart_cat_mmaps, date("d M", strtotime($index_mmaps)));
            array_push($total_rank_chart_data_mmaps, floatval($curr_mmaps_rank));
        }
        $avg_postion_chart_cat_mmaps = array();
        $avg_postion_chart_data_mmaps = array();
        foreach ($avg_postion_mmaps as $avgpos_mmaps => $curr_mmaps_avgpos) {
            array_push($avg_postion_chart_cat_mmaps, date("d M", strtotime($avgpos_mmaps)));
            array_push($avg_postion_chart_data_mmaps, floatval($curr_mmaps_avgpos));
        }
        $first_place_chart_cat_mmaps = array();
        $first_place_chart_data_mmaps = array();
        foreach ($first_place_mmaps as $top1_mmaps => $curr_mmaps_top1) {
            array_push($first_place_chart_cat_mmaps, date("d M", strtotime($top1_mmaps)));
            array_push($first_place_chart_data_mmaps, floatval($curr_mmaps_top1));
        }

        $top_3_chart_cat_mmaps = array();
        $top_3_chart_data_mmaps = array();
        foreach ($top_3_mmaps as $top3_mmaps => $curr_mmaps_top3) {
            array_push($top_3_chart_cat_mmaps, date("d M", strtotime($top3_mmaps)));
            array_push($top_3_chart_data_mmaps, floatval($curr_mmaps_top3));
        }

        $top_10_chart_cat_mmaps = array();
        $top_10_chart_data_mmaps = array();
        foreach ($top_10_mmaps as $top10_mmaps => $curr_top10_avgpos) {
            array_push($top_10_chart_cat_mmaps, date("d M", strtotime($top10_mmaps)));
            array_push($top_10_chart_data_mmaps, floatval($curr_top10_avgpos));
        }
// mmaps Last Step Data End
        return array(
            "google_rank" => array(
                "total_rank_percentage" => array(
                    "xAxis_data" => $total_rank_chart_cat_gorganic,
                    "yAxis_data" => $total_rank_chart_data_gorganic
                ),
                "average_rank" => array(
                    "xAxis_data" => $avg_postion_chart_cat_gorganic,
                    "yAxis_data" => $avg_postion_chart_data_gorganic
                ),
                "first_place" => array(
                    "xAxis_data" => $first_place_chart_cat_gorganic,
                    "yAxis_data" => $first_place_chart_data_gorganic
                ),
                "top_3" => array(
                    "xAxis_data" => $top_3_chart_cat_gorganic,
                    "yAxis_data" => $top_3_chart_data_gorganic
                ),
                "top_10" => array(
                    "xAxis_data" => $top_10_chart_cat_gorganic,
                    "yAxis_data" => $top_10_chart_data_gorganic
                )
            ),
            "google_maps_rank" => array(
                "total_rank_percentage" => array(
                    "xAxis_data" => $total_rank_chart_cat_gmaps,
                    "yAxis_data" => $total_rank_chart_data_gmaps
                ),
                "average_rank" => array(
                    "xAxis_data" => $avg_postion_chart_cat_gmaps,
                    "yAxis_data" => $avg_postion_chart_data_gmaps
                ),
                "first_place" => array(
                    "xAxis_data" => $first_place_chart_cat_gmaps,
                    "yAxis_data" => $first_place_chart_data_gmaps
                ),
                "top_3" => array(
                    "xAxis_data" => $top_3_chart_cat_gmaps,
                    "yAxis_data" => $top_3_chart_data_gmaps
                ),
                "top_10" => array(
                    "xAxis_data" => $top_10_chart_cat_gmaps,
                    "yAxis_data" => $top_10_chart_data_gmaps
                )
            ),
            "bing_rank" => array(
                "total_rank_percentage" => array(
                    "xAxis_data" => $total_rank_chart_cat_borganic,
                    "yAxis_data" => $total_rank_chart_data_borganic
                ),
                "average_rank" => array(
                    "xAxis_data" => $avg_postion_chart_cat_borganic,
                    "yAxis_data" => $avg_postion_chart_data_borganic
                ),
                "first_place" => array(
                    "xAxis_data" => $first_place_chart_cat_borganic,
                    "yAxis_data" => $first_place_chart_data_borganic
                ),
                "top_3" => array(
                    "xAxis_data" => $top_3_chart_cat_borganic,
                    "yAxis_data" => $top_3_chart_data_borganic
                ),
                "top_10" => array(
                    "xAxis_data" => $top_10_chart_cat_borganic,
                    "yAxis_data" => $top_10_chart_data_borganic
                )
            ),
            "bing_maps_rank" => array(
                "total_rank_percentage" => array(
                    "xAxis_data" => $total_rank_chart_cat_bmaps,
                    "yAxis_data" => $total_rank_chart_data_bmaps
                ),
                "average_rank" => array(
                    "xAxis_data" => $avg_postion_chart_cat_bmaps,
                    "yAxis_data" => $avg_postion_chart_data_bmaps
                ),
                "first_place" => array(
                    "xAxis_data" => $first_place_chart_cat_bmaps,
                    "yAxis_data" => $first_place_chart_data_bmaps
                ),
                "top_3" => array(
                    "xAxis_data" => $top_3_chart_cat_bmaps,
                    "yAxis_data" => $top_3_chart_data_bmaps
                ),
                "top_10" => array(
                    "xAxis_data" => $top_10_chart_cat_bmaps,
                    "yAxis_data" => $top_10_chart_data_bmaps
                )
            ),
            "mobile_rank" => array(
                "total_rank_percentage" => array(
                    "xAxis_data" => $total_rank_chart_cat_mobile,
                    "yAxis_data" => $total_rank_chart_data_mobile
                ),
                "average_rank" => array(
                    "xAxis_data" => $avg_postion_chart_cat_mobile,
                    "yAxis_data" => $avg_postion_chart_data_mobile
                ),
                "first_place" => array(
                    "xAxis_data" => $first_place_chart_cat_mobile,
                    "yAxis_data" => $first_place_chart_data_mobile
                ),
                "top_3" => array(
                    "xAxis_data" => $top_3_chart_cat_mobile,
                    "yAxis_data" => $top_3_chart_data_mobile
                ),
                "top_10" => array(
                    "xAxis_data" => $top_10_chart_cat_mobile,
                    "yAxis_data" => $top_10_chart_data_mobile
                )
            ),
            "mobile_maps_rank" => array(
                "total_rank_percentage" => array(
                    "xAxis_data" => $total_rank_chart_cat_mmaps,
                    "yAxis_data" => $total_rank_chart_data_mmaps
                ),
                "average_rank" => array(
                    "xAxis_data" => $avg_postion_chart_cat_mmaps,
                    "yAxis_data" => $avg_postion_chart_data_mmaps
                ),
                "first_place" => array(
                    "xAxis_data" => $first_place_chart_cat_mmaps,
                    "yAxis_data" => $first_place_chart_data_mmaps
                ),
                "top_3" => array(
                    "xAxis_data" => $top_3_chart_cat_mmaps,
                    "yAxis_data" => $top_3_chart_data_mmaps
                ),
                "top_10" => array(
                    "xAxis_data" => $top_10_chart_cat_mmaps,
                    "yAxis_data" => $top_10_chart_data_mmaps
                )
            )
        );
    }

    public function getMonthlyDataMetrics($from_date, $to_date, $location_id, $campaign_id) {

        $month_rank_date_arr = array();
        $get_prev_one_m_data = 0;

        if ($campaign_id == 0) {
            $cond = 'location_id=' . $location_id;
        } else {
            if ($this->Keyword->is_valid_campaign($campaign_id)) {
                if ($campaign_id > 0) {
                    $cond = " campaign_id = $campaign_id";
                }
            } else {
                $this->json(0, "Invalid Campaign Id");
            }
        }

        $sqlQueryforCurrentMonthData = "SELECT rank,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank, dateOfRank FROM tbl_keywords_history WHERE campaign_id = $campaign_id and dateOfRank >= '" . date("Y-m-") . "01'";

        $check_current_month_data = $this->connection->execute($sqlQueryforCurrentMonthData)->fetchAll("assoc");
        if (empty($check_current_month_data)) {
            $get_prev_one_m_data = 1;
            $month_rank_date_arr[] = date("Y-m-d", strtotime("first day of -1 month", strtotime($from_date)));
        }

        $new_date = $from_date;
        $month_rank_date_arr[] = date("Y-m-", strtotime($new_date)) . '01';
        while ($new_date < $to_date) {
            $change_date = date("Y-m-d", strtotime("first day of +1 month", strtotime($new_date)));
            $new_date = $change_date;
            if ($change_date < $to_date) {
                $month_rank_date_arr[] = $change_date;
            }
        }

        if ($get_prev_one_m_data == 0) {
            $month_rank_date_arr[] = date("Y-m-") . '01';
        }
        $month_rank_date_arr = array_unique($month_rank_date_arr);
        $month_keyword_history = array();

        $mgorganic_avg_postion = 0;
        $mgmaps_avg_postion = 0;
        $mborganic_avg_postion = 0;
        $mbmaps_avg_postion = 0;
        $mmobile_avg_postion = 0;
        $mmmaps_avg_postion = 0;

        foreach ($month_rank_date_arr as $index_chart_date => $row_chart_date) {

            $last_index = $index_chart_date + 1;
            $DateOfRank1 = $row_chart_date;
            $DateOfRank2 = date("Y-m-", strtotime($row_chart_date)) . '31';

            $sql = "SELECT rank,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank, dateOfRank FROM tbl_keywords_history WHERE $cond and dateOfRank > '$DateOfRank1 00:00:00' and dateOfRank <= '$DateOfRank2 23:59:59' group by keyword order by dateOfRank desc";
            if (count($month_rank_date_arr) == $last_index) {
                $sql = "SELECT rank,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank, dateOfRank FROM tbl_keywords WHERE $cond group by keyword order by dateOfRank desc";
            }

            $date_result = $this->connection->execute($sql)->fetchAll("assoc");

            if ($index_chart_date == 0 && empty($date_result)) {
                $sql = "SELECT rank,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank, dateOfRank FROM tbl_keywords_history WHERE $cond group by keyword order by dateOfRank desc";

                $date_result = $this->connection->execute($sql)->fetchAll("assoc");
            }

            if (!empty($date_result)) {

                $mgoranic_rank = 0;
                $mtotal_rank_gorganic = $mfirst_place_rank_gorganic = $mtop_3_rank_gorganic = $mtop_10_rank_gorganic = $mtotal_keywords_rank_gorganic = 0;

                $mgmaps_rank = 0;
                $mtotal_rank_gmaps = $mfirst_place_rank_gmaps = $mtop_3_rank_gmaps = $mtop_10_rank_gmaps = $mtotal_keywords_rank_gmaps = 0;

                $mborganic_rank = 0;
                $mtotal_rank_borganic = $mfirst_place_rank_borganic = $mtop_3_rank_borganic = $mtop_10_rank_borganic = $mtotal_keywords_rank_borganic = 0;

                $mbmaps_rank = 0;
                $mtotal_rank_bmaps = $mfirst_place_rank_bmaps = $mtop_3_rank_bmaps = $mtop_10_rank_bmaps = $mtotal_keywords_rank_bmaps = 0;

                $mmobile_rank = 0;
                $mtotal_rank_mobile = $mfirst_place_rank_mobile = $mtop_3_rank_mobile = $mtop_10_rank_mobile = $mtotal_keywords_rank_mobile = 0;

                $mmmaps_rank = 0;
                $mtotal_rank_mmaps = $mfirst_place_rank_mmaps = $mtop_3_rank_mmaps = $mtop_10_rank_mmaps = $mtotal_keywords_rank_mmaps = 0;

                $count_date_result = count($date_result);

                foreach ($date_result as $index => $row_result) {


// gogole organic rank
                    if (!empty($row_result['rank'])) {
                        $goranic_rank = $row_result['rank'];
                    }
// gogole map organic rank
                    if (!empty($row_result['maps_rank'])) {
                        $gmaps_rank = $row_result['maps_rank'];
                    }
// Bing organic rank
                    if (!empty($row_result['bing_rank'])) {
                        $borganic_rank = $row_result['bing_rank'];
                    }
// Bing maps rank
                    if (!empty($row_result['bing_maps_rank'])) {
                        $bmaps_rank = $row_result['bing_maps_rank'];
                    }
// Mobie rank
                    if (!empty($row_result['mobile_rank'])) {
                        $mobile_rank = $row_result['mobile_rank'];
                    }
// Mobie Maps rank
                    if (!empty($row_result['mobile_maps_rank'])) {
                        $mmaps_rank = $row_result['mobile_maps_rank'];
                    }

// Google Organic Rank Calculation Start
                    if ($mgoranic_rank > 0) {
                        $mtotal_rank_gorganic += 1;
                        $mtotal_keywords_rank_gorganic += $mgoranic_rank;
                    } else {
                        $mtotal_keywords_rank_gorganic += 50;
                    }

                    if ($mgoranic_rank == 1) {
                        $mfirst_place_rank_gorganic += 1;
                    }
                    if ($mgoranic_rank >= 1 && $mgoranic_rank <= 3) {
                        $mtop_3_rank_gorganic += 1;
                    }
                    if ($mgoranic_rank >= 1 && $mgoranic_rank <= 10) {
                        $mtop_10_rank_gorganic += 1;
                    }
// Google Organic Rank Calculation End
// Google Maps Rank Calculation Start
                    if ($mgmaps_rank > 0) {
                        $mtotal_rank_gmaps += 1;
                        $mtotal_keywords_rank_gmaps += $mgmaps_rank;
                    } else {
                        $mtotal_keywords_rank_gmaps += 50;
                    }

                    if ($mgmaps_rank == 1) {
                        $mfirst_place_rank_gmaps += 1;
                    }
                    if ($mgmaps_rank >= 1 && $mgmaps_rank <= 3) {
                        $mtop_3_rank_gmaps += 1;
                    }
                    if ($mgmaps_rank >= 1 && $mgmaps_rank <= 10) {
                        $mtop_10_rank_gmaps += 1;
                    }
// Google Maps Rank Calculation End
// Bing Organic Rank Calculation Start
                    if ($mborganic_rank > 0) {
                        $mtotal_rank_borganic += 1;
                        $mtotal_keywords_rank_borganic += $mborganic_rank;
                    } else {
                        $mtotal_keywords_rank_borganic += 50;
                    }

                    if ($mborganic_rank == 1) {
                        $mfirst_place_rank_borganic += 1;
                    }
                    if ($mborganic_rank >= 1 && $mborganic_rank <= 3) {
                        $mtop_3_rank_borganic += 1;
                    }
                    if ($mborganic_rank >= 1 && $mborganic_rank <= 10) {
                        $mtop_10_rank_borganic += 1;
                    }
// Bing Organic Rank Calculation End
// Bing Maps Rank Calculation Start
                    if ($mbmaps_rank > 0) {
                        $mtotal_rank_bmaps += 1;
                        $mtotal_keywords_rank_bmaps += $mbmaps_rank;
                    } else {
                        $mtotal_keywords_rank_bmaps += 50;
                    }

                    if ($mbmaps_rank == 1) {
                        $mfirst_place_rank_bmaps += 1;
                    }
                    if ($mbmaps_rank >= 1 && $mbmaps_rank <= 3) {
                        $mtop_3_rank_bmaps += 1;
                    }
                    if ($mbmaps_rank >= 1 && $mbmaps_rank <= 10) {
                        $mtop_10_rank_bmaps += 1;
                    }
// Bing Maps Rank Calculation End
// Mobile Rank Calculation Start
                    if ($mmobile_rank > 0) {
                        $mtotal_rank_mobile += 1;
                        $mtotal_keywords_rank_mobile += $mmobile_rank;
                    } else {
                        $mtotal_keywords_rank_mobile += 50;
                    }

                    if ($mmobile_rank == 1) {
                        $mfirst_place_rank_mobile += 1;
                    }
                    if ($mmobile_rank >= 1 && $mmobile_rank <= 3) {
                        $mtop_3_rank_mobile += 1;
                    }
                    if ($mmobile_rank >= 1 && $mmobile_rank <= 10) {
                        $mtop_10_rank_mobile += 1;
                    }
// Mobile Rank Calculation End
// Mobile Maps Rank Calculation Start
                    if ($mmmaps_rank > 0) {
                        $mtotal_rank_mmaps += 1;
                        $mtotal_keywords_rank_mmaps += $mmmaps_rank;
                    } else {
                        $mtotal_keywords_rank_mmaps += 50;
                    }

                    if ($mmmaps_rank == 1) {
                        $mfirst_place_rank_mmaps += 1;
                    }
                    if ($mmmaps_rank >= 1 && $mmmaps_rank <= 3) {
                        $mtop_3_rank_mmaps += 1;
                    }
                    if ($mmmaps_rank >= 1 && $mmmaps_rank <= 10) {
                        $mtop_10_rank_mmaps += 1;
                    }
// Mobile Maps Rank Calculation End
                }

                $mgorganic_avg_postion = sprintf("%.2f", $mtotal_keywords_rank_gorganic / $count_date_result);
                $mgmaps_avg_postion = sprintf("%.2f", $mtotal_keywords_rank_gmaps / $count_date_result);
                $mborganic_avg_postion = sprintf("%.2f", $mtotal_keywords_rank_borganic / $count_date_result);
                $mbmaps_avg_postion = sprintf("%.2f", $mtotal_keywords_rank_bmaps / $count_date_result);
                $mmobile_avg_postion = sprintf("%.2f", $mtotal_keywords_rank_mobile / $count_date_result);
                $mmmaps_avg_postion = sprintf("%.2f", $mtotal_keywords_rank_mmaps / $count_date_result);
            }

// google organcic total start
            $mtotalrank_gorganic[$row_chart_date] = sprintf("%.2f", ($mtotal_rank_gorganic / $count_date_result) * 100);
            $mavg_postion_gorganic[$row_chart_date] = $mgorganic_avg_postion;

            $mfirst_place_gorganic[$row_chart_date] = $mfirst_place_rank_gorganic;
            $mtop_3_gorganic[$row_chart_date] = $mtop_3_rank_gorganic;
            $mtop_10_gorganic[$row_chart_date] = $mtop_10_rank_gorganic;
// google organcic total end
// google maps total start
            $mtotalrank_gmaps[$row_chart_date] = sprintf("%.2f", ($mtotal_rank_gmaps / $count_date_result) * 100);
            $mavg_postion_gmaps[$row_chart_date] = $mgmaps_avg_postion;
            $mfirst_place_gmaps[$row_chart_date] = $mfirst_place_rank_gmaps;
            $mtop_3_gmaps[$row_chart_date] = $mtop_3_rank_gmaps;
            $mtop_10_gmaps[$row_chart_date] = $mtop_10_rank_gmaps;
// google maps total end    
// bing organcic total start
            $mtotalrank_borganic[$row_chart_date] = sprintf("%.2f", ($mtotal_rank_borganic / $count_date_result) * 100);
            $mavg_postion_borganic[$row_chart_date] = $mborganic_avg_postion;
            $mfirst_place_borganic[$row_chart_date] = $mfirst_place_rank_borganic;
            $mtop_3_borganic[$row_chart_date] = $mtop_3_rank_borganic;
            $mtop_10_borganic[$row_chart_date] = $mtop_10_rank_borganic;
// bing organcic total end
// bing maps total start
//pr($count_date_result);
            $mtotalrank_bmaps[$row_chart_date] = sprintf("%.2f", ($mtotal_rank_bmaps / $count_date_result) * 100);

            $mavg_postion_bmaps[$row_chart_date] = $mbmaps_avg_postion;
            $mfirst_place_bmaps[$row_chart_date] = $mfirst_place_rank_bmaps;
            $mtop_3_bmaps[$row_chart_date] = $mtop_3_rank_bmaps;
            $mtop_10_bmaps[$row_chart_date] = $mtop_10_rank_bmaps;
// bing maps total end
// Mobile total start
            $mtotalrank_mobile[$row_chart_date] = sprintf("%.2f", ($mtotal_rank_mobile / $count_date_result) * 100);
            $mavg_postion_mobile[$row_chart_date] = $mmobile_avg_postion;
            $mfirst_place_mobile[$row_chart_date] = $mfirst_place_rank_mobile;
            $mtop_3_mobile[$row_chart_date] = $mtop_3_rank_mobile;
            $mtop_10_mobile[$row_chart_date] = $mtop_10_rank_mobile;
// Mobile total end
// Mobile maps total start
            $mtotalrank_mmaps[$row_chart_date] = sprintf("%.2f", ($mtotal_rank_mmaps / $count_date_result) * 100);
            $mavg_postion_mmaps[$row_chart_date] = $mmmaps_avg_postion;
            $mfirst_place_mmaps[$row_chart_date] = $mfirst_place_rank_mmaps;
            $mtop_3_mmaps[$row_chart_date] = $mtop_3_rank_mmaps;
            $mtop_10_mmaps[$row_chart_date] = $mtop_10_rank_mmaps;
// Mobile maps total end 
        }

// gorganic Last Step Data Start
        $mtotal_rank_chart_cat_gorganic = array();
        $mtotal_rank_chart_data_gorganic = array();
        foreach ($mtotalrank_gorganic as $index_gorganic => $curr_gorganic_rank) {
            array_push($mtotal_rank_chart_cat_gorganic, date("d M", strtotime($index_gorganic)));
            array_push($mtotal_rank_chart_data_gorganic, floatval($curr_gorganic_rank));
        }

        $mavg_postion_chart_cat_gorganic = array();
        $mavg_postion_chart_data_gorganic = array();
        foreach ($mavg_postion_gorganic as $avgpos_gorganic => $curr_gorganic_avgpos) {
            array_push($mavg_postion_chart_cat_gorganic, date("d M", strtotime($avgpos_gorganic)));
            array_push($mavg_postion_chart_data_gorganic, floatval($curr_gorganic_avgpos));
        }

        $mfirst_place_chart_cat_gorganic = array();
        $mfirst_place_chart_data_gorganic = array();
        foreach ($mfirst_place_gorganic as $top1_gorganic => $curr_gorganic_top1) {
            array_push($mfirst_place_chart_cat_gorganic, date("d M", strtotime($top1_gorganic)));
            array_push($mfirst_place_chart_data_gorganic, floatval($curr_gorganic_top1));
        }

        $mtop_3_chart_cat_gorganic = array();
        $mtop_3_chart_data_gorganic = array();
        foreach ($mtop_3_gorganic as $top3_gorganic => $curr_gorganic_top3) {
            array_push($mtop_3_chart_cat_gorganic, date("d M", strtotime($top3_gorganic)));
            array_push($mtop_3_chart_data_gorganic, floatval($curr_gorganic_top3));
        }

        $mtop_10_chart_cat_gorganic = array();
        $mtop_10_chart_data_gorganic = array();
        foreach ($mtop_10_gorganic as $top10_gorganic => $curr_top10_avgpos) {
            array_push($mtop_10_chart_cat_gorganic, date("d M", strtotime($top10_gorganic)));
            array_push($mtop_10_chart_data_gorganic, floatval($curr_top10_avgpos));
        }

// gorganic Last Step Data End
// gmaps Last Step Data Start
        $mtotal_rank_chart_cat_gmaps = array();
        $mtotal_rank_chart_data_gmaps = array();
        foreach ($mtotalrank_gmaps as $index_gmaps => $curr_gmaps_rank) {
            array_push($mtotal_rank_chart_cat_gmaps, date("d M", strtotime($index_gmaps)));
            array_push($mtotal_rank_chart_data_gmaps, floatval($curr_gmaps_rank));
        }
        $mavg_postion_chart_cat_gmaps = array();
        $mavg_postion_chart_data_gmaps = array();
        foreach ($mavg_postion_gmaps as $avgpos_gmaps => $curr_gmaps_avgpos) {
            array_push($mavg_postion_chart_cat_gmaps, date("d M", strtotime($avgpos_gmaps)));
            array_push($mavg_postion_chart_data_gmaps, floatval($curr_gmaps_avgpos));
        }
        $mfirst_place_chart_cat_gmaps = array();
        $mfirst_place_chart_data_gmaps = array();
        foreach ($mfirst_place_gmaps as $top1_gmaps => $curr_gmaps_top1) {
            array_push($mfirst_place_chart_cat_gmaps, date("d M", strtotime($top1_gmaps)));
            array_push($mfirst_place_chart_data_gmaps, floatval($curr_gmaps_top1));
        }

        $mtop_3_chart_cat_gmaps = array();
        $mtop_3_chart_data_gmaps = array();
        foreach ($mtop_3_gmaps as $top3_gmaps => $curr_gmaps_top3) {
            array_push($mtop_3_chart_cat_gmaps, date("d M", strtotime($top3_gmaps)));
            array_push($mtop_3_chart_data_gmaps, floatval($curr_gmaps_top3));
        }

        $mtop_10_chart_cat_gmaps = array();
        $mtop_10_chart_data_gmaps = array();
        foreach ($mtop_10_gmaps as $top10_gmaps => $curr_top10_avgpos) {
            array_push($mtop_10_chart_cat_gmaps, date("d M", strtotime($top10_gmaps)));
            array_push($mtop_10_chart_data_gmaps, floatval($curr_top10_avgpos));
        }
// gmaps Last Step Data End
// borganic Last Step Data Start
        $mtotal_rank_chart_cat_borganic = array();
        $mtotal_rank_chart_data_borganic = array();
        foreach ($mtotalrank_borganic as $index_borganic => $curr_borganic_rank) {
            array_push($mtotal_rank_chart_cat_borganic, date("d M", strtotime($index_borganic)));
            array_push($mtotal_rank_chart_data_borganic, floatval($curr_borganic_rank));
        }
        $mavg_postion_chart_cat_borganic = array();
        $mavg_postion_chart_data_borganic = array();
        foreach ($mavg_postion_borganic as $avgpos_borganic => $curr_borganic_avgpos) {
            array_push($mavg_postion_chart_cat_borganic, date("d M", strtotime($avgpos_borganic)));
            array_push($mavg_postion_chart_data_borganic, floatval($curr_borganic_avgpos));
        }
        $mfirst_place_chart_cat_borganic = array();
        $mfirst_place_chart_data_borganic = array();
        foreach ($mfirst_place_borganic as $top1_borganic => $curr_borganic_top1) {
            array_push($mfirst_place_chart_cat_borganic, date("d M", strtotime($top1_borganic)));
            array_push($mfirst_place_chart_data_borganic, floatval($curr_borganic_top1));
        }

        $mtop_3_chart_cat_borganic = array();
        $mtop_3_chart_data_borganic = array();
        foreach ($mtop_3_borganic as $top3_borganic => $curr_borganic_top3) {
            array_push($mtop_3_chart_cat_borganic, date("d M", strtotime($top3_borganic)));
            array_push($mtop_3_chart_data_borganic, floatval($curr_borganic_top3));
        }

        $mtop_10_chart_cat_borganic = array();
        $mtop_10_chart_data_borganic = array();
        foreach ($mtop_10_borganic as $top10_borganic => $curr_top10_avgpos) {
            array_push($mtop_10_chart_cat_borganic, date("d M", strtotime($top10_borganic)));
            array_push($mtop_10_chart_data_borganic, floatval($curr_top10_avgpos));
        }

// borganic Last Step Data End
// bmaps Last Step Data Start
        $mtotal_rank_chart_cat_bmaps = array();
        $mtotal_rank_chart_data_bmaps = array();
        foreach ($mtotalrank_bmaps as $index_bmaps => $curr_bmaps_rank) {
            array_push($mtotal_rank_chart_cat_bmaps, date("d M", strtotime($index_bmaps)));
            array_push($mtotal_rank_chart_data_bmaps, floatval($curr_bmaps_rank));
        }

        $mavg_postion_chart_cat_bmaps = array();
        $mavg_postion_chart_data_bmaps = array();
        foreach ($mavg_postion_bmaps as $avgpos_bmaps => $curr_bmaps_avgpos) {
            array_push($mavg_postion_chart_cat_bmaps, date("d M", strtotime($avgpos_bmaps)));
            array_push($mavg_postion_chart_data_bmaps, floatval($curr_bmaps_avgpos));
        }

        $mfirst_place_chart_cat_bmaps = array();
        $mfirst_place_chart_data_bmaps = array();
        foreach ($mfirst_place_bmaps as $top1_bmaps => $curr_bmaps_top1) {
            array_push($mfirst_place_chart_cat_bmaps, date("d M", strtotime($top1_bmaps)));
            array_push($mfirst_place_chart_data_bmaps, floatval($curr_bmaps_top1));
        }

        $mtop_3_chart_cat_bmaps = array();
        $mtop_3_chart_data_bmaps = array();
        foreach ($mtop_3_bmaps as $top3_bmaps => $curr_bmaps_top3) {
            array_push($mtop_3_chart_cat_bmaps, date("d M", strtotime($top3_bmaps)));
            array_push($mtop_3_chart_data_bmaps, floatval($curr_bmaps_top3));
        }

        $mtop_10_chart_cat_bmaps = array();
        $mtop_10_chart_data_bmaps = array();
        foreach ($mtop_10_bmaps as $top10_bmaps => $curr_top10_avgpos) {
            array_push($mtop_10_chart_cat_bmaps, date("d M", strtotime($top10_bmaps)));
            array_push($mtop_10_chart_data_bmaps, floatval($curr_top10_avgpos));
        }
// bmaps Last Step Data End
// mobile Last Step Data Start
        $mtotal_rank_chart_cat_mobile = array();
        $mtotal_rank_chart_data_mobile = array();
        foreach ($mtotalrank_mobile as $index_mobile => $curr_mobile_rank) {
            array_push($mtotal_rank_chart_cat_mobile, date("d M", strtotime($index_mobile)));
            array_push($mtotal_rank_chart_data_mobile, floatval($curr_mobile_rank));
        }
        $mavg_postion_chart_cat_mobile = array();
        $mavg_postion_chart_data_mobile = array();
        foreach ($mavg_postion_mobile as $avgpos_mobile => $curr_mobile_avgpos) {
            array_push($mavg_postion_chart_cat_mobile, date("d M", strtotime($avgpos_mobile)));
            array_push($mavg_postion_chart_data_mobile, floatval($curr_mobile_avgpos));
        }
        $mfirst_place_chart_cat_mobile = array();
        $mfirst_place_chart_data_mobile = array();
        foreach ($mfirst_place_mobile as $top1_mobile => $curr_mobile_top1) {
            array_push($mfirst_place_chart_cat_mobile, date("d M", strtotime($top1_mobile)));
            array_push($mfirst_place_chart_data_mobile, floatval($curr_mobile_top1));
        }

        $mtop_3_chart_cat_mobile = array();
        $mtop_3_chart_data_mobile = array();
        foreach ($mtop_3_mobile as $top3_mobile => $curr_mobile_top3) {
            array_push($mtop_3_chart_cat_mobile, date("d M", strtotime($top3_mobile)));
            array_push($mtop_3_chart_data_mobile, floatval($curr_mobile_top3));
        }

        $mtop_10_chart_cat_mobile = array();
        $mtop_10_chart_data_mobile = array();
        foreach ($mtop_10_mobile as $top10_mobile => $curr_top10_avgpos) {
            array_push($mtop_10_chart_cat_mobile, date("d M", strtotime($top10_mobile)));
            array_push($mtop_10_chart_data_mobile, floatval($curr_top10_avgpos));
        }
// mobile Last Step Data End
// mmaps Last Step Data Start
        $mtotal_rank_chart_cat_mmaps = array();
        $mtotal_rank_chart_data_mmaps = array();
        foreach ($mtotalrank_mmaps as $index_mmaps => $curr_mmaps_rank) {
            array_push($mtotal_rank_chart_cat_mmaps, date("d M", strtotime($index_mmaps)));
            array_push($mtotal_rank_chart_data_mmaps, floatval($curr_mmaps_rank));
        }
        $mavg_postion_chart_cat_mmaps = array();
        $mavg_postion_chart_data_mmaps = array();
        foreach ($mavg_postion_mmaps as $avgpos_mmaps => $curr_mmaps_avgpos) {
            array_push($mavg_postion_chart_cat_mmaps, date("d M", strtotime($avgpos_mmaps)));
            array_push($mavg_postion_chart_data_mmaps, floatval($curr_mmaps_avgpos));
        }
        $mfirst_place_chart_cat_mmaps = array();
        $mfirst_place_chart_data_mmaps = array();
        foreach ($mfirst_place_mmaps as $top1_mmaps => $curr_mmaps_top1) {
            array_push($mfirst_place_chart_cat_mmaps, date("d M", strtotime($top1_mmaps)));
            array_push($mfirst_place_chart_data_mmaps, floatval($curr_mmaps_top1));
        }

        $mtop_3_chart_cat_mmaps = array();
        $mtop_3_chart_data_mmaps = array();
        foreach ($mtop_3_mmaps as $top3_mmaps => $curr_mmaps_top3) {
            array_push($mtop_3_chart_cat_mmaps, date("d M", strtotime($top3_mmaps)));
            array_push($mtop_3_chart_data_mmaps, floatval($curr_mmaps_top3));
        }

        $mtop_10_chart_cat_mmaps = array();
        $mtop_10_chart_data_mmaps = array();
        foreach ($mtop_10_mmaps as $top10_mmaps => $curr_top10_avgpos) {
            array_push($mtop_10_chart_cat_mmaps, date("d M", strtotime($top10_mmaps)));
            array_push($mtop_10_chart_data_mmaps, floatval($curr_top10_avgpos));
        }

// mmaps Last Step Data End

        return array(
            "google_rank" => array(
                "total_rank_percentage" => array(
                    "xAxis_data" => $mtotal_rank_chart_cat_gorganic,
                    "yAxis_data" => $mtotal_rank_chart_data_gorganic
                ),
                "average_rank" => array(
                    "xAxis_data" => $mavg_postion_chart_cat_gorganic,
                    "yAxis_data" => $mavg_postion_chart_data_gorganic
                ),
                "first_place" => array(
                    "xAxis_data" => $mfirst_place_chart_cat_gorganic,
                    "yAxis_data" => $mfirst_place_chart_data_gorganic
                ),
                "top_3" => array(
                    "xAxis_data" => $mtop_3_chart_cat_gorganic,
                    "yAxis_data" => $mtop_3_chart_data_gorganic
                ),
                "top_10" => array(
                    "xAxis_data" => $mtop_10_chart_cat_gorganic,
                    "yAxis_data" => $mtop_10_chart_data_gorganic
                )
            ),
            "google_maps_rank" => array(
                "total_rank_percentage" => array(
                    "xAxis_data" => $mtotal_rank_chart_cat_gmaps,
                    "yAxis_data" => $mtotal_rank_chart_data_gmaps
                ),
                "average_rank" => array(
                    "xAxis_data" => $mavg_postion_chart_cat_gmaps,
                    "yAxis_data" => $mavg_postion_chart_data_gmaps
                ),
                "first_place" => array(
                    "xAxis_data" => $mfirst_place_chart_cat_gmaps,
                    "yAxis_data" => $mfirst_place_chart_data_gmaps
                ),
                "top_3" => array(
                    "xAxis_data" => $mtop_3_chart_cat_gmaps,
                    "yAxis_data" => $mtop_3_chart_data_gmaps
                ),
                "top_10" => array(
                    "xAxis_data" => $mtop_10_chart_cat_gmaps,
                    "yAxis_data" => $mtop_10_chart_data_gmaps
                )
            ),
            "bing_rank" => array(
                "total_rank_percentage" => array(
                    "xAxis_data" => $mtotal_rank_chart_cat_borganic,
                    "yAxis_data" => $mtotal_rank_chart_data_borganic
                ),
                "average_rank" => array(
                    "xAxis_data" => $mavg_postion_chart_cat_borganic,
                    "yAxis_data" => $mavg_postion_chart_data_borganic
                ),
                "first_place" => array(
                    "xAxis_data" => $mfirst_place_chart_cat_borganic,
                    "yAxis_data" => $mfirst_place_chart_data_borganic
                ),
                "top_3" => array(
                    "xAxis_data" => $mtop_3_chart_cat_borganic,
                    "yAxis_data" => $mtop_3_chart_data_borganic
                ),
                "top_10" => array(
                    "xAxis_data" => $mtop_10_chart_cat_borganic,
                    "yAxis_data" => $mtop_10_chart_data_borganic
                )
            ),
            "bing_maps_rank" => array(
                "total_rank_percentage" => array(
                    "xAxis_data" => $mtotal_rank_chart_cat_bmaps,
                    "yAxis_data" => $mtotal_rank_chart_data_bmaps
                ),
                "average_rank" => array(
                    "xAxis_data" => $mavg_postion_chart_cat_bmaps,
                    "yAxis_data" => $mavg_postion_chart_data_bmaps
                ),
                "first_place" => array(
                    "xAxis_data" => $mfirst_place_chart_cat_bmaps,
                    "yAxis_data" => $mfirst_place_chart_data_bmaps
                ),
                "top_3" => array(
                    "xAxis_data" => $mtop_3_chart_cat_bmaps,
                    "yAxis_data" => $mtop_3_chart_data_bmaps
                ),
                "top_10" => array(
                    "xAxis_data" => $mtop_10_chart_cat_bmaps,
                    "yAxis_data" => $mtop_10_chart_data_bmaps
                )
            ),
            "mobile_rank" => array(
                "total_rank_percentage" => array(
                    "xAxis_data" => $mtotal_rank_chart_cat_mobile,
                    "yAxis_data" => $mtotal_rank_chart_data_mobile
                ),
                "average_rank" => array(
                    "xAxis_data" => $mavg_postion_chart_cat_mobile,
                    "yAxis_data" => $mavg_postion_chart_data_mobile
                ),
                "first_place" => array(
                    "xAxis_data" => $mfirst_place_chart_cat_mobile,
                    "yAxis_data" => $mfirst_place_chart_data_mobile
                ),
                "top_3" => array(
                    "xAxis_data" => $mtop_3_chart_cat_mobile,
                    "yAxis_data" => $mtop_3_chart_data_mobile
                ),
                "top_10" => array(
                    "xAxis_data" => $mtop_10_chart_cat_mobile,
                    "yAxis_data" => $mtop_10_chart_data_mobile
                )
            ),
            "mobile_maps_rank" => array(
                "total_rank_percentage" => array(
                    "xAxis_data" => $mtotal_rank_chart_cat_gmaps,
                    "yAxis_data" => $mtotal_rank_chart_data_gmaps
                ),
                "average_rank" => array(
                    "xAxis_data" => $mavg_postion_chart_cat_gmaps,
                    "yAxis_data" => $mavg_postion_chart_data_gmaps
                ),
                "first_place" => array(
                    "xAxis_data" => $mfirst_place_chart_cat_gmaps,
                    "yAxis_data" => $mfirst_place_chart_data_gmaps
                ),
                "top_3" => array(
                    "xAxis_data" => $mtop_3_chart_cat_gmaps,
                    "yAxis_data" => $mtop_3_chart_data_gmaps
                ),
                "top_10" => array(
                    "xAxis_data" => $mtop_10_chart_cat_gmaps,
                    "yAxis_data" => $mtop_10_chart_data_gmaps
                )
            )
        );
    }

    public function getLocationLandingPages($from_date, $to_date, $location_id, $campaign_id) {

        if ($location_id > 0) {

            if ($campaign_id == 0) {

                $cond = 'location_id=' . $location_id;
            } else {
                if ($this->Keyword->is_valid_campaign($campaign_id)) {
                    if ($campaign_id > 0) {
                        $cond = "campaign_id = $campaign_id";
                    }
                } else {
                    $this->json(0, "Invalid Campaign Id");
                }
            }
// landing page operation now...
            $sqlQueryToGetAllLandingPages = "SELECT landing_page from tbl_keygroup where location_id = " . $location_id . " AND created>='" . $from_date . "' AND created<='" . $to_date . "'";
            $resultToGetPagesList = $this->connection->execute($sqlQueryToGetAllLandingPages)->fetchAll("assoc");
            if ($resultToGetPagesList > 0) {
                $pages = array();
                foreach ($resultToGetPagesList as $row) {
                    if (!empty($row['landing_page'])) {
                        array_push($pages, $row['landing_page']);
                    }
                }
                return $pages;
            } else {
                return array();
            }
        }
        $this->json(0, "Invalid location id");
    }

    public function getCompetitorWeeklyDataMetrics($from_date, $to_date, $location_id, $campaign_id) {

        if ($campaign_id == 0) {
            $cond = '';
        } else {
            if ($this->Keyword->is_valid_campaign($campaign_id)) {
                if ($campaign_id > 0) {
                    $cond = " AND campaign_id = $campaign_id";
                }
            } else {
                $this->json(0, "Invalid Campaign Id");
            }
        }
        $new_date = $from_date;

        $rank_date_arr[] = $new_date;
        while ($new_date < $to_date) {
            $change_date = date('Y-m-d', strtotime($new_date) + 7 * 24 * 3600);
            $new_date = $change_date;
            if ($change_date < $to_date) {
                $rank_date_arr[] = $change_date;
            }
        }
        $rank_date_arr[] = $to_date;

        $com_count_date_result = 0;
        $weeklydata = array();
        $grank_total = $grank = $firstplace = $top3 = $top10 = $totalkeywords = 0;

        $competitor_urls = $this->getLocationCompetitors($location_id);
        $xAxis = array();
        $avg_pos = array();
        $total_rank = array();
        $top3_ar = array();
        $firstPlace = array();
        $top10_ar = array();
        foreach ($competitor_urls as $index => $competitor_url) {

            $trimmedurl = $this->fully_trim($competitor_url['website']);
            if ($trimmedurl == '') {
                continue;
            }

            $yAxis = array();
            $total_rank_temp = array();
            $avg_pos_temp = array();
            $top3_ar_temp = array();
            $firstPlace_temp = array();
            $firstPlace_temp = array();
            $top10_ar_temp = array();

            $weekly_chart_date_cat = '';

            foreach ($rank_date_arr as $index_chart_date => $row_chart_date) {

                $weekly_chart_date_cat .= date("d M Y", strtotime($row_chart_date)) . ',';
                $last_index = $index_chart_date + 1;
                $DateOfRank1 = $row_chart_date;
                if (isset($rank_date_arr[$index_chart_date + 1])) {
                    $DateOfRank2 = $rank_date_arr[$index_chart_date + 1];
                } else {
                    $DateOfRank2 = $DateOfRank1;
                }

                $sql = "SELECT keyword, rank,ranked_url,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank FROM tbl_keywords_history WHERE location_id = $location_id $cond AND dateOfRank >= '$DateOfRank1 00:00:00' and dateOfRank <= '$DateOfRank2 23:59:59'";
                if (count($rank_date_arr) == $last_index) {
                    $sql = "SELECT keyword, rank,ranked_url,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank FROM tbl_keywords WHERE location_id = $location_id $cond";
                }

                $keywordata = $this->connection->execute($sql)->fetchAll("assoc");
                if (empty($keywordata)) {
                    $sql = "SELECT keyword, rank,ranked_url,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank FROM tbl_keywords WHERE location_id = $location_id $cond";
                    $keywordata = $this->connection->execute($sql)->fetchAll("assoc");
                }

                if (!empty($keywordata)) {

                    $grank_total = $grank = $firstplace = $top3 = $top10 = $totalkeywords = 0;
                    $count_date_result = count($keywordata);

                    foreach ($keywordata as $inx => $keywordrow) {

                        $trimmed_ranked_url = $this->fully_trim($keywordrow['ranked_url']);

                        $rnk = 50;

                        if (isset($trimmed_ranked_url) && strpos($trimmed_ranked_url, $trimmedurl) !== false) {

                            $rnk = ($keywordrow['rank'] == NULL || empty($keywordrow['rank'])) ? 50 : $keywordrow['rank'];
                        }

                        $grank_total += $rnk;
                        if ($rnk == 1) {
                            $firstplace++;
                        }
                        if ($rnk >= 1 && $rnk <= 3) {
                            $top3++;
                        }
                        if ($rnk >= 1 && $rnk <= 10) {
                            $top10++;
                        }

                        $totalkeywords++;
                    }
                }

                array_push($total_rank_temp, floatval(sprintf("%.2f", ($grank / $totalkeywords) * 100)));
                array_push($top3_ar_temp, intval($top3 != '' ? $top3 : 0));
                array_push($top10_ar_temp, intval($top10 != '' ? $top10 : 0));
                array_push($avg_pos_temp, floatval(sprintf("%.2f", $grank_total / $totalkeywords)));
                array_push($firstPlace_temp, intval($firstplace != '' ? $firstplace : 0));
            }

            array_push($total_rank, array("name" => $trimmedurl, "data" => $total_rank_temp));
            array_push($avg_pos, array("name" => $trimmedurl, "data" => $avg_pos_temp));
            array_push($top3_ar, array("name" => $trimmedurl, "data" => $top3_ar_temp));
            array_push($top10_ar, array("name" => $trimmedurl, "data" => $top10_ar_temp));
            array_push($firstPlace, array("name" => $trimmedurl, "data" => $firstPlace_temp));
        }

        $date_array = array();
        foreach ($rank_date_arr as $date) {
            array_push($date_array, date("d M", strtotime($date)));
        }

        $compt_rcrd = array(
            "xAxis" => $date_array,
            "totalRank" => $total_rank,
            "avgPos" => $avg_pos,
            "firstPlace" => $firstPlace,
            "top3" => $top3_ar,
            "top10" => $top10_ar
        );
        // array_push($weeklydata, $compt_rcrd);

        return $compt_rcrd;
    }

    public function getCompetitorMonthlyDataMetrics($from_date, $to_date, $location_id, $campaign_id) {

        if ($campaign_id == 0) {
            $cond = '';
        } else {
            if ($this->Keyword->is_valid_campaign($campaign_id)) {
                if ($campaign_id > 0) {
                    $cond = " AND campaign_id = $campaign_id";
                }
            } else {
                $this->json(0, "Invalid Campaign Id");
            }
        }

        $new_date = $from_date;
        $month_rank_date_arr[] = date("Y-m-", strtotime($new_date)) . '01';
        while ($new_date < $to_date) {
            $change_date = date("Y-m-d", strtotime("first day of +1 month", strtotime($new_date)));
            $new_date = $change_date;
            if ($change_date < $to_date) {
                $month_rank_date_arr[] = $change_date;
            }
        }

        $grank_total = $grank = $firstplace = $top3 = $top10 = $totalkeywords = 0;
        $monthlydata = array();
        $competitor_urls = $this->getLocationCompetitors($location_id);

        $xAxis = array();
        $avg_pos = array();
        $total_rank = array();
        $top3_ar = array();
        $firstPlace = array();
        $top10_ar = array();

        foreach ($competitor_urls as $index => $competitor_url) {

            $trimmedurl = $this->fully_trim($competitor_url['website']);
            if ($trimmedurl == '') {
                continue;
            }

            $total_rank_temp = array();
            $avg_pos_temp = array();
            $top3_ar_temp = array();
            $firstPlace_temp = array();
            $firstPlace_temp = array();
            $top10_ar_temp = array();
            $yAxis = array();

            $comp_month_history_chart_cat = '';

            foreach ($month_rank_date_arr as $index_chart_date => $row_chart_date) {

                $comp_month_history_chart_cat .= date('M Y', strtotime($row_chart_date)) . ',';
                $last_index = $index_chart_date + 1;
                $DateOfRank1 = $row_chart_date;
                if (isset($month_rank_date_arr[$index_chart_date + 1])) {
                    $DateOfRank2 = $month_rank_date_arr[$index_chart_date + 1];
                } else {
                    $DateOfRank2 = $DateOfRank1;
                }

                $sql = "SELECT keyword, rank,ranked_url,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank FROM tbl_keywords_history WHERE location_id = $location_id $cond AND dateOfRank >= '$DateOfRank1 00:00:00' and dateOfRank <= '$DateOfRank2 23:59:59'";
                if (count($rank_date_arr) == $last_index) {
                    $sql = "SELECT keyword,ranked_url, rank,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank FROM tbl_keywords WHERE location_id = $location_id $cond";
                }

                $keywordata = $this->connection->execute($sql)->fetchAll("assoc");
                if (empty($keywordata)) {
                    $sql = "SELECT keyword,ranked_url, rank,maps_rank,mobile_rank,mobile_maps_rank,bing_rank,bing_maps_rank FROM tbl_keywords WHERE location_id = $location_id $cond";
                    $keywordata = $this->connection->execute($sql)->fetchAll("assoc");
                }

                if (!empty($keywordata)) {

                    $grank_total = $grank = $firstplace = $top3 = $top10 = $totalkeywords = 0;
                    $count_date_result = count($keywordata);

                    foreach ($keywordata as $keywordrow) {

                        $trimmed_ranked_url = $this->fully_trim($keywordrow['ranked_url']);

                        $rnk = 50;

                        if (isset($trimmed_ranked_url) && strpos($trimmed_ranked_url, $trimmedurl) !== false) {

                            $rnk = ($keywordrow['rank'] == NULL || empty($keywordrow['rank'])) ? 50 : $keywordrow['rank'];
                        }

                        $grank_total += $rnk;
                        if ($rnk == 1) {
                            $firstplace++;
                        }
                        if ($rnk >= 1 && $rnk <= 3) {
                            $top3++;
                        }
                        if ($rnk >= 1 && $rnk <= 10) {
                            $top10++;
                        }

                        $totalkeywords++;
                    }
                }

                array_push($total_rank_temp, floatval(sprintf("%.2f", ($grank / $totalkeywords) * 100)));
                array_push($top3_ar_temp, intval($top3 != '' ? $top3 : 0));
                array_push($top10_ar_temp, intval($top10 != '' ? $top10 : 0));
                array_push($avg_pos_temp, floatval(sprintf("%.2f", $grank_total / $totalkeywords)));
                array_push($firstPlace_temp, intval($firstplace != '' ? $firstplace : 0));
            }

            array_push($total_rank, array("name" => $trimmedurl, "data" => $total_rank_temp));
            array_push($avg_pos, array("name" => $trimmedurl, "data" => $avg_pos_temp));
            array_push($top3_ar, array("name" => $trimmedurl, "data" => $top3_ar_temp));
            array_push($top10_ar, array("name" => $trimmedurl, "data" => $top10_ar_temp));
            array_push($firstPlace, array("name" => $trimmedurl, "data" => $firstPlace_temp));
        }

        $date_array = array();
        foreach ($month_rank_date_arr as $date) {
            array_push($date_array, date("d M", strtotime($date)));
        }

        $compt_rcrd = array(
            "xAxis" => $date_array,
            "totalRank" => $total_rank,
            "avgPos" => $avg_pos,
            "firstPlace" => $firstPlace,
            "top3" => $top3_ar,
            "top10" => $top10_ar
        );

        return $compt_rcrd;
    }

    public function getLocationCompetitors($location_id) {

        if ($location_id > 0) {

            $this->loadmodel("Competitor");

            $location_details = $this->getLocationDetails($location_id)['website'];

            // get all competitors
            $competitors = $this->Competitor->find("all", ["conditions" => ["location_id" => $location_id], "fields" => ["id", "website"]])->toArray();

            $competitors_array = array();
            $comp_summary = array();
            array_push($competitors_array, array("key" => 0, "website" => $this->fully_trim($location_details)));

            foreach ($competitors as $competitor) {
                array_push($competitors_array, array("key" => $competitor->id, "website" => $this->fully_trim($competitor->website)));
            }
            return $competitors_array;
        } else {

            $this->json(0, "Invalid location id");
        }
    }

    public function getLocationDetails($location_id) {

        $sqlQueryToGetAgencyDetails = "SELECT lc.website,ag.name,ag.email,lc.address,lc.country_id,lc.state_id,lc.city_id,lc.zip_code FROM tbl_agencies ag INNER JOIN tbl_locations lc on ag.id = lc.agency_id where lc.id = :location_id  order by lc.id desc limit 1";

        $details = $this->connection->execute($sqlQueryToGetAgencyDetails, ['location_id' => $location_id])->fetchAll("assoc");

        if (!empty($details)) {
            return $details[0];
        } else {
            return array();
        }
    }

    public function getRankVsTargetLeftSideValue($from_date, $to_date, $location_id, $campaign_id) {

        if ($campaign_id == 0) {
            $cond = 'location_id = ' . $location_id;
        } else {
            if ($this->Keyword->is_valid_campaign($campaign_id)) {
                if ($campaign_id > 0) {
                    $cond = " AND campaign_id = $campaign_id";
                }
            } else {
                $this->json(0, "Invalid Campaign Id");
            }
        }
        $sqlQueryToGetAllGroups = "SELECT id,landing_page FROM tbl_keygroup where $cond";
        $keywordgrps = $this->connection->execute($sqlQueryToGetAllGroups)->fetchAll("assoc");

        $total_target_url = 0;
        $matchedar = array();
        $matched = 0;
        $total_rank_count = 0;
        $total_keywords_count = 0;
        foreach ($keywordgrps as $index => $keywordgrp) {

            $target_url = $this->fully_trim($keywordgrp['landing_page']);
            $target_page = '';
            $group_id = $keywordgrp['id'];

            $sqlToFindAllKeywords = "SELECT * FROM tbl_keywords WHERE group_id = :group_id ORDER BY isprimary DESC";
            $keywords = $this->connection->execute($sqlToFindAllKeywords, ["group_id" => $group_id])->fetchAll("assoc");

            if ($target_url != '') {
                $total_target_url++;
            }

            foreach ($keywords as $index => $keywordrow) {
                $arrranks = array();
                $ranktxt = '50+';
                $rank = 50;
                $rankedurl = '';
                $ranked_url = $this->fully_trim($keywordrow['ranked_url']);
                if (isset($ranked_url) && strpos($ranked_url, $target_url) !== false) {
                    $rank = $keywordrow['rank'];
                    $ranktxt = $rank;
                    $rankedurl = $keywordrow['rankedUrl'];
                    $k++;
                }

                $total_rank_count += $rank;
                $total_keywords_count++;

                if ($rankedurl != '' && $target_url != '') {
                    if ($this->fully_trim($target_url) == $this->fully_trim($rankedurl) && !empty($target_url)) {
                        if (!in_array($target_url, $matchedar)) {
                            $matchedar[] = $target_url;
                        }
                    }
                }
            }
        }
        $matched = count($matchedar);
        $percentage = sprintf("%.2f", ($matched / $total_target_url) * 100);
        $current_avg_rank = floor($total_rank_count / $total_keywords_count);

        $previous_rank_date = date("Y-m", strtotime("-1 months", time()));
        $sql = "SELECT rank,ranked_url FROM tbl_keywords_history WHERE $cond and dateOfRank >= '$previous_rank_date-01 00:00:00' and dateOfRank <= '$previous_rank_date-31 23:59:59' GROUP BY keyword ORDER BY id DESC";
        $previous_rank_key_result = $this->connection->execute($sql)->fetchall("assoc");

        $foundprev = 0;
        $pre_total_rank = 0;
        $prev_total = 0;
        foreach ($previous_rank_key_result as $inx => $historydata) {
            $pre_rank = $historydata['rank'] == NULL || !empty($historydata['rank']) ? 50 : $historydata['rank'];
            $pre_total_rank += $pre_rank;
            $prev_total++;
        }
        $prev_avg_rank = floor($pre_total_rank / $prev_total);
        $change_rank = $prev_avg_rank - $current_avg_rank;

        return array("target_ranking" => array("first" => $total_target_url . "/" . $matched, "second" => $percentage), "avg_rank" => array("first" => $current_avg_rank, "second" => $change_rank));
    }

    public function getRankVsTargetPercentageData($from_date, $to_date, $location_id, $campaign_id) {

        if ($campaign_id == 0) {
            $cond = '';
        } else {
            if ($this->Keyword->is_valid_campaign($campaign_id)) {
                if ($campaign_id > 0) {
                    $cond = " AND campaign_id = $campaign_id";
                }
            } else {
                $this->json(0, "Invalid Campaign Id");
            }
        }

        $new_date = $from_date;
        $rank_date_arr = array();
        $rank_date_arr[] = $new_date;
        while ($new_date < $to_date) {
            $change_date = date('Y-m-d', strtotime($new_date) + 7 * 24 * 3600);
            $new_date = $change_date;
            if ($change_date < $to_date) {
                $rank_date_arr[] = $change_date;
            }
        }
        $rank_date_arr[] = $to_date;
        unset($rank_date_arr[count($rank_date_arr) - 1]);

        $total_rank_data = array();
        $first_place_data = array();
        $top_3_data = array();
        $top_10_data = array();

        $totalmatched = 0;
        $match_percentage = 0;
        $rank_vs_hs_weekly_chart_date_cat = array();
        $rank_vs_hs_weekly_chart_date_data = array();
        foreach ($rank_date_arr as $index_chart_date => $row_chart_date) {

            $last_index = $index_chart_date + 1;
            $DateOfRank1 = $row_chart_date;
            if (isset($rank_date_arr[$index_chart_date + 1])) {
                $DateOfRank2 = $rank_date_arr[$index_chart_date + 1];
            } else {
                $DateOfRank2 = $DateOfRank1;
            }

            // Total Rank
            $sql = "SELECT k.keyword, k.rank,k.ranked_url, g.landing_page FROM tbl_keywords_history k inner join tbl_keygroup g "
                    . "on k.group_id = g.id WHERE k.location_id = $location_id $cond AND k.dateOfRank >= '$DateOfRank1 00:00:00' and k.dateOfRank <= '$DateOfRank2 23:59:59'";

            if (count($rank_date_arr) == $last_index) {

                $sql = "SELECT k.keyword, k.rank,k.ranked_url, g.landing_page FROM tbl_keywords k inner join tbl_keygroup g "
                        . "on k.group_id = g.id WHERE k.location_id = $location_id $cond";
            }
            $keywordata = $this->connection->execute($sql)->fetchAll("assoc");
            if ($index_chart_date == 0 && empty($keywordata)) {
                $sql = "SELECT k.keyword, k.rank,k.ranked_url, g.landing_page FROM tbl_keywords_history k inner join tbl_keygroup g "
                        . "on k.group_id = g.id WHERE k.location_id = $location_id $cond group by k.keyword order by k.dateOfRank desc";

                $keywordata = $this->connection->execute($sql)->fetchAll("assoc");
            }

            $rrankedurl = '';

            if (!empty($keywordata)) {

                $match_ranking_url = array();
                $count_date_result = count($keywordata);
                $matchedurls = array();
                $totlurls = array();

                foreach ($keywordata as $inx => $keywordrow) {

                    $rrankedurl = trim($keywordrow['ranked_url']);
                    $ttarget_url = trim($keywordrow['landing_page']);

                    if ($ttarget_url != '') {
                        if (!in_array($ttarget_url, $totlurls)) {
                            $totlurls[] = $ttarget_url;
                        }
                    }
                    if ($rrankedurl != '' && $ttarget_url != '') {
                        if ($this->fully_trim($ttarget_url) == $this->fully_trim($rrankedurl)) {
                            if (!in_array($ttarget_url, $matchedurls)) {
                                $matchedurls[] = $ttarget_url;
                            }
                        }
                    }
                }
            }

            if (count($matchedurls) > 0) {

                $totalmatched = count($matchedurls);
                $totalurls = count($totlurls);
            }
            $match_percentage = ($totalmatched / $totalurls) * 100;
            array_push($rank_vs_hs_weekly_chart_date_cat, date("d M Y", strtotime($row_chart_date)));
            array_push($rank_vs_hs_weekly_chart_date_data, floatval(sprintf("%.2f", $match_percentage)));
        }

        return array("xAxis" => $rank_vs_hs_weekly_chart_date_cat, "yAxis" => $rank_vs_hs_weekly_chart_date_data);
    }

    public function getRankVsTargetAvgPositionData($from_date, $to_date, $location_id, $campaign_id) {

        if ($campaign_id == 0) {
            $cond = '';
        } else {
            if ($this->Keyword->is_valid_campaign($campaign_id)) {
                if ($campaign_id > 0) {
                    $cond = " AND campaign_id = $campaign_id";
                }
            } else {
                $this->json(0, "Invalid Campaign Id");
            }
        }
        $new_date = $from_date;
        $rank_date_arr = array();
        $rank_date_arr[] = $new_date;
        while ($new_date < $to_date) {
            $change_date = date('Y-m-d', strtotime($new_date) + 7 * 24 * 3600);
            $new_date = $change_date;
            if ($change_date < $to_date) {
                $rank_date_arr[] = $change_date;
            }
        }
        $rank_date_arr[] = $to_date;
        unset($rank_date_arr[count($rank_date_arr) - 1]);

        $total_rank_data = array();
        $first_place_data = array();
        $top_3_data = array();
        $top_10_data = array();

        $gorganic_avg_postion = 0;

        foreach ($rank_date_arr as $index_chart_date => $row_chart_date) {

            $last_index = $index_chart_date + 1;
            $DateOfRank1 = $row_chart_date;
            if (isset($rank_date_arr[$index_chart_date + 1])) {
                $DateOfRank2 = $rank_date_arr[$index_chart_date + 1];
            } else {
                $DateOfRank2 = $DateOfRank1;
            }

            $sql = "SELECT rank, dateOfRank FROM tbl_keywords_history WHERE location_id = " . $location_id . " $cond and dateOfRank > '$DateOfRank1 00:00:00' and dateOfRank <= '$DateOfRank2 23:59:59' group by keyword";
            if (count($rank_date_arr) == $last_index) {
                $sql = "SELECT rank, dateOfRank FROM tbl_keywords WHERE location_id = " . $location_id . " $cond group by keyword";
            }

            $date_result = $this->connection->execute($sql)->fetchAll("assoc");
            if ($index_chart_date == 0 && empty($date_result)) {
                $sql = "SELECT rank, dateOfRank FROM tbl_keywords_history WHERE location_id = " . $location_id . " $cond group by keyword order by dateOfRank desc";
                $date_result = $this->connection->execute($sql)->fetchAll("assoc");
            }

            if (!empty($date_result)) {

                $goranic_rank = 0;
                $total_rank_gorganic = $first_place_rank_gorganic = $top_3_rank_gorganic = $top_10_rank_gorganic = $total_keywords_rank_gorganic = 0;

                $count_date_result = count($date_result);

                foreach ($date_result as $index => $row_result) {

                    // gogole organic rank
                    $goranic_rank = $row_result['rank'];

                    // Google Organic Rank Calculation Start
                    if ($goranic_rank > 0) {
                        $total_rank_gorganic += 1;
                        $total_keywords_rank_gorganic += $goranic_rank;
                    } else {
                        $total_keywords_rank_gorganic += 50;
                    }
                }
                $gorganic_avg_postion = sprintf("%.2f", $total_keywords_rank_gorganic / $count_date_result);
            }

            $avg_postion_gorganic[$row_chart_date] = $gorganic_avg_postion;
        }

        $avg_postion_chart_cat_gorganic = array();
        $avg_postion_chart_data_gorganic = array();
        foreach ($avg_postion_gorganic as $avgpos_gorganic => $curr_gorganic_avgpos) {
            array_push($avg_postion_chart_cat_gorganic, date("d M", strtotime($avgpos_gorganic)));
            array_push($avg_postion_chart_data_gorganic, floatval($curr_gorganic_avgpos));
        }

        return array("xAxis" => $avg_postion_chart_cat_gorganic, "yAxis" => $avg_postion_chart_data_gorganic);
    }

    // this method should be used to run via cron file
    public function runExecutiveSummaryReport() {
        // get timestamps of last 1 year
        $getTimeStats = getTimestampArrayLast1Yr();
        // here we take the location id of the location
        $getActiveLocations = array("location_id" => 8);

        if (count($getActiveLocations) > 0) {

            foreach ($getActiveLocations as $location) {

                $location_id = $location['location_id'];
                $is_avail = 0;
                $row_id = 0;
                $sqlQueryToGetExecutiveHistoryData = "SELECT * from tbl_executive_history_data where location_id = $location_id order by id desc limit 1";
                $getLocationData = $this->connection->execute($sqlQueryToGetExecutiveHistoryData)->fetchAll("assoc");

                if (count($getLocationData) > 0) {
                    $data_parsed = unserialize($getLocationData[0]['data_parsed']);
                    $getMonth = strtotime($data_parsed['month']);
                    $CurrentMonth = strtotime(date("F Y"));
                    if ($getMonth == $CurrentMonth) {
                        $is_avail = 1;
                        $row_id = $getLocationData[0]['id'];
                    }
                }

                foreach ($getTimeStats as $date) {

                    if (strtotime(date("Y-m")) == strtotime($date)) {

                        /* Traffic Data Variable */
                        $traffic_data = 0;
                        /* Keyword Position Variable */
                        $position = 0;
                        /* Keyword Position Variables */
                        $top3 = 0;
                        $top10 = 0;
                        $top20 = 0;
                        $top50 = 0;
                        $top100 = 0;
//--
                        $count_totalRecords = 0;
                        $startDateTimestamp = strtotime($date . "-01");
                        $endDateTimestamp = strtotime($date . "-30");

                        $sqlQueryToGetKewordStats = "SELECT traffic,position from tbl_keyword_research where location_id = $location_id AND created >= $startDateTimestamp AND created <= $endDateTimestamp";
                        $get_keywordOppurtunity = $this->connection->execute($sqlQueryToGetKewordStats)->fetchAll("assoc");

                        foreach ($get_keywordOppurtunity as $index => $data) {

                            /* Top 3 Keywords */
                            if ($data['position'] >= 1 && $data['position'] <= 3) {
                                $top3++;
                            }
                            /* Top 4-10 Keywords */
                            if ($data['position'] >= 4 && $data['position'] <= 10) {
                                $top10++;
                            }
                            /* Top 11-20 Keywords */
                            if ($data['position'] >= 11 && $data['position'] <= 20) {
                                $top20++;
                            }
                            /* Top 21-50 Keywords */
                            if ($data['position'] >= 21 && $data['position'] <= 50) {
                                $top50++;
                            }
                            /* Top 51-100 Keywords */
                            if ($data['position'] >= 51 && $data['position'] <= 100) {
                                $top100++;
                            }
                            $position += $data['position'];
                            $count_totalRecords++;
                        }

                        $from_date = $date . "-01";
                        $to_date = $date . "-30";

                        if ($this->is_dbtable_exists("api_short_analytics_$location_id")) {
                            
                            $sqlQueryToGetAddShortAnalyticsData = "SELECT * from api_short_analytics_$location_id where DateOfVisit >='$from_date' AND DateOfVisit <= '$to_date'";

                            $getAnalyticsData = $this->connection->execute($sqlQueryToGetAddShortAnalyticsData)->fetchAll("assoc");

                            foreach ($getAnalyticsData as $index => $value) {
                                $traffic_data += $value['total'];
                            }
                        }

                        /* serializing array */
                        $serialized = serialize(array(
                            "month" => date("F Y", strtotime($date)),
                            "locationid" => $location_id,
                            "traffic" => $traffic_data,
                            "position" => $position,
                            "top3" => $top3,
                            "top10" => $top10,
                            "top20" => $top20,
                            "top50" => $top50,
                            "top100" => $top100
                        ));

                        if ($is_avail) {
                            // update for new record
                            $updateExecutiveHistoryData = "UPDATE tbl_executive_history_data SET data_parsed = '" . $serialized . "' where location_id = " . $location_id . " AND id = " . $row_id;
                        } else {
                            // insert new record
                            $insertExecutiveReport = "INSERT INTO tbl_executive_history_data (location_id,data_parsed,type) VALUES (" . $location_id . ",'" . $serialized . "','')";
                        }

                        $this->connection->execute($updateExecutiveHistoryData);
                    }
                }
            }
        }
    }

    // this method is used get data which saved from above step
    public function getExecutiveSummaryReport($location_id) {

        if ($location_id > 0) {

            $sqlQueryToGetExecutiveData = "SELECT * FROM tbl_executive_history_data WHERE location_id = $location_id";

            $getdatas = $this->connection->execute($sqlQueryToGetExecutiveData)->fetchAll("assoc");
            $jsonmonth = $jsontraffic = $jsonrank = $jsontop3 = $jsontop10 = $jsontop20 = $jsontop50 = $jsontop100 = array();

            foreach ($getdatas as $index => $data) {

                $unserial_data = unserialize($data['data_parsed']);
                if ($unserial_data['traffic'] == 0) {
                    $unserial_data['traffic'] = null;
                }
                if ($unserial_data['position'] == 0) {
                    $unserial_data['position'] = null;
                }
                if ($unserial_data['top3'] == 0) {
                    $unserial_data['top3'] = null;
                }
                if ($unserial_data['top10'] == 0) {
                    $unserial_data['top10'] = null;
                }
                if ($unserial_data['top20'] == 0) {
                    $unserial_data['top20'] = null;
                }
                if ($unserial_data['top50'] == 0) {
                    $unserial_data['top50'] = null;
                }
                if ($unserial_data['top100'] == 0) {
                    $unserial_data['top100'] = null;
                }

                array_push($jsonmonth, $unserial_data['month']);
                array_push($jsontraffic, $unserial_data['traffic']);
                array_push($jsonrank, $unserial_data['position']);
                array_push($jsontop3, $unserial_data['top3']);
                array_push($jsontop10, $unserial_data['top10']);
                array_push($jsontop20, $unserial_data['top20']);
                array_push($jsontop50, $unserial_data['top50']);
                array_push($jsontop100, $unserial_data['top100']);
            }

            return array(
                "xAxis" => $jsonmonth,
                "seo" => array(
                    "name" => "Total Seo Traffic",
                    "data" => $jsontraffic
                ),
                "rank" => array(
                    "name" => "Total Keywords Ranking",
                    "data" => $jsonrank
                ),
                "top" => array(
                    array(
                        "name" => "Top 3",
                        "data" => $jsontop3
                    ),
                    array(
                        "name" => "Top 4-10",
                        "data" => $jsontop10
                    ),
                    array(
                        "name" => "Top 11-20",
                        "data" => $jsontop20
                    ),
                    array(
                        "name" => "Top 21-50",
                        "data" => $jsontop50
                    ),
                    array(
                        "name" => "Top 51-100",
                        "data" => $jsontop100
                    )
                )
            );
        } else {

            $this->json(0, "Invalid location id");
        }
    }

    public function getTimestampArrayLast1Yr() {
        /* date */
        $currentMonth = date("Y-m-d");
        $last1yrdatefromCurrent = date("Y-m-d", strtotime("-11 months"));
        /* timestamps */
        $currentMonthTimestamp = strtotime($currentMonth);
        $last1yrdatefromCurrentTimestamp = strtotime($last1yrdatefromCurrent);
        /* timestamp array */
        $uniqueTimestap_array = array();
        /* db Query */

        $start = new \DateTime($last1yrdatefromCurrent);
        $start->modify('first day of this month');
        $end = new \DateTime($currentMonth);
        $end->modify('first day of next month');
        $interval = \DateInterval::createFromDateString('1 month');
        $period = new \DatePeriod($start, $interval, $end);

        foreach ($period as $dt) {
            array_push($uniqueTimestap_array, $dt->format("Y-m"));
        }

        return $uniqueTimestap_array;
    }

}

?>
